package a2;

import S8.U;
import c2.f;
import com.algolia.search.model.internal.request.RequestMultipleQueries$Companion;
import java.util.List;
import s8.AbstractC1420h;
import u0.AbstractC1480a;

/* renamed from: a2.a */
/* loaded from: classes.dex */
public final class C0340a {
    public static final RequestMultipleQueries$Companion Companion = new RequestMultipleQueries$Companion();

    /* renamed from: c */
    public static final U f5873c;

    /* renamed from: a */
    public final List f5874a;

    /* renamed from: b */
    public final f f5875b;

    static {
        U uF = AbstractC1480a.f("com.algolia.search.model.internal.request.RequestMultipleQueries", null, 2, "requests", false);
        uF.m("strategy", true);
        f5873c = uF;
    }

    public C0340a(List list, f fVar) {
        AbstractC1420h.f(list, "indexQueries");
        this.f5874a = list;
        this.f5875b = fVar;
    }
}
