package A2;

import android.content.Context;
import java.security.MessageDigest;
import s2.m;
import u2.z;

/* loaded from: classes.dex */
public final class e implements m {

    /* renamed from: b, reason: collision with root package name */
    public static final e f17b = new e();

    @Override // s2.f
    public final void b(MessageDigest messageDigest) {
    }

    @Override // s2.m
    public final z a(Context context, z zVar, int i10, int i11) {
        return zVar;
    }
}
