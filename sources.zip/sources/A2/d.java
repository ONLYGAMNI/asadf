package A2;

import B2.n;
import B2.p;
import B2.v;
import android.graphics.ColorSpace;
import android.graphics.ImageDecoder;
import android.graphics.ImageDecoder$OnHeaderDecodedListener;
import android.os.Build;
import android.util.Log;
import android.util.Size;
import s2.EnumC1396a;
import s2.h;
import s2.i;
import s2.j;

/* loaded from: classes.dex */
public final class d implements ImageDecoder$OnHeaderDecodedListener {

    /* renamed from: a */
    public final v f12a = v.a();

    /* renamed from: b */
    public final int f13b;

    /* renamed from: c */
    public final int f14c;
    public final EnumC1396a d;

    /* renamed from: e */
    public final n f15e;

    /* renamed from: f */
    public final boolean f16f;
    public final j g;

    public d(int i10, int i11, i iVar) {
        this.f13b = i10;
        this.f14c = i11;
        this.d = (EnumC1396a) iVar.c(p.f146f);
        this.f15e = (n) iVar.c(n.g);
        h hVar = p.f148i;
        this.f16f = iVar.c(hVar) != null && ((Boolean) iVar.c(hVar)).booleanValue();
        this.g = (j) iVar.c(p.g);
    }

    public final void onHeaderDecoded(ImageDecoder imageDecoder, ImageDecoder.ImageInfo imageInfo, ImageDecoder.Source source) {
        if (this.f12a.c(this.f13b, this.f14c, this.f16f, false)) {
            imageDecoder.setAllocator(3);
        } else {
            imageDecoder.setAllocator(1);
        }
        if (this.d == EnumC1396a.f14905b) {
            imageDecoder.setMemorySizePolicy(0);
        }
        imageDecoder.setOnPartialImageListener(new c());
        Size size = imageInfo.getSize();
        int width = this.f13b;
        if (width == Integer.MIN_VALUE) {
            width = size.getWidth();
        }
        int height = this.f14c;
        if (height == Integer.MIN_VALUE) {
            height = size.getHeight();
        }
        float fB = this.f15e.b(size.getWidth(), size.getHeight(), width, height);
        int iRound = Math.round(size.getWidth() * fB);
        int iRound2 = Math.round(size.getHeight() * fB);
        if (Log.isLoggable("ImageDecoder", 2)) {
            Log.v("ImageDecoder", "Resizing from [" + size.getWidth() + "x" + size.getHeight() + "] to [" + iRound + "x" + iRound2 + "] scaleFactor: " + fB);
        }
        imageDecoder.setTargetSize(iRound, iRound2);
        j jVar = this.g;
        if (jVar != null) {
            int i10 = Build.VERSION.SDK_INT;
            if (i10 >= 28) {
                imageDecoder.setTargetColorSpace(ColorSpace.get((jVar == j.f14914a && imageInfo.getColorSpace() != null && imageInfo.getColorSpace().isWideGamut()) ? ColorSpace.Named.DISPLAY_P3 : ColorSpace.Named.SRGB));
            } else if (i10 >= 26) {
                imageDecoder.setTargetColorSpace(ColorSpace.get(ColorSpace.Named.SRGB));
            }
        }
    }
}
