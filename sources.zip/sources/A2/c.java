package A2;

import android.graphics.ImageDecoder;
import android.graphics.ImageDecoder$OnPartialImageListener;

/* loaded from: classes.dex */
public final class c implements ImageDecoder$OnPartialImageListener {
    public final boolean onPartialImage(ImageDecoder.DecodeException decodeException) {
        return false;
    }
}
