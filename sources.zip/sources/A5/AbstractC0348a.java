package a5;

import E5.t;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import java.util.concurrent.atomic.AtomicBoolean;
import m.ExecutorC1188a;

/* renamed from: a5.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0348a {

    /* renamed from: a, reason: collision with root package name */
    public static final ExecutorC1188a f5936a = new ExecutorC1188a(1);

    public static Task a(Task task, Task task2) {
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource(cancellationTokenSource.getToken());
        t tVar = new t(taskCompletionSource, new AtomicBoolean(false), cancellationTokenSource, 6);
        ExecutorC1188a executorC1188a = f5936a;
        task.continueWithTask(executorC1188a, tVar);
        task2.continueWithTask(executorC1188a, tVar);
        return taskCompletionSource.getTask();
    }
}
