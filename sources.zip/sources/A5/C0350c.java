package a5;

import android.util.Log;
import com.google.android.gms.tasks.Tasks;
import java.util.concurrent.ExecutorService;
import s8.AbstractC1420h;
import z8.f;

/* renamed from: a5.c */
/* loaded from: classes.dex */
public final class C0350c {

    /* renamed from: a */
    public final ExecutorC0349b f5940a;

    /* renamed from: b */
    public final ExecutorC0349b f5941b;

    /* renamed from: c */
    public final ExecutorC0349b f5942c;

    public C0350c(ExecutorService executorService, ExecutorService executorService2) {
        AbstractC1420h.f(executorService, "backgroundExecutorService");
        AbstractC1420h.f(executorService2, "blockingExecutorService");
        this.f5940a = new ExecutorC0349b(executorService);
        this.f5941b = new ExecutorC0349b(executorService);
        Tasks.forResult(null);
        this.f5942c = new ExecutorC0349b(executorService2);
    }

    public static final void a() {
        String name = Thread.currentThread().getName();
        AbstractC1420h.e(name, "threadName");
        if (Boolean.valueOf(f.B0(name, "Firebase Background Thread #", false)).booleanValue()) {
            return;
        }
        String str = "Must be called on a background thread, was called on " + Thread.currentThread().getName() + '.';
        if (Log.isLoggable("FirebaseCrashlytics", 3)) {
            Log.d("FirebaseCrashlytics", str, null);
        }
    }

    public static final void b() {
        String name = Thread.currentThread().getName();
        AbstractC1420h.e(name, "threadName");
        if (Boolean.valueOf(f.B0(name, "Firebase Blocking Thread #", false)).booleanValue()) {
            return;
        }
        String str = "Must be called on a blocking thread, was called on " + Thread.currentThread().getName() + '.';
        if (Log.isLoggable("FirebaseCrashlytics", 3)) {
            Log.d("FirebaseCrashlytics", str, null);
        }
    }
}
