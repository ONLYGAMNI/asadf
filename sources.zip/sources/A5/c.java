package A5;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final String f40a;

    /* renamed from: b, reason: collision with root package name */
    public final long f41b;

    /* renamed from: c, reason: collision with root package name */
    public final int f42c;

    public c(String str, long j10, int i10) {
        this.f40a = str;
        this.f41b = j10;
        this.f42c = i10;
    }

    public static b a() {
        b bVar = new b(0, (byte) 0);
        bVar.d = 0L;
        return bVar;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        String str = this.f40a;
        if (str != null ? str.equals(cVar.f40a) : cVar.f40a == null) {
            if (this.f41b == cVar.f41b) {
                int i10 = cVar.f42c;
                int i11 = this.f42c;
                if (i11 == 0) {
                    if (i10 == 0) {
                        return true;
                    }
                } else if (t.e.a(i11, i10)) {
                    return true;
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        String str = this.f40a;
        int iHashCode = str == null ? 0 : str.hashCode();
        long j10 = this.f41b;
        int i10 = (((iHashCode ^ 1000003) * 1000003) ^ ((int) (j10 ^ (j10 >>> 32)))) * 1000003;
        int i11 = this.f42c;
        return (i11 != 0 ? t.e.d(i11) : 0) ^ i10;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("TokenResult{token=");
        sb.append(this.f40a);
        sb.append(", tokenExpirationTimestamp=");
        sb.append(this.f41b);
        sb.append(", responseCode=");
        int i10 = this.f42c;
        sb.append(i10 != 1 ? i10 != 2 ? i10 != 3 ? "null" : "AUTH_ERROR" : "BAD_CONFIG" : "OK");
        sb.append("}");
        return sb.toString();
    }
}
