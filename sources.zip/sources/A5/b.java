package A5;

import Q8.m;
import R.X;
import U8.j;
import V.f;
import a.AbstractC0338a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;
import e.AbstractC0764a;
import java.io.File;
import k6.z;
import kotlinx.serialization.descriptors.SerialDescriptor;
import l.AbstractC1146p0;
import l.C1150s;
import l.g1;
import r3.C1352h;
import s8.AbstractC1420h;
import u2.C1497l;
import z0.C1688b;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a */
    public final /* synthetic */ int f37a;

    /* renamed from: b */
    public int f38b;

    /* renamed from: c */
    public Object f39c;
    public Object d;

    public /* synthetic */ b(int i10, byte b7) {
        this.f37a = i10;
    }

    /* JADX WARN: Code restructure failed: missing block: B:226:0x01cf, code lost:
    
        if (r14.size() <= 0) goto L228;
     */
    /* JADX WARN: Code restructure failed: missing block: B:227:0x01d1, code lost:
    
        r0 = new X0.e(r14, r15);
     */
    /* JADX WARN: Code restructure failed: missing block: B:228:0x01d7, code lost:
    
        r0 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:229:0x01d8, code lost:
    
        if (r0 == null) goto L231;
     */
    /* JADX WARN: Code restructure failed: missing block: B:231:0x01dc, code lost:
    
        if (r19 == false) goto L233;
     */
    /* JADX WARN: Code restructure failed: missing block: B:232:0x01de, code lost:
    
        r0 = new X0.e(r6, r9, r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:233:0x01e4, code lost:
    
        r0 = new X0.e(r6, r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:234:0x01ea, code lost:
    
        if (r8 == 1) goto L246;
     */
    /* JADX WARN: Code restructure failed: missing block: B:236:0x01ed, code lost:
    
        if (r8 == 2) goto L245;
     */
    /* JADX WARN: Code restructure failed: missing block: B:238:0x01f1, code lost:
    
        if (r5 == 1) goto L243;
     */
    /* JADX WARN: Code restructure failed: missing block: B:239:0x01f3, code lost:
    
        if (r5 == 2) goto L242;
     */
    /* JADX WARN: Code restructure failed: missing block: B:240:0x01f5, code lost:
    
        r1 = android.graphics.Shader.TileMode.CLAMP;
     */
    /* JADX WARN: Code restructure failed: missing block: B:241:0x01f7, code lost:
    
        r17 = r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:242:0x01fa, code lost:
    
        r1 = android.graphics.Shader.TileMode.MIRROR;
     */
    /* JADX WARN: Code restructure failed: missing block: B:243:0x01fd, code lost:
    
        r1 = android.graphics.Shader.TileMode.REPEAT;
     */
    /* JADX WARN: Code restructure failed: missing block: B:244:0x0200, code lost:
    
        r1 = 0;
        r3 = new android.graphics.LinearGradient(r11, r27, r26, r25, (int[]) r0.f5309b, (float[]) r0.f5310c, r17);
     */
    /* JADX WARN: Code restructure failed: missing block: B:245:0x0217, code lost:
    
        r1 = 0;
        r3 = new android.graphics.SweepGradient(r22, r23, (int[]) r0.f5309b, (float[]) r0.f5310c);
     */
    /* JADX WARN: Code restructure failed: missing block: B:246:0x022a, code lost:
    
        r9 = r22;
        r15 = r23;
        r1 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:247:0x0232, code lost:
    
        if (r24 <= 0.0f) goto L259;
     */
    /* JADX WARN: Code restructure failed: missing block: B:249:0x0237, code lost:
    
        if (r5 == 1) goto L255;
     */
    /* JADX WARN: Code restructure failed: missing block: B:251:0x023a, code lost:
    
        if (r5 == 2) goto L254;
     */
    /* JADX WARN: Code restructure failed: missing block: B:252:0x023c, code lost:
    
        r2 = android.graphics.Shader.TileMode.CLAMP;
     */
    /* JADX WARN: Code restructure failed: missing block: B:254:0x0241, code lost:
    
        r2 = android.graphics.Shader.TileMode.MIRROR;
     */
    /* JADX WARN: Code restructure failed: missing block: B:255:0x0244, code lost:
    
        r2 = android.graphics.Shader.TileMode.REPEAT;
     */
    /* JADX WARN: Code restructure failed: missing block: B:256:0x0247, code lost:
    
        r3 = new android.graphics.RadialGradient(r9, r15, r24, (int[]) r0.f5309b, (float[]) r0.f5310c, r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:258:0x0264, code lost:
    
        return new A5.b(r3, null, r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:260:0x026c, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static A5.b d(android.content.res.Resources r29, int r30, android.content.res.Resources.Theme r31) throws org.xmlpull.v1.XmlPullParserException, android.content.res.Resources.NotFoundException, java.io.IOException {
        /*
            Method dump skipped, instructions count: 659
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A5.b.d(android.content.res.Resources, int, android.content.res.Resources$Theme):A5.b");
    }

    public static void e(String str) {
        if (str.equalsIgnoreCase(":memory:")) {
            return;
        }
        int length = str.length() - 1;
        int i10 = 0;
        boolean z3 = false;
        while (i10 <= length) {
            boolean z9 = AbstractC1420h.h(str.charAt(!z3 ? i10 : length), 32) <= 0;
            if (z3) {
                if (!z9) {
                    break;
                } else {
                    length--;
                }
            } else if (z9) {
                i10++;
            } else {
                z3 = true;
            }
        }
        if (str.subSequence(i10, length + 1).toString().length() == 0) {
            return;
        }
        Log.w("SupportSQLite", "deleting the database file: ".concat(str));
        try {
            SQLiteDatabase.deleteDatabase(new File(str));
        } catch (Exception e4) {
            Log.w("SupportSQLite", "delete failed: ", e4);
        }
    }

    public void a(Object obj) {
        int i10 = this.f38b;
        if (i10 == 4) {
            Object[] objArr = new Object[5];
            ((Object[]) this.d)[4] = objArr;
            this.d = objArr;
            i10 = 0;
        }
        ((Object[]) this.d)[i10] = obj;
        this.f38b = i10 + 1;
    }

    public void b() {
        g1 g1Var;
        ImageView imageView = (ImageView) this.f39c;
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            AbstractC1146p0.a(drawable);
        }
        if (drawable == null || (g1Var = (g1) this.d) == null) {
            return;
        }
        C1150s.e(drawable, g1Var, imageView.getDrawableState());
    }

    public c c() {
        String str = ((Long) this.d) == null ? " tokenExpirationTimestamp" : "";
        if (str.isEmpty()) {
            return new c((String) this.f39c, ((Long) this.d).longValue(), this.f38b);
        }
        throw new IllegalStateException("Missing required properties:".concat(str));
    }

    public String f() {
        StringBuilder sb = new StringBuilder("$");
        int i10 = this.f38b + 1;
        for (int i11 = 0; i11 < i10; i11++) {
            Object obj = ((Object[]) this.f39c)[i11];
            if (obj instanceof SerialDescriptor) {
                SerialDescriptor serialDescriptor = (SerialDescriptor) obj;
                if (!AbstractC1420h.a(serialDescriptor.c(), m.f3945o)) {
                    int i12 = ((int[]) this.d)[i11];
                    if (i12 >= 0) {
                        sb.append(".");
                        sb.append(serialDescriptor.f(i12));
                    }
                } else if (((int[]) this.d)[i11] != -1) {
                    sb.append("[");
                    sb.append(((int[]) this.d)[i11]);
                    sb.append("]");
                }
            } else if (obj != j.f4979a) {
                sb.append("['");
                sb.append(obj);
                sb.append("']");
            }
        }
        String string = sb.toString();
        AbstractC1420h.e(string, "StringBuilder().apply(builderAction).toString()");
        return string;
    }

    public boolean g() {
        ColorStateList colorStateList;
        return ((Shader) this.f39c) == null && (colorStateList = (ColorStateList) this.d) != null && colorStateList.isStateful();
    }

    public void h(AttributeSet attributeSet, int i10) {
        int resourceId;
        ImageView imageView = (ImageView) this.f39c;
        Context context = imageView.getContext();
        int[] iArr = AbstractC0764a.f10126f;
        z zVarJ = z.j(context, attributeSet, iArr, i10, 0);
        X.m(imageView, imageView.getContext(), iArr, attributeSet, (TypedArray) zVarJ.f12479c, i10);
        try {
            Drawable drawable = imageView.getDrawable();
            TypedArray typedArray = (TypedArray) zVarJ.f12479c;
            if (drawable == null && (resourceId = typedArray.getResourceId(1, -1)) != -1 && (drawable = AbstractC0338a.s(imageView.getContext(), resourceId)) != null) {
                imageView.setImageDrawable(drawable);
            }
            if (drawable != null) {
                AbstractC1146p0.a(drawable);
            }
            if (typedArray.hasValue(2)) {
                f.c(imageView, zVarJ.e(2));
            }
            if (typedArray.hasValue(3)) {
                f.d(imageView, AbstractC1146p0.b(typedArray.getInt(3, -1), null));
            }
            zVarJ.k();
        } catch (Throwable th) {
            zVarJ.k();
            throw th;
        }
    }

    public void i(E0.c cVar) {
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x0017  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void j(E0.c r5) {
        /*
            r4 = this;
            java.lang.String r0 = "SELECT count(*) FROM sqlite_master WHERE name != 'android_metadata'"
            android.database.Cursor r0 = r5.f0(r0)
            boolean r1 = r0.moveToFirst()     // Catch: java.lang.Throwable -> L15
            r2 = 0
            if (r1 == 0) goto L17
            int r1 = r0.getInt(r2)     // Catch: java.lang.Throwable -> L15
            if (r1 != 0) goto L17
            r1 = 1
            goto L18
        L15:
            r5 = move-exception
            goto L6e
        L17:
            r1 = r2
        L18:
            r3 = 0
            android.support.v4.media.session.b.g(r0, r3)
            java.lang.Object r0 = r4.d
            B.b r0 = (B.b) r0
            r0.getClass()
            B.b.o(r5)
            if (r1 != 0) goto L47
            f3.a r1 = B.b.s(r5)
            boolean r3 = r1.f10554b
            if (r3 == 0) goto L31
            goto L47
        L31:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r2 = "Pre-packaged database has an invalid schema: "
            r0.<init>(r2)
            java.lang.String r1 = r1.f10555c
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r5.<init>(r0)
            throw r5
        L47:
            java.lang.String r1 = "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)"
            r5.R(r1)
            java.lang.String r1 = "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '5181942b9ebc31ce68dacb56c16fd79f')"
            r5.R(r1)
            java.lang.Object r5 = r0.f65b
            androidx.work.impl.WorkDatabase_Impl r5 = (androidx.work.impl.WorkDatabase_Impl) r5
            java.util.List r0 = r5.f7340f
            if (r0 == 0) goto L6d
            int r0 = r0.size()
        L5d:
            if (r2 >= r0) goto L6d
            java.util.List r1 = r5.f7340f
            java.lang.Object r1 = r1.get(r2)
            P0.b r1 = (P0.b) r1
            r1.getClass()
            int r2 = r2 + 1
            goto L5d
        L6d:
            return
        L6e:
            throw r5     // Catch: java.lang.Throwable -> L6f
        L6f:
            r1 = move-exception
            android.support.v4.media.session.b.g(r0, r5)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: A5.b.j(E0.c):void");
    }

    public void k(E0.c cVar, int i10, int i11) {
        m(cVar, i10, i11);
    }

    /* JADX WARN: Removed duplicated region for block: B:88:0x0019  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void l(E0.c r10) {
        /*
            Method dump skipped, instructions count: 302
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A5.b.l(E0.c):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:129:0x0043  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x0041 A[EDGE_INSN: B:204:0x0041->B:128:0x0041 BREAK  A[LOOP:3: B:122:0x002a->B:207:?], SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void m(E0.c r17, int r18, int r19) {
        /*
            Method dump skipped, instructions count: 415
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: A5.b.m(E0.c, int, int):void");
    }

    public void n(int i10) {
        ImageView imageView = (ImageView) this.f39c;
        if (i10 != 0) {
            Drawable drawableS = AbstractC0338a.s(imageView.getContext(), i10);
            if (drawableS != null) {
                AbstractC1146p0.a(drawableS);
            }
            imageView.setImageDrawable(drawableS);
        } else {
            imageView.setImageDrawable(null);
        }
        b();
    }

    public String toString() {
        switch (this.f37a) {
            case 2:
                return f();
            default:
                return super.toString();
        }
    }

    public b(C1688b c1688b, B.b bVar) {
        this.f37a = 6;
        this.f37a = 6;
        this.f38b = 16;
        this.f39c = c1688b;
        this.d = bVar;
    }

    public b() {
        this.f37a = 3;
        Object[] objArr = new Object[5];
        this.f39c = objArr;
        this.d = objArr;
    }

    public b(ImageView imageView) {
        this.f37a = 4;
        this.f38b = 0;
        this.f39c = imageView;
    }

    public b(Shader shader, ColorStateList colorStateList, int i10) {
        this.f37a = 1;
        this.f39c = shader;
        this.d = colorStateList;
        this.f38b = i10;
    }

    public b(C1352h c1352h) {
        this.f37a = 5;
        this.d = O2.c.a(150, new C1497l(this, 0));
        this.f39c = c1352h;
    }
}
