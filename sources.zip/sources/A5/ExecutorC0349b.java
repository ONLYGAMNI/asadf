package a5;

import D6.p;
import Z4.k;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

/* renamed from: a5.b */
/* loaded from: classes.dex */
public final class ExecutorC0349b implements Executor {

    /* renamed from: a */
    public final ExecutorService f5937a;

    /* renamed from: b */
    public final Object f5938b = new Object();

    /* renamed from: c */
    public Task f5939c = Tasks.forResult(null);

    public ExecutorC0349b(ExecutorService executorService) {
        this.f5937a = executorService;
    }

    public final Task a(Runnable runnable) {
        Task taskContinueWithTask;
        synchronized (this.f5938b) {
            taskContinueWithTask = this.f5939c.continueWithTask(this.f5937a, new p(runnable, 25));
            this.f5939c = taskContinueWithTask;
        }
        return taskContinueWithTask;
    }

    public final Task b(k kVar) {
        Task taskContinueWithTask;
        synchronized (this.f5938b) {
            taskContinueWithTask = this.f5939c.continueWithTask(this.f5937a, new p(kVar, 24));
            this.f5939c = taskContinueWithTask;
        }
        return taskContinueWithTask;
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.f5937a.execute(runnable);
    }
}
