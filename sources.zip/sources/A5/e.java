package A5;

import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import y5.i;

/* loaded from: classes.dex */
public final class e {
    public static final long d = TimeUnit.HOURS.toMillis(24);

    /* renamed from: e, reason: collision with root package name */
    public static final long f47e = TimeUnit.MINUTES.toMillis(30);

    /* renamed from: a, reason: collision with root package name */
    public final i f48a;

    /* renamed from: b, reason: collision with root package name */
    public long f49b;

    /* renamed from: c, reason: collision with root package name */
    public int f50c;

    public e() {
        if (v5.d.f15719b == null) {
            Pattern pattern = i.f16387c;
            v5.d.f15719b = new v5.d(3);
        }
        v5.d dVar = v5.d.f15719b;
        if (i.d == null) {
            i.d = new i(dVar);
        }
        this.f48a = i.d;
    }

    public final synchronized long a(int i10) {
        if (!(i10 == 429 || (i10 >= 500 && i10 < 600))) {
            return d;
        }
        double dPow = Math.pow(2.0d, this.f50c);
        this.f48a.getClass();
        return (long) Math.min(dPow + ((long) (Math.random() * 1000.0d)), f47e);
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x001b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final synchronized boolean b() {
        /*
            r4 = this;
            monitor-enter(r4)
            int r0 = r4.f50c     // Catch: java.lang.Throwable -> L19
            if (r0 == 0) goto L1b
            y5.i r0 = r4.f48a     // Catch: java.lang.Throwable -> L19
            v5.d r0 = r0.f16388a     // Catch: java.lang.Throwable -> L19
            r0.getClass()     // Catch: java.lang.Throwable -> L19
            long r0 = java.lang.System.currentTimeMillis()     // Catch: java.lang.Throwable -> L19
            long r2 = r4.f49b     // Catch: java.lang.Throwable -> L19
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 <= 0) goto L17
            goto L1b
        L17:
            r0 = 0
            goto L1c
        L19:
            r0 = move-exception
            goto L1e
        L1b:
            r0 = 1
        L1c:
            monitor-exit(r4)
            return r0
        L1e:
            monitor-exit(r4)     // Catch: java.lang.Throwable -> L19
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: A5.e.b():boolean");
    }

    public final synchronized void c() {
        this.f50c = 0;
    }

    public final synchronized void d(int i10) {
        if ((i10 >= 200 && i10 < 300) || i10 == 401 || i10 == 404) {
            c();
            return;
        }
        this.f50c++;
        long jA = a(i10);
        this.f48a.f16388a.getClass();
        this.f49b = System.currentTimeMillis() + jA;
    }
}
