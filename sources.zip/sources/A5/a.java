package A5;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final String f33a;

    /* renamed from: b, reason: collision with root package name */
    public final String f34b;

    /* renamed from: c, reason: collision with root package name */
    public final String f35c;
    public final c d;

    /* renamed from: e, reason: collision with root package name */
    public final int f36e;

    public a(String str, String str2, String str3, c cVar, int i10) {
        this.f33a = str;
        this.f34b = str2;
        this.f35c = str3;
        this.d = cVar;
        this.f36e = i10;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        String str = this.f33a;
        if (str != null ? str.equals(aVar.f33a) : aVar.f33a == null) {
            String str2 = this.f34b;
            if (str2 != null ? str2.equals(aVar.f34b) : aVar.f34b == null) {
                String str3 = this.f35c;
                if (str3 != null ? str3.equals(aVar.f35c) : aVar.f35c == null) {
                    c cVar = this.d;
                    if (cVar != null ? cVar.equals(aVar.d) : aVar.d == null) {
                        int i10 = this.f36e;
                        if (i10 == 0) {
                            if (aVar.f36e == 0) {
                                return true;
                            }
                        } else if (t.e.a(i10, aVar.f36e)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public final int hashCode() {
        String str = this.f33a;
        int iHashCode = ((str == null ? 0 : str.hashCode()) ^ 1000003) * 1000003;
        String str2 = this.f34b;
        int iHashCode2 = (iHashCode ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.f35c;
        int iHashCode3 = (iHashCode2 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        c cVar = this.d;
        int iHashCode4 = (iHashCode3 ^ (cVar == null ? 0 : cVar.hashCode())) * 1000003;
        int i10 = this.f36e;
        return (i10 != 0 ? t.e.d(i10) : 0) ^ iHashCode4;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("InstallationResponse{uri=");
        sb.append(this.f33a);
        sb.append(", fid=");
        sb.append(this.f34b);
        sb.append(", refreshToken=");
        sb.append(this.f35c);
        sb.append(", authToken=");
        sb.append(this.d);
        sb.append(", responseCode=");
        int i10 = this.f36e;
        sb.append(i10 != 1 ? i10 != 2 ? "null" : "BAD_CONFIG" : "OK");
        sb.append("}");
        return sb.toString();
    }
}
