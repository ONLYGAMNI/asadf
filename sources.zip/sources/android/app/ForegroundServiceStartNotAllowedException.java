package android.app;

import android.os.Parcelable;

/* loaded from: classes.dex */
public final /* synthetic */ class ForegroundServiceStartNotAllowedException extends ServiceStartNotAllowedException implements Parcelable {
    static {
        throw new NoClassDefFoundError();
    }
}
