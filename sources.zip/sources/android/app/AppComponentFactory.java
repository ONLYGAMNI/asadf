package android.app;

/* loaded from: classes.dex */
public /* synthetic */ class AppComponentFactory {
    static {
        throw new NoClassDefFoundError();
    }
}
