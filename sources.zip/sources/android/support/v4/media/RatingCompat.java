package android.support.v4.media;

import S3.b;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new b(6);

    /* renamed from: a, reason: collision with root package name */
    public final int f5961a;

    /* renamed from: b, reason: collision with root package name */
    public final float f5962b;

    public RatingCompat(int i10, float f10) {
        this.f5961a = i10;
        this.f5962b = f10;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return this.f5961a;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("Rating:style=");
        sb.append(this.f5961a);
        sb.append(" rating=");
        float f10 = this.f5962b;
        sb.append(f10 < 0.0f ? "unrated" : String.valueOf(f10));
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f5961a);
        parcel.writeFloat(this.f5962b);
    }
}
