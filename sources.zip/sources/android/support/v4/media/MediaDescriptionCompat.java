package android.support.v4.media;

import S3.b;
import android.graphics.Bitmap;
import android.media.MediaDescription;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class MediaDescriptionCompat implements Parcelable {
    public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new b(4);

    /* renamed from: a, reason: collision with root package name */
    public final String f5952a;

    /* renamed from: b, reason: collision with root package name */
    public final CharSequence f5953b;

    /* renamed from: c, reason: collision with root package name */
    public final CharSequence f5954c;
    public final CharSequence d;

    /* renamed from: e, reason: collision with root package name */
    public final Bitmap f5955e;

    /* renamed from: f, reason: collision with root package name */
    public final Uri f5956f;

    /* renamed from: n, reason: collision with root package name */
    public final Bundle f5957n;

    /* renamed from: o, reason: collision with root package name */
    public final Uri f5958o;

    /* renamed from: p, reason: collision with root package name */
    public Object f5959p;

    public MediaDescriptionCompat(String str, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, Bitmap bitmap, Uri uri, Bundle bundle, Uri uri2) {
        this.f5952a = str;
        this.f5953b = charSequence;
        this.f5954c = charSequence2;
        this.d = charSequence3;
        this.f5955e = bitmap;
        this.f5956f = uri;
        this.f5957n = bundle;
        this.f5958o = uri2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return ((Object) this.f5953b) + ", " + ((Object) this.f5954c) + ", " + ((Object) this.d);
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        Object objBuild = this.f5959p;
        if (objBuild == null) {
            MediaDescription.Builder builder = new MediaDescription.Builder();
            builder.setMediaId(this.f5952a);
            builder.setTitle(this.f5953b);
            builder.setSubtitle(this.f5954c);
            builder.setDescription(this.d);
            builder.setIconBitmap(this.f5955e);
            builder.setIconUri(this.f5956f);
            builder.setExtras(this.f5957n);
            builder.setMediaUri(this.f5958o);
            objBuild = builder.build();
            this.f5959p = objBuild;
        }
        ((MediaDescription) objBuild).writeToParcel(parcel, i10);
    }
}
