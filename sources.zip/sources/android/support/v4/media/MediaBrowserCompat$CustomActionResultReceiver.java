package android.support.v4.media;

import android.os.Bundle;
import b.C0465d;

/* loaded from: classes.dex */
class MediaBrowserCompat$CustomActionResultReceiver extends C0465d {
    @Override // b.C0465d
    public final void a(int i10, Bundle bundle) {
    }
}
