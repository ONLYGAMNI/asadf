package android.support.v4.media.session;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class PlaybackStateCompat implements Parcelable {
    public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new S3.b(11);

    /* renamed from: a, reason: collision with root package name */
    public final int f5971a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5972b;

    /* renamed from: c, reason: collision with root package name */
    public final long f5973c;
    public final float d;

    /* renamed from: e, reason: collision with root package name */
    public final long f5974e;

    /* renamed from: f, reason: collision with root package name */
    public final int f5975f;

    /* renamed from: n, reason: collision with root package name */
    public final CharSequence f5976n;

    /* renamed from: o, reason: collision with root package name */
    public final long f5977o;

    /* renamed from: p, reason: collision with root package name */
    public final ArrayList f5978p;

    /* renamed from: q, reason: collision with root package name */
    public final long f5979q;

    /* renamed from: r, reason: collision with root package name */
    public final Bundle f5980r;

    public static final class CustomAction implements Parcelable {
        public static final Parcelable.Creator<CustomAction> CREATOR = new c();

        /* renamed from: a, reason: collision with root package name */
        public final String f5981a;

        /* renamed from: b, reason: collision with root package name */
        public final CharSequence f5982b;

        /* renamed from: c, reason: collision with root package name */
        public final int f5983c;
        public final Bundle d;

        public CustomAction(Parcel parcel) {
            this.f5981a = parcel.readString();
            this.f5982b = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f5983c = parcel.readInt();
            this.d = parcel.readBundle(b.class.getClassLoader());
        }

        @Override // android.os.Parcelable
        public final int describeContents() {
            return 0;
        }

        public final String toString() {
            return "Action:mName='" + ((Object) this.f5982b) + ", mIcon=" + this.f5983c + ", mExtras=" + this.d;
        }

        @Override // android.os.Parcelable
        public final void writeToParcel(Parcel parcel, int i10) {
            parcel.writeString(this.f5981a);
            TextUtils.writeToParcel(this.f5982b, parcel, i10);
            parcel.writeInt(this.f5983c);
            parcel.writeBundle(this.d);
        }
    }

    public PlaybackStateCompat(Parcel parcel) {
        this.f5971a = parcel.readInt();
        this.f5972b = parcel.readLong();
        this.d = parcel.readFloat();
        this.f5977o = parcel.readLong();
        this.f5973c = parcel.readLong();
        this.f5974e = parcel.readLong();
        this.f5976n = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f5978p = parcel.createTypedArrayList(CustomAction.CREATOR);
        this.f5979q = parcel.readLong();
        this.f5980r = parcel.readBundle(b.class.getClassLoader());
        this.f5975f = parcel.readInt();
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("PlaybackState {state=");
        sb.append(this.f5971a);
        sb.append(", position=");
        sb.append(this.f5972b);
        sb.append(", buffered position=");
        sb.append(this.f5973c);
        sb.append(", speed=");
        sb.append(this.d);
        sb.append(", updated=");
        sb.append(this.f5977o);
        sb.append(", actions=");
        sb.append(this.f5974e);
        sb.append(", error code=");
        sb.append(this.f5975f);
        sb.append(", error message=");
        sb.append(this.f5976n);
        sb.append(", custom actions=");
        sb.append(this.f5978p);
        sb.append(", active item id=");
        return a.o(sb, this.f5979q, "}");
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f5971a);
        parcel.writeLong(this.f5972b);
        parcel.writeFloat(this.d);
        parcel.writeLong(this.f5977o);
        parcel.writeLong(this.f5973c);
        parcel.writeLong(this.f5974e);
        TextUtils.writeToParcel(this.f5976n, parcel, i10);
        parcel.writeTypedList(this.f5978p);
        parcel.writeLong(this.f5979q);
        parcel.writeBundle(this.f5980r);
        parcel.writeInt(this.f5975f);
    }
}
