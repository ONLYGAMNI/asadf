package android.support.v4.media.session;

import C3.f;
import C8.D0;
import C8.I;
import C8.Q;
import D.m;
import E.j;
import O8.h;
import S8.B;
import S8.C0302d;
import S8.O;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcelable;
import android.text.InputFilter;
import android.util.Log;
import android.util.Size;
import android.util.SizeF;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.ImageView;
import androidx.fragment.app.AbstractC0385e;
import androidx.fragment.app.DialogInterfaceOnCancelListenerC0394n;
import androidx.fragment.app.r;
import androidx.navigation.fragment.NavHostFragment;
import com.tajir.tajir.R;
import d0.C0611a;
import d0.C0612b;
import e8.C0795g;
import f9.d;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.Serializable;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.charset.Charset;
import kotlinx.serialization.KSerializer;
import kotlinx.serialization.encoding.Encoder;
import p3.i;
import q0.F;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class b {
    public static final ByteBuffer B(ByteBuffer byteBuffer, int i10, int i11) {
        AbstractC1420h.f(byteBuffer, "<this>");
        ByteBuffer byteBufferDuplicate = byteBuffer.duplicate();
        AbstractC1420h.e(byteBufferDuplicate, "");
        byteBufferDuplicate.position(i10);
        byteBufferDuplicate.limit(i10 + i11);
        ByteBuffer byteBufferSlice = byteBufferDuplicate.slice();
        AbstractC1420h.e(byteBufferSlice, "");
        return byteBufferSlice;
    }

    public static final void C(View view) {
        AbstractC1420h.f(view, "<this>");
        boolean z3 = view.getVisibility() == 0;
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(view, "alpha", z3 ? 1.0f : 0.0f, z3 ? 0.0f : 1.0f);
        objectAnimatorOfFloat.setDuration(ViewConfiguration.getDoubleTapTimeout());
        if (z3) {
            objectAnimatorOfFloat.addListener(new W6.b(view, 2));
        } else {
            view.setVisibility(0);
        }
        objectAnimatorOfFloat.start();
    }

    public static final C0302d a(KSerializer kSerializer) {
        AbstractC1420h.f(kSerializer, "elementSerializer");
        return new C0302d(kSerializer, 0);
    }

    public static final B b(KSerializer kSerializer, KSerializer kSerializer2) {
        AbstractC1420h.f(kSerializer, "keySerializer");
        return new B(kSerializer, kSerializer2, 1);
    }

    public static final void c(View view, Float f10, Float f11, long j10) {
        AbstractC1420h.f(view, "<this>");
        view.setAlpha(f10 != null ? f10.floatValue() : 0.0f);
        view.clearAnimation();
        view.animate().alpha(f11.floatValue()).setDuration(j10).start();
    }

    public static final void d(View view, Integer num, Integer num2, Integer num3, Integer num4) {
        AbstractC1420h.f(view, "<this>");
        if (view.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            AbstractC1420h.d(layoutParams, "null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams");
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
            marginLayoutParams.setMarginStart(num != null ? num.intValue() : marginLayoutParams.getMarginStart());
            marginLayoutParams.topMargin = num2 != null ? num2.intValue() : marginLayoutParams.topMargin;
            marginLayoutParams.setMarginEnd(num3 != null ? num3.intValue() : marginLayoutParams.getMarginEnd());
            marginLayoutParams.bottomMargin = num4 != null ? num4.intValue() : marginLayoutParams.bottomMargin;
            view.setLayoutParams(marginLayoutParams);
        }
    }

    public static final Bundle e(C0795g... c0795gArr) {
        Bundle bundle = new Bundle(c0795gArr.length);
        for (C0795g c0795g : c0795gArr) {
            String str = (String) c0795g.f10311a;
            Object obj = c0795g.f10312b;
            if (obj == null) {
                bundle.putString(str, null);
            } else if (obj instanceof Boolean) {
                bundle.putBoolean(str, ((Boolean) obj).booleanValue());
            } else if (obj instanceof Byte) {
                bundle.putByte(str, ((Number) obj).byteValue());
            } else if (obj instanceof Character) {
                bundle.putChar(str, ((Character) obj).charValue());
            } else if (obj instanceof Double) {
                bundle.putDouble(str, ((Number) obj).doubleValue());
            } else if (obj instanceof Float) {
                bundle.putFloat(str, ((Number) obj).floatValue());
            } else if (obj instanceof Integer) {
                bundle.putInt(str, ((Number) obj).intValue());
            } else if (obj instanceof Long) {
                bundle.putLong(str, ((Number) obj).longValue());
            } else if (obj instanceof Short) {
                bundle.putShort(str, ((Number) obj).shortValue());
            } else if (obj instanceof Bundle) {
                bundle.putBundle(str, (Bundle) obj);
            } else if (obj instanceof CharSequence) {
                bundle.putCharSequence(str, (CharSequence) obj);
            } else if (obj instanceof Parcelable) {
                bundle.putParcelable(str, (Parcelable) obj);
            } else if (obj instanceof boolean[]) {
                bundle.putBooleanArray(str, (boolean[]) obj);
            } else if (obj instanceof byte[]) {
                bundle.putByteArray(str, (byte[]) obj);
            } else if (obj instanceof char[]) {
                bundle.putCharArray(str, (char[]) obj);
            } else if (obj instanceof double[]) {
                bundle.putDoubleArray(str, (double[]) obj);
            } else if (obj instanceof float[]) {
                bundle.putFloatArray(str, (float[]) obj);
            } else if (obj instanceof int[]) {
                bundle.putIntArray(str, (int[]) obj);
            } else if (obj instanceof long[]) {
                bundle.putLongArray(str, (long[]) obj);
            } else if (obj instanceof short[]) {
                bundle.putShortArray(str, (short[]) obj);
            } else if (obj instanceof Object[]) {
                Class<?> componentType = obj.getClass().getComponentType();
                AbstractC1420h.c(componentType);
                if (Parcelable.class.isAssignableFrom(componentType)) {
                    bundle.putParcelableArray(str, (Parcelable[]) obj);
                } else if (String.class.isAssignableFrom(componentType)) {
                    bundle.putStringArray(str, (String[]) obj);
                } else if (CharSequence.class.isAssignableFrom(componentType)) {
                    bundle.putCharSequenceArray(str, (CharSequence[]) obj);
                } else {
                    if (!Serializable.class.isAssignableFrom(componentType)) {
                        throw new IllegalArgumentException("Illegal value array type " + componentType.getCanonicalName() + " for key \"" + str + '\"');
                    }
                    bundle.putSerializable(str, (Serializable) obj);
                }
            } else if (obj instanceof Serializable) {
                bundle.putSerializable(str, (Serializable) obj);
            } else if (obj instanceof IBinder) {
                M.a.a(bundle, str, (IBinder) obj);
            } else if (obj instanceof Size) {
                M.b.a(bundle, str, (Size) obj);
            } else {
                if (!(obj instanceof SizeF)) {
                    throw new IllegalArgumentException("Illegal value type " + obj.getClass().getCanonicalName() + " for key \"" + str + '\"');
                }
                M.b.b(bundle, str, (SizeF) obj);
            }
        }
        return bundle;
    }

    public static final Charset f(AbstractC0385e abstractC0385e) {
        AbstractC1420h.f(abstractC0385e, "<this>");
        String strO = abstractC0385e.o("charset");
        if (strO == null) {
            return null;
        }
        try {
            return Charset.forName(strO);
        } catch (IllegalArgumentException unused) {
            return null;
        }
    }

    public static final void g(Closeable closeable, Throwable th) {
        if (closeable != null) {
            if (th == null) {
                closeable.close();
                return;
            }
            try {
                closeable.close();
            } catch (Throwable th2) {
                com.bumptech.glide.c.b(th, th2);
            }
        }
    }

    public static final void h(ByteBuffer byteBuffer, ByteBuffer byteBuffer2, int i10) {
        AbstractC1420h.f(byteBuffer, "$this$copyTo");
        int iRemaining = byteBuffer2.remaining();
        if (byteBuffer.hasArray() && !byteBuffer.isReadOnly() && byteBuffer2.hasArray() && !byteBuffer2.isReadOnly()) {
            int iPosition = byteBuffer2.position();
            System.arraycopy(byteBuffer.array(), byteBuffer.arrayOffset() + i10, byteBuffer2.array(), byteBuffer2.arrayOffset() + iPosition, iRemaining);
            byteBuffer2.position(iPosition + iRemaining);
        } else {
            ByteBuffer byteBufferDuplicate = byteBuffer.duplicate();
            byteBufferDuplicate.limit(iRemaining + i10);
            byteBufferDuplicate.position(i10);
            byteBuffer2.put(byteBufferDuplicate);
        }
    }

    public static void i(Encoder encoder, h hVar, Object obj) {
        AbstractC1420h.f(hVar, "serializer");
        if (hVar.getDescriptor().i()) {
            encoder.Q(hVar, obj);
        } else if (obj == null) {
            encoder.k();
        } else {
            encoder.getClass();
            encoder.Q(hVar, obj);
        }
    }

    public static final void j(ImageView imageView, boolean z3) {
        if (z3) {
            imageView.setBackgroundColor(j.getColor(imageView.getContext(), R.color.transparent));
            return;
        }
        TypedValue typedValue = new TypedValue();
        imageView.getContext().getTheme().resolveAttribute(android.R.attr.selectableItemBackground, typedValue, true);
        imageView.setBackgroundResource(typedValue.resourceId);
    }

    public static final F k(r rVar) {
        Dialog dialog;
        Window window;
        AbstractC1420h.f(rVar, "<this>");
        for (r rVar2 = rVar; rVar2 != null; rVar2 = rVar2.f6805C) {
            if (rVar2 instanceof NavHostFragment) {
                return ((NavHostFragment) rVar2).c0();
            }
            r rVar3 = rVar2.q().f6663x;
            if (rVar3 instanceof NavHostFragment) {
                return ((NavHostFragment) rVar3).c0();
            }
        }
        View view = rVar.f6814M;
        if (view != null) {
            return A3.a.j(view);
        }
        View decorView = null;
        DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n = rVar instanceof DialogInterfaceOnCancelListenerC0394n ? (DialogInterfaceOnCancelListenerC0394n) rVar : null;
        if (dialogInterfaceOnCancelListenerC0394n != null && (dialog = dialogInterfaceOnCancelListenerC0394n.f6787o0) != null && (window = dialog.getWindow()) != null) {
            decorView = window.getDecorView();
        }
        if (decorView != null) {
            return A3.a.j(decorView);
        }
        throw new IllegalStateException(a.k("Fragment ", rVar, " does not have a NavController set"));
    }

    public static float m(int i10, String[] strArr) throws NumberFormatException {
        float f10 = Float.parseFloat(strArr[i10]);
        if (f10 >= 0.0f && f10 <= 1.0f) {
            return f10;
        }
        throw new IllegalArgumentException("Motion easing control point value must be between 0 and 1; instead got: " + f10);
    }

    public static final KSerializer n(KSerializer kSerializer) {
        AbstractC1420h.f(kSerializer, "<this>");
        return kSerializer.getDescriptor().i() ? kSerializer : new O(kSerializer);
    }

    public static Intent o(Activity activity) {
        Intent intentA = m.a(activity);
        if (intentA != null) {
            return intentA;
        }
        try {
            String strQ = q(activity, activity.getComponentName());
            if (strQ == null) {
                return null;
            }
            ComponentName componentName = new ComponentName(activity, strQ);
            try {
                return q(activity, componentName) == null ? Intent.makeMainActivity(componentName) : new Intent().setComponent(componentName);
            } catch (PackageManager.NameNotFoundException unused) {
                Log.e("NavUtils", "getParentActivityIntent: bad parentActivityName '" + strQ + "' in manifest");
                return null;
            }
        } catch (PackageManager.NameNotFoundException e4) {
            throw new IllegalArgumentException(e4);
        }
    }

    public static Intent p(Context context, ComponentName componentName) throws PackageManager.NameNotFoundException {
        String strQ = q(context, componentName);
        if (strQ == null) {
            return null;
        }
        ComponentName componentName2 = new ComponentName(componentName.getPackageName(), strQ);
        return q(context, componentName2) == null ? Intent.makeMainActivity(componentName2) : new Intent().setComponent(componentName2);
    }

    public static String q(Context context, ComponentName componentName) throws PackageManager.NameNotFoundException {
        String string;
        PackageManager packageManager = context.getPackageManager();
        int i10 = Build.VERSION.SDK_INT;
        ActivityInfo activityInfo = packageManager.getActivityInfo(componentName, i10 >= 29 ? 269222528 : i10 >= 24 ? 787072 : 640);
        String str = activityInfo.parentActivityName;
        if (str != null) {
            return str;
        }
        Bundle bundle = activityInfo.metaData;
        if (bundle == null || (string = bundle.getString("android.support.PARENT_ACTIVITY")) == null) {
            return null;
        }
        if (string.charAt(0) != '.') {
            return string;
        }
        return context.getPackageName() + string;
    }

    public static boolean r(String str, String str2) {
        return str.startsWith(str2.concat("(")) && str.endsWith(")");
    }

    public static final boolean s(View view) {
        AbstractC1420h.f(view, "<this>");
        view.getGlobalVisibleRect(new Rect());
        view.getLocalVisibleRect(new Rect());
        return !r0.equals(r1);
    }

    public static C0612b t(String str, i iVar) {
        C0611a c0611a = C0611a.f10077a;
        J8.c cVar = Q.f297c;
        D0 d0D = I.d();
        cVar.getClass();
        B1.a aVarB = I.b(f.t(cVar, d0D));
        AbstractC1420h.f(str, "name");
        return new C0612b(str, iVar, c0611a, aVarB);
    }

    public static f0.b u(MappedByteBuffer mappedByteBuffer) throws IOException {
        long j10;
        ByteBuffer byteBufferDuplicate = mappedByteBuffer.duplicate();
        byteBufferDuplicate.order(ByteOrder.BIG_ENDIAN);
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
        int i10 = byteBufferDuplicate.getShort() & 65535;
        if (i10 > 100) {
            throw new IOException("Cannot read metadata.");
        }
        byteBufferDuplicate.position(byteBufferDuplicate.position() + 6);
        int i11 = 0;
        while (true) {
            if (i11 >= i10) {
                j10 = -1;
                break;
            }
            int i12 = byteBufferDuplicate.getInt();
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            j10 = byteBufferDuplicate.getInt() & 4294967295L;
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 4);
            if (1835365473 == i12) {
                break;
            }
            i11++;
        }
        if (j10 != -1) {
            byteBufferDuplicate.position(byteBufferDuplicate.position() + ((int) (j10 - byteBufferDuplicate.position())));
            byteBufferDuplicate.position(byteBufferDuplicate.position() + 12);
            long j11 = byteBufferDuplicate.getInt() & 4294967295L;
            for (int i13 = 0; i13 < j11; i13++) {
                int i14 = byteBufferDuplicate.getInt();
                long j12 = byteBufferDuplicate.getInt() & 4294967295L;
                byteBufferDuplicate.getInt();
                if (1164798569 == i14 || 1701669481 == i14) {
                    byteBufferDuplicate.position((int) (j12 + j10));
                    f0.b bVar = new f0.b(2);
                    byteBufferDuplicate.order(ByteOrder.LITTLE_ENDIAN);
                    int iPosition = byteBufferDuplicate.position() + byteBufferDuplicate.getInt(byteBufferDuplicate.position());
                    bVar.d = byteBufferDuplicate;
                    bVar.f3952a = iPosition;
                    int i15 = iPosition - byteBufferDuplicate.getInt(iPosition);
                    bVar.f3953b = i15;
                    bVar.f3954c = ((ByteBuffer) bVar.d).getShort(i15);
                    return bVar;
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    public static final void v(H7.a aVar, ByteBuffer byteBuffer, int i10) throws EOFException {
        AbstractC1420h.f(aVar, "<this>");
        ByteBuffer byteBuffer2 = aVar.f1589a;
        int i11 = aVar.f1590b;
        if (aVar.f1591c - i11 < i10) {
            throw new EOFException("Not enough bytes to read a buffer content of size " + i10 + '.');
        }
        int iLimit = byteBuffer.limit();
        try {
            byteBuffer.limit(byteBuffer.position() + i10);
            h(byteBuffer2, byteBuffer, i11);
            byteBuffer.limit(iLimit);
            aVar.c(i10);
        } catch (Throwable th) {
            byteBuffer.limit(iLimit);
            throw th;
        }
    }

    public static final void w(View view, int i10, int i11) {
        AbstractC1420h.f(view, "<this>");
        view.getLayoutParams().width = i10;
        view.getLayoutParams().height = i11;
        view.setLayoutParams(view.getLayoutParams());
    }

    public static int x(Context context, int i10, int i11) {
        TypedValue typedValueI = D4.a.I(context, i10);
        return (typedValueI == null || typedValueI.type != 16) ? i11 : typedValueI.data;
    }

    public static TimeInterpolator y(Context context, int i10, Interpolator interpolator) {
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(i10, typedValue, true)) {
            return interpolator;
        }
        if (typedValue.type != 3) {
            throw new IllegalArgumentException("Motion easing theme attribute must be an @interpolator resource for ?attr/motionEasing*Interpolator attributes or a string for ?attr/motionEasing* attributes.");
        }
        String strValueOf = String.valueOf(typedValue.string);
        if (!r(strValueOf, "cubic-bezier") && !r(strValueOf, "path")) {
            return AnimationUtils.loadInterpolator(context, typedValue.resourceId);
        }
        if (!r(strValueOf, "cubic-bezier")) {
            if (r(strValueOf, "path")) {
                return T.a.c(d.i(strValueOf.substring(5, strValueOf.length() - 1)));
            }
            throw new IllegalArgumentException("Invalid motion easing type: ".concat(strValueOf));
        }
        String[] strArrSplit = strValueOf.substring(13, strValueOf.length() - 1).split(",");
        if (strArrSplit.length == 4) {
            return T.a.b(m(0, strArrSplit), m(1, strArrSplit), m(2, strArrSplit), m(3, strArrSplit));
        }
        throw new IllegalArgumentException("Motion easing theme attribute must have 4 control points if using bezier curve format; instead got: " + strArrSplit.length);
    }

    public abstract void A(boolean z3);

    public abstract InputFilter[] l(InputFilter[] inputFilterArr);

    public abstract void z(boolean z3);
}
