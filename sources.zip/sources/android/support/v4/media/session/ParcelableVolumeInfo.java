package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public class ParcelableVolumeInfo implements Parcelable {
    public static final Parcelable.Creator<ParcelableVolumeInfo> CREATOR = new S3.b(10);

    /* renamed from: a, reason: collision with root package name */
    public int f5967a;

    /* renamed from: b, reason: collision with root package name */
    public int f5968b;

    /* renamed from: c, reason: collision with root package name */
    public int f5969c;
    public int d;

    /* renamed from: e, reason: collision with root package name */
    public int f5970e;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f5967a);
        parcel.writeInt(this.f5969c);
        parcel.writeInt(this.d);
        parcel.writeInt(this.f5970e);
        parcel.writeInt(this.f5968b);
    }
}
