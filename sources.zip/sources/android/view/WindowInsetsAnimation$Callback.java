package android.view;

/* loaded from: classes.dex */
public /* synthetic */ class WindowInsetsAnimation$Callback {
    static {
        throw new NoClassDefFoundError();
    }
}
