package A;

import com.tajir.tajir.R;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f0a = {R.attr.keylines, R.attr.statusBarBackground};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f1b = {android.R.attr.layout_gravity, R.attr.layout_anchor, R.attr.layout_anchorGravity, R.attr.layout_behavior, R.attr.layout_dodgeInsetEdges, R.attr.layout_insetEdge, R.attr.layout_keyline};
}
