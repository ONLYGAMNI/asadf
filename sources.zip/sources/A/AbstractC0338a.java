package a;

import E5.E;
import O8.h;
import P6.m;
import R8.b;
import S6.A;
import S6.C0272a0;
import S8.C;
import V.o;
import V.p;
import V.q;
import V.r;
import V.s;
import V.t;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.ActionMode;
import android.widget.TextView;
import c5.v0;
import com.bumptech.glide.c;
import com.bumptech.glide.d;
import com.tajir.tajir.main.page.Page;
import d0.i;
import f8.AbstractC0842j;
import f8.AbstractC0843k;
import i6.C1009a;
import io.ktor.http.BadContentTypeFormatException;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import kotlinx.serialization.SerializationException;
import kotlinx.serialization.descriptors.SerialDescriptor;
import kotlinx.serialization.encoding.Encoder;
import l.Q0;
import r8.l;
import s.AbstractC1387g;
import s.C1383c;
import s.C1386f;
import s8.AbstractC1420h;
import s8.AbstractC1432t;
import v7.C1575f;
import v7.C1579j;
import z8.f;

/* renamed from: a.a */
/* loaded from: classes.dex */
public abstract class AbstractC0338a implements Encoder, b {
    public static boolean C() {
        int i10 = Build.VERSION.SDK_INT;
        if (i10 < 33) {
            if (i10 >= 32) {
                String str = Build.VERSION.CODENAME;
                if (!"REL".equals(str)) {
                    Locale locale = Locale.ROOT;
                    if (str.toUpperCase(locale).compareTo("Tiramisu".toUpperCase(locale)) >= 0) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    public static final List H(List list, List list2, Map map, Set set, Set set2) {
        AbstractC1420h.f(list, "apiItems");
        AbstractC1420h.f(list2, "cart");
        AbstractC1420h.f(map, "stock");
        AbstractC1420h.f(set, "subscriptions");
        AbstractC1420h.f(set2, "flashStockMsgAnimations");
        List listP0 = AbstractC0842j.p0(list);
        List list3 = listP0;
        ArrayList arrayList = new ArrayList();
        for (Object obj : list3) {
            if (obj instanceof A) {
                arrayList.add(obj);
            }
        }
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            A a6 = (A) it.next();
            if (!a6.getItems().isEmpty()) {
                List<C0272a0> items = a6.getItems();
                ArrayList arrayList2 = new ArrayList();
                for (Object obj2 : items) {
                    if (obj2 instanceof m) {
                        arrayList2.add(obj2);
                    }
                }
                g0(list2, map, arrayList2);
                Iterator it2 = arrayList2.iterator();
                while (it2.hasNext()) {
                    m mVar = (m) it2.next();
                    mVar.setSubscribedLocally(set.contains(mVar.getId()));
                }
                h0(arrayList2, set2);
            }
        }
        ArrayList arrayList3 = new ArrayList();
        for (Object obj3 : list3) {
            if (obj3 instanceof m) {
                arrayList3.add(obj3);
            }
        }
        g0(list2, map, arrayList3);
        Iterator it3 = arrayList3.iterator();
        while (it3.hasNext()) {
            m mVar2 = (m) it3.next();
            mVar2.setSubscribedLocally(set.contains(mVar2.getId()));
        }
        h0(arrayList3, set2);
        return listP0;
    }

    public static C1575f M(String str) throws BadContentTypeFormatException {
        if (f.K0(str)) {
            return C1575f.f15805f;
        }
        C1579j c1579j = (C1579j) AbstractC0842j.i0(v0.r(str));
        String str2 = c1579j.f15809a;
        int iH0 = f.H0(str2, '/', 0, false, 6);
        if (iH0 == -1) {
            if (AbstractC1420h.a(f.a1(str2).toString(), "*")) {
                return C1575f.f15805f;
            }
            throw new BadContentTypeFormatException("Bad Content-Type format: ".concat(str));
        }
        String strSubstring = str2.substring(0, iH0);
        AbstractC1420h.e(strSubstring, "this as java.lang.String…ing(startIndex, endIndex)");
        String string = f.a1(strSubstring).toString();
        if (string.length() == 0) {
            throw new BadContentTypeFormatException("Bad Content-Type format: ".concat(str));
        }
        String strSubstring2 = str2.substring(iH0 + 1);
        AbstractC1420h.e(strSubstring2, "this as java.lang.String).substring(startIndex)");
        String string2 = f.a1(strSubstring2).toString();
        if (f.C0(string, ' ') || f.C0(string2, ' ')) {
            throw new BadContentTypeFormatException("Bad Content-Type format: ".concat(str));
        }
        if (string2.length() == 0 || f.C0(string2, '/')) {
            throw new BadContentTypeFormatException("Bad Content-Type format: ".concat(str));
        }
        return new C1575f(string, string2, c1579j.f15810b);
    }

    public static final byte[] W(InputStream inputStream) throws IOException {
        AbstractC1420h.f(inputStream, "<this>");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(Math.max(8192, inputStream.available()));
        l(inputStream, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        AbstractC1420h.e(byteArray, "toByteArray(...)");
        return byteArray;
    }

    public static final void b0(I7.b bVar, byte[] bArr, int i10, int i11) throws EOFException {
        int i12 = bVar.f1590b;
        if (bVar.f1591c - i12 < i11) {
            throw new EOFException("Not enough bytes to read a byte array of size " + i11 + '.');
        }
        ByteBuffer byteBuffer = bVar.f1589a;
        AbstractC1420h.f(byteBuffer, "$this$copyTo");
        if (!byteBuffer.hasArray() || byteBuffer.isReadOnly()) {
            byteBuffer.duplicate().get(bArr, i10, i11);
        } else {
            System.arraycopy(byteBuffer.array(), byteBuffer.arrayOffset() + i12, bArr, i10, i11);
        }
        bVar.c(i11);
    }

    public static final boolean d0(Page page) {
        return AbstractC0843k.O(Page.BROWSE, Page.PODCAST, Page.OFFERS).contains(page);
    }

    public static void e(StringBuilder sb, Object obj, l lVar) {
        if (lVar != null) {
            sb.append((CharSequence) lVar.invoke(obj));
            return;
        }
        if (obj == null ? true : obj instanceof CharSequence) {
            sb.append((CharSequence) obj);
        } else if (obj instanceof Character) {
            sb.append(((Character) obj).charValue());
        } else {
            sb.append((CharSequence) String.valueOf(obj));
        }
    }

    public static void e0(TextView textView, int i10) {
        c.f(i10);
        if (Build.VERSION.SDK_INT >= 28) {
            s.c(textView, i10);
            return;
        }
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i11 = o.a(textView) ? fontMetricsInt.top : fontMetricsInt.ascent;
        if (i10 > Math.abs(i11)) {
            textView.setPadding(textView.getPaddingLeft(), i10 + i11, textView.getPaddingRight(), textView.getPaddingBottom());
        }
    }

    public static void f0(TextView textView, int i10) {
        c.f(i10);
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i11 = o.a(textView) ? fontMetricsInt.bottom : fontMetricsInt.descent;
        if (i10 > Math.abs(i11)) {
            textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), i10 - i11);
        }
    }

    public static final void g0(List list, Map map, ArrayList arrayList) {
        Object next;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            m mVar = (m) it.next();
            Iterator it2 = list.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    next = null;
                    break;
                } else {
                    next = it2.next();
                    if (AbstractC1420h.a(((C1009a) next).f11226a, mVar.getId())) {
                        break;
                    }
                }
            }
            C1009a c1009a = (C1009a) next;
            mVar.setCartQuantity(c1009a != null ? c1009a.f11227b : 0L);
            if (map.containsKey(mVar.getId())) {
                Object obj = map.get(mVar.getId());
                AbstractC1420h.c(obj);
                mVar.setMaxStock(((Number) obj).longValue());
            }
        }
    }

    public static final void h0(ArrayList arrayList, Set set) {
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            m mVar = (m) it.next();
            if (set.contains(mVar.getId())) {
                mVar.startStockMessageAnimation();
            } else {
                mVar.endStockMessageAnimation();
            }
        }
    }

    public static int i(int i10, int i11) {
        if (i11 <= 1073741823) {
            return Math.min(Math.max(i10, i11), 1073741823);
        }
        throw new IllegalArgumentException(d.v("min (%s) must be less than or equal to max (%s)", Integer.valueOf(i11), 1073741823));
    }

    public static final S1.c i0(String str) {
        AbstractC1420h.f(str, "<this>");
        return new S1.c(str);
    }

    public static final S1.l j0(String str) {
        AbstractC1420h.f(str, "<this>");
        return new S1.l(str);
    }

    public static final int k0(int i10) {
        return (int) TypedValue.applyDimension(1, i10, Resources.getSystem().getDisplayMetrics());
    }

    public static void l(InputStream inputStream, ByteArrayOutputStream byteArrayOutputStream) throws IOException {
        AbstractC1420h.f(inputStream, "<this>");
        byte[] bArr = new byte[8192];
        int i10 = inputStream.read(bArr);
        while (i10 >= 0) {
            byteArrayOutputStream.write(bArr, 0, i10);
            i10 = inputStream.read(bArr);
        }
    }

    public static ActionMode.Callback l0(ActionMode.Callback callback) {
        return (!(callback instanceof t) || Build.VERSION.SDK_INT < 26) ? callback : ((t) callback).f5052a;
    }

    public static ActionMode.Callback m0(ActionMode.Callback callback, TextView textView) {
        int i10 = Build.VERSION.SDK_INT;
        return (i10 < 26 || i10 > 27 || (callback instanceof t) || callback == null) ? callback : new t(callback, textView);
    }

    public static final String q(String str) {
        AbstractC1420h.f(str, "path");
        List listV0 = f.V0(str, new String[]{":"});
        if (!listV0.isEmpty()) {
            return (String) listV0.get(listV0.size() - 1);
        }
        return null;
    }

    public static Drawable s(Context context, int i10) {
        return Q0.d().f(context, i10);
    }

    public static final int v(int i10, String str) {
        String property;
        Integer numQ0;
        try {
            property = System.getProperty("io.ktor.utils.io.".concat(str));
        } catch (SecurityException unused) {
            property = null;
        }
        return (property == null || (numQ0 = z8.m.q0(property)) == null) ? i10 : numQ0.intValue();
    }

    public static P.f z(TextView textView) {
        TextDirectionHeuristic textDirectionHeuristic;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 28) {
            return new P.f(s.b(textView));
        }
        TextPaint textPaint = new TextPaint(textView.getPaint());
        TextDirectionHeuristic textDirectionHeuristic2 = TextDirectionHeuristics.FIRSTSTRONG_LTR;
        int iA = q.a(textView);
        int iD = q.d(textView);
        if (textView.getTransformationMethod() instanceof PasswordTransformationMethod) {
            textDirectionHeuristic = TextDirectionHeuristics.LTR;
        } else {
            if (i10 < 28 || (textView.getInputType() & 15) != 3) {
                boolean z3 = p.b(textView) == 1;
                switch (p.c(textView)) {
                    case 2:
                        textDirectionHeuristic = TextDirectionHeuristics.ANYRTL_LTR;
                        break;
                    case 3:
                        textDirectionHeuristic = TextDirectionHeuristics.LTR;
                        break;
                    case 4:
                        textDirectionHeuristic = TextDirectionHeuristics.RTL;
                        break;
                    case 5:
                        textDirectionHeuristic = TextDirectionHeuristics.LOCALE;
                        break;
                    case i.STRING_SET_FIELD_NUMBER /* 6 */:
                        textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR;
                        break;
                    case i.DOUBLE_FIELD_NUMBER /* 7 */:
                        textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
                        break;
                    default:
                        if (!z3) {
                            textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_LTR;
                            break;
                        } else {
                            textDirectionHeuristic = TextDirectionHeuristics.FIRSTSTRONG_RTL;
                            break;
                        }
                }
            } else {
                byte directionality = Character.getDirectionality(s.a(r.a(p.d(textView)))[0].codePointAt(0));
                textDirectionHeuristic = (directionality == 1 || directionality == 2) ? TextDirectionHeuristics.RTL : TextDirectionHeuristics.LTR;
            }
        }
        return new P.f(textPaint, textDirectionHeuristic, iA, iD);
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public abstract void A(byte b7);

    @Override // kotlinx.serialization.encoding.Encoder
    public void B(boolean z3) {
        p(Boolean.valueOf(z3));
        throw null;
    }

    @Override // R8.b
    public void D(SerialDescriptor serialDescriptor, int i10, float f10) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        J(f10);
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public void E(SerialDescriptor serialDescriptor, int i10) {
        AbstractC1420h.f(serialDescriptor, "enumDescriptor");
        p(Integer.valueOf(i10));
        throw null;
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public abstract void G(int i10);

    @Override // R8.b
    public void I(int i10, int i11, SerialDescriptor serialDescriptor) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        G(i11);
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public void J(float f10) {
        p(Float.valueOf(f10));
        throw null;
    }

    public abstract void K(Throwable th);

    public abstract void L(E e4);

    @Override // R8.b
    public void N(SerialDescriptor serialDescriptor, int i10, short s9) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        u(s9);
    }

    @Override // R8.b
    public void O(SerialDescriptor serialDescriptor, int i10, double d) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        t(d);
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public abstract void P(long j10);

    @Override // kotlinx.serialization.encoding.Encoder
    public void Q(h hVar, Object obj) {
        AbstractC1420h.f(hVar, "serializer");
        hVar.serialize(this, obj);
    }

    public abstract Object R(Intent intent, int i10);

    @Override // kotlinx.serialization.encoding.Encoder
    public void S(char c4) {
        p(Character.valueOf(c4));
        throw null;
    }

    public abstract void T(C1386f c1386f, C1386f c1386f2);

    public abstract void U(C1386f c1386f, Thread thread);

    @Override // R8.b
    public void V(SerialDescriptor serialDescriptor, int i10, long j10) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        P(j10);
    }

    public boolean X(SerialDescriptor serialDescriptor) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        return true;
    }

    @Override // R8.b
    public void Y(SerialDescriptor serialDescriptor, int i10, boolean z3) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        B(z3);
    }

    @Override // R8.b
    public void Z(SerialDescriptor serialDescriptor, int i10, char c4) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        S(c4);
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public void a0(String str) {
        AbstractC1420h.f(str, "value");
        p(str);
        throw null;
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public b b(SerialDescriptor serialDescriptor) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        return this;
    }

    public void c(SerialDescriptor serialDescriptor) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
    }

    @Override // R8.b
    public void c0(SerialDescriptor serialDescriptor, int i10, String str) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        AbstractC1420h.f(str, "value");
        o(serialDescriptor, i10);
        a0(str);
    }

    public abstract boolean f(AbstractC1387g abstractC1387g, C1383c c1383c, C1383c c1383c2);

    public abstract boolean g(AbstractC1387g abstractC1387g, Object obj, Object obj2);

    public abstract boolean h(AbstractC1387g abstractC1387g, C1386f c1386f, C1386f c1386f2);

    @Override // kotlinx.serialization.encoding.Encoder
    public Encoder j(C c4) {
        AbstractC1420h.f(c4, "inlineDescriptor");
        return this;
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public void k() {
        throw new SerializationException("'null' is not supported by default");
    }

    @Override // R8.b
    public void m(SerialDescriptor serialDescriptor, int i10, byte b7) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        o(serialDescriptor, i10);
        A(b7);
    }

    public abstract Intent n(Context context, Object obj);

    public void o(SerialDescriptor serialDescriptor, int i10) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
    }

    public void p(Object obj) {
        AbstractC1420h.f(obj, "value");
        throw new SerializationException("Non-serializable " + AbstractC1432t.a(obj.getClass()) + " is not supported by " + AbstractC1432t.a(getClass()) + " encoder");
    }

    @Override // R8.b
    public void r(SerialDescriptor serialDescriptor, int i10, h hVar, Object obj) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        AbstractC1420h.f(hVar, "serializer");
        o(serialDescriptor, i10);
        Q(hVar, obj);
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public void t(double d) {
        p(Double.valueOf(d));
        throw null;
    }

    @Override // kotlinx.serialization.encoding.Encoder
    public abstract void u(short s9);

    @Override // kotlinx.serialization.encoding.Encoder
    public b w(SerialDescriptor serialDescriptor, int i10) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        return b(serialDescriptor);
    }

    public void x(SerialDescriptor serialDescriptor, int i10, h hVar, Object obj) {
        AbstractC1420h.f(serialDescriptor, "descriptor");
        AbstractC1420h.f(hVar, "serializer");
        o(serialDescriptor, i10);
        android.support.v4.media.session.b.i(this, hVar, obj);
    }

    public K8.d y(Context context, Object obj) {
        AbstractC1420h.f(context, "context");
        return null;
    }
}
