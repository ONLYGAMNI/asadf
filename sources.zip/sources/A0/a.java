package A0;

import E0.c;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public final int f2a;

    /* renamed from: b, reason: collision with root package name */
    public final int f3b;

    public a(int i10, int i11) {
        this.f2a = i10;
        this.f3b = i11;
    }

    public abstract void a(c cVar);
}
