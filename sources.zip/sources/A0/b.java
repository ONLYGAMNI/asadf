package a0;

import K3.D;
import K3.E;
import R.C0240c;
import R.X;
import S.j;
import S.m;
import S.o;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import com.google.android.gms.common.api.f;
import com.google.android.material.chip.Chip;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public abstract class b extends C0240c {

    /* renamed from: n */
    public static final Rect f5839n = new Rect(f.API_PRIORITY_OTHER, f.API_PRIORITY_OTHER, Integer.MIN_VALUE, Integer.MIN_VALUE);

    /* renamed from: o */
    public static final E f5840o = new E(25);

    /* renamed from: p */
    public static final D f5841p = new D(26);

    /* renamed from: h */
    public final AccessibilityManager f5844h;

    /* renamed from: i */
    public final View f5845i;

    /* renamed from: j */
    public C0339a f5846j;
    public final Rect d = new Rect();

    /* renamed from: e */
    public final Rect f5842e = new Rect();

    /* renamed from: f */
    public final Rect f5843f = new Rect();
    public final int[] g = new int[2];

    /* renamed from: k */
    public int f5847k = Integer.MIN_VALUE;

    /* renamed from: l */
    public int f5848l = Integer.MIN_VALUE;

    /* renamed from: m */
    public int f5849m = Integer.MIN_VALUE;

    public b(View view) {
        if (view == null) {
            throw new IllegalArgumentException("View may not be null");
        }
        this.f5845i = view;
        this.f5844h = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        view.setFocusable(true);
        WeakHashMap weakHashMap = X.f3966a;
        if (R.E.c(view) == 0) {
            R.E.s(view, 1);
        }
    }

    @Override // R.C0240c
    public final m b(View view) {
        if (this.f5846j == null) {
            this.f5846j = new C0339a(this);
        }
        return this.f5846j;
    }

    @Override // R.C0240c
    public final void d(View view, j jVar) {
        View.AccessibilityDelegate accessibilityDelegate = this.f3974a;
        AccessibilityNodeInfo accessibilityNodeInfo = jVar.f4177a;
        accessibilityDelegate.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
        Chip chip = ((b4.d) this).f7516q;
        accessibilityNodeInfo.setCheckable(chip.d());
        accessibilityNodeInfo.setClickable(chip.isClickable());
        jVar.g(chip.getAccessibilityClassName());
        jVar.k(chip.getText());
    }

    public final boolean j(int i10) {
        if (this.f5848l != i10) {
            return false;
        }
        this.f5848l = Integer.MIN_VALUE;
        b4.d dVar = (b4.d) this;
        if (i10 == 1) {
            Chip chip = dVar.f7516q;
            chip.f9476t = false;
            chip.refreshDrawableState();
        }
        q(i10, 8);
        return true;
    }

    public final j k(int i10) {
        AccessibilityNodeInfo accessibilityNodeInfo;
        AccessibilityNodeInfo accessibilityNodeInfoObtain = AccessibilityNodeInfo.obtain();
        j jVar = new j(accessibilityNodeInfoObtain);
        accessibilityNodeInfoObtain.setEnabled(true);
        accessibilityNodeInfoObtain.setFocusable(true);
        jVar.g("android.view.View");
        Rect rect = f5839n;
        accessibilityNodeInfoObtain.setBoundsInParent(rect);
        accessibilityNodeInfoObtain.setBoundsInScreen(rect);
        jVar.f4178b = -1;
        View view = this.f5845i;
        accessibilityNodeInfoObtain.setParent(view);
        o(i10, jVar);
        if (jVar.e() == null && accessibilityNodeInfoObtain.getContentDescription() == null) {
            throw new RuntimeException("Callbacks must add text or a content description in populateNodeForVirtualViewId()");
        }
        Rect rect2 = this.f5842e;
        jVar.d(rect2);
        if (rect2.equals(rect)) {
            throw new RuntimeException("Callbacks must set parent bounds in populateNodeForVirtualViewId()");
        }
        int actions = accessibilityNodeInfoObtain.getActions();
        if ((actions & 64) != 0) {
            throw new RuntimeException("Callbacks must not add ACTION_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        if ((actions & 128) != 0) {
            throw new RuntimeException("Callbacks must not add ACTION_CLEAR_ACCESSIBILITY_FOCUS in populateNodeForVirtualViewId()");
        }
        accessibilityNodeInfoObtain.setPackageName(view.getContext().getPackageName());
        jVar.f4179c = i10;
        accessibilityNodeInfoObtain.setSource(view, i10);
        if (this.f5847k == i10) {
            accessibilityNodeInfoObtain.setAccessibilityFocused(true);
            jVar.a(128);
        } else {
            accessibilityNodeInfoObtain.setAccessibilityFocused(false);
            jVar.a(64);
        }
        boolean z3 = this.f5848l == i10;
        if (z3) {
            jVar.a(2);
        } else if (accessibilityNodeInfoObtain.isFocusable()) {
            jVar.a(1);
        }
        accessibilityNodeInfoObtain.setFocused(z3);
        int[] iArr = this.g;
        view.getLocationOnScreen(iArr);
        Rect rect3 = this.d;
        accessibilityNodeInfoObtain.getBoundsInScreen(rect3);
        if (rect3.equals(rect)) {
            jVar.d(rect3);
            if (jVar.f4178b != -1) {
                j jVar2 = new j(AccessibilityNodeInfo.obtain());
                int i11 = jVar.f4178b;
                while (true) {
                    accessibilityNodeInfo = jVar2.f4177a;
                    if (i11 == -1) {
                        break;
                    }
                    jVar2.f4178b = -1;
                    accessibilityNodeInfo.setParent(view, -1);
                    accessibilityNodeInfo.setBoundsInParent(rect);
                    o(i11, jVar2);
                    jVar2.d(rect2);
                    rect3.offset(rect2.left, rect2.top);
                    i11 = jVar2.f4178b;
                }
                accessibilityNodeInfo.recycle();
            }
            rect3.offset(iArr[0] - view.getScrollX(), iArr[1] - view.getScrollY());
        }
        Rect rect4 = this.f5843f;
        if (view.getLocalVisibleRect(rect4)) {
            rect4.offset(iArr[0] - view.getScrollX(), iArr[1] - view.getScrollY());
            if (rect3.intersect(rect4)) {
                jVar.f4177a.setBoundsInScreen(rect3);
                if (!rect3.isEmpty() && view.getWindowVisibility() == 0) {
                    Object parent = view.getParent();
                    while (true) {
                        if (parent instanceof View) {
                            View view2 = (View) parent;
                            if (view2.getAlpha() <= 0.0f || view2.getVisibility() != 0) {
                                break;
                            }
                            parent = view2.getParent();
                        } else if (parent != null) {
                            accessibilityNodeInfoObtain.setVisibleToUser(true);
                        }
                    }
                }
            }
        }
        return jVar;
    }

    public abstract void l(ArrayList arrayList);

    /* JADX WARN: Removed duplicated region for block: B:165:0x00c0  */
    /* JADX WARN: Removed duplicated region for block: B:173:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:176:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:193:0x0153  */
    /* JADX WARN: Removed duplicated region for block: B:213:0x01ab  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean m(int r20, android.graphics.Rect r21) {
        /*
            Method dump skipped, instructions count: 499
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.b.m(int, android.graphics.Rect):boolean");
    }

    public final j n(int i10) {
        if (i10 != -1) {
            return k(i10);
        }
        View view = this.f5845i;
        AccessibilityNodeInfo accessibilityNodeInfoObtain = AccessibilityNodeInfo.obtain(view);
        j jVar = new j(accessibilityNodeInfoObtain);
        WeakHashMap weakHashMap = X.f3966a;
        view.onInitializeAccessibilityNodeInfo(accessibilityNodeInfoObtain);
        ArrayList arrayList = new ArrayList();
        l(arrayList);
        if (accessibilityNodeInfoObtain.getChildCount() > 0 && arrayList.size() > 0) {
            throw new RuntimeException("Views cannot have both real and virtual children");
        }
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            jVar.f4177a.addChild(view, ((Integer) arrayList.get(i11)).intValue());
        }
        return jVar;
    }

    public abstract void o(int i10, j jVar);

    public final boolean p(int i10) {
        int i11;
        View view = this.f5845i;
        if ((!view.isFocused() && !view.requestFocus()) || (i11 = this.f5848l) == i10) {
            return false;
        }
        if (i11 != Integer.MIN_VALUE) {
            j(i11);
        }
        if (i10 == Integer.MIN_VALUE) {
            return false;
        }
        this.f5848l = i10;
        b4.d dVar = (b4.d) this;
        if (i10 == 1) {
            Chip chip = dVar.f7516q;
            chip.f9476t = true;
            chip.refreshDrawableState();
        }
        q(i10, 8);
        return true;
    }

    public final void q(int i10, int i11) {
        View view;
        ViewParent parent;
        AccessibilityEvent accessibilityEventObtain;
        if (i10 == Integer.MIN_VALUE || !this.f5844h.isEnabled() || (parent = (view = this.f5845i).getParent()) == null) {
            return;
        }
        if (i10 != -1) {
            accessibilityEventObtain = AccessibilityEvent.obtain(i11);
            j jVarN = n(i10);
            accessibilityEventObtain.getText().add(jVarN.e());
            AccessibilityNodeInfo accessibilityNodeInfo = jVarN.f4177a;
            accessibilityEventObtain.setContentDescription(accessibilityNodeInfo.getContentDescription());
            accessibilityEventObtain.setScrollable(accessibilityNodeInfo.isScrollable());
            accessibilityEventObtain.setPassword(accessibilityNodeInfo.isPassword());
            accessibilityEventObtain.setEnabled(accessibilityNodeInfo.isEnabled());
            accessibilityEventObtain.setChecked(accessibilityNodeInfo.isChecked());
            if (accessibilityEventObtain.getText().isEmpty() && accessibilityEventObtain.getContentDescription() == null) {
                throw new RuntimeException("Callbacks must add text or a content description in populateEventForVirtualViewId()");
            }
            accessibilityEventObtain.setClassName(accessibilityNodeInfo.getClassName());
            o.a(accessibilityEventObtain, view, i10);
            accessibilityEventObtain.setPackageName(view.getContext().getPackageName());
        } else {
            accessibilityEventObtain = AccessibilityEvent.obtain(i11);
            view.onInitializeAccessibilityEvent(accessibilityEventObtain);
        }
        parent.requestSendAccessibilityEvent(view, accessibilityEventObtain);
    }
}
