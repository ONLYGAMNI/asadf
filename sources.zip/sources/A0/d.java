package a0;

import D6.G;
import R.X;
import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.OverScroller;
import java.util.Arrays;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: v, reason: collision with root package name */
    public static final M0.b f5853v = new M0.b(2);

    /* renamed from: a, reason: collision with root package name */
    public int f5854a;

    /* renamed from: b, reason: collision with root package name */
    public final int f5855b;
    public float[] d;

    /* renamed from: e, reason: collision with root package name */
    public float[] f5857e;

    /* renamed from: f, reason: collision with root package name */
    public float[] f5858f;
    public float[] g;

    /* renamed from: h, reason: collision with root package name */
    public int[] f5859h;

    /* renamed from: i, reason: collision with root package name */
    public int[] f5860i;

    /* renamed from: j, reason: collision with root package name */
    public int[] f5861j;

    /* renamed from: k, reason: collision with root package name */
    public int f5862k;

    /* renamed from: l, reason: collision with root package name */
    public VelocityTracker f5863l;

    /* renamed from: m, reason: collision with root package name */
    public final float f5864m;

    /* renamed from: n, reason: collision with root package name */
    public final float f5865n;

    /* renamed from: o, reason: collision with root package name */
    public final int f5866o;

    /* renamed from: p, reason: collision with root package name */
    public final OverScroller f5867p;

    /* renamed from: q, reason: collision with root package name */
    public final E4.b f5868q;

    /* renamed from: r, reason: collision with root package name */
    public View f5869r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f5870s;

    /* renamed from: t, reason: collision with root package name */
    public final ViewGroup f5871t;

    /* renamed from: c, reason: collision with root package name */
    public int f5856c = -1;

    /* renamed from: u, reason: collision with root package name */
    public final G f5872u = new G(this, 12);

    public d(Context context, ViewGroup viewGroup, E4.b bVar) {
        if (viewGroup == null) {
            throw new IllegalArgumentException("Parent view may not be null");
        }
        if (bVar == null) {
            throw new IllegalArgumentException("Callback may not be null");
        }
        this.f5871t = viewGroup;
        this.f5868q = bVar;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f5866o = (int) ((context.getResources().getDisplayMetrics().density * 20.0f) + 0.5f);
        this.f5855b = viewConfiguration.getScaledTouchSlop();
        this.f5864m = viewConfiguration.getScaledMaximumFlingVelocity();
        this.f5865n = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f5867p = new OverScroller(context, f5853v);
    }

    public final void a() {
        this.f5856c = -1;
        float[] fArr = this.d;
        if (fArr != null) {
            Arrays.fill(fArr, 0.0f);
            Arrays.fill(this.f5857e, 0.0f);
            Arrays.fill(this.f5858f, 0.0f);
            Arrays.fill(this.g, 0.0f);
            Arrays.fill(this.f5859h, 0);
            Arrays.fill(this.f5860i, 0);
            Arrays.fill(this.f5861j, 0);
            this.f5862k = 0;
        }
        VelocityTracker velocityTracker = this.f5863l;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f5863l = null;
        }
    }

    public final void b(View view, int i10) {
        ViewParent parent = view.getParent();
        ViewGroup viewGroup = this.f5871t;
        if (parent != viewGroup) {
            throw new IllegalArgumentException("captureChildView: parameter must be a descendant of the ViewDragHelper's tracked parent view (" + viewGroup + ")");
        }
        this.f5869r = view;
        this.f5856c = i10;
        this.f5868q.z(view, i10);
        n(1);
    }

    public final boolean c(View view, float f10, float f11) {
        if (view == null) {
            return false;
        }
        E4.b bVar = this.f5868q;
        boolean z3 = bVar.s(view) > 0;
        boolean z9 = bVar.t() > 0;
        if (!z3 || !z9) {
            return z3 ? Math.abs(f10) > ((float) this.f5855b) : z9 && Math.abs(f11) > ((float) this.f5855b);
        }
        float f12 = (f11 * f11) + (f10 * f10);
        int i10 = this.f5855b;
        return f12 > ((float) (i10 * i10));
    }

    public final void d(int i10) {
        float[] fArr = this.d;
        if (fArr != null) {
            int i11 = this.f5862k;
            int i12 = 1 << i10;
            if ((i11 & i12) != 0) {
                fArr[i10] = 0.0f;
                this.f5857e[i10] = 0.0f;
                this.f5858f[i10] = 0.0f;
                this.g[i10] = 0.0f;
                this.f5859h[i10] = 0;
                this.f5860i[i10] = 0;
                this.f5861j[i10] = 0;
                this.f5862k = (~i12) & i11;
            }
        }
    }

    public final int e(int i10, int i11, int i12) {
        if (i10 == 0) {
            return 0;
        }
        float width = this.f5871t.getWidth() / 2;
        float fSin = (((float) Math.sin((Math.min(1.0f, Math.abs(i10) / r0) - 0.5f) * 0.47123894f)) * width) + width;
        int iAbs = Math.abs(i11);
        return Math.min(iAbs > 0 ? Math.round(Math.abs(fSin / iAbs) * 1000.0f) * 4 : (int) (((Math.abs(i10) / i12) + 1.0f) * 256.0f), 600);
    }

    public final boolean f() {
        if (this.f5854a == 2) {
            OverScroller overScroller = this.f5867p;
            boolean zComputeScrollOffset = overScroller.computeScrollOffset();
            int currX = overScroller.getCurrX();
            int currY = overScroller.getCurrY();
            int left = currX - this.f5869r.getLeft();
            int top = currY - this.f5869r.getTop();
            if (left != 0) {
                View view = this.f5869r;
                WeakHashMap weakHashMap = X.f3966a;
                view.offsetLeftAndRight(left);
            }
            if (top != 0) {
                View view2 = this.f5869r;
                WeakHashMap weakHashMap2 = X.f3966a;
                view2.offsetTopAndBottom(top);
            }
            if (left != 0 || top != 0) {
                this.f5868q.B(this.f5869r, currX, currY);
            }
            if (zComputeScrollOffset && currX == overScroller.getFinalX() && currY == overScroller.getFinalY()) {
                overScroller.abortAnimation();
                zComputeScrollOffset = false;
            }
            if (!zComputeScrollOffset) {
                this.f5871t.post(this.f5872u);
            }
        }
        return this.f5854a == 2;
    }

    public final View g(int i10, int i11) {
        ViewGroup viewGroup = this.f5871t;
        for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
            this.f5868q.getClass();
            View childAt = viewGroup.getChildAt(childCount);
            if (i10 >= childAt.getLeft() && i10 < childAt.getRight() && i11 >= childAt.getTop() && i11 < childAt.getBottom()) {
                return childAt;
            }
        }
        return null;
    }

    public final boolean h(int i10, int i11, int i12, int i13) {
        float f10;
        float f11;
        float f12;
        float f13;
        int left = this.f5869r.getLeft();
        int top = this.f5869r.getTop();
        int i14 = i10 - left;
        int i15 = i11 - top;
        OverScroller overScroller = this.f5867p;
        int i16 = 0;
        if (i14 == 0 && i15 == 0) {
            overScroller.abortAnimation();
            n(0);
            return false;
        }
        View view = this.f5869r;
        int i17 = (int) this.f5865n;
        int i18 = (int) this.f5864m;
        int iAbs = Math.abs(i12);
        if (iAbs < i17) {
            i12 = 0;
        } else if (iAbs > i18) {
            i12 = i12 > 0 ? i18 : -i18;
        }
        int iAbs2 = Math.abs(i13);
        if (iAbs2 < i17) {
            i13 = i16;
        } else if (iAbs2 > i18) {
            if (i13 > 0) {
                i13 = i18;
            } else {
                i16 = -i18;
                i13 = i16;
            }
        }
        int iAbs3 = Math.abs(i14);
        int iAbs4 = Math.abs(i15);
        int iAbs5 = Math.abs(i12);
        int iAbs6 = Math.abs(i13);
        int i19 = iAbs5 + iAbs6;
        int i20 = iAbs3 + iAbs4;
        if (i12 != 0) {
            f10 = iAbs5;
            f11 = i19;
        } else {
            f10 = iAbs3;
            f11 = i20;
        }
        float f14 = f10 / f11;
        if (i13 != 0) {
            f12 = iAbs6;
            f13 = i19;
        } else {
            f12 = iAbs4;
            f13 = i20;
        }
        float f15 = f12 / f13;
        E4.b bVar = this.f5868q;
        overScroller.startScroll(left, top, i14, i15, (int) ((e(i15, i13, bVar.t()) * f15) + (e(i14, i12, bVar.s(view)) * f14)));
        n(2);
        return true;
    }

    public final boolean i(int i10) {
        if ((this.f5862k & (1 << i10)) != 0) {
            return true;
        }
        Log.e("ViewDragHelper", "Ignoring pointerId=" + i10 + " because ACTION_DOWN was not received for this pointer before ACTION_MOVE. It likely happened because  ViewDragHelper did not receive all the events in the event stream.");
        return false;
    }

    public final void j(MotionEvent motionEvent) {
        int i10;
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            a();
        }
        if (this.f5863l == null) {
            this.f5863l = VelocityTracker.obtain();
        }
        this.f5863l.addMovement(motionEvent);
        int i11 = 0;
        if (actionMasked == 0) {
            float x9 = motionEvent.getX();
            float y9 = motionEvent.getY();
            int pointerId = motionEvent.getPointerId(0);
            View viewG = g((int) x9, (int) y9);
            l(x9, y9, pointerId);
            q(viewG, pointerId);
            int i12 = this.f5859h[pointerId];
            return;
        }
        if (actionMasked == 1) {
            if (this.f5854a == 1) {
                k();
            }
            a();
            return;
        }
        E4.b bVar = this.f5868q;
        if (actionMasked != 2) {
            if (actionMasked == 3) {
                if (this.f5854a == 1) {
                    this.f5870s = true;
                    bVar.C(this.f5869r, 0.0f, 0.0f);
                    this.f5870s = false;
                    if (this.f5854a == 1) {
                        n(0);
                    }
                }
                a();
                return;
            }
            if (actionMasked == 5) {
                int pointerId2 = motionEvent.getPointerId(actionIndex);
                float x10 = motionEvent.getX(actionIndex);
                float y10 = motionEvent.getY(actionIndex);
                l(x10, y10, pointerId2);
                if (this.f5854a == 0) {
                    q(g((int) x10, (int) y10), pointerId2);
                    int i13 = this.f5859h[pointerId2];
                    return;
                }
                int i14 = (int) x10;
                int i15 = (int) y10;
                View view = this.f5869r;
                if (view != null) {
                    i11 = (i14 < view.getLeft() || i14 >= view.getRight() || i15 < view.getTop() || i15 >= view.getBottom()) ? 0 : 1;
                }
                if (i11 != 0) {
                    q(this.f5869r, pointerId2);
                    return;
                }
                return;
            }
            if (actionMasked != 6) {
                return;
            }
            int pointerId3 = motionEvent.getPointerId(actionIndex);
            if (this.f5854a == 1 && pointerId3 == this.f5856c) {
                int pointerCount = motionEvent.getPointerCount();
                while (true) {
                    if (i11 >= pointerCount) {
                        i10 = -1;
                        break;
                    }
                    int pointerId4 = motionEvent.getPointerId(i11);
                    if (pointerId4 != this.f5856c) {
                        View viewG2 = g((int) motionEvent.getX(i11), (int) motionEvent.getY(i11));
                        View view2 = this.f5869r;
                        if (viewG2 == view2 && q(view2, pointerId4)) {
                            i10 = this.f5856c;
                            break;
                        }
                    }
                    i11++;
                }
                if (i10 == -1) {
                    k();
                }
            }
            d(pointerId3);
            return;
        }
        if (this.f5854a == 1) {
            if (i(this.f5856c)) {
                int iFindPointerIndex = motionEvent.findPointerIndex(this.f5856c);
                float x11 = motionEvent.getX(iFindPointerIndex);
                float y11 = motionEvent.getY(iFindPointerIndex);
                float[] fArr = this.f5858f;
                int i16 = this.f5856c;
                int i17 = (int) (x11 - fArr[i16]);
                int i18 = (int) (y11 - this.g[i16]);
                int left = this.f5869r.getLeft() + i17;
                int top = this.f5869r.getTop() + i18;
                int left2 = this.f5869r.getLeft();
                int top2 = this.f5869r.getTop();
                if (i17 != 0) {
                    left = bVar.i(this.f5869r, left);
                    WeakHashMap weakHashMap = X.f3966a;
                    this.f5869r.offsetLeftAndRight(left - left2);
                }
                if (i18 != 0) {
                    top = bVar.j(this.f5869r, top);
                    WeakHashMap weakHashMap2 = X.f3966a;
                    this.f5869r.offsetTopAndBottom(top - top2);
                }
                if (i17 != 0 || i18 != 0) {
                    bVar.B(this.f5869r, left, top);
                }
                m(motionEvent);
                return;
            }
            return;
        }
        int pointerCount2 = motionEvent.getPointerCount();
        while (i11 < pointerCount2) {
            int pointerId5 = motionEvent.getPointerId(i11);
            if (i(pointerId5)) {
                float x12 = motionEvent.getX(i11);
                float y12 = motionEvent.getY(i11);
                float f10 = x12 - this.d[pointerId5];
                float f11 = y12 - this.f5857e[pointerId5];
                Math.abs(f10);
                Math.abs(f11);
                int i19 = this.f5859h[pointerId5];
                Math.abs(f11);
                Math.abs(f10);
                int i20 = this.f5859h[pointerId5];
                Math.abs(f10);
                Math.abs(f11);
                int i21 = this.f5859h[pointerId5];
                Math.abs(f11);
                Math.abs(f10);
                int i22 = this.f5859h[pointerId5];
                if (this.f5854a != 1) {
                    View viewG3 = g((int) x12, (int) y12);
                    if (c(viewG3, f10, f11) && q(viewG3, pointerId5)) {
                        break;
                    }
                } else {
                    break;
                }
            }
            i11++;
        }
        m(motionEvent);
    }

    public final void k() {
        VelocityTracker velocityTracker = this.f5863l;
        float f10 = this.f5864m;
        velocityTracker.computeCurrentVelocity(1000, f10);
        float xVelocity = this.f5863l.getXVelocity(this.f5856c);
        float f11 = this.f5865n;
        float fAbs = Math.abs(xVelocity);
        float f12 = 0.0f;
        if (fAbs < f11) {
            xVelocity = 0.0f;
        } else if (fAbs > f10) {
            xVelocity = xVelocity > 0.0f ? f10 : -f10;
        }
        float yVelocity = this.f5863l.getYVelocity(this.f5856c);
        float fAbs2 = Math.abs(yVelocity);
        if (fAbs2 >= f11) {
            if (fAbs2 > f10) {
                if (yVelocity <= 0.0f) {
                    f10 = -f10;
                }
                f12 = f10;
            } else {
                f12 = yVelocity;
            }
        }
        this.f5870s = true;
        this.f5868q.C(this.f5869r, xVelocity, f12);
        this.f5870s = false;
        if (this.f5854a == 1) {
            n(0);
        }
    }

    public final void l(float f10, float f11, int i10) {
        float[] fArr = this.d;
        if (fArr == null || fArr.length <= i10) {
            int i11 = i10 + 1;
            float[] fArr2 = new float[i11];
            float[] fArr3 = new float[i11];
            float[] fArr4 = new float[i11];
            float[] fArr5 = new float[i11];
            int[] iArr = new int[i11];
            int[] iArr2 = new int[i11];
            int[] iArr3 = new int[i11];
            if (fArr != null) {
                System.arraycopy(fArr, 0, fArr2, 0, fArr.length);
                float[] fArr6 = this.f5857e;
                System.arraycopy(fArr6, 0, fArr3, 0, fArr6.length);
                float[] fArr7 = this.f5858f;
                System.arraycopy(fArr7, 0, fArr4, 0, fArr7.length);
                float[] fArr8 = this.g;
                System.arraycopy(fArr8, 0, fArr5, 0, fArr8.length);
                int[] iArr4 = this.f5859h;
                System.arraycopy(iArr4, 0, iArr, 0, iArr4.length);
                int[] iArr5 = this.f5860i;
                System.arraycopy(iArr5, 0, iArr2, 0, iArr5.length);
                int[] iArr6 = this.f5861j;
                System.arraycopy(iArr6, 0, iArr3, 0, iArr6.length);
            }
            this.d = fArr2;
            this.f5857e = fArr3;
            this.f5858f = fArr4;
            this.g = fArr5;
            this.f5859h = iArr;
            this.f5860i = iArr2;
            this.f5861j = iArr3;
        }
        float[] fArr9 = this.d;
        this.f5858f[i10] = f10;
        fArr9[i10] = f10;
        float[] fArr10 = this.f5857e;
        this.g[i10] = f11;
        fArr10[i10] = f11;
        int[] iArr7 = this.f5859h;
        int i12 = (int) f10;
        int i13 = (int) f11;
        ViewGroup viewGroup = this.f5871t;
        int left = viewGroup.getLeft();
        int i14 = this.f5866o;
        int i15 = i12 < left + i14 ? 1 : 0;
        if (i13 < viewGroup.getTop() + i14) {
            i15 |= 4;
        }
        if (i12 > viewGroup.getRight() - i14) {
            i15 |= 2;
        }
        if (i13 > viewGroup.getBottom() - i14) {
            i15 |= 8;
        }
        iArr7[i10] = i15;
        this.f5862k |= 1 << i10;
    }

    public final void m(MotionEvent motionEvent) {
        int pointerCount = motionEvent.getPointerCount();
        for (int i10 = 0; i10 < pointerCount; i10++) {
            int pointerId = motionEvent.getPointerId(i10);
            if (i(pointerId)) {
                float x9 = motionEvent.getX(i10);
                float y9 = motionEvent.getY(i10);
                this.f5858f[pointerId] = x9;
                this.g[pointerId] = y9;
            }
        }
    }

    public final void n(int i10) {
        this.f5871t.removeCallbacks(this.f5872u);
        if (this.f5854a != i10) {
            this.f5854a = i10;
            this.f5868q.A(i10);
            if (this.f5854a == 0) {
                this.f5869r = null;
            }
        }
    }

    public final boolean o(int i10, int i11) {
        if (this.f5870s) {
            return h(i10, i11, (int) this.f5863l.getXVelocity(this.f5856c), (int) this.f5863l.getYVelocity(this.f5856c));
        }
        throw new IllegalStateException("Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased");
    }

    /* JADX WARN: Removed duplicated region for block: B:52:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0114  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean p(android.view.MotionEvent r18) {
        /*
            Method dump skipped, instructions count: 323
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a0.d.p(android.view.MotionEvent):boolean");
    }

    public final boolean q(View view, int i10) {
        if (view == this.f5869r && this.f5856c == i10) {
            return true;
        }
        if (view == null || !this.f5868q.K(view, i10)) {
            return false;
        }
        this.f5856c = i10;
        b(view, i10);
        return true;
    }
}
