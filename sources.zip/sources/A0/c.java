package a0;

import K3.E;
import S.j;
import android.graphics.Rect;
import java.util.Comparator;

/* loaded from: classes.dex */
public final class c implements Comparator {

    /* renamed from: a, reason: collision with root package name */
    public final Rect f5850a = new Rect();

    /* renamed from: b, reason: collision with root package name */
    public final Rect f5851b = new Rect();

    /* renamed from: c, reason: collision with root package name */
    public final boolean f5852c;
    public final E d;

    public c(boolean z3, E e4) {
        this.f5852c = z3;
        this.d = e4;
    }

    @Override // java.util.Comparator
    public final int compare(Object obj, Object obj2) {
        this.d.getClass();
        Rect rect = this.f5850a;
        ((j) obj).d(rect);
        Rect rect2 = this.f5851b;
        ((j) obj2).d(rect2);
        int i10 = rect.top;
        int i11 = rect2.top;
        if (i10 < i11) {
            return -1;
        }
        if (i10 > i11) {
            return 1;
        }
        int i12 = rect.left;
        int i13 = rect2.left;
        boolean z3 = this.f5852c;
        if (i12 < i13) {
            return z3 ? 1 : -1;
        }
        if (i12 > i13) {
            return z3 ? -1 : 1;
        }
        int i14 = rect.bottom;
        int i15 = rect2.bottom;
        if (i14 < i15) {
            return -1;
        }
        if (i14 > i15) {
            return 1;
        }
        int i16 = rect.right;
        int i17 = rect2.right;
        if (i16 < i17) {
            return z3 ? 1 : -1;
        }
        if (i16 > i17) {
            return z3 ? -1 : 1;
        }
        return 0;
    }
}
