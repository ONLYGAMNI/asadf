package A3;

import android.content.Context;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: b */
    public static final c f24b;

    /* renamed from: a */
    public b f25a;

    static {
        c cVar = new c();
        cVar.f25a = null;
        f24b = cVar;
    }

    public static b a(Context context) {
        b bVar;
        c cVar = f24b;
        synchronized (cVar) {
            try {
                if (cVar.f25a == null) {
                    if (context.getApplicationContext() != null) {
                        context = context.getApplicationContext();
                    }
                    cVar.f25a = new b(context, 0, false);
                }
                bVar = cVar.f25a;
            } catch (Throwable th) {
                throw th;
            }
        }
        return bVar;
    }
}
