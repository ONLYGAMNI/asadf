package a3;

import c3.InterfaceC0506b;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: a, reason: collision with root package name */
    public final Executor f5906a;

    /* renamed from: b, reason: collision with root package name */
    public final b3.d f5907b;

    /* renamed from: c, reason: collision with root package name */
    public final d f5908c;
    public final InterfaceC0506b d;

    public j(Executor executor, b3.d dVar, d dVar2, InterfaceC0506b interfaceC0506b) {
        this.f5906a = executor;
        this.f5907b = dVar;
        this.f5908c = dVar2;
        this.d = interfaceC0506b;
    }
}
