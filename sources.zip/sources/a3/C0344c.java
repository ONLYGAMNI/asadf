package a3;

import java.util.Set;

/* renamed from: a3.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0344c {

    /* renamed from: a, reason: collision with root package name */
    public final long f5881a;

    /* renamed from: b, reason: collision with root package name */
    public final long f5882b;

    /* renamed from: c, reason: collision with root package name */
    public final Set f5883c;

    public C0344c(long j10, long j11, Set set) {
        this.f5881a = j10;
        this.f5882b = j11;
        this.f5883c = set;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0344c)) {
            return false;
        }
        C0344c c0344c = (C0344c) obj;
        return this.f5881a == c0344c.f5881a && this.f5882b == c0344c.f5882b && this.f5883c.equals(c0344c.f5883c);
    }

    public final int hashCode() {
        long j10 = this.f5881a;
        int i10 = (((int) (j10 ^ (j10 >>> 32))) ^ 1000003) * 1000003;
        long j11 = this.f5882b;
        return ((i10 ^ ((int) ((j11 >>> 32) ^ j11))) * 1000003) ^ this.f5883c.hashCode();
    }

    public final String toString() {
        return "ConfigValue{delta=" + this.f5881a + ", maxAllowedDelay=" + this.f5882b + ", flags=" + this.f5883c + "}";
    }
}
