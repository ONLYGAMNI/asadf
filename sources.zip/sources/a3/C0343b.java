package a3;

import d3.C0752b;
import java.util.HashMap;
import java.util.Map;

/* renamed from: a3.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0343b {

    /* renamed from: a, reason: collision with root package name */
    public final C0752b f5879a;

    /* renamed from: b, reason: collision with root package name */
    public final Map f5880b;

    public C0343b(C0752b c0752b, HashMap map) {
        this.f5879a = c0752b;
        this.f5880b = map;
    }

    public final long a(R2.d dVar, long j10, int i10) {
        long jA = j10 - this.f5879a.a();
        C0344c c0344c = (C0344c) this.f5880b.get(dVar);
        long j11 = c0344c.f5881a;
        return Math.min(Math.max((long) (Math.pow(3.0d, i10 - 1) * j11 * Math.max(1.0d, Math.log(10000.0d) / Math.log((j11 > 1 ? j11 : 2L) * r12))), jA), c0344c.f5882b);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0343b)) {
            return false;
        }
        C0343b c0343b = (C0343b) obj;
        return this.f5879a.equals(c0343b.f5879a) && this.f5880b.equals(c0343b.f5880b);
    }

    public final int hashCode() {
        return ((this.f5879a.hashCode() ^ 1000003) * 1000003) ^ this.f5880b.hashCode();
    }

    public final String toString() {
        return "SchedulerConfig{clock=" + this.f5879a + ", values=" + this.f5880b + "}";
    }
}
