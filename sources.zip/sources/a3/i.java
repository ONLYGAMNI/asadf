package a3;

import android.content.Context;
import b3.InterfaceC0486c;
import c3.InterfaceC0506b;
import d3.C0752b;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: a */
    public final Context f5899a;

    /* renamed from: b */
    public final V2.f f5900b;

    /* renamed from: c */
    public final b3.d f5901c;
    public final d d;

    /* renamed from: e */
    public final Executor f5902e;

    /* renamed from: f */
    public final InterfaceC0506b f5903f;
    public final C0752b g;

    /* renamed from: h */
    public final C0752b f5904h;

    /* renamed from: i */
    public final InterfaceC0486c f5905i;

    public i(Context context, V2.f fVar, b3.d dVar, d dVar2, Executor executor, InterfaceC0506b interfaceC0506b, C0752b c0752b, C0752b c0752b2, InterfaceC0486c interfaceC0486c) {
        this.f5899a = context;
        this.f5900b = fVar;
        this.f5901c = dVar;
        this.d = dVar2;
        this.f5902e = executor;
        this.f5903f = interfaceC0506b;
        this.g = c0752b;
        this.f5904h = c0752b2;
        this.f5905i = interfaceC0486c;
    }

    /* JADX WARN: Removed duplicated region for block: B:658:0x0611  */
    /* JADX WARN: Removed duplicated region for block: B:660:0x0616 A[Catch: IOException -> 0x0639, TryCatch #0 {IOException -> 0x0639, blocks: (B:655:0x0609, B:660:0x0616, B:665:0x0629, B:667:0x062f, B:680:0x064e, B:683:0x0656, B:684:0x065f), top: B:721:0x0609 }] */
    /* JADX WARN: Removed duplicated region for block: B:667:0x062f A[Catch: IOException -> 0x0639, TRY_LEAVE, TryCatch #0 {IOException -> 0x0639, blocks: (B:655:0x0609, B:660:0x0616, B:665:0x0629, B:667:0x062f, B:680:0x064e, B:683:0x0656, B:684:0x065f), top: B:721:0x0609 }] */
    /* JADX WARN: Removed duplicated region for block: B:671:0x063c  */
    /* JADX WARN: Removed duplicated region for block: B:700:0x06c8  */
    /* JADX WARN: Removed duplicated region for block: B:725:0x05a1 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:753:0x05f6 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:784:0x06a8 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:808:0x0628 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void a(U2.j r46, int r47) throws java.lang.Throwable {
        /*
            Method dump skipped, instructions count: 1885
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a3.i.a(U2.j, int):void");
    }
}
