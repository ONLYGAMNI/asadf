package a3;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public static final e f5887a;

    /* renamed from: b, reason: collision with root package name */
    public static final e f5888b;

    /* renamed from: c, reason: collision with root package name */
    public static final e f5889c;
    public static final /* synthetic */ e[] d;

    static {
        e eVar = new e("NETWORK_UNMETERED", 0);
        f5887a = eVar;
        e eVar2 = new e("DEVICE_IDLE", 1);
        f5888b = eVar2;
        e eVar3 = new e("DEVICE_CHARGING", 2);
        f5889c = eVar3;
        d = new e[]{eVar, eVar2, eVar3};
    }

    public static e valueOf(String str) {
        return (e) Enum.valueOf(e.class, str);
    }

    public static e[] values() {
        return (e[]) d.clone();
    }
}
