package A3;

import E5.E;
import E5.RunnableC0066h;
import S.m;
import U2.k;
import U2.n;
import V2.e;
import a.AbstractC0338a;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Binder;
import android.os.Process;
import androidx.emoji2.text.h;
import b0.C0477g;
import b3.f;
import com.google.android.gms.common.internal.K;
import d3.AbstractC0751a;
import d8.InterfaceC0763a;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import l1.d;
import p3.i;
import y2.C1664b;
import y2.g;
import y2.o;
import y2.s;
import y2.t;
import y2.y;
import y3.AbstractC1670c;

/* loaded from: classes.dex */
public final class b implements h, t, g {

    /* renamed from: a */
    public final /* synthetic */ int f22a;

    /* renamed from: b */
    public Context f23b;

    public /* synthetic */ b() {
        this.f22a = 2;
    }

    @Override // y2.g
    public Class a() {
        return Drawable.class;
    }

    @Override // y2.g
    public Object b(Resources resources, int i10, Resources.Theme theme) {
        Context context = this.f23b;
        return com.bumptech.glide.c.C(context, context, i10, theme);
    }

    @Override // androidx.emoji2.text.h
    public void c(AbstractC0338a abstractC0338a) {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new androidx.emoji2.text.a("EmojiCompatInitializer"));
        threadPoolExecutor.allowCoreThreadTimeOut(true);
        threadPoolExecutor.execute(new RunnableC0066h(this, abstractC0338a, threadPoolExecutor, 2));
    }

    @Override // y2.g
    public /* bridge */ /* synthetic */ void d(Object obj) {
    }

    public k e() {
        Context context = this.f23b;
        if (context == null) {
            throw new IllegalStateException(Context.class.getCanonicalName() + " must be set");
        }
        k kVar = new k();
        kVar.f4860a = W2.a.a(n.f4867a);
        m mVar = new m(context);
        kVar.f4861b = mVar;
        kVar.f4862c = W2.a.a(new d(9, mVar, new e(mVar, 0)));
        m mVar2 = kVar.f4861b;
        kVar.d = new e(mVar2, 1);
        InterfaceC0763a interfaceC0763aA = W2.a.a(new U2.t(kVar.d, W2.a.a(new l1.c(mVar2, 22))));
        kVar.f4863e = interfaceC0763aA;
        i iVar = new i(16, (byte) 0);
        m mVar3 = kVar.f4861b;
        X0.i iVar2 = new X0.i(mVar3, interfaceC0763aA, iVar);
        InterfaceC0763a interfaceC0763a = kVar.f4860a;
        InterfaceC0763a interfaceC0763a2 = kVar.f4862c;
        U2.t tVar = new U2.t(interfaceC0763a, interfaceC0763a2, iVar2, interfaceC0763aA, interfaceC0763aA);
        f fVar = AbstractC0751a.f10091a;
        C0477g c0477g = AbstractC0751a.f10092b;
        T2.t tVar2 = new T2.t();
        tVar2.f4585a = mVar3;
        tVar2.f4586b = interfaceC0763a2;
        tVar2.f4587c = interfaceC0763aA;
        tVar2.d = iVar2;
        tVar2.f4588e = interfaceC0763a;
        tVar2.f4589f = interfaceC0763aA;
        tVar2.f4590n = fVar;
        tVar2.f4591o = c0477g;
        tVar2.f4592p = interfaceC0763aA;
        kVar.f4864f = W2.a.a(new U2.t(tVar, tVar2, new E(interfaceC0763a, interfaceC0763aA, iVar2, interfaceC0763aA, 8)));
        return kVar;
    }

    public ApplicationInfo f(int i10, String str) {
        return this.f23b.getPackageManager().getApplicationInfo(str, i10);
    }

    public PackageInfo g(int i10, String str) {
        return this.f23b.getPackageManager().getPackageInfo(str, i10);
    }

    public boolean h() {
        String nameForUid;
        int callingUid = Binder.getCallingUid();
        int iMyUid = Process.myUid();
        Context context = this.f23b;
        if (callingUid == iMyUid) {
            return a.o(context);
        }
        if (!AbstractC1670c.d() || (nameForUid = context.getPackageManager().getNameForUid(Binder.getCallingUid())) == null) {
            return false;
        }
        return context.getPackageManager().isInstantApp(nameForUid);
    }

    @Override // y2.t
    public s n(y yVar) {
        switch (this.f22a) {
            case 5:
                return new C1664b(this.f23b, this);
            case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                return new C1664b(this.f23b, yVar.c(Integer.class, AssetFileDescriptor.class));
            default:
                return new o(this.f23b, 1);
        }
    }

    public /* synthetic */ b(Context context, int i10, boolean z3) {
        this.f22a = i10;
        this.f23b = context;
    }

    public b(Context context, int i10) {
        this.f22a = i10;
        switch (i10) {
            case 3:
                this.f23b = context.getApplicationContext();
                break;
            default:
                K.j(context);
                Context applicationContext = context.getApplicationContext();
                K.j(applicationContext);
                this.f23b = applicationContext;
                break;
        }
    }
}
