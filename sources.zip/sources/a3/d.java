package a3;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.PersistableBundle;
import android.util.Base64;
import android.util.Log;
import b3.k;
import com.google.android.datatransport.runtime.scheduling.jobscheduling.JobInfoSchedulerService;
import e3.AbstractC0784a;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Set;
import java.util.zip.Adler32;
import x8.AbstractC1655g;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final Context f5884a;

    /* renamed from: b, reason: collision with root package name */
    public final b3.d f5885b;

    /* renamed from: c, reason: collision with root package name */
    public final C0343b f5886c;

    public d(Context context, b3.d dVar, C0343b c0343b) {
        this.f5884a = context;
        this.f5885b = dVar;
        this.f5886c = c0343b;
    }

    public final void a(U2.j jVar, int i10, boolean z3) {
        Context context = this.f5884a;
        ComponentName componentName = new ComponentName(context, (Class<?>) JobInfoSchedulerService.class);
        JobScheduler jobScheduler = (JobScheduler) context.getSystemService("jobscheduler");
        Adler32 adler32 = new Adler32();
        adler32.update(context.getPackageName().getBytes(Charset.forName("UTF-8")));
        adler32.update(jVar.f4857a.getBytes(Charset.forName("UTF-8")));
        ByteBuffer byteBufferAllocate = ByteBuffer.allocate(4);
        R2.d dVar = jVar.f4859c;
        adler32.update(byteBufferAllocate.putInt(AbstractC0784a.a(dVar)).array());
        byte[] bArr = jVar.f4858b;
        if (bArr != null) {
            adler32.update(bArr);
        }
        int value = (int) adler32.getValue();
        if (!z3) {
            Iterator<JobInfo> it = jobScheduler.getAllPendingJobs().iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                JobInfo next = it.next();
                int i11 = next.getExtras().getInt("attemptNumber");
                if (next.getId() == value) {
                    if (i11 >= i10) {
                        AbstractC1655g.h(jVar, "JobInfoScheduler", "Upload for context %s is already scheduled. Returning...");
                        return;
                    }
                }
            }
        }
        SQLiteDatabase sQLiteDatabaseB = ((k) this.f5885b).b();
        String strValueOf = String.valueOf(AbstractC0784a.a(dVar));
        String str = jVar.f4857a;
        Cursor cursorRawQuery = sQLiteDatabaseB.rawQuery("SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?", new String[]{str, strValueOf});
        try {
            Long lValueOf = cursorRawQuery.moveToNext() ? Long.valueOf(cursorRawQuery.getLong(0)) : 0L;
            cursorRawQuery.close();
            long jLongValue = lValueOf.longValue();
            JobInfo.Builder builder = new JobInfo.Builder(value, componentName);
            C0343b c0343b = this.f5886c;
            Long l5 = lValueOf;
            builder.setMinimumLatency(c0343b.a(dVar, jLongValue, i10));
            Set set = ((C0344c) c0343b.f5880b.get(dVar)).f5883c;
            if (set.contains(e.f5887a)) {
                builder.setRequiredNetworkType(2);
            } else {
                builder.setRequiredNetworkType(1);
            }
            if (set.contains(e.f5889c)) {
                builder.setRequiresCharging(true);
            }
            if (set.contains(e.f5888b)) {
                builder.setRequiresDeviceIdle(true);
            }
            PersistableBundle persistableBundle = new PersistableBundle();
            persistableBundle.putInt("attemptNumber", i10);
            persistableBundle.putString("backendName", str);
            persistableBundle.putInt("priority", AbstractC0784a.a(dVar));
            if (bArr != null) {
                persistableBundle.putString("extras", Base64.encodeToString(bArr, 0));
            }
            builder.setExtras(persistableBundle);
            Object[] objArr = {jVar, Integer.valueOf(value), Long.valueOf(c0343b.a(dVar, jLongValue, i10)), l5, Integer.valueOf(i10)};
            String strS = AbstractC1655g.s("JobInfoScheduler");
            if (Log.isLoggable(strS, 3)) {
                Log.d(strS, String.format("Scheduling upload for context %s with jobId=%d in %dms(Backend next call timestamp %d). Attempt %d", objArr));
            }
            jobScheduler.schedule(builder.build());
        } catch (Throwable th) {
            cursorRawQuery.close();
            throw th;
        }
    }
}
