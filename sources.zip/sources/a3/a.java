package A3;

import B.k;
import D.h;
import D.i;
import Q8.g;
import Q8.m;
import T4.o;
import W6.q;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.StrictMode;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import com.algolia.search.exception.AlgoliaClientException;
import com.google.firebase.components.DependencyCycleException;
import com.tajir.tajir.App;
import f8.AbstractC0841i;
import f8.AbstractC0842j;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlinx.serialization.descriptors.SerialDescriptor;
import org.xmlpull.v1.XmlSerializer;
import q0.C1291c;
import q0.F;
import r8.l;
import s2.AbstractC1397b;
import s8.AbstractC1420h;
import v7.C1565D;
import v7.C1567F;
import v7.C1569H;
import v7.InterfaceC1562A;
import y3.AbstractC1670c;
import y8.e;
import y8.j;
import z8.f;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a */
    public static Context f18a = null;

    /* renamed from: b */
    public static Boolean f19b = null;

    /* renamed from: c */
    public static Field f20c = null;
    public static boolean d = false;

    /* renamed from: e */
    public static boolean f21e = true;

    public static final C1569H a(C1565D c1565d) {
        AbstractC1420h.f(c1565d, "builder");
        C1565D c1565d2 = new C1565D();
        y(c1565d2, c1565d);
        return c1565d2.b();
    }

    public static final AlgoliaClientException b(Throwable th) {
        AbstractC1420h.f(th, "<this>");
        return new AlgoliaClientException(th.getMessage(), th.getCause());
    }

    public static final g c(String str, SerialDescriptor[] serialDescriptorArr, l lVar) {
        AbstractC1420h.f(str, "serialName");
        AbstractC1420h.f(lVar, "builderAction");
        if (!(!f.K0(str))) {
            throw new IllegalArgumentException("Blank serial names are prohibited".toString());
        }
        Q8.a aVar = new Q8.a(str);
        lVar.invoke(aVar);
        return new g(str, m.f3944n, aVar.f3906b.size(), AbstractC0841i.f0(serialDescriptorArr), aVar);
    }

    public static final g d(String str, C3.f fVar, SerialDescriptor[] serialDescriptorArr, l lVar) {
        AbstractC1420h.f(str, "serialName");
        AbstractC1420h.f(lVar, "builder");
        if (!(!f.K0(str))) {
            throw new IllegalArgumentException("Blank serial names are prohibited".toString());
        }
        if (!(!fVar.equals(m.f3944n))) {
            throw new IllegalArgumentException("For StructureKind.CLASS please use 'buildClassSerialDescriptor' instead".toString());
        }
        Q8.a aVar = new Q8.a(str);
        lVar.invoke(aVar);
        return new g(str, fVar, aVar.f3906b.size(), AbstractC0841i.f0(serialDescriptorArr), aVar);
    }

    public static int e(Context context, String str) {
        int iC;
        int iMyPid = Process.myPid();
        int iMyUid = Process.myUid();
        String packageName = context.getPackageName();
        if (context.checkPermission(str, iMyPid, iMyUid) == -1) {
            return -1;
        }
        String strD = h.d(str);
        if (strD != null) {
            if (packageName == null) {
                String[] packagesForUid = context.getPackageManager().getPackagesForUid(iMyUid);
                if (packagesForUid == null || packagesForUid.length <= 0) {
                    return -1;
                }
                packageName = packagesForUid[0];
            }
            int iMyUid2 = Process.myUid();
            String packageName2 = context.getPackageName();
            if (iMyUid2 == iMyUid && Q.b.a(packageName2, packageName) && Build.VERSION.SDK_INT >= 29) {
                AppOpsManager appOpsManagerC = i.c(context);
                iC = i.a(appOpsManagerC, strD, Binder.getCallingUid(), packageName);
                if (iC == 0) {
                    iC = i.a(appOpsManagerC, strD, iMyUid, i.b(context));
                }
            } else {
                iC = h.c((AppOpsManager) h.a(context, AppOpsManager.class), strD, packageName);
            }
            if (iC != 0) {
                return -2;
            }
        }
        return 0;
    }

    public static void f(Closeable closeable) throws IOException {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException unused) {
            }
        }
    }

    public static boolean g(File file, Resources resources, int i10) throws Throwable {
        InputStream inputStreamOpenRawResource;
        try {
            inputStreamOpenRawResource = resources.openRawResource(i10);
        } catch (Throwable th) {
            th = th;
            inputStreamOpenRawResource = null;
        }
        try {
            boolean zH = h(file, inputStreamOpenRawResource);
            f(inputStreamOpenRawResource);
            return zH;
        } catch (Throwable th2) {
            th = th2;
            f(inputStreamOpenRawResource);
            throw th;
        }
    }

    public static boolean h(File file, InputStream inputStream) throws Throwable {
        StrictMode.ThreadPolicy threadPolicyAllowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        FileOutputStream fileOutputStream = null;
        try {
            try {
                FileOutputStream fileOutputStream2 = new FileOutputStream(file, false);
                try {
                    byte[] bArr = new byte[1024];
                    while (true) {
                        int i10 = inputStream.read(bArr);
                        if (i10 == -1) {
                            f(fileOutputStream2);
                            StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                            return true;
                        }
                        fileOutputStream2.write(bArr, 0, i10);
                    }
                } catch (IOException e4) {
                    e = e4;
                    fileOutputStream = fileOutputStream2;
                    Log.e("TypefaceCompatUtil", "Error copying resource contents to temp file: " + e.getMessage());
                    f(fileOutputStream);
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    return false;
                } catch (Throwable th) {
                    th = th;
                    fileOutputStream = fileOutputStream2;
                    f(fileOutputStream);
                    StrictMode.setThreadPolicy(threadPolicyAllowThreadDiskWrites);
                    throw th;
                }
            } catch (Throwable th2) {
                th = th2;
            }
        } catch (IOException e5) {
            e = e5;
        }
    }

    public static void i(ArrayList arrayList) {
        HashMap map = new HashMap(arrayList.size());
        Iterator it = arrayList.iterator();
        while (true) {
            int i10 = 0;
            if (!it.hasNext()) {
                Iterator it2 = map.values().iterator();
                while (it2.hasNext()) {
                    for (T4.g gVar : (Set) it2.next()) {
                        for (T4.i iVar : gVar.f4635a.f4623c) {
                            if (iVar.f4642c == 0) {
                                Set<T4.g> set = (Set) map.get(new T4.h(iVar.f4640a, iVar.f4641b == 2));
                                if (set != null) {
                                    for (T4.g gVar2 : set) {
                                        gVar.f4636b.add(gVar2);
                                        gVar2.f4637c.add(gVar);
                                    }
                                }
                            }
                        }
                    }
                }
                HashSet hashSet = new HashSet();
                Iterator it3 = map.values().iterator();
                while (it3.hasNext()) {
                    hashSet.addAll((Set) it3.next());
                }
                HashSet hashSet2 = new HashSet();
                Iterator it4 = hashSet.iterator();
                while (it4.hasNext()) {
                    T4.g gVar3 = (T4.g) it4.next();
                    if (gVar3.f4637c.isEmpty()) {
                        hashSet2.add(gVar3);
                    }
                }
                while (!hashSet2.isEmpty()) {
                    T4.g gVar4 = (T4.g) hashSet2.iterator().next();
                    hashSet2.remove(gVar4);
                    i10++;
                    Iterator it5 = gVar4.f4636b.iterator();
                    while (it5.hasNext()) {
                        T4.g gVar5 = (T4.g) it5.next();
                        gVar5.f4637c.remove(gVar4);
                        if (gVar5.f4637c.isEmpty()) {
                            hashSet2.add(gVar5);
                        }
                    }
                }
                if (i10 == arrayList.size()) {
                    return;
                }
                ArrayList arrayList2 = new ArrayList();
                Iterator it6 = hashSet.iterator();
                while (it6.hasNext()) {
                    T4.g gVar6 = (T4.g) it6.next();
                    if (!gVar6.f4637c.isEmpty() && !gVar6.f4636b.isEmpty()) {
                        arrayList2.add(gVar6.f4635a);
                    }
                }
                throw new DependencyCycleException(arrayList2);
            }
            T4.b bVar = (T4.b) it.next();
            T4.g gVar7 = new T4.g(bVar);
            for (o oVar : bVar.f4622b) {
                boolean z3 = !(bVar.f4624e == 0);
                T4.h hVar = new T4.h(oVar, z3);
                if (!map.containsKey(hVar)) {
                    map.put(hVar, new HashSet());
                }
                Set set2 = (Set) map.get(hVar);
                if (!set2.isEmpty() && !z3) {
                    throw new IllegalArgumentException("Multiple components provide " + oVar + ".");
                }
                set2.add(gVar7);
            }
        }
    }

    public static final F j(View view) {
        AbstractC1420h.f(view, "view");
        e eVar = new e(new y8.f(new y8.f(2, j.B(view, C1291c.f14432o), C1291c.f14433p)));
        F f10 = (F) (!eVar.hasNext() ? null : eVar.next());
        if (f10 != null) {
            return f10;
        }
        throw new IllegalStateException("View " + view + " does not have a NavController set");
    }

    public static App k() {
        App app = App.f9924b;
        if (app != null) {
            return app;
        }
        AbstractC1420h.m("instance");
        throw null;
    }

    public static int l(int i10, int i11) {
        if (i11 == 0) {
            return 0;
        }
        return (i10 + i11) % i11;
    }

    public static File m(Context context) {
        File cacheDir = context.getCacheDir();
        if (cacheDir == null) {
            return null;
        }
        String str = ".font" + Process.myPid() + "-" + Process.myTid() + "-";
        for (int i10 = 0; i10 < 100; i10++) {
            File file = new File(cacheDir, str + i10);
            if (file.createNewFile()) {
                return file;
            }
        }
        return null;
    }

    public static synchronized boolean o(Context context) {
        Boolean bool;
        Context applicationContext = context.getApplicationContext();
        Context context2 = f18a;
        if (context2 != null && (bool = f19b) != null && context2 == applicationContext) {
            return bool.booleanValue();
        }
        f19b = null;
        if (AbstractC1670c.d()) {
            f19b = Boolean.valueOf(applicationContext.getPackageManager().isInstantApp());
        } else {
            try {
                context.getClassLoader().loadClass("com.google.android.instantapps.supervisor.InstantAppsRuntime");
                f19b = Boolean.TRUE;
            } catch (ClassNotFoundException unused) {
                f19b = Boolean.FALSE;
            }
        }
        f18a = applicationContext;
        return f19b.booleanValue();
    }

    public static final void p(Appendable appendable, String str, String str2) throws IOException {
        AbstractC1420h.f(str, "key");
        AbstractC1420h.f(str2, "value");
        Appendable appendableAppend = appendable.append("-> " + str + ": " + str2);
        AbstractC1420h.e(appendableAppend, "append(value)");
        AbstractC1420h.e(appendableAppend.append('\n'), "append('\\n')");
    }

    public static final void q(Appendable appendable, Set set) throws IOException {
        AbstractC1420h.f(set, "headers");
        for (Map.Entry entry : AbstractC0842j.k0(new k(11), AbstractC0842j.p0(set))) {
            p(appendable, (String) entry.getKey(), AbstractC0842j.a0((List) entry.getValue(), "; ", null, null, null, 62));
        }
    }

    public static MappedByteBuffer r(Context context, Uri uri) throws IOException {
        try {
            ParcelFileDescriptor parcelFileDescriptorA = H.m.a(context.getContentResolver(), uri, "r", null);
            if (parcelFileDescriptorA == null) {
                if (parcelFileDescriptorA != null) {
                    parcelFileDescriptorA.close();
                }
                return null;
            }
            try {
                FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptorA.getFileDescriptor());
                try {
                    FileChannel channel = fileInputStream.getChannel();
                    MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                    fileInputStream.close();
                    parcelFileDescriptorA.close();
                    return map;
                } finally {
                }
            } finally {
            }
        } catch (IOException unused) {
            return null;
        }
    }

    public static final void s(Context context, String str) {
        String strC = H5.a.a().c("tajir_whatsapp_link");
        String strB = str != null ? AbstractC1397b.b("?text=", URLEncoder.encode(str, StandardCharsets.UTF_8.name())) : "";
        context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(!q.m(strC) ? android.support.v4.media.session.a.l(strC, strB) : AbstractC1397b.b("https://wa.me/+924232301497", strB))));
    }

    public static void t(Context context, String str) throws IOException {
        if (str.equals("")) {
            context.deleteFile("androidx.appcompat.app.AppCompatDelegate.application_locales_record_file");
            return;
        }
        try {
            FileOutputStream fileOutputStreamOpenFileOutput = context.openFileOutput("androidx.appcompat.app.AppCompatDelegate.application_locales_record_file", 0);
            XmlSerializer xmlSerializerNewSerializer = Xml.newSerializer();
            try {
                try {
                    xmlSerializerNewSerializer.setOutput(fileOutputStreamOpenFileOutput, null);
                    xmlSerializerNewSerializer.startDocument("UTF-8", Boolean.TRUE);
                    xmlSerializerNewSerializer.startTag(null, "locales");
                    xmlSerializerNewSerializer.attribute(null, "application_locales", str);
                    xmlSerializerNewSerializer.endTag(null, "locales");
                    xmlSerializerNewSerializer.endDocument();
                    Log.d("AppLocalesStorageHelper", "Storing App Locales : app-locales: " + str + " persisted successfully.");
                } catch (Exception e4) {
                    Log.w("AppLocalesStorageHelper", "Storing App Locales : Failed to persist app-locales: ".concat(str), e4);
                    if (fileOutputStreamOpenFileOutput != null) {
                    }
                }
                if (fileOutputStreamOpenFileOutput != null) {
                    try {
                        fileOutputStreamOpenFileOutput.close();
                    } catch (IOException unused) {
                    }
                }
            } catch (Throwable th) {
                if (fileOutputStreamOpenFileOutput != null) {
                    try {
                        fileOutputStreamOpenFileOutput.close();
                    } catch (IOException unused2) {
                    }
                }
                throw th;
            }
        } catch (FileNotFoundException unused3) {
            Log.w("AppLocalesStorageHelper", "Storing App Locales : FileNotFoundException: Cannot open file androidx.appcompat.app.AppCompatDelegate.application_locales_record_file for writing ");
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:78:0x003c, code lost:
    
        r2 = r4.getAttributeValue(null, "application_locales");
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static java.lang.String u(android.content.Context r9) throws java.io.IOException {
        /*
            java.lang.String r0 = "androidx.appcompat.app.AppCompatDelegate.application_locales_record_file"
            java.lang.String r1 = "AppLocalesStorageHelper"
            java.lang.String r2 = ""
            java.io.FileInputStream r3 = r9.openFileInput(r0)     // Catch: java.io.FileNotFoundException -> L6b
            org.xmlpull.v1.XmlPullParser r4 = android.util.Xml.newPullParser()     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
            java.lang.String r5 = "UTF-8"
            r4.setInput(r3, r5)     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
            int r5 = r4.getDepth()     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
        L17:
            int r6 = r4.next()     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
            r7 = 1
            if (r6 == r7) goto L43
            r7 = 3
            if (r6 != r7) goto L2a
            int r8 = r4.getDepth()     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
            if (r8 <= r5) goto L43
            goto L2a
        L28:
            r9 = move-exception
            goto L65
        L2a:
            if (r6 == r7) goto L17
            r7 = 4
            if (r6 != r7) goto L30
            goto L17
        L30:
            java.lang.String r6 = r4.getName()     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
            java.lang.String r7 = "locales"
            boolean r6 = r6.equals(r7)     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
            if (r6 == 0) goto L17
            java.lang.String r5 = "application_locales"
            r6 = 0
            java.lang.String r2 = r4.getAttributeValue(r6, r5)     // Catch: java.lang.Throwable -> L28 java.lang.Throwable -> L49
        L43:
            if (r3 == 0) goto L51
        L45:
            r3.close()     // Catch: java.io.IOException -> L51
            goto L51
        L49:
            java.lang.String r4 = "Reading app Locales : Unable to parse through file :androidx.appcompat.app.AppCompatDelegate.application_locales_record_file"
            android.util.Log.w(r1, r4)     // Catch: java.lang.Throwable -> L28
            if (r3 == 0) goto L51
            goto L45
        L51:
            boolean r3 = r2.isEmpty()
            if (r3 != 0) goto L61
            java.lang.String r9 = "Reading app Locales : Locales read from file: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file , appLocales: "
            java.lang.String r9 = r9.concat(r2)
            android.util.Log.d(r1, r9)
            goto L64
        L61:
            r9.deleteFile(r0)
        L64:
            return r2
        L65:
            if (r3 == 0) goto L6a
            r3.close()     // Catch: java.io.IOException -> L6a
        L6a:
            throw r9
        L6b:
            java.lang.String r9 = "Reading app Locales : Locales record file not found: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file"
            android.util.Log.w(r1, r9)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: A3.a.u(android.content.Context):java.lang.String");
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final java.lang.Object v(i7.C1011b r4, i8.d r5) throws java.lang.Throwable {
        /*
            boolean r0 = r5 instanceof i7.d
            if (r0 == 0) goto L13
            r0 = r5
            i7.d r0 = (i7.d) r0
            int r1 = r0.f11277c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f11277c = r1
            goto L18
        L13:
            i7.d r0 = new i7.d
            r0.<init>(r5)
        L18:
            java.lang.Object r5 = r0.f11276b
            j8.a r1 = j8.EnumC1073a.f11857a
            int r2 = r0.f11277c
            r3 = 1
            if (r2 == 0) goto L31
            if (r2 != r3) goto L29
            i7.b r4 = r0.f11275a
            f9.d.x(r5)
            goto L47
        L29:
            java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
            java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
            r4.<init>(r5)
            throw r4
        L31:
            f9.d.x(r5)
            s7.b r5 = r4.e()
            io.ktor.utils.io.x r5 = r5.d()
            r0.f11275a = r4
            r0.f11277c = r3
            java.lang.Object r5 = D4.b.M(r5, r0)
            if (r5 != r1) goto L47
            return r1
        L47:
            H7.d r5 = (H7.d) r5
            byte[] r5 = com.bumptech.glide.c.H(r5)
            i7.e r0 = new i7.e
            h7.c r1 = r4.f11271a
            r7.b r2 = r4.d()
            s7.b r4 = r4.e()
            r0.<init>(r1, r2, r4, r5)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: A3.a.v(i7.b, i8.d):java.lang.Object");
    }

    public static final void y(C1565D c1565d, C1565D c1565d2) {
        AbstractC1420h.f(c1565d, "<this>");
        AbstractC1420h.f(c1565d2, "url");
        C1567F c1567f = c1565d2.f15764a;
        AbstractC1420h.f(c1567f, "<set-?>");
        c1565d.f15764a = c1567f;
        c1565d.d(c1565d2.f15765b);
        c1565d.f15766c = c1565d2.f15766c;
        List list = c1565d2.f15769h;
        AbstractC1420h.f(list, "<set-?>");
        c1565d.f15769h = list;
        c1565d.f15767e = c1565d2.f15767e;
        c1565d.f15768f = c1565d2.f15768f;
        InterfaceC1562A interfaceC1562A = c1565d2.f15770i;
        AbstractC1420h.f(interfaceC1562A, "value");
        c1565d.f15770i = interfaceC1562A;
        c1565d.f15771j = new P.i(interfaceC1562A);
        String str = c1565d2.g;
        AbstractC1420h.f(str, "<set-?>");
        c1565d.g = str;
        c1565d.d = c1565d2.d;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0052 A[PHI: r2
  0x0052: PHI (r2v3 long) = (r2v1 long), (r2v2 long) binds: [B:31:0x0050, B:34:0x005b] A[DONT_GENERATE, DONT_INLINE]] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static final long z(int r8, A8.c r9) {
        /*
            java.lang.String r0 = "unit"
            s8.AbstractC1420h.f(r9, r0)
            A8.c r0 = A8.c.d
            int r0 = r9.compareTo(r0)
            r1 = 1
            if (r0 > 0) goto L1b
            long r2 = (long) r8
            A8.c r8 = A8.c.f57b
            long r8 = C3.f.e(r2, r9, r8)
            long r8 = r8 << r1
            int r0 = A8.a.d
            int r0 = A8.b.f56a
            goto L66
        L1b:
            long r2 = (long) r8
            A8.c r8 = A8.c.f57b
            r4 = 4611686018426999999(0x3ffffffffffa14bf, double:1.9999999999138678)
            long r4 = C3.f.e(r4, r8, r9)
            long r6 = -r4
            int r0 = (r6 > r2 ? 1 : (r6 == r2 ? 0 : -1))
            if (r0 > 0) goto L3a
            int r0 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r0 > 0) goto L3a
            long r8 = C3.f.e(r2, r9, r8)
            long r8 = r8 << r1
            int r0 = A8.a.d
            int r0 = A8.b.f56a
            goto L66
        L3a:
            A8.c r8 = A8.c.f58c
            java.lang.String r0 = "targetUnit"
            s8.AbstractC1420h.f(r8, r0)
            java.util.concurrent.TimeUnit r8 = r8.f63a
            java.util.concurrent.TimeUnit r9 = r9.f63a
            long r8 = r8.convert(r2, r9)
            r2 = -4611686018427387903(0xc000000000000001, double:-2.0000000000000004)
            int r0 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r0 >= 0) goto L54
        L52:
            r8 = r2
            goto L5e
        L54:
            r2 = 4611686018427387903(0x3fffffffffffffff, double:1.9999999999999998)
            int r0 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r0 <= 0) goto L5e
            goto L52
        L5e:
            long r8 = r8 << r1
            r0 = 1
            long r8 = r8 + r0
            int r0 = A8.a.d
            int r0 = A8.b.f56a
        L66:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: A3.a.z(int, A8.c):long");
    }

    public float n(View view) {
        if (f21e) {
            try {
                return view.getTransitionAlpha();
            } catch (NoSuchMethodError unused) {
                f21e = false;
            }
        }
        return view.getAlpha();
    }

    public void w(View view, float f10) {
        if (f21e) {
            try {
                view.setTransitionAlpha(f10);
                return;
            } catch (NoSuchMethodError unused) {
                f21e = false;
            }
        }
        view.setAlpha(f10);
    }

    public void x(View view, int i10) throws IllegalAccessException, NoSuchFieldException, SecurityException, IllegalArgumentException {
        if (!d) {
            try {
                Field declaredField = View.class.getDeclaredField("mViewFlags");
                f20c = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException unused) {
                Log.i("ViewUtilsBase", "fetchViewFlagsField: ");
            }
            d = true;
        }
        Field field = f20c;
        if (field != null) {
            try {
                f20c.setInt(view, i10 | (field.getInt(view) & (-13)));
            } catch (IllegalAccessException unused2) {
            }
        }
    }
}
