package a3;

import D6.p;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import b3.k;
import c3.InterfaceC0505a;
import c3.InterfaceC0506b;
import com.google.android.datatransport.runtime.synchronization.SynchronizationException;
import java.util.Objects;

/* loaded from: classes.dex */
public final /* synthetic */ class f implements Runnable {

    /* renamed from: a */
    public final /* synthetic */ i f5890a;

    /* renamed from: b */
    public final /* synthetic */ U2.j f5891b;

    /* renamed from: c */
    public final /* synthetic */ int f5892c;
    public final /* synthetic */ Runnable d;

    public /* synthetic */ f(i iVar, U2.j jVar, int i10, Runnable runnable) {
        this.f5890a = iVar;
        this.f5891b = jVar;
        this.f5892c = i10;
        this.d = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        final U2.j jVar = this.f5891b;
        final int i10 = this.f5892c;
        Runnable runnable = this.d;
        final i iVar = this.f5890a;
        InterfaceC0506b interfaceC0506b = iVar.f5903f;
        try {
            try {
                b3.d dVar = iVar.f5901c;
                Objects.requireNonNull(dVar);
                ((k) interfaceC0506b).X(new p(dVar, 21));
                NetworkInfo activeNetworkInfo = ((ConnectivityManager) iVar.f5899a.getSystemService("connectivity")).getActiveNetworkInfo();
                if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
                    ((k) interfaceC0506b).X(new InterfaceC0505a() { // from class: a3.g
                        @Override // c3.InterfaceC0505a
                        public final Object e() {
                            iVar.d.a(jVar, i10 + 1, false);
                            return null;
                        }
                    });
                } else {
                    iVar.a(jVar, i10);
                }
            } catch (SynchronizationException unused) {
                iVar.d.a(jVar, i10 + 1, false);
            }
            runnable.run();
        } catch (Throwable th) {
            runnable.run();
            throw th;
        }
    }
}
