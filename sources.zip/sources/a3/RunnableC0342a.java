package a3;

import com.google.android.datatransport.runtime.scheduling.jobscheduling.AlarmManagerSchedulerBroadcastReceiver;

/* renamed from: a3.a */
/* loaded from: classes.dex */
public final /* synthetic */ class RunnableC0342a implements Runnable {
    @Override // java.lang.Runnable
    public final void run() {
        int i10 = AlarmManagerSchedulerBroadcastReceiver.f8956a;
    }
}
