package A8;

import java.util.concurrent.TimeUnit;
import x8.AbstractC1655g;

/* loaded from: classes.dex */
public final class c extends Enum {

    /* renamed from: b */
    public static final c f57b;

    /* renamed from: c */
    public static final c f58c;
    public static final c d;

    /* renamed from: e */
    public static final c f59e;

    /* renamed from: f */
    public static final c f60f;

    /* renamed from: n */
    public static final c f61n;

    /* renamed from: o */
    public static final /* synthetic */ c[] f62o;

    /* renamed from: a */
    public final TimeUnit f63a;

    static {
        c cVar = new c("NANOSECONDS", 0, TimeUnit.NANOSECONDS);
        f57b = cVar;
        c cVar2 = new c("MICROSECONDS", 1, TimeUnit.MICROSECONDS);
        c cVar3 = new c("MILLISECONDS", 2, TimeUnit.MILLISECONDS);
        f58c = cVar3;
        c cVar4 = new c("SECONDS", 3, TimeUnit.SECONDS);
        d = cVar4;
        c cVar5 = new c("MINUTES", 4, TimeUnit.MINUTES);
        f59e = cVar5;
        c cVar6 = new c("HOURS", 5, TimeUnit.HOURS);
        f60f = cVar6;
        c cVar7 = new c("DAYS", 6, TimeUnit.DAYS);
        f61n = cVar7;
        c[] cVarArr = {cVar, cVar2, cVar3, cVar4, cVar5, cVar6, cVar7};
        f62o = cVarArr;
        AbstractC1655g.k(cVarArr);
    }

    public c(String str, int i10, TimeUnit timeUnit) {
        super(str, i10);
        this.f63a = timeUnit;
    }

    public static c valueOf(String str) {
        return (c) Enum.valueOf(c.class, str);
    }

    public static c[] values() {
        return (c[]) f62o.clone();
    }
}
