package A8;

import s8.AbstractC1420h;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public final class a implements Comparable {

    /* renamed from: b, reason: collision with root package name */
    public static final long f53b;

    /* renamed from: c, reason: collision with root package name */
    public static final long f54c;
    public static final /* synthetic */ int d = 0;

    /* renamed from: a, reason: collision with root package name */
    public final long f55a;

    static {
        int i10 = b.f56a;
        f53b = Long.MAX_VALUE;
        f54c = -9223372036854775805L;
    }

    public static final void a(StringBuilder sb, int i10, int i11, int i12, String str) {
        CharSequence charSequenceSubSequence;
        sb.append(i10);
        if (i11 != 0) {
            sb.append('.');
            String strValueOf = String.valueOf(i11);
            AbstractC1420h.f(strValueOf, "<this>");
            if (i12 < 0) {
                throw new IllegalArgumentException(AbstractC1480a.j("Desired length ", i12, " is less than zero."));
            }
            if (i12 <= strValueOf.length()) {
                charSequenceSubSequence = strValueOf.subSequence(0, strValueOf.length());
            } else {
                StringBuilder sb2 = new StringBuilder(i12);
                int length = i12 - strValueOf.length();
                int i13 = 1;
                if (1 <= length) {
                    while (true) {
                        sb2.append('0');
                        if (i13 == length) {
                            break;
                        } else {
                            i13++;
                        }
                    }
                }
                sb2.append((CharSequence) strValueOf);
                charSequenceSubSequence = sb2;
            }
            String string = charSequenceSubSequence.toString();
            int i14 = -1;
            int length2 = string.length() - 1;
            if (length2 >= 0) {
                while (true) {
                    int i15 = length2 - 1;
                    if (string.charAt(length2) != '0') {
                        i14 = length2;
                        break;
                    } else if (i15 < 0) {
                        break;
                    } else {
                        length2 = i15;
                    }
                }
            }
            int i16 = i14 + 1;
            if (i16 < 3) {
                sb.append((CharSequence) string, 0, i16);
            } else {
                sb.append((CharSequence) string, 0, ((i14 + 3) / 3) * 3);
            }
        }
        sb.append(str);
    }

    public static final boolean b(long j10) {
        return j10 == f53b || j10 == f54c;
    }

    public static final long c(long j10, c cVar) {
        AbstractC1420h.f(cVar, "unit");
        if (j10 == f53b) {
            return Long.MAX_VALUE;
        }
        if (j10 == f54c) {
            return Long.MIN_VALUE;
        }
        long j11 = j10 >> 1;
        c cVar2 = (((int) j10) & 1) == 0 ? c.f57b : c.f58c;
        AbstractC1420h.f(cVar2, "sourceUnit");
        return cVar.f63a.convert(j11, cVar2.f63a);
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        long j10 = ((a) obj).f55a;
        long j11 = this.f55a;
        long j12 = j11 ^ j10;
        int i10 = 1;
        if (j12 >= 0 && (((int) j12) & 1) != 0) {
            int i11 = (((int) j11) & 1) - (((int) j10) & 1);
            return j11 < 0 ? -i11 : i11;
        }
        if (j11 < j10) {
            i10 = -1;
        } else if (j11 == j10) {
            i10 = 0;
        }
        return i10;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof a) {
            return this.f55a == ((a) obj).f55a;
        }
        return false;
    }

    public final int hashCode() {
        long j10 = this.f55a;
        return (int) (j10 ^ (j10 >>> 32));
    }

    public final String toString() {
        boolean z3;
        int iC;
        int i10;
        int i11;
        long j10 = this.f55a;
        if (j10 == 0) {
            return "0s";
        }
        if (j10 == f53b) {
            return "Infinity";
        }
        if (j10 == f54c) {
            return "-Infinity";
        }
        boolean z9 = j10 < 0;
        StringBuilder sb = new StringBuilder();
        if (z9) {
            sb.append('-');
        }
        if (j10 < 0) {
            j10 = (((int) j10) & 1) + ((-(j10 >> 1)) << 1);
            int i12 = b.f56a;
        }
        long jC = c(j10, c.f61n);
        if (b(j10)) {
            z3 = z9;
            iC = 0;
        } else {
            z3 = z9;
            iC = (int) (c(j10, c.f60f) % 24);
        }
        int iC2 = b(j10) ? 0 : (int) (c(j10, c.f59e) % 60);
        int iC3 = b(j10) ? 0 : (int) (c(j10, c.d) % 60);
        if (b(j10)) {
            i10 = 0;
        } else {
            i10 = (int) ((((int) j10) & 1) == 1 ? ((j10 >> 1) % 1000) * 1000000 : (j10 >> 1) % 1000000000);
        }
        boolean z10 = jC != 0;
        boolean z11 = iC != 0;
        boolean z12 = iC2 != 0;
        boolean z13 = (iC3 == 0 && i10 == 0) ? false : true;
        if (z10) {
            sb.append(jC);
            sb.append('d');
            i11 = 1;
        } else {
            i11 = 0;
        }
        if (z11 || (z10 && (z12 || z13))) {
            int i13 = i11 + 1;
            if (i11 > 0) {
                sb.append(' ');
            }
            sb.append(iC);
            sb.append('h');
            i11 = i13;
        }
        if (z12 || (z13 && (z11 || z10))) {
            int i14 = i11 + 1;
            if (i11 > 0) {
                sb.append(' ');
            }
            sb.append(iC2);
            sb.append('m');
            i11 = i14;
        }
        if (z13) {
            int i15 = i11 + 1;
            if (i11 > 0) {
                sb.append(' ');
            }
            if (iC3 != 0 || z10 || z11 || z12) {
                a(sb, iC3, i10, 9, "s");
            } else if (i10 >= 1000000) {
                a(sb, i10 / 1000000, i10 % 1000000, 6, "ms");
            } else if (i10 >= 1000) {
                a(sb, i10 / 1000, i10 % 1000, 3, "us");
            } else {
                sb.append(i10);
                sb.append("ns");
            }
            i11 = i15;
        }
        if (z3 && i11 > 1) {
            sb.insert(1, '(').append(')');
        }
        String string = sb.toString();
        AbstractC1420h.e(string, "toString(...)");
        return string;
    }
}
