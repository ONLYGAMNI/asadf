package a8;

import C3.f;
import L7.d;
import N7.b;
import Z7.c;

/* renamed from: a8.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0352a implements d, b {

    /* renamed from: a, reason: collision with root package name */
    public final d f5946a;

    /* renamed from: b, reason: collision with root package name */
    public b f5947b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f5948c;
    public A5.b d;

    /* renamed from: e, reason: collision with root package name */
    public volatile boolean f5949e;

    public C0352a(d dVar) {
        this.f5946a = dVar;
    }

    @Override // L7.d
    public final void a(b bVar) {
        if (Q7.a.e(this.f5947b, bVar)) {
            this.f5947b = bVar;
            this.f5946a.a(this);
        }
    }

    @Override // L7.d
    public final void b() {
        if (this.f5949e) {
            return;
        }
        synchronized (this) {
            try {
                if (this.f5949e) {
                    return;
                }
                if (!this.f5948c) {
                    this.f5949e = true;
                    this.f5948c = true;
                    this.f5946a.b();
                } else {
                    A5.b bVar = this.d;
                    if (bVar == null) {
                        bVar = new A5.b();
                        this.d = bVar;
                    }
                    bVar.a(Z7.d.f5834a);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // N7.b
    public final void c() {
        this.f5947b.c();
    }

    public final void d() {
        Object obj;
        while (true) {
            synchronized (this) {
                try {
                    A5.b bVar = this.d;
                    if (bVar == null) {
                        this.f5948c = false;
                        return;
                    }
                    this.d = null;
                    d dVar = this.f5946a;
                    for (Object[] objArr = (Object[]) bVar.f39c; objArr != null; objArr = objArr[4]) {
                        for (int i10 = 0; i10 < 4 && (obj = objArr[i10]) != null; i10++) {
                            if (obj == Z7.d.f5834a) {
                                dVar.b();
                                return;
                            } else {
                                if (obj instanceof c) {
                                    dVar.onError(((c) obj).f5833a);
                                    return;
                                }
                                dVar.f(obj);
                            }
                        }
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    @Override // L7.d
    public final void f(Object obj) {
        if (this.f5949e) {
            return;
        }
        if (obj == null) {
            this.f5947b.c();
            onError(new NullPointerException("onNext called with null. Null values are generally not allowed in 2.x operators and sources."));
            return;
        }
        synchronized (this) {
            try {
                if (this.f5949e) {
                    return;
                }
                if (!this.f5948c) {
                    this.f5948c = true;
                    this.f5946a.f(obj);
                    d();
                } else {
                    A5.b bVar = this.d;
                    if (bVar == null) {
                        bVar = new A5.b();
                        this.d = bVar;
                    }
                    bVar.a(obj);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // L7.d
    public final void onError(Throwable th) {
        if (this.f5949e) {
            f.o(th);
            return;
        }
        synchronized (this) {
            try {
                boolean z3 = true;
                if (!this.f5949e) {
                    if (this.f5948c) {
                        this.f5949e = true;
                        A5.b bVar = this.d;
                        if (bVar == null) {
                            bVar = new A5.b();
                            this.d = bVar;
                        }
                        ((Object[]) bVar.f39c)[0] = new c(th);
                        return;
                    }
                    this.f5949e = true;
                    this.f5948c = true;
                    z3 = false;
                }
                if (z3) {
                    f.o(th);
                } else {
                    this.f5946a.onError(th);
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }
}
