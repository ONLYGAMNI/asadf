package A6;

import P6.j;

/* loaded from: classes.dex */
public abstract /* synthetic */ class a {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f51a;

    static {
        int[] iArr = new int[j.values().length];
        try {
            iArr[j.TITLE_TEXT_HTML.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[j.DELIVERY_SUMMARY.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[j.DELIVERY_DETAIL_VALUE.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr[j.DELIVERY_DETAIL_TITLE.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr[j.DELIVERY_DETAIL_SKU.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        f51a = iArr;
    }
}
