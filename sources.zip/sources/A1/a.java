package A1;

import e8.C0803o;
import i8.d;
import j8.EnumC1073a;
import k8.AbstractC1113j;
import r8.p;

/* loaded from: classes.dex */
public final class a extends AbstractC1113j implements p {

    /* renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f4a;

    @Override // k8.AbstractC1104a
    public final d create(Object obj, d dVar) {
        a aVar = new a(2, dVar);
        aVar.f4a = obj;
        return aVar;
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        a aVar = (a) create((C1.d) obj, (d) obj2);
        C0803o c0803o = C0803o.f10326a;
        aVar.invokeSuspend(c0803o);
        return c0803o;
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        f9.d.x(obj);
        ((C1.d) this.f4a).a();
        return C0803o.f10326a;
    }
}
