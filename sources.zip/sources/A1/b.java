package A1;

import C1.d;
import C8.C0;
import C8.G;
import C8.I;
import K3.O;
import e8.C0803o;
import r8.l;
import s8.AbstractC1420h;
import s8.AbstractC1421i;
import u1.C1481a;
import u1.C1482b;

/* loaded from: classes.dex */
public final class b extends AbstractC1421i implements l {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f5a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ c f6b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ b(c cVar, int i10) {
        super(1);
        this.f5a = i10;
        this.f6b = cVar;
    }

    @Override // r8.l
    public final Object invoke(Object obj) {
        switch (this.f5a) {
            case 0:
                c cVar = this.f6b;
                d dVar = cVar.f8b;
                dVar.f206c.f8610a = (String) obj;
                a aVar = new a(2, null);
                O o9 = cVar.d;
                o9.getClass();
                AbstractC1420h.f(dVar, "searcher");
                C1482b c1482b = new C1482b(aVar, dVar, null);
                G g = dVar.f208f;
                AbstractC1420h.f(g, "coroutineScope");
                C0 c0 = (C0) o9.f2321c;
                if (c0 != null) {
                    c0.cancel(null);
                }
                o9.f2321c = I.v(g, null, new C1481a(o9, c1482b, null), 3);
                break;
            default:
                d dVar2 = this.f6b.f8b;
                dVar2.f206c.f8610a = (String) obj;
                dVar2.a();
                break;
        }
        return C0803o.f10326a;
    }
}
