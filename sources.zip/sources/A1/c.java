package A1;

import C1.d;
import K3.O;
import X0.r;
import java.util.concurrent.CopyOnWriteArraySet;
import q1.AbstractC1309a;
import s2.AbstractC1397b;
import s8.AbstractC1420h;
import t.e;
import v1.C1547a;

/* loaded from: classes.dex */
public final class c extends AbstractC1309a {

    /* renamed from: a, reason: collision with root package name */
    public final r f7a;

    /* renamed from: b, reason: collision with root package name */
    public final d f8b;

    /* renamed from: c, reason: collision with root package name */
    public final int f9c;
    public final O d;

    /* renamed from: e, reason: collision with root package name */
    public final b f10e;

    /* renamed from: f, reason: collision with root package name */
    public final b f11f;

    public c(r rVar, d dVar, int i10, O o9) {
        AbstractC1420h.f(dVar, "searcher");
        AbstractC1397b.f(i10, "searchMode");
        this.f7a = rVar;
        this.f8b = dVar;
        this.f9c = i10;
        this.d = o9;
        this.f10e = new b(this, 0);
        this.f11f = new b(this, 1);
    }

    @Override // q1.AbstractC1309a
    public final void a() {
        int iD = e.d(this.f9c);
        r rVar = this.f7a;
        if (iD == 0) {
            v1.b bVar = (v1.b) rVar.f5359b;
            bVar.getClass();
            b bVar2 = this.f10e;
            AbstractC1420h.f(bVar2, "subscription");
            ((CopyOnWriteArraySet) bVar.f431b).add(bVar2);
            return;
        }
        if (iD != 1) {
            return;
        }
        C1547a c1547a = (C1547a) rVar.f5360c;
        c1547a.getClass();
        b bVar3 = this.f11f;
        AbstractC1420h.f(bVar3, "subscription");
        ((CopyOnWriteArraySet) c1547a.f431b).add(bVar3);
    }

    @Override // q1.AbstractC1309a
    public final void b() {
        int iD = e.d(this.f9c);
        r rVar = this.f7a;
        if (iD == 0) {
            v1.b bVar = (v1.b) rVar.f5359b;
            bVar.getClass();
            b bVar2 = this.f10e;
            AbstractC1420h.f(bVar2, "subscription");
            ((CopyOnWriteArraySet) bVar.f431b).remove(bVar2);
            return;
        }
        if (iD != 1) {
            return;
        }
        C1547a c1547a = (C1547a) rVar.f5360c;
        c1547a.getClass();
        b bVar3 = this.f11f;
        AbstractC1420h.f(bVar3, "subscription");
        ((CopyOnWriteArraySet) c1547a.f431b).remove(bVar3);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof c)) {
            return false;
        }
        c cVar = (c) obj;
        return AbstractC1420h.a(this.f7a, cVar.f7a) && AbstractC1420h.a(this.f8b, cVar.f8b) && this.f9c == cVar.f9c && AbstractC1420h.a(this.d, cVar.d);
    }

    public final int hashCode() {
        return this.d.hashCode() + ((e.d(this.f9c) + ((this.f8b.hashCode() + (this.f7a.hashCode() * 31)) * 31)) * 31);
    }

    public final String toString() {
        return "SearchBoxConnectionSearcher(viewModel=" + this.f7a + ", searcher=" + this.f8b + ", searchMode=" + AbstractC1397b.i(this.f9c) + ", debouncer=" + this.d + ')';
    }
}
