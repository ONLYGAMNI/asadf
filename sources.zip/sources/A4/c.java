package A4;

/* loaded from: classes.dex */
public final class c extends d {
    public c(String str, String str2) {
        this(new a(str, str2.toCharArray()), (Character) '=');
    }

    public final d a(a aVar) {
        return new c(aVar, (Character) null);
    }

    public c(a aVar, Character ch) {
        super(aVar, ch);
        if (aVar.f27b.length != 64) {
            throw new IllegalArgumentException();
        }
    }
}
