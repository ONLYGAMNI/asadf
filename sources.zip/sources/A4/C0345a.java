package a4;

/* renamed from: a4.a */
/* loaded from: classes.dex */
public final class C0345a {

    /* renamed from: a */
    public J0.b f5909a;

    /* renamed from: b */
    public final /* synthetic */ C0347c f5910b;

    public C0345a(C0347c c0347c) {
        this.f5910b = c0347c;
    }
}
