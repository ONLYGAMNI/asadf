package a4;

import I0.k;
import J0.d;
import J0.e;
import a.AbstractC0338a;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedStateListDrawable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.autofill.AutofillManager;
import android.widget.CompoundButton;
import com.tajir.tajir.R;
import i4.m;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashSet;
import l.C1145p;

/* renamed from: a4.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0347c extends C1145p {

    /* renamed from: F, reason: collision with root package name */
    public static final int[] f5912F = {R.attr.state_indeterminate};

    /* renamed from: G, reason: collision with root package name */
    public static final int[] f5913G = {R.attr.state_error};

    /* renamed from: H, reason: collision with root package name */
    public static final int[][] f5914H = {new int[]{android.R.attr.state_enabled, R.attr.state_error}, new int[]{android.R.attr.state_enabled, android.R.attr.state_checked}, new int[]{android.R.attr.state_enabled, -16842912}, new int[]{-16842910, android.R.attr.state_checked}, new int[]{-16842910, -16842912}};

    /* renamed from: I, reason: collision with root package name */
    public static final int f5915I = Resources.getSystem().getIdentifier("btn_check_material_anim", "drawable", "android");

    /* renamed from: A, reason: collision with root package name */
    public boolean f5916A;

    /* renamed from: B, reason: collision with root package name */
    public CharSequence f5917B;

    /* renamed from: C, reason: collision with root package name */
    public CompoundButton.OnCheckedChangeListener f5918C;

    /* renamed from: D, reason: collision with root package name */
    public final e f5919D;

    /* renamed from: E, reason: collision with root package name */
    public final C0345a f5920E;

    /* renamed from: e, reason: collision with root package name */
    public final LinkedHashSet f5921e;

    /* renamed from: f, reason: collision with root package name */
    public final LinkedHashSet f5922f;

    /* renamed from: n, reason: collision with root package name */
    public ColorStateList f5923n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f5924o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f5925p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f5926q;

    /* renamed from: r, reason: collision with root package name */
    public CharSequence f5927r;

    /* renamed from: s, reason: collision with root package name */
    public Drawable f5928s;

    /* renamed from: t, reason: collision with root package name */
    public Drawable f5929t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f5930u;

    /* renamed from: v, reason: collision with root package name */
    public ColorStateList f5931v;

    /* renamed from: w, reason: collision with root package name */
    public ColorStateList f5932w;

    /* renamed from: x, reason: collision with root package name */
    public PorterDuff.Mode f5933x;

    /* renamed from: y, reason: collision with root package name */
    public int f5934y;

    /* renamed from: z, reason: collision with root package name */
    public int[] f5935z;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0139  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public C0347c(android.content.Context r12, android.util.AttributeSet r13) throws java.lang.Throwable {
        /*
            Method dump skipped, instructions count: 327
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: a4.C0347c.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    private String getButtonStateDescription() {
        int i10 = this.f5934y;
        return i10 == 1 ? getResources().getString(R.string.mtrl_checkbox_state_description_checked) : i10 == 0 ? getResources().getString(R.string.mtrl_checkbox_state_description_unchecked) : getResources().getString(R.string.mtrl_checkbox_state_description_indeterminate);
    }

    private ColorStateList getMaterialThemeColorsTintList() {
        if (this.f5923n == null) {
            int iN = D4.b.n(this, R.attr.colorControlActivated);
            int iN2 = D4.b.n(this, R.attr.colorError);
            int iN3 = D4.b.n(this, R.attr.colorSurface);
            int iN4 = D4.b.n(this, R.attr.colorOnSurface);
            this.f5923n = new ColorStateList(f5914H, new int[]{D4.b.G(iN3, 1.0f, iN2), D4.b.G(iN3, 1.0f, iN), D4.b.G(iN3, 0.54f, iN4), D4.b.G(iN3, 0.38f, iN4), D4.b.G(iN3, 0.38f, iN4)});
        }
        return this.f5923n;
    }

    private ColorStateList getSuperButtonTintList() {
        ColorStateList colorStateList = this.f5931v;
        return colorStateList != null ? colorStateList : super.getButtonTintList() != null ? super.getButtonTintList() : getSupportButtonTintList();
    }

    public final void a() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        k kVar;
        Drawable drawableMutate = this.f5928s;
        ColorStateList colorStateList3 = this.f5931v;
        PorterDuff.Mode modeB = V.b.b(this);
        if (drawableMutate == null) {
            drawableMutate = null;
        } else if (colorStateList3 != null) {
            drawableMutate = drawableMutate.mutate();
            if (modeB != null) {
                I.b.i(drawableMutate, modeB);
            }
        }
        this.f5928s = drawableMutate;
        Drawable drawableMutate2 = this.f5929t;
        ColorStateList colorStateList4 = this.f5932w;
        PorterDuff.Mode mode = this.f5933x;
        if (drawableMutate2 == null) {
            drawableMutate2 = null;
        } else if (colorStateList4 != null) {
            drawableMutate2 = drawableMutate2.mutate();
            if (mode != null) {
                I.b.i(drawableMutate2, mode);
            }
        }
        this.f5929t = drawableMutate2;
        if (this.f5930u) {
            e eVar = this.f5919D;
            if (eVar != null) {
                Drawable drawable = eVar.f1880a;
                C0345a c0345a = this.f5920E;
                if (drawable != null) {
                    AnimatedVectorDrawable animatedVectorDrawable = (AnimatedVectorDrawable) drawable;
                    if (c0345a.f5909a == null) {
                        c0345a.f5909a = new J0.b(c0345a);
                    }
                    animatedVectorDrawable.unregisterAnimationCallback(c0345a.f5909a);
                }
                ArrayList arrayList = eVar.f1875e;
                d dVar = eVar.f1873b;
                if (arrayList != null && c0345a != null) {
                    arrayList.remove(c0345a);
                    if (eVar.f1875e.size() == 0 && (kVar = eVar.d) != null) {
                        dVar.f1870b.removeListener(kVar);
                        eVar.d = null;
                    }
                }
                Drawable drawable2 = eVar.f1880a;
                if (drawable2 != null) {
                    AnimatedVectorDrawable animatedVectorDrawable2 = (AnimatedVectorDrawable) drawable2;
                    if (c0345a.f5909a == null) {
                        c0345a.f5909a = new J0.b(c0345a);
                    }
                    animatedVectorDrawable2.registerAnimationCallback(c0345a.f5909a);
                } else if (c0345a != null) {
                    if (eVar.f1875e == null) {
                        eVar.f1875e = new ArrayList();
                    }
                    if (!eVar.f1875e.contains(c0345a)) {
                        eVar.f1875e.add(c0345a);
                        if (eVar.d == null) {
                            eVar.d = new k(eVar, 1);
                        }
                        dVar.f1870b.addListener(eVar.d);
                    }
                }
            }
            if (Build.VERSION.SDK_INT >= 24) {
                Drawable drawable3 = this.f5928s;
                if ((drawable3 instanceof AnimatedStateListDrawable) && eVar != null) {
                    ((AnimatedStateListDrawable) drawable3).addTransition(R.id.checked, R.id.unchecked, eVar, false);
                    ((AnimatedStateListDrawable) this.f5928s).addTransition(R.id.indeterminate, R.id.unchecked, eVar, false);
                }
            }
        }
        Drawable drawable4 = this.f5928s;
        if (drawable4 != null && (colorStateList2 = this.f5931v) != null) {
            I.b.h(drawable4, colorStateList2);
        }
        Drawable drawable5 = this.f5929t;
        if (drawable5 != null && (colorStateList = this.f5932w) != null) {
            I.b.h(drawable5, colorStateList);
        }
        Drawable drawable6 = this.f5928s;
        Drawable drawable7 = this.f5929t;
        if (drawable6 == null) {
            drawable6 = drawable7;
        } else if (drawable7 != null) {
            int intrinsicWidth = drawable7.getIntrinsicWidth();
            if (intrinsicWidth == -1) {
                intrinsicWidth = drawable6.getIntrinsicWidth();
            }
            int intrinsicHeight = drawable7.getIntrinsicHeight();
            if (intrinsicHeight == -1) {
                intrinsicHeight = drawable6.getIntrinsicHeight();
            }
            if (intrinsicWidth > drawable6.getIntrinsicWidth() || intrinsicHeight > drawable6.getIntrinsicHeight()) {
                float f10 = intrinsicWidth / intrinsicHeight;
                if (f10 >= drawable6.getIntrinsicWidth() / drawable6.getIntrinsicHeight()) {
                    int intrinsicWidth2 = drawable6.getIntrinsicWidth();
                    intrinsicHeight = (int) (intrinsicWidth2 / f10);
                    intrinsicWidth = intrinsicWidth2;
                } else {
                    intrinsicHeight = drawable6.getIntrinsicHeight();
                    intrinsicWidth = (int) (f10 * intrinsicHeight);
                }
            }
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{drawable6, drawable7});
            layerDrawable.setLayerSize(1, intrinsicWidth, intrinsicHeight);
            layerDrawable.setLayerGravity(1, 17);
            drawable6 = layerDrawable;
        }
        super.setButtonDrawable(drawable6);
        refreshDrawableState();
    }

    @Override // android.widget.CompoundButton
    public Drawable getButtonDrawable() {
        return this.f5928s;
    }

    public Drawable getButtonIconDrawable() {
        return this.f5929t;
    }

    public ColorStateList getButtonIconTintList() {
        return this.f5932w;
    }

    public PorterDuff.Mode getButtonIconTintMode() {
        return this.f5933x;
    }

    @Override // android.widget.CompoundButton
    public ColorStateList getButtonTintList() {
        return this.f5931v;
    }

    public int getCheckedState() {
        return this.f5934y;
    }

    public CharSequence getErrorAccessibilityLabel() {
        return this.f5927r;
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final boolean isChecked() {
        return this.f5934y == 1;
    }

    @Override // android.widget.TextView, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f5924o && this.f5931v == null && this.f5932w == null) {
            setUseMaterialThemeColors(true);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final int[] onCreateDrawableState(int i10) {
        int[] iArrCopyOf;
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i10 + 2);
        if (getCheckedState() == 2) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f5912F);
        }
        if (this.f5926q) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, f5913G);
        }
        int i11 = 0;
        while (true) {
            if (i11 >= iArrOnCreateDrawableState.length) {
                iArrCopyOf = Arrays.copyOf(iArrOnCreateDrawableState, iArrOnCreateDrawableState.length + 1);
                iArrCopyOf[iArrOnCreateDrawableState.length] = 16842912;
                break;
            }
            int i12 = iArrOnCreateDrawableState[i11];
            if (i12 == 16842912) {
                iArrCopyOf = iArrOnCreateDrawableState;
                break;
            }
            if (i12 == 0) {
                iArrCopyOf = (int[]) iArrOnCreateDrawableState.clone();
                iArrCopyOf[i11] = 16842912;
                break;
            }
            i11++;
        }
        this.f5935z = iArrCopyOf;
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onDraw(Canvas canvas) {
        Drawable drawableA;
        if (!this.f5925p || !TextUtils.isEmpty(getText()) || (drawableA = V.c.a(this)) == null) {
            super.onDraw(canvas);
            return;
        }
        int width = ((getWidth() - drawableA.getIntrinsicWidth()) / 2) * (m.f(this) ? -1 : 1);
        int iSave = canvas.save();
        canvas.translate(width, 0.0f);
        super.onDraw(canvas);
        canvas.restoreToCount(iSave);
        if (getBackground() != null) {
            Rect bounds = drawableA.getBounds();
            I.b.f(getBackground(), bounds.left + width, bounds.top, bounds.right + width, bounds.bottom);
        }
    }

    @Override // android.view.View
    public final void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        if (accessibilityNodeInfo != null && this.f5926q) {
            accessibilityNodeInfo.setText(((Object) accessibilityNodeInfo.getText()) + ", " + ((Object) this.f5927r));
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0346b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0346b c0346b = (C0346b) parcelable;
        super.onRestoreInstanceState(c0346b.getSuperState());
        setCheckedState(c0346b.f5911a);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public final Parcelable onSaveInstanceState() {
        C0346b c0346b = new C0346b(super.onSaveInstanceState());
        c0346b.f5911a = getCheckedState();
        return c0346b;
    }

    @Override // l.C1145p, android.widget.CompoundButton
    public void setButtonDrawable(int i10) {
        setButtonDrawable(AbstractC0338a.s(getContext(), i10));
    }

    public void setButtonIconDrawable(Drawable drawable) {
        this.f5929t = drawable;
        a();
    }

    public void setButtonIconDrawableResource(int i10) {
        setButtonIconDrawable(AbstractC0338a.s(getContext(), i10));
    }

    public void setButtonIconTintList(ColorStateList colorStateList) {
        if (this.f5932w == colorStateList) {
            return;
        }
        this.f5932w = colorStateList;
        a();
    }

    public void setButtonIconTintMode(PorterDuff.Mode mode) {
        if (this.f5933x == mode) {
            return;
        }
        this.f5933x = mode;
        a();
    }

    @Override // android.widget.CompoundButton
    public void setButtonTintList(ColorStateList colorStateList) {
        if (this.f5931v == colorStateList) {
            return;
        }
        this.f5931v = colorStateList;
        a();
    }

    @Override // android.widget.CompoundButton
    public void setButtonTintMode(PorterDuff.Mode mode) {
        setSupportButtonTintMode(mode);
        a();
    }

    public void setCenterIfNoTextEnabled(boolean z3) {
        this.f5925p = z3;
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z3) {
        setCheckedState(z3 ? 1 : 0);
    }

    public void setCheckedState(int i10) {
        AutofillManager autofillManager;
        CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
        if (this.f5934y != i10) {
            this.f5934y = i10;
            super.setChecked(i10 == 1);
            refreshDrawableState();
            int i11 = Build.VERSION.SDK_INT;
            if (i11 >= 30 && this.f5917B == null) {
                super.setStateDescription(getButtonStateDescription());
            }
            if (this.f5916A) {
                return;
            }
            this.f5916A = true;
            LinkedHashSet linkedHashSet = this.f5922f;
            if (linkedHashSet != null) {
                Iterator it = linkedHashSet.iterator();
                if (it.hasNext()) {
                    android.support.v4.media.session.a.u(it.next());
                    throw null;
                }
            }
            if (this.f5934y != 2 && (onCheckedChangeListener = this.f5918C) != null) {
                onCheckedChangeListener.onCheckedChanged(this, isChecked());
            }
            if (i11 >= 26 && (autofillManager = (AutofillManager) getContext().getSystemService(AutofillManager.class)) != null) {
                autofillManager.notifyValueChanged(this);
            }
            this.f5916A = false;
        }
    }

    @Override // android.widget.TextView, android.view.View
    public void setEnabled(boolean z3) {
        super.setEnabled(z3);
    }

    public void setErrorAccessibilityLabel(CharSequence charSequence) {
        this.f5927r = charSequence;
    }

    public void setErrorAccessibilityLabelResource(int i10) {
        setErrorAccessibilityLabel(i10 != 0 ? getResources().getText(i10) : null);
    }

    public void setErrorShown(boolean z3) {
        if (this.f5926q == z3) {
            return;
        }
        this.f5926q = z3;
        refreshDrawableState();
        Iterator it = this.f5921e.iterator();
        if (it.hasNext()) {
            android.support.v4.media.session.a.u(it.next());
            throw null;
        }
    }

    @Override // android.widget.CompoundButton
    public void setOnCheckedChangeListener(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.f5918C = onCheckedChangeListener;
    }

    @Override // android.widget.CompoundButton, android.view.View
    public void setStateDescription(CharSequence charSequence) {
        this.f5917B = charSequence;
        if (charSequence != null) {
            super.setStateDescription(charSequence);
        } else {
            if (Build.VERSION.SDK_INT < 30 || charSequence != null) {
                return;
            }
            super.setStateDescription(getButtonStateDescription());
        }
    }

    public void setUseMaterialThemeColors(boolean z3) {
        this.f5924o = z3;
        if (z3) {
            V.b.c(this, getMaterialThemeColorsTintList());
        } else {
            V.b.c(this, null);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public final void toggle() {
        setChecked(!isChecked());
    }

    @Override // l.C1145p, android.widget.CompoundButton
    public void setButtonDrawable(Drawable drawable) {
        this.f5928s = drawable;
        this.f5930u = false;
        a();
    }
}
