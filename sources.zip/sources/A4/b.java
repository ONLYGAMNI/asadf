package A4;

/* loaded from: classes.dex */
public final class b extends d {
    public final char[] d;

    public b(a aVar) {
        super(aVar, (Character) null);
        this.d = new char[512];
        char[] cArr = aVar.f27b;
        if (cArr.length != 16) {
            throw new IllegalArgumentException();
        }
        for (int i10 = 0; i10 < 256; i10++) {
            char[] cArr2 = this.d;
            cArr2[i10] = cArr[i10 >>> 4];
            cArr2[i10 | 256] = cArr[i10 & 15];
        }
    }
}
