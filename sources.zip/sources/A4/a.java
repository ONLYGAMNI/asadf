package A4;

import d0.i;
import java.math.RoundingMode;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final String f26a;

    /* renamed from: b, reason: collision with root package name */
    public final char[] f27b;

    /* renamed from: c, reason: collision with root package name */
    public final int f28c;
    public final int d;

    /* renamed from: e, reason: collision with root package name */
    public final byte[] f29e;

    public a(String str, char[] cArr) {
        byte[] bArr = new byte[128];
        Arrays.fill(bArr, (byte) -1);
        for (int i10 = 0; i10 < cArr.length; i10++) {
            char c4 = cArr[i10];
            if (!(c4 < 128)) {
                throw new IllegalArgumentException(com.bumptech.glide.d.v("Non-ASCII character: %s", Character.valueOf(c4)));
            }
            if (!(bArr[c4] == -1)) {
                throw new IllegalArgumentException(com.bumptech.glide.d.v("Duplicate character: %s", Character.valueOf(c4)));
            }
            bArr[c4] = (byte) i10;
        }
        this.f26a = str;
        this.f27b = cArr;
        try {
            int iW = E4.b.w(cArr.length, RoundingMode.UNNECESSARY);
            this.f28c = iW;
            int iNumberOfTrailingZeros = Integer.numberOfTrailingZeros(iW);
            this.d = iW >> iNumberOfTrailingZeros;
            this.f29e = bArr;
            boolean[] zArr = new boolean[1 << (3 - iNumberOfTrailingZeros)];
            for (int i11 = 0; i11 < this.d; i11++) {
                int i12 = i11 * 8;
                int i13 = this.f28c;
                RoundingMode roundingMode = RoundingMode.CEILING;
                roundingMode.getClass();
                if (i13 == 0) {
                    throw new ArithmeticException("/ by zero");
                }
                int i14 = i12 / i13;
                int i15 = i12 - (i13 * i14);
                if (i15 != 0) {
                    int i16 = ((i12 ^ i13) >> 31) | 1;
                    switch (B4.a.f175a[roundingMode.ordinal()]) {
                        case 1:
                            if (i15 != 0) {
                                throw new ArithmeticException("mode was UNNECESSARY, but rounding was necessary");
                            }
                            continue;
                        case 2:
                            break;
                        case 3:
                            if (i16 >= 0) {
                                continue;
                            }
                            break;
                        case 4:
                            break;
                        case 5:
                            if (i16 <= 0) {
                                continue;
                            }
                            break;
                        case i.STRING_SET_FIELD_NUMBER /* 6 */:
                        case i.DOUBLE_FIELD_NUMBER /* 7 */:
                        case 8:
                            int iAbs = Math.abs(i15);
                            int iAbs2 = iAbs - (Math.abs(i13) - iAbs);
                            if (iAbs2 != 0) {
                                if (iAbs2 <= 0) {
                                    break;
                                }
                            } else if (roundingMode != RoundingMode.HALF_UP) {
                                if (!((roundingMode == RoundingMode.HALF_EVEN) & ((i14 & 1) != 0))) {
                                    break;
                                }
                            }
                            break;
                        default:
                            throw new AssertionError();
                    }
                    i14 += i16;
                }
                zArr[i14] = true;
            }
        } catch (ArithmeticException e4) {
            throw new IllegalArgumentException("Illegal alphabet length " + cArr.length, e4);
        }
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        aVar.getClass();
        return Arrays.equals(this.f27b, aVar.f27b);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f27b) + 1237;
    }

    public final String toString() {
        return this.f26a;
    }
}
