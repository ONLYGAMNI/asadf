package A4;

import java.util.Objects;

/* loaded from: classes.dex */
public class d {

    /* renamed from: c */
    public static final c f30c = new c("base64()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/");

    /* renamed from: a */
    public final a f31a;

    /* renamed from: b */
    public final Character f32b;

    static {
        new c("base64Url()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_");
        new d("base32()", "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567");
        new d("base32Hex()", "0123456789ABCDEFGHIJKLMNOPQRSTUV");
        new b(new a("base16()", "0123456789ABCDEF".toCharArray()));
    }

    public d(a aVar, Character ch) {
        aVar.getClass();
        this.f31a = aVar;
        if (ch != null) {
            char cCharValue = ch.charValue();
            byte[] bArr = aVar.f29e;
            if (cCharValue < bArr.length && bArr[cCharValue] != -1) {
                throw new IllegalArgumentException(com.bumptech.glide.d.v("Padding character %s was already in alphabet", ch));
            }
        }
        this.f32b = ch;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof d)) {
            return false;
        }
        d dVar = (d) obj;
        return this.f31a.equals(dVar.f31a) && Objects.equals(this.f32b, dVar.f32b);
    }

    public final int hashCode() {
        return this.f31a.hashCode() ^ Objects.hashCode(this.f32b);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("BaseEncoding.");
        a aVar = this.f31a;
        sb.append(aVar);
        if (8 % aVar.f28c != 0) {
            Character ch = this.f32b;
            if (ch == null) {
                sb.append(".omitPadding()");
            } else {
                sb.append(".withPadChar('");
                sb.append(ch);
                sb.append("')");
            }
        }
        return sb.toString();
    }

    public d(String str, String str2) {
        this(new a(str, str2.toCharArray()), (Character) '=');
    }
}
