package a7;

import android.view.View;
import androidx.viewpager2.widget.ViewPager2;

/* loaded from: classes.dex */
public final class b implements ViewPager2.PageTransformer {

    /* renamed from: a, reason: collision with root package name */
    public final float f5945a = 0.85f;

    @Override // androidx.viewpager2.widget.ViewPager2.PageTransformer
    public final void transformPage(View view, float f10) {
        int width = view.getWidth();
        view.setPivotY(view.getHeight() / 2.0f);
        float f11 = width;
        view.setPivotX(f11 / 2.0f);
        float f12 = this.f5945a;
        if (f10 < -1.0f) {
            view.setScaleX(f12);
            view.setScaleY(f12);
            view.setPivotX(f11);
            return;
        }
        if (f10 > 1.0f) {
            view.setPivotX(0.0f);
            view.setScaleX(f12);
            view.setScaleY(f12);
        } else {
            if (f10 < 0.0f) {
                float f13 = ((1.0f - f12) * (f10 + 1.0f)) + f12;
                view.setScaleX(f13);
                view.setScaleY(f13);
                view.setPivotX((((-f10) * 0.5f) + 0.5f) * f11);
                return;
            }
            float f14 = 1.0f - f10;
            float f15 = ((1.0f - f12) * f14) + f12;
            view.setScaleX(f15);
            view.setScaleY(f15);
            view.setPivotX(f14 * 0.5f * f11);
        }
    }
}
