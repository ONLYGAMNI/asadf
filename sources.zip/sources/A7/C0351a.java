package a7;

import android.content.res.Resources;
import android.view.View;
import androidx.viewpager2.widget.ViewPager2;
import s8.AbstractC1420h;

/* renamed from: a7.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0351a implements ViewPager2.PageTransformer {

    /* renamed from: a, reason: collision with root package name */
    public final float f5943a = 0.85f;

    /* renamed from: b, reason: collision with root package name */
    public float f5944b = 0.2f;

    @Override // androidx.viewpager2.widget.ViewPager2.PageTransformer
    public final void transformPage(View view, float f10) {
        AbstractC1420h.f(view, "page");
        float f11 = this.f5943a;
        double d = f11;
        this.f5944b = d >= 0.8d ? 0.2f : d >= 0.6d ? 0.3f : 0.4f;
        view.setElevation(-Math.abs(f10));
        Math.max(1.0f - Math.abs(f10 * 0.5f), 0.5f);
        float fMax = Math.max(1.0f - Math.abs(this.f5944b * f10), f11);
        view.setScaleX(fMax);
        view.setScaleY(fMax);
        AbstractC1420h.b(Resources.getSystem(), "Resources.getSystem()");
        view.setTranslationX((((int) (((((int) 0.0f) / 2) * r5.getDisplayMetrics().density) + 0.5f)) * f10) + ((1.0f - fMax) * (f10 > 0.0f ? -view.getWidth() : view.getWidth())));
    }
}
