package androidx.fragment.app;

import android.view.View;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityManager;
import java.util.WeakHashMap;
import t4.C1460n;

/* loaded from: classes.dex */
public final class O implements View.OnAttachStateChangeListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6692a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f6693b;

    public /* synthetic */ O(Object obj, int i10) {
        this.f6692a = i10;
        this.f6693b = obj;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        AccessibilityManager accessibilityManager;
        Object obj = this.f6693b;
        switch (this.f6692a) {
            case 0:
                View view2 = (View) obj;
                view2.removeOnAttachStateChangeListener(this);
                WeakHashMap weakHashMap = R.X.f3966a;
                R.I.c(view2);
                break;
            case 1:
            case 2:
                break;
            default:
                C1460n c1460n = (C1460n) obj;
                if (c1460n.f15077B != null && (accessibilityManager = c1460n.f15076A) != null) {
                    WeakHashMap weakHashMap2 = R.X.f3966a;
                    if (R.H.b(c1460n)) {
                        S.c.a(accessibilityManager, c1460n.f15077B);
                        break;
                    }
                }
                break;
        }
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
        AccessibilityManager accessibilityManager;
        switch (this.f6692a) {
            case 0:
                break;
            case 1:
                k.f fVar = (k.f) this.f6693b;
                ViewTreeObserver viewTreeObserver = fVar.f11917F;
                if (viewTreeObserver != null) {
                    if (!viewTreeObserver.isAlive()) {
                        fVar.f11917F = view.getViewTreeObserver();
                    }
                    fVar.f11917F.removeGlobalOnLayoutListener(fVar.f11927q);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            case 2:
                k.D d = (k.D) this.f6693b;
                ViewTreeObserver viewTreeObserver2 = d.f11884w;
                if (viewTreeObserver2 != null) {
                    if (!viewTreeObserver2.isAlive()) {
                        d.f11884w = view.getViewTreeObserver();
                    }
                    d.f11884w.removeGlobalOnLayoutListener(d.f11878q);
                }
                view.removeOnAttachStateChangeListener(this);
                break;
            default:
                C1460n c1460n = (C1460n) this.f6693b;
                S.d dVar = c1460n.f15077B;
                if (dVar != null && (accessibilityManager = c1460n.f15076A) != null) {
                    S.c.b(accessibilityManager, dVar);
                    break;
                }
                break;
        }
    }

    private final void a(View view) {
    }

    private final void b(View view) {
    }

    private final void c(View view) {
    }
}
