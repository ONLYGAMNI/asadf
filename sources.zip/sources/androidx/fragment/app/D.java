package androidx.fragment.app;

import a.AbstractC0338a;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.util.Log;
import f8.AbstractC0841i;
import f8.AbstractC0842j;
import f8.AbstractC0857y;
import f8.C0852t;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class D extends AbstractC0338a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6616a;

    public /* synthetic */ D(int i10) {
        this.f6616a = i10;
    }

    @Override // a.AbstractC0338a
    public final Object R(Intent intent, int i10) {
        switch (this.f6616a) {
            case 0:
                return new androidx.activity.result.a(intent, i10);
            case 1:
                C0852t c0852t = C0852t.f10628a;
                if (i10 != -1 || intent == null) {
                    return c0852t;
                }
                String[] stringArrayExtra = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
                int[] intArrayExtra = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
                if (intArrayExtra == null || stringArrayExtra == null) {
                    return c0852t;
                }
                ArrayList arrayList = new ArrayList(intArrayExtra.length);
                for (int i11 : intArrayExtra) {
                    arrayList.add(Boolean.valueOf(i11 == 0));
                }
                return AbstractC0857y.F(AbstractC0842j.w0(AbstractC0841i.Y(stringArrayExtra), arrayList));
            default:
                return new androidx.activity.result.a(intent, i10);
        }
    }

    @Override // a.AbstractC0338a
    public final Intent n(Context context, Object obj) {
        Bundle bundleExtra;
        switch (this.f6616a) {
            case 0:
                androidx.activity.result.e eVar = (androidx.activity.result.e) obj;
                Intent intent = new Intent("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST");
                Intent intent2 = eVar.f6047b;
                if (intent2 != null && (bundleExtra = intent2.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) != null) {
                    intent.putExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE", bundleExtra);
                    intent2.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
                    if (intent2.getBooleanExtra("androidx.fragment.extra.ACTIVITY_OPTIONS_BUNDLE", false)) {
                        IntentSender intentSender = eVar.f6046a;
                        AbstractC1420h.f(intentSender, "intentSender");
                        eVar = new androidx.activity.result.e(intentSender, null, eVar.f6048c, eVar.d);
                    }
                }
                intent.putExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST", eVar);
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "CreateIntent created the following intent: " + intent);
                }
                return intent;
            case 1:
                String[] strArr = (String[]) obj;
                AbstractC1420h.f(context, "context");
                AbstractC1420h.f(strArr, "input");
                Intent intentPutExtra = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr);
                AbstractC1420h.e(intentPutExtra, "Intent(ACTION_REQUEST_PE…EXTRA_PERMISSIONS, input)");
                return intentPutExtra;
            default:
                Intent intent3 = (Intent) obj;
                AbstractC1420h.f(context, "context");
                AbstractC1420h.f(intent3, "input");
                return intent3;
        }
    }

    @Override // a.AbstractC0338a
    public K8.d y(Context context, Object obj) {
        switch (this.f6616a) {
            case 1:
                String[] strArr = (String[]) obj;
                AbstractC1420h.f(context, "context");
                AbstractC1420h.f(strArr, "input");
                if (strArr.length == 0) {
                    return new K8.d(C0852t.f10628a);
                }
                for (String str : strArr) {
                    if (E.j.checkSelfPermission(context, str) != 0) {
                        return null;
                    }
                }
                int iA = AbstractC0857y.A(strArr.length);
                if (iA < 16) {
                    iA = 16;
                }
                LinkedHashMap linkedHashMap = new LinkedHashMap(iA);
                for (String str2 : strArr) {
                    linkedHashMap.put(str2, Boolean.TRUE);
                }
                return new K8.d(linkedHashMap);
            default:
                return super.y(context, obj);
        }
    }
}
