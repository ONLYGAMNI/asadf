package androidx.fragment.app;

/* renamed from: androidx.fragment.app.d */
/* loaded from: classes.dex */
public final class C0384d extends AbstractC0385e {
    public final boolean d;

    /* renamed from: e */
    public boolean f6755e;

    /* renamed from: f */
    public l1.d f6756f;

    public C0384d(V v9, M.d dVar, boolean z3) {
        super(0, v9, dVar);
        this.d = z3;
    }

    /* JADX WARN: Removed duplicated region for block: B:112:0x0028  */
    /* JADX WARN: Removed duplicated region for block: B:133:0x0060  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final l1.d q(android.content.Context r9) throws android.content.res.Resources.NotFoundException {
        /*
            Method dump skipped, instructions count: 259
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.C0384d.q(android.content.Context):l1.d");
    }
}
