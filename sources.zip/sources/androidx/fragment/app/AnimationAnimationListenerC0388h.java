package androidx.fragment.app;

import E5.RunnableC0066h;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import s8.AbstractC1420h;

/* renamed from: androidx.fragment.app.h */
/* loaded from: classes.dex */
public final class AnimationAnimationListenerC0388h implements Animation.AnimationListener {

    /* renamed from: a */
    public final /* synthetic */ V f6764a;

    /* renamed from: b */
    public final /* synthetic */ C0389i f6765b;

    /* renamed from: c */
    public final /* synthetic */ View f6766c;
    public final /* synthetic */ C0384d d;

    public AnimationAnimationListenerC0388h(V v9, C0389i c0389i, View view, C0384d c0384d) {
        this.f6764a = v9;
        this.f6765b = c0389i;
        this.f6766c = view;
        this.d = c0384d;
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationEnd(Animation animation) {
        AbstractC1420h.f(animation, "animation");
        C0389i c0389i = this.f6765b;
        c0389i.f6767a.post(new RunnableC0066h(c0389i, this.f6766c, this.d, 4));
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Animation from operation " + this.f6764a + " has ended.");
        }
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationRepeat(Animation animation) {
        AbstractC1420h.f(animation, "animation");
    }

    @Override // android.view.animation.Animation.AnimationListener
    public final void onAnimationStart(Animation animation) {
        AbstractC1420h.f(animation, "animation");
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Animation from operation " + this.f6764a + " has reached onAnimationStart.");
        }
    }
}
