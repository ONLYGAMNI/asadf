package androidx.fragment.app;

/* loaded from: classes.dex */
public final class C implements M {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ r f6615a;

    public C(r rVar) {
        this.f6615a = rVar;
    }

    @Override // androidx.fragment.app.M
    public final void a(I i10, r rVar) {
        this.f6615a.getClass();
    }
}
