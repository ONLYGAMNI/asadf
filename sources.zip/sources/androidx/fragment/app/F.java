package androidx.fragment.app;

import java.util.ArrayList;

/* loaded from: classes.dex */
public interface F {
    boolean a(ArrayList arrayList, ArrayList arrayList2);
}
