package androidx.fragment.app;

import android.util.Log;
import androidx.lifecycle.j0;
import androidx.lifecycle.q0;
import java.util.HashMap;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class L extends j0 {
    public static final K g = new K(0);
    public final boolean d;

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f6674a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final HashMap f6675b = new HashMap();

    /* renamed from: c, reason: collision with root package name */
    public final HashMap f6676c = new HashMap();

    /* renamed from: e, reason: collision with root package name */
    public boolean f6677e = false;

    /* renamed from: f, reason: collision with root package name */
    public boolean f6678f = false;

    public L(boolean z3) {
        this.d = z3;
    }

    public final void b(r rVar) {
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "Clearing non-config state for " + rVar);
        }
        c(rVar.f6833e);
    }

    public final void c(String str) {
        HashMap map = this.f6675b;
        L l5 = (L) map.get(str);
        if (l5 != null) {
            l5.onCleared();
            map.remove(str);
        }
        HashMap map2 = this.f6676c;
        q0 q0Var = (q0) map2.get(str);
        if (q0Var != null) {
            q0Var.a();
            map2.remove(str);
        }
    }

    public final void d(r rVar) {
        if (this.f6678f) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "Ignoring removeRetainedFragment as the state is already saved");
            }
        } else {
            if (this.f6674a.remove(rVar.f6833e) == null || !Log.isLoggable("FragmentManager", 2)) {
                return;
            }
            Log.v("FragmentManager", "Updating retained Fragments: Removed " + rVar);
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || L.class != obj.getClass()) {
            return false;
        }
        L l5 = (L) obj;
        return this.f6674a.equals(l5.f6674a) && this.f6675b.equals(l5.f6675b) && this.f6676c.equals(l5.f6676c);
    }

    public final int hashCode() {
        return this.f6676c.hashCode() + ((this.f6675b.hashCode() + (this.f6674a.hashCode() * 31)) * 31);
    }

    @Override // androidx.lifecycle.j0
    public final void onCleared() {
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "onCleared called for " + this);
        }
        this.f6677e = true;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("FragmentManagerViewModel{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} Fragments (");
        Iterator it = this.f6674a.values().iterator();
        while (it.hasNext()) {
            sb.append(it.next());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") Child Non Config (");
        Iterator it2 = this.f6675b.keySet().iterator();
        while (it2.hasNext()) {
            sb.append((String) it2.next());
            if (it2.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(") ViewModelStores (");
        Iterator it3 = this.f6676c.keySet().iterator();
        while (it3.hasNext()) {
            sb.append((String) it3.next());
            if (it3.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append(')');
        return sb.toString();
    }
}
