package androidx.fragment.app;

import android.view.View;
import android.view.ViewGroup;

/* renamed from: androidx.fragment.app.x */
/* loaded from: classes.dex */
public final class ViewOnAttachStateChangeListenerC0403x implements View.OnAttachStateChangeListener {

    /* renamed from: a */
    public final /* synthetic */ P f6864a;

    /* renamed from: b */
    public final /* synthetic */ y f6865b;

    public ViewOnAttachStateChangeListenerC0403x(y yVar, P p9) {
        this.f6865b = yVar;
        this.f6864a = p9;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewAttachedToWindow(View view) {
        P p9 = this.f6864a;
        r rVar = p9.f6696c;
        p9.k();
        C0389i.j((ViewGroup) rVar.f6814M.getParent(), this.f6865b.f6866a).i();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public final void onViewDetachedFromWindow(View view) {
    }
}
