package androidx.fragment.app;

/* renamed from: androidx.fragment.app.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0386f extends AbstractC0385e {
}
