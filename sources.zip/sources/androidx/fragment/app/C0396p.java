package androidx.fragment.app;

import android.view.View;

/* renamed from: androidx.fragment.app.p */
/* loaded from: classes.dex */
public final class C0396p extends AbstractC0402w {

    /* renamed from: a */
    public final /* synthetic */ r f6793a;

    public C0396p(r rVar) {
        this.f6793a = rVar;
    }

    @Override // androidx.fragment.app.AbstractC0402w
    public final View c(int i10) {
        r rVar = this.f6793a;
        View view = rVar.f6814M;
        if (view != null) {
            return view.findViewById(i10);
        }
        throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", rVar, " does not have a view"));
    }

    @Override // androidx.fragment.app.AbstractC0402w
    public final boolean d() {
        return this.f6793a.f6814M != null;
    }
}
