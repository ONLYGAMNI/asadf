package androidx.fragment.app;

import androidx.lifecycle.j0;
import androidx.lifecycle.n0;
import m0.AbstractC1194c;
import q0.C1307t;

/* loaded from: classes.dex */
public final class K implements n0 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6673a;

    @Override // androidx.lifecycle.n0
    public final j0 create(Class cls) {
        switch (this.f6673a) {
            case 0:
                return new L(true);
            case 1:
                return new n0.c();
            default:
                return new C1307t();
        }
    }

    @Override // androidx.lifecycle.n0
    public final j0 create(Class cls, AbstractC1194c abstractC1194c) {
        switch (this.f6673a) {
        }
        return create(cls);
    }
}
