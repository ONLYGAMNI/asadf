package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;

/* renamed from: androidx.fragment.app.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0383c implements Parcelable {
    public static final Parcelable.Creator<C0383c> CREATOR = new S3.b(15);

    /* renamed from: a, reason: collision with root package name */
    public final List f6753a;

    /* renamed from: b, reason: collision with root package name */
    public final List f6754b;

    public C0383c(ArrayList arrayList, ArrayList arrayList2) {
        this.f6753a = arrayList;
        this.f6754b = arrayList2;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeStringList(this.f6753a);
        parcel.writeTypedList(this.f6754b);
    }

    public C0383c(Parcel parcel) {
        this.f6753a = parcel.createStringArrayList();
        this.f6754b = parcel.createTypedArrayList(C0382b.CREATOR);
    }
}
