package androidx.fragment.app;

import android.app.Dialog;
import android.view.View;

/* renamed from: androidx.fragment.app.m */
/* loaded from: classes.dex */
public final class C0393m extends AbstractC0402w {

    /* renamed from: a */
    public final /* synthetic */ AbstractC0402w f6774a;

    /* renamed from: b */
    public final /* synthetic */ DialogInterfaceOnCancelListenerC0394n f6775b;

    public C0393m(DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n, C0396p c0396p) {
        this.f6775b = dialogInterfaceOnCancelListenerC0394n;
        this.f6774a = c0396p;
    }

    @Override // androidx.fragment.app.AbstractC0402w
    public final View c(int i10) {
        AbstractC0402w abstractC0402w = this.f6774a;
        if (abstractC0402w.d()) {
            return abstractC0402w.c(i10);
        }
        Dialog dialog = this.f6775b.f6787o0;
        if (dialog != null) {
            return dialog.findViewById(i10);
        }
        return null;
    }

    @Override // androidx.fragment.app.AbstractC0402w
    public final boolean d() {
        return this.f6774a.d() || this.f6775b.f6791s0;
    }
}
