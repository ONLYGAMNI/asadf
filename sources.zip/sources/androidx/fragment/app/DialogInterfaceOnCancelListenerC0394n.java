package androidx.fragment.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.lifecycle.e0;
import com.tajir.tajir.R;

/* renamed from: androidx.fragment.app.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class DialogInterfaceOnCancelListenerC0394n extends r implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {

    /* renamed from: d0, reason: collision with root package name */
    public Handler f6776d0;

    /* renamed from: m0, reason: collision with root package name */
    public boolean f6785m0;

    /* renamed from: o0, reason: collision with root package name */
    public Dialog f6787o0;

    /* renamed from: p0, reason: collision with root package name */
    public boolean f6788p0;

    /* renamed from: q0, reason: collision with root package name */
    public boolean f6789q0;

    /* renamed from: r0, reason: collision with root package name */
    public boolean f6790r0;

    /* renamed from: e0, reason: collision with root package name */
    public final D6.G f6777e0 = new D6.G(this, 14);

    /* renamed from: f0, reason: collision with root package name */
    public final DialogInterfaceOnCancelListenerC0390j f6778f0 = new DialogInterfaceOnCancelListenerC0390j(this);

    /* renamed from: g0, reason: collision with root package name */
    public final DialogInterfaceOnDismissListenerC0391k f6779g0 = new DialogInterfaceOnDismissListenerC0391k(this);

    /* renamed from: h0, reason: collision with root package name */
    public int f6780h0 = 0;

    /* renamed from: i0, reason: collision with root package name */
    public int f6781i0 = 0;

    /* renamed from: j0, reason: collision with root package name */
    public boolean f6782j0 = true;

    /* renamed from: k0, reason: collision with root package name */
    public boolean f6783k0 = true;

    /* renamed from: l0, reason: collision with root package name */
    public int f6784l0 = -1;

    /* renamed from: n0, reason: collision with root package name */
    public final C0392l f6786n0 = new C0392l(this);

    /* renamed from: s0, reason: collision with root package name */
    public boolean f6791s0 = false;

    @Override // androidx.fragment.app.r
    public void B(Bundle bundle) {
        this.K = true;
    }

    @Override // androidx.fragment.app.r
    public final void D(Context context) {
        super.D(context);
        this.f6825X.f(this.f6786n0);
        if (this.f6790r0) {
            return;
        }
        this.f6789q0 = false;
    }

    @Override // androidx.fragment.app.r
    public void E(Bundle bundle) {
        super.E(bundle);
        this.f6776d0 = new Handler();
        this.f6783k0 = this.f6807E == 0;
        if (bundle != null) {
            this.f6780h0 = bundle.getInt("android:style", 0);
            this.f6781i0 = bundle.getInt("android:theme", 0);
            this.f6782j0 = bundle.getBoolean("android:cancelable", true);
            this.f6783k0 = bundle.getBoolean("android:showsDialog", this.f6783k0);
            this.f6784l0 = bundle.getInt("android:backStackId", -1);
        }
    }

    @Override // androidx.fragment.app.r
    public void H() {
        this.K = true;
        Dialog dialog = this.f6787o0;
        if (dialog != null) {
            this.f6788p0 = true;
            dialog.setOnDismissListener(null);
            this.f6787o0.dismiss();
            if (!this.f6789q0) {
                onDismiss(this.f6787o0);
            }
            this.f6787o0 = null;
            this.f6791s0 = false;
        }
    }

    @Override // androidx.fragment.app.r
    public final void I() {
        this.K = true;
        if (!this.f6790r0 && !this.f6789q0) {
            this.f6789q0 = true;
        }
        this.f6825X.j(this.f6786n0);
    }

    @Override // androidx.fragment.app.r
    public final LayoutInflater J(Bundle bundle) {
        LayoutInflater layoutInflaterJ = super.J(bundle);
        boolean z3 = this.f6783k0;
        if (!z3 || this.f6785m0) {
            if (Log.isLoggable("FragmentManager", 2)) {
                String str = "getting layout inflater for DialogFragment " + this;
                if (this.f6783k0) {
                    Log.d("FragmentManager", "mCreatingDialog = true: " + str);
                } else {
                    Log.d("FragmentManager", "mShowsDialog = false: " + str);
                }
            }
            return layoutInflaterJ;
        }
        if (z3 && !this.f6791s0) {
            try {
                this.f6785m0 = true;
                Dialog dialogG0 = g0();
                this.f6787o0 = dialogG0;
                if (this.f6783k0) {
                    j0(dialogG0, this.f6780h0);
                    Context contextN = n();
                    if (contextN instanceof Activity) {
                        this.f6787o0.setOwnerActivity((Activity) contextN);
                    }
                    this.f6787o0.setCancelable(this.f6782j0);
                    this.f6787o0.setOnCancelListener(this.f6778f0);
                    this.f6787o0.setOnDismissListener(this.f6779g0);
                    this.f6791s0 = true;
                } else {
                    this.f6787o0 = null;
                }
                this.f6785m0 = false;
            } catch (Throwable th) {
                this.f6785m0 = false;
                throw th;
            }
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.d("FragmentManager", "get layout inflater for DialogFragment " + this + " from dialog context");
        }
        Dialog dialog = this.f6787o0;
        return dialog != null ? layoutInflaterJ.cloneInContext(dialog.getContext()) : layoutInflaterJ;
    }

    @Override // androidx.fragment.app.r
    public void O(Bundle bundle) {
        Dialog dialog = this.f6787o0;
        if (dialog != null) {
            Bundle bundleOnSaveInstanceState = dialog.onSaveInstanceState();
            bundleOnSaveInstanceState.putBoolean("android:dialogShowing", false);
            bundle.putBundle("android:savedDialogState", bundleOnSaveInstanceState);
        }
        int i10 = this.f6780h0;
        if (i10 != 0) {
            bundle.putInt("android:style", i10);
        }
        int i11 = this.f6781i0;
        if (i11 != 0) {
            bundle.putInt("android:theme", i11);
        }
        boolean z3 = this.f6782j0;
        if (!z3) {
            bundle.putBoolean("android:cancelable", z3);
        }
        boolean z9 = this.f6783k0;
        if (!z9) {
            bundle.putBoolean("android:showsDialog", z9);
        }
        int i12 = this.f6784l0;
        if (i12 != -1) {
            bundle.putInt("android:backStackId", i12);
        }
    }

    @Override // androidx.fragment.app.r
    public void P() {
        this.K = true;
        Dialog dialog = this.f6787o0;
        if (dialog != null) {
            this.f6788p0 = false;
            dialog.show();
            View decorView = this.f6787o0.getWindow().getDecorView();
            e0.l(decorView, this);
            decorView.setTag(R.id.view_tree_view_model_store_owner, this);
            X0.f.x(decorView, this);
        }
    }

    @Override // androidx.fragment.app.r
    public void Q() {
        this.K = true;
        Dialog dialog = this.f6787o0;
        if (dialog != null) {
            dialog.hide();
        }
    }

    @Override // androidx.fragment.app.r
    public final void S(Bundle bundle) {
        Bundle bundle2;
        this.K = true;
        if (this.f6787o0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f6787o0.onRestoreInstanceState(bundle2);
    }

    @Override // androidx.fragment.app.r
    public final void T(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        Bundle bundle2;
        super.T(layoutInflater, viewGroup, bundle);
        if (this.f6814M != null || this.f6787o0 == null || bundle == null || (bundle2 = bundle.getBundle("android:savedDialogState")) == null) {
            return;
        }
        this.f6787o0.onRestoreInstanceState(bundle2);
    }

    public void c0() {
        e0(false, false);
    }

    public void d0() {
        e0(true, false);
    }

    public final void e0(boolean z3, boolean z9) {
        if (this.f6789q0) {
            return;
        }
        this.f6789q0 = true;
        this.f6790r0 = false;
        Dialog dialog = this.f6787o0;
        if (dialog != null) {
            dialog.setOnDismissListener(null);
            this.f6787o0.dismiss();
            if (!z9) {
                if (Looper.myLooper() == this.f6776d0.getLooper()) {
                    onDismiss(this.f6787o0);
                } else {
                    this.f6776d0.post(this.f6777e0);
                }
            }
        }
        this.f6788p0 = true;
        if (this.f6784l0 >= 0) {
            I iQ = q();
            int i10 = this.f6784l0;
            if (i10 < 0) {
                throw new IllegalArgumentException(android.support.v4.media.session.a.h(i10, "Bad id: "));
            }
            iQ.w(new G(iQ, null, i10), z3);
            this.f6784l0 = -1;
            return;
        }
        C0381a c0381a = new C0381a(q());
        c0381a.f6735p = true;
        c0381a.h(this);
        if (z3) {
            c0381a.e(true);
        } else {
            c0381a.e(false);
        }
    }

    public int f0() {
        return this.f6781i0;
    }

    public Dialog g0() {
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "onCreateDialog called for DialogFragment " + this);
        }
        return new androidx.activity.k(W(), f0());
    }

    public final Dialog h0() {
        Dialog dialog = this.f6787o0;
        if (dialog != null) {
            return dialog;
        }
        throw new IllegalStateException("DialogFragment " + this + " does not have a Dialog.");
    }

    @Override // androidx.fragment.app.r
    public final AbstractC0402w i() {
        return new C0393m(this, new C0396p(this));
    }

    public final void i0(boolean z3) {
        this.f6782j0 = z3;
        Dialog dialog = this.f6787o0;
        if (dialog != null) {
            dialog.setCancelable(z3);
        }
    }

    public void j0(Dialog dialog, int i10) {
        if (i10 != 1 && i10 != 2) {
            if (i10 != 3) {
                return;
            }
            Window window = dialog.getWindow();
            if (window != null) {
                window.addFlags(24);
            }
        }
        dialog.requestWindowFeature(1);
    }

    public void k0(I i10, String str) {
        this.f6789q0 = false;
        this.f6790r0 = true;
        i10.getClass();
        C0381a c0381a = new C0381a(i10);
        c0381a.f6735p = true;
        c0381a.f(0, this, str, 1);
        c0381a.e(false);
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public void onCancel(DialogInterface dialogInterface) {
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public void onDismiss(DialogInterface dialogInterface) {
        if (this.f6788p0) {
            return;
        }
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "onDismiss called for DialogFragment " + this);
        }
        e0(true, true);
    }
}
