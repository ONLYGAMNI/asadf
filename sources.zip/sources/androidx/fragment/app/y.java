package androidx.fragment.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.strictmode.FragmentTagUsageViolation;
import i0.AbstractC0916a;
import j0.AbstractC1047c;
import j0.C1046b;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public final class y implements LayoutInflater.Factory2 {

    /* renamed from: a, reason: collision with root package name */
    public final I f6866a;

    public y(I i10) {
        this.f6866a = i10;
    }

    @Override // android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        boolean zIsAssignableFrom;
        P pF;
        boolean zEquals = FragmentContainerView.class.getName().equals(str);
        I i10 = this.f6866a;
        if (zEquals) {
            return new FragmentContainerView(context, attributeSet, i10);
        }
        if (!"fragment".equals(str)) {
            return null;
        }
        String attributeValue = attributeSet.getAttributeValue(null, "class");
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0916a.f11041a);
        if (attributeValue == null) {
            attributeValue = typedArrayObtainStyledAttributes.getString(0);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(1, -1);
        String string = typedArrayObtainStyledAttributes.getString(2);
        typedArrayObtainStyledAttributes.recycle();
        if (attributeValue != null) {
            try {
                zIsAssignableFrom = r.class.isAssignableFrom(B.b(context.getClassLoader(), attributeValue));
            } catch (ClassNotFoundException unused) {
                zIsAssignableFrom = false;
            }
            if (zIsAssignableFrom) {
                int id = view != null ? view.getId() : 0;
                if (id == -1 && resourceId == -1 && string == null) {
                    throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Must specify unique android:id, android:tag, or have a parent with an id for " + attributeValue);
                }
                r rVarC = resourceId != -1 ? i10.C(resourceId) : null;
                if (rVarC == null && string != null) {
                    rVarC = i10.D(string);
                }
                if (rVarC == null && id != -1) {
                    rVarC = i10.C(id);
                }
                if (rVarC == null) {
                    B bF = i10.F();
                    context.getClassLoader();
                    rVarC = bF.a(attributeValue);
                    rVarC.f6842u = true;
                    rVarC.f6806D = resourceId != 0 ? resourceId : id;
                    rVarC.f6807E = id;
                    rVarC.f6808F = string;
                    rVarC.f6843v = true;
                    rVarC.f6847z = i10;
                    C0399t c0399t = i10.f6660u;
                    rVarC.f6803A = c0399t;
                    rVarC.K(c0399t.f6852b, attributeSet, rVarC.f6830b);
                    pF = i10.a(rVarC);
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "Fragment " + rVarC + " has been inflated via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
                    }
                } else {
                    if (rVarC.f6843v) {
                        throw new IllegalArgumentException(attributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(resourceId) + ", tag " + string + ", or parent id 0x" + Integer.toHexString(id) + " with another fragment for " + attributeValue);
                    }
                    rVarC.f6843v = true;
                    rVarC.f6847z = i10;
                    C0399t c0399t2 = i10.f6660u;
                    rVarC.f6803A = c0399t2;
                    rVarC.K(c0399t2.f6852b, attributeSet, rVarC.f6830b);
                    pF = i10.f(rVarC);
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "Retained Fragment " + rVarC + " has been re-attached via the <fragment> tag: id=0x" + Integer.toHexString(resourceId));
                    }
                }
                ViewGroup viewGroup = (ViewGroup) view;
                C1046b c1046b = AbstractC1047c.f11689a;
                AbstractC1047c.b(new FragmentTagUsageViolation(rVarC, "Attempting to use <fragment> tag to add fragment " + rVarC + " to container " + viewGroup));
                AbstractC1047c.a(rVarC).getClass();
                rVarC.f6813L = viewGroup;
                pF.k();
                pF.j();
                View view2 = rVarC.f6814M;
                if (view2 == null) {
                    throw new IllegalStateException(AbstractC1480a.k("Fragment ", attributeValue, " did not create a view."));
                }
                if (resourceId != 0) {
                    view2.setId(resourceId);
                }
                if (rVarC.f6814M.getTag() == null) {
                    rVarC.f6814M.setTag(string);
                }
                rVarC.f6814M.addOnAttachStateChangeListener(new ViewOnAttachStateChangeListenerC0403x(this, pF));
                return rVarC.f6814M;
            }
        }
        return null;
    }
}
