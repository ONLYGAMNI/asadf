package androidx.fragment.app;

/* loaded from: classes.dex */
public abstract /* synthetic */ class W {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ int[] f6721a;

    static {
        int[] iArr = new int[t.e.e(3).length];
        try {
            iArr[0] = 1;
        } catch (NoSuchFieldError unused) {
        }
        f6721a = iArr;
    }
}
