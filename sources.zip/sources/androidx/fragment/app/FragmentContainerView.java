package androidx.fragment.app;

import R.B0;
import android.animation.LayoutTransition;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import com.tajir.tajir.R;
import i0.AbstractC0916a;
import java.util.ArrayList;
import java.util.Iterator;
import s8.AbstractC1420h;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public final class FragmentContainerView extends FrameLayout {

    /* renamed from: a */
    public final ArrayList f6620a;

    /* renamed from: b */
    public final ArrayList f6621b;

    /* renamed from: c */
    public View.OnApplyWindowInsetsListener f6622c;
    public boolean d;

    public FragmentContainerView(Context context) {
        super(context);
        this.f6620a = new ArrayList();
        this.f6621b = new ArrayList();
        this.d = true;
    }

    public final void a(View view) {
        if (this.f6621b.contains(view)) {
            this.f6620a.add(view);
        }
    }

    @Override // android.view.ViewGroup
    public final void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        AbstractC1420h.f(view, "child");
        Object tag = view.getTag(R.id.fragment_container_view_tag);
        if ((tag instanceof r ? (r) tag : null) != null) {
            super.addView(view, i10, layoutParams);
            return;
        }
        throw new IllegalStateException(("Views added to a FragmentContainerView must be associated with a Fragment. View " + view + " is not associated with a Fragment.").toString());
    }

    @Override // android.view.ViewGroup, android.view.View
    public final WindowInsets dispatchApplyWindowInsets(WindowInsets windowInsets) {
        B0 b0I;
        AbstractC1420h.f(windowInsets, "insets");
        B0 b0H = B0.h(null, windowInsets);
        View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = this.f6622c;
        if (onApplyWindowInsetsListener != null) {
            AbstractC1420h.c(onApplyWindowInsetsListener);
            WindowInsets windowInsetsOnApplyWindowInsets = onApplyWindowInsetsListener.onApplyWindowInsets(this, windowInsets);
            AbstractC1420h.e(windowInsetsOnApplyWindowInsets, "onApplyWindowInsetsListe…lyWindowInsets(v, insets)");
            b0I = B0.h(null, windowInsetsOnApplyWindowInsets);
        } else {
            b0I = R.X.i(this, b0H);
        }
        AbstractC1420h.e(b0I, "if (applyWindowInsetsLis…, insetsCompat)\n        }");
        if (!b0I.f3951a.m()) {
            int childCount = getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                R.X.b(getChildAt(i10), b0I);
            }
        }
        return windowInsets;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchDraw(Canvas canvas) {
        AbstractC1420h.f(canvas, "canvas");
        if (this.d) {
            Iterator it = this.f6620a.iterator();
            while (it.hasNext()) {
                super.drawChild(canvas, (View) it.next(), getDrawingTime());
            }
        }
        super.dispatchDraw(canvas);
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        AbstractC1420h.f(canvas, "canvas");
        AbstractC1420h.f(view, "child");
        if (this.d) {
            ArrayList arrayList = this.f6620a;
            if ((!arrayList.isEmpty()) && arrayList.contains(view)) {
                return false;
            }
        }
        return super.drawChild(canvas, view, j10);
    }

    @Override // android.view.ViewGroup
    public final void endViewTransition(View view) {
        AbstractC1420h.f(view, "view");
        this.f6621b.remove(view);
        if (this.f6620a.remove(view)) {
            this.d = true;
        }
        super.endViewTransition(view);
    }

    public final <F extends r> F getFragment() {
        AbstractActivityC0400u abstractActivityC0400u;
        r rVar;
        I iU;
        View view = this;
        while (true) {
            abstractActivityC0400u = null;
            if (view == null) {
                rVar = null;
                break;
            }
            Object tag = view.getTag(R.id.fragment_container_view_tag);
            rVar = tag instanceof r ? (r) tag : null;
            if (rVar != null) {
                break;
            }
            Object parent = view.getParent();
            view = parent instanceof View ? (View) parent : null;
        }
        if (rVar == null) {
            Context context = getContext();
            while (true) {
                if (!(context instanceof ContextWrapper)) {
                    break;
                }
                if (context instanceof AbstractActivityC0400u) {
                    abstractActivityC0400u = (AbstractActivityC0400u) context;
                    break;
                }
                context = ((ContextWrapper) context).getBaseContext();
            }
            if (abstractActivityC0400u == null) {
                throw new IllegalStateException("View " + this + " is not within a subclass of FragmentActivity.");
            }
            iU = abstractActivityC0400u.u();
        } else {
            if (!rVar.x()) {
                throw new IllegalStateException("The Fragment " + rVar + " that owns View " + this + " has already been destroyed. Nested fragments should always use the child FragmentManager.");
            }
            iU = rVar.m();
        }
        return (F) iU.C(getId());
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        AbstractC1420h.f(windowInsets, "insets");
        return windowInsets;
    }

    @Override // android.view.ViewGroup
    public final void removeAllViewsInLayout() {
        int childCount = getChildCount();
        while (true) {
            childCount--;
            if (-1 >= childCount) {
                super.removeAllViewsInLayout();
                return;
            } else {
                View childAt = getChildAt(childCount);
                AbstractC1420h.e(childAt, "view");
                a(childAt);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public final void removeView(View view) {
        AbstractC1420h.f(view, "view");
        a(view);
        super.removeView(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViewAt(int i10) {
        View childAt = getChildAt(i10);
        AbstractC1420h.e(childAt, "view");
        a(childAt);
        super.removeViewAt(i10);
    }

    @Override // android.view.ViewGroup
    public final void removeViewInLayout(View view) {
        AbstractC1420h.f(view, "view");
        a(view);
        super.removeViewInLayout(view);
    }

    @Override // android.view.ViewGroup
    public final void removeViews(int i10, int i11) {
        int i12 = i10 + i11;
        for (int i13 = i10; i13 < i12; i13++) {
            View childAt = getChildAt(i13);
            AbstractC1420h.e(childAt, "view");
            a(childAt);
        }
        super.removeViews(i10, i11);
    }

    @Override // android.view.ViewGroup
    public final void removeViewsInLayout(int i10, int i11) {
        int i12 = i10 + i11;
        for (int i13 = i10; i13 < i12; i13++) {
            View childAt = getChildAt(i13);
            AbstractC1420h.e(childAt, "view");
            a(childAt);
        }
        super.removeViewsInLayout(i10, i11);
    }

    public final void setDrawDisappearingViewsLast(boolean z3) {
        this.d = z3;
    }

    @Override // android.view.ViewGroup
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        throw new UnsupportedOperationException("FragmentContainerView does not support Layout Transitions or animateLayoutChanges=\"true\".");
    }

    @Override // android.view.View
    public void setOnApplyWindowInsetsListener(View.OnApplyWindowInsetsListener onApplyWindowInsetsListener) {
        AbstractC1420h.f(onApplyWindowInsetsListener, "listener");
        this.f6622c = onApplyWindowInsetsListener;
    }

    @Override // android.view.ViewGroup
    public final void startViewTransition(View view) {
        AbstractC1420h.f(view, "view");
        if (view.getParent() == this) {
            this.f6621b.add(view);
        }
        super.startViewTransition(view);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet) {
        String str;
        super(context, attributeSet, 0);
        AbstractC1420h.f(context, "context");
        this.f6620a = new ArrayList();
        this.f6621b = new ArrayList();
        this.d = true;
        if (attributeSet != null) {
            String classAttribute = attributeSet.getClassAttribute();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0916a.f11042b, 0, 0);
            if (classAttribute == null) {
                classAttribute = typedArrayObtainStyledAttributes.getString(0);
                str = "android:name";
            } else {
                str = "class";
            }
            typedArrayObtainStyledAttributes.recycle();
            if (classAttribute == null || isInEditMode()) {
                return;
            }
            throw new UnsupportedOperationException("FragmentContainerView must be within a FragmentActivity to use " + str + "=\"" + classAttribute + '\"');
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FragmentContainerView(Context context, AttributeSet attributeSet, I i10) {
        View view;
        super(context, attributeSet);
        AbstractC1420h.f(context, "context");
        AbstractC1420h.f(attributeSet, "attrs");
        AbstractC1420h.f(i10, "fm");
        this.f6620a = new ArrayList();
        this.f6621b = new ArrayList();
        this.d = true;
        String classAttribute = attributeSet.getClassAttribute();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0916a.f11042b, 0, 0);
        classAttribute = classAttribute == null ? typedArrayObtainStyledAttributes.getString(0) : classAttribute;
        String string = typedArrayObtainStyledAttributes.getString(1);
        typedArrayObtainStyledAttributes.recycle();
        int id = getId();
        r rVarC = i10.C(id);
        if (classAttribute != null && rVarC == null) {
            if (id == -1) {
                throw new IllegalStateException(AbstractC1480a.k("FragmentContainerView must have an android:id to add Fragment ", classAttribute, string != null ? " with tag ".concat(string) : ""));
            }
            B bF = i10.F();
            context.getClassLoader();
            r rVarA = bF.a(classAttribute);
            AbstractC1420h.e(rVarA, "fm.fragmentFactory.insta…ontext.classLoader, name)");
            rVarA.K(context, attributeSet, null);
            C0381a c0381a = new C0381a(i10);
            c0381a.f6735p = true;
            rVarA.f6813L = this;
            c0381a.f(getId(), rVarA, string, 1);
            if (!c0381a.g) {
                c0381a.f6727h = false;
                c0381a.f6736q.z(c0381a, true);
            } else {
                throw new IllegalStateException("This transaction is already being added to the back stack");
            }
        }
        Iterator it = i10.f6644c.n().iterator();
        while (it.hasNext()) {
            P p9 = (P) it.next();
            r rVar = p9.f6696c;
            if (rVar.f6807E == getId() && (view = rVar.f6814M) != null && view.getParent() == null) {
                rVar.f6813L = this;
                p9.b();
            }
        }
    }
}
