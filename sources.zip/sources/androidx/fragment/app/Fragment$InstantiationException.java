package androidx.fragment.app;

/* loaded from: classes.dex */
public class Fragment$InstantiationException extends RuntimeException {
}
