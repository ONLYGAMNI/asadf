package androidx.fragment.app;

import android.util.Log;
import android.view.View;
import f8.AbstractC0842j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import s2.AbstractC1397b;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class V {

    /* renamed from: a */
    public int f6715a;

    /* renamed from: b */
    public int f6716b;

    /* renamed from: c */
    public final r f6717c;
    public final ArrayList d;

    /* renamed from: e */
    public final LinkedHashSet f6718e;

    /* renamed from: f */
    public boolean f6719f;
    public boolean g;

    /* renamed from: h */
    public final P f6720h;

    public V(int i10, int i11, P p9, M.d dVar) {
        AbstractC1397b.f(i10, "finalState");
        AbstractC1397b.f(i11, "lifecycleImpact");
        AbstractC1420h.f(p9, "fragmentStateManager");
        r rVar = p9.f6696c;
        AbstractC1420h.e(rVar, "fragmentStateManager.fragment");
        AbstractC1397b.f(i10, "finalState");
        AbstractC1397b.f(i11, "lifecycleImpact");
        AbstractC1420h.f(rVar, "fragment");
        this.f6715a = i10;
        this.f6716b = i11;
        this.f6717c = rVar;
        this.d = new ArrayList();
        this.f6718e = new LinkedHashSet();
        dVar.b(new D6.p(this, 26));
        this.f6720h = p9;
    }

    public final void a() {
        if (this.f6719f) {
            return;
        }
        this.f6719f = true;
        LinkedHashSet linkedHashSet = this.f6718e;
        if (linkedHashSet.isEmpty()) {
            b();
            return;
        }
        Iterator it = AbstractC0842j.t0(linkedHashSet).iterator();
        while (it.hasNext()) {
            ((M.d) it.next()).a();
        }
    }

    public final void b() {
        if (!this.g) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "SpecialEffectsController: " + this + " has called complete.");
            }
            this.g = true;
            Iterator it = this.d.iterator();
            while (it.hasNext()) {
                ((Runnable) it.next()).run();
            }
        }
        this.f6720h.k();
    }

    public final void c(int i10, int i11) {
        AbstractC1397b.f(i10, "finalState");
        AbstractC1397b.f(i11, "lifecycleImpact");
        int iD = t.e.d(i11);
        r rVar = this.f6717c;
        if (iD == 0) {
            if (this.f6715a != 1) {
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + rVar + " mFinalState = " + android.support.v4.media.session.a.z(this.f6715a) + " -> " + android.support.v4.media.session.a.z(i10) + '.');
                }
                this.f6715a = i10;
                return;
            }
            return;
        }
        if (iD == 1) {
            if (this.f6715a == 1) {
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: For fragment " + rVar + " mFinalState = REMOVED -> VISIBLE. mLifecycleImpact = " + android.support.v4.media.session.a.y(this.f6716b) + " to ADDING.");
                }
                this.f6715a = 2;
                this.f6716b = 2;
                return;
            }
            return;
        }
        if (iD != 2) {
            return;
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "SpecialEffectsController: For fragment " + rVar + " mFinalState = " + android.support.v4.media.session.a.z(this.f6715a) + " -> REMOVED. mLifecycleImpact  = " + android.support.v4.media.session.a.y(this.f6716b) + " to REMOVING.");
        }
        this.f6715a = 1;
        this.f6716b = 3;
    }

    public final void d() {
        int i10 = this.f6716b;
        P p9 = this.f6720h;
        if (i10 != 2) {
            if (i10 == 3) {
                r rVar = p9.f6696c;
                AbstractC1420h.e(rVar, "fragmentStateManager.fragment");
                View viewY = rVar.Y();
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "Clearing focus " + viewY.findFocus() + " on view " + viewY + " for Fragment " + rVar);
                }
                viewY.clearFocus();
                return;
            }
            return;
        }
        r rVar2 = p9.f6696c;
        AbstractC1420h.e(rVar2, "fragmentStateManager.fragment");
        View viewFindFocus = rVar2.f6814M.findFocus();
        if (viewFindFocus != null) {
            rVar2.k().f6802k = viewFindFocus;
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "requestFocus: Saved focused view " + viewFindFocus + " for Fragment " + rVar2);
            }
        }
        View viewY2 = this.f6717c.Y();
        if (viewY2.getParent() == null) {
            p9.b();
            viewY2.setAlpha(0.0f);
        }
        if (viewY2.getAlpha() == 0.0f && viewY2.getVisibility() == 0) {
            viewY2.setVisibility(4);
        }
        C0397q c0397q = rVar2.f6817P;
        viewY2.setAlpha(c0397q == null ? 1.0f : c0397q.f6801j);
    }

    public final String toString() {
        StringBuilder sbQ = android.support.v4.media.session.a.q("Operation {", Integer.toHexString(System.identityHashCode(this)), "} {finalState = ");
        sbQ.append(android.support.v4.media.session.a.z(this.f6715a));
        sbQ.append(" lifecycleImpact = ");
        sbQ.append(android.support.v4.media.session.a.y(this.f6716b));
        sbQ.append(" fragment = ");
        sbQ.append(this.f6717c);
        sbQ.append('}');
        return sbQ.toString();
    }
}
