package androidx.fragment.app;

import androidx.lifecycle.EnumC0424v;

/* loaded from: classes.dex */
class FragmentManager$6 implements androidx.lifecycle.B {
    @Override // androidx.lifecycle.B
    public final void d(androidx.lifecycle.D d, EnumC0424v enumC0424v) {
        if (enumC0424v == EnumC0424v.ON_START || enumC0424v == EnumC0424v.ON_DESTROY) {
            throw null;
        }
    }
}
