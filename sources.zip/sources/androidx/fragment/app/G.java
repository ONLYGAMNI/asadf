package androidx.fragment.app;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class G implements F {

    /* renamed from: a */
    public final String f6623a;

    /* renamed from: b */
    public final int f6624b;

    /* renamed from: c */
    public final int f6625c = 1;
    public final /* synthetic */ I d;

    public G(I i10, String str, int i11) {
        this.d = i10;
        this.f6623a = str;
        this.f6624b = i11;
    }

    @Override // androidx.fragment.app.F
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        r rVar = this.d.f6663x;
        if (rVar != null && this.f6624b < 0 && this.f6623a == null && rVar.m().P()) {
            return false;
        }
        return this.d.R(arrayList, arrayList2, this.f6623a, this.f6624b, this.f6625c);
    }
}
