package androidx.fragment.app;

import D.RunnableC0050a;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Bundle;
import androidx.lifecycle.EnumC0424v;
import androidx.lifecycle.e0;
import androidx.lifecycle.h0;
import androidx.lifecycle.l0;
import androidx.lifecycle.n0;
import androidx.lifecycle.q0;
import androidx.lifecycle.r0;
import java.util.LinkedHashMap;
import m0.C1196e;

/* loaded from: classes.dex */
public final class S implements androidx.lifecycle.r, C0.f, r0 {

    /* renamed from: a */
    public final r f6705a;

    /* renamed from: b */
    public final q0 f6706b;

    /* renamed from: c */
    public final Runnable f6707c;
    public n0 d;

    /* renamed from: e */
    public androidx.lifecycle.F f6708e = null;

    /* renamed from: f */
    public com.bumptech.glide.manager.q f6709f = null;

    public S(r rVar, q0 q0Var, RunnableC0050a runnableC0050a) {
        this.f6705a = rVar;
        this.f6706b = q0Var;
        this.f6707c = runnableC0050a;
    }

    public final void a(EnumC0424v enumC0424v) {
        this.f6708e.e(enumC0424v);
    }

    @Override // C0.f
    public final C0.e b() {
        e();
        return (C0.e) this.f6709f.d;
    }

    @Override // androidx.lifecycle.r
    public final n0 c() {
        Application application;
        r rVar = this.f6705a;
        n0 n0VarC = rVar.c();
        if (!n0VarC.equals(rVar.f6826Y)) {
            this.d = n0VarC;
            return n0VarC;
        }
        if (this.d == null) {
            Context applicationContext = rVar.W().getApplicationContext();
            while (true) {
                if (!(applicationContext instanceof ContextWrapper)) {
                    application = null;
                    break;
                }
                if (applicationContext instanceof Application) {
                    application = (Application) applicationContext;
                    break;
                }
                applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
            }
            this.d = new h0(application, rVar, rVar.f6834f);
        }
        return this.d;
    }

    @Override // androidx.lifecycle.r
    public final C1196e d() {
        Application application;
        r rVar = this.f6705a;
        Context applicationContext = rVar.W().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        C1196e c1196e = new C1196e(0);
        LinkedHashMap linkedHashMap = c1196e.f12974a;
        if (application != null) {
            linkedHashMap.put(l0.f6992a, application);
        }
        linkedHashMap.put(e0.f6957a, rVar);
        linkedHashMap.put(e0.f6958b, this);
        Bundle bundle = rVar.f6834f;
        if (bundle != null) {
            linkedHashMap.put(e0.f6959c, bundle);
        }
        return c1196e;
    }

    public final void e() {
        if (this.f6708e == null) {
            this.f6708e = new androidx.lifecycle.F(this);
            com.bumptech.glide.manager.q qVar = new com.bumptech.glide.manager.q(this);
            this.f6709f = qVar;
            qVar.h();
            this.f6707c.run();
        }
    }

    @Override // androidx.lifecycle.r0
    public final q0 f() {
        e();
        return this.f6706b;
    }

    @Override // androidx.lifecycle.D
    public final androidx.lifecycle.F h() {
        e();
        return this.f6708e;
    }
}
