package androidx.fragment.app;

import android.util.Log;
import android.view.View;

/* renamed from: androidx.fragment.app.l */
/* loaded from: classes.dex */
public final class C0392l implements androidx.lifecycle.O {

    /* renamed from: a */
    public final /* synthetic */ DialogInterfaceOnCancelListenerC0394n f6773a;

    public C0392l(DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n) {
        this.f6773a = dialogInterfaceOnCancelListenerC0394n;
    }

    @Override // androidx.lifecycle.O
    public final void a(Object obj) {
        if (((androidx.lifecycle.D) obj) != null) {
            DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n = this.f6773a;
            if (dialogInterfaceOnCancelListenerC0394n.f6783k0) {
                View viewY = dialogInterfaceOnCancelListenerC0394n.Y();
                if (viewY.getParent() != null) {
                    throw new IllegalStateException("DialogFragment can not be attached to a container view");
                }
                if (dialogInterfaceOnCancelListenerC0394n.f6787o0 != null) {
                    if (Log.isLoggable("FragmentManager", 3)) {
                        Log.d("FragmentManager", "DialogFragment " + this + " setting the content view on " + dialogInterfaceOnCancelListenerC0394n.f6787o0);
                    }
                    dialogInterfaceOnCancelListenerC0394n.f6787o0.setContentView(viewY);
                }
            }
        }
    }
}
