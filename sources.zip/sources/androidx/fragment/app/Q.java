package androidx.fragment.app;

import androidx.lifecycle.EnumC0425w;

/* loaded from: classes.dex */
public final class Q {

    /* renamed from: a */
    public int f6698a;

    /* renamed from: b */
    public r f6699b;

    /* renamed from: c */
    public boolean f6700c = false;
    public int d;

    /* renamed from: e */
    public int f6701e;

    /* renamed from: f */
    public int f6702f;
    public int g;

    /* renamed from: h */
    public EnumC0425w f6703h;

    /* renamed from: i */
    public EnumC0425w f6704i;

    public Q(int i10, r rVar) {
        this.f6698a = i10;
        this.f6699b = rVar;
        EnumC0425w enumC0425w = EnumC0425w.f7006e;
        this.f6703h = enumC0425w;
        this.f6704i = enumC0425w;
    }

    public Q(int i10, r rVar, int i11) {
        this.f6698a = i10;
        this.f6699b = rVar;
        EnumC0425w enumC0425w = EnumC0425w.f7006e;
        this.f6703h = enumC0425w;
        this.f6704i = enumC0425w;
    }
}
