package androidx.fragment.app;

import R.InterfaceC0255n;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import androidx.activity.InterfaceC0355c;
import androidx.lifecycle.EnumC0425w;
import androidx.lifecycle.r0;
import com.tajir.tajir.R;
import j0.AbstractC1047c;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import r8.InterfaceC1379a;
import s2.AbstractC1397b;
import s8.AbstractC1420h;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public final class I {

    /* renamed from: A */
    public X0.m f6629A;

    /* renamed from: B */
    public X0.m f6630B;

    /* renamed from: C */
    public X0.m f6631C;

    /* renamed from: D */
    public ArrayDeque f6632D;

    /* renamed from: E */
    public boolean f6633E;

    /* renamed from: F */
    public boolean f6634F;

    /* renamed from: G */
    public boolean f6635G;

    /* renamed from: H */
    public boolean f6636H;

    /* renamed from: I */
    public boolean f6637I;

    /* renamed from: J */
    public ArrayList f6638J;
    public ArrayList K;

    /* renamed from: L */
    public ArrayList f6639L;

    /* renamed from: M */
    public L f6640M;

    /* renamed from: N */
    public final D6.G f6641N;

    /* renamed from: b */
    public boolean f6643b;
    public ArrayList d;

    /* renamed from: e */
    public ArrayList f6645e;
    public androidx.activity.z g;

    /* renamed from: l */
    public ArrayList f6651l;

    /* renamed from: m */
    public final X0.c f6652m;

    /* renamed from: n */
    public final CopyOnWriteArrayList f6653n;

    /* renamed from: o */
    public final z f6654o;

    /* renamed from: p */
    public final z f6655p;

    /* renamed from: q */
    public final z f6656q;

    /* renamed from: r */
    public final z f6657r;

    /* renamed from: s */
    public final A f6658s;

    /* renamed from: t */
    public int f6659t;

    /* renamed from: u */
    public C0399t f6660u;

    /* renamed from: v */
    public AbstractC0402w f6661v;

    /* renamed from: w */
    public r f6662w;

    /* renamed from: x */
    public r f6663x;

    /* renamed from: y */
    public final B f6664y;

    /* renamed from: z */
    public final K3.E f6665z;

    /* renamed from: a */
    public final ArrayList f6642a = new ArrayList();

    /* renamed from: c */
    public final X0.i f6644c = new X0.i(9);

    /* renamed from: f */
    public final y f6646f = new y(this);

    /* renamed from: h */
    public final U6.g f6647h = new U6.g(this, 3);

    /* renamed from: i */
    public final AtomicInteger f6648i = new AtomicInteger();

    /* renamed from: j */
    public final Map f6649j = Collections.synchronizedMap(new HashMap());

    /* renamed from: k */
    public final Map f6650k = Collections.synchronizedMap(new HashMap());

    /* JADX WARN: Type inference failed for: r0v12, types: [androidx.fragment.app.z] */
    /* JADX WARN: Type inference failed for: r0v13, types: [androidx.fragment.app.z] */
    /* JADX WARN: Type inference failed for: r0v14, types: [androidx.fragment.app.z] */
    /* JADX WARN: Type inference failed for: r0v15, types: [androidx.fragment.app.z] */
    public I() {
        Collections.synchronizedMap(new HashMap());
        this.f6652m = new X0.c(this);
        this.f6653n = new CopyOnWriteArrayList();
        final int i10 = 0;
        this.f6654o = new Q.a(this) { // from class: androidx.fragment.app.z

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ I f6868b;

            {
                this.f6868b = this;
            }

            @Override // Q.a
            public final void d(Object obj) {
                switch (i10) {
                    case 0:
                        I i11 = this.f6868b;
                        if (i11.J()) {
                            i11.h(false);
                            break;
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        I i12 = this.f6868b;
                        if (i12.J() && num.intValue() == 80) {
                            i12.l(false);
                            break;
                        }
                        break;
                    case 2:
                        D.l lVar = (D.l) obj;
                        I i13 = this.f6868b;
                        if (i13.J()) {
                            i13.m(lVar.f398a, false);
                            break;
                        }
                        break;
                    default:
                        D.A a6 = (D.A) obj;
                        I i14 = this.f6868b;
                        if (i14.J()) {
                            i14.r(a6.f382a, false);
                            break;
                        }
                        break;
                }
            }
        };
        final int i11 = 1;
        this.f6655p = new Q.a(this) { // from class: androidx.fragment.app.z

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ I f6868b;

            {
                this.f6868b = this;
            }

            @Override // Q.a
            public final void d(Object obj) {
                switch (i11) {
                    case 0:
                        I i112 = this.f6868b;
                        if (i112.J()) {
                            i112.h(false);
                            break;
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        I i12 = this.f6868b;
                        if (i12.J() && num.intValue() == 80) {
                            i12.l(false);
                            break;
                        }
                        break;
                    case 2:
                        D.l lVar = (D.l) obj;
                        I i13 = this.f6868b;
                        if (i13.J()) {
                            i13.m(lVar.f398a, false);
                            break;
                        }
                        break;
                    default:
                        D.A a6 = (D.A) obj;
                        I i14 = this.f6868b;
                        if (i14.J()) {
                            i14.r(a6.f382a, false);
                            break;
                        }
                        break;
                }
            }
        };
        final int i12 = 2;
        this.f6656q = new Q.a(this) { // from class: androidx.fragment.app.z

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ I f6868b;

            {
                this.f6868b = this;
            }

            @Override // Q.a
            public final void d(Object obj) {
                switch (i12) {
                    case 0:
                        I i112 = this.f6868b;
                        if (i112.J()) {
                            i112.h(false);
                            break;
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        I i122 = this.f6868b;
                        if (i122.J() && num.intValue() == 80) {
                            i122.l(false);
                            break;
                        }
                        break;
                    case 2:
                        D.l lVar = (D.l) obj;
                        I i13 = this.f6868b;
                        if (i13.J()) {
                            i13.m(lVar.f398a, false);
                            break;
                        }
                        break;
                    default:
                        D.A a6 = (D.A) obj;
                        I i14 = this.f6868b;
                        if (i14.J()) {
                            i14.r(a6.f382a, false);
                            break;
                        }
                        break;
                }
            }
        };
        final int i13 = 3;
        this.f6657r = new Q.a(this) { // from class: androidx.fragment.app.z

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ I f6868b;

            {
                this.f6868b = this;
            }

            @Override // Q.a
            public final void d(Object obj) {
                switch (i13) {
                    case 0:
                        I i112 = this.f6868b;
                        if (i112.J()) {
                            i112.h(false);
                            break;
                        }
                        break;
                    case 1:
                        Integer num = (Integer) obj;
                        I i122 = this.f6868b;
                        if (i122.J() && num.intValue() == 80) {
                            i122.l(false);
                            break;
                        }
                        break;
                    case 2:
                        D.l lVar = (D.l) obj;
                        I i132 = this.f6868b;
                        if (i132.J()) {
                            i132.m(lVar.f398a, false);
                            break;
                        }
                        break;
                    default:
                        D.A a6 = (D.A) obj;
                        I i14 = this.f6868b;
                        if (i14.J()) {
                            i14.r(a6.f382a, false);
                            break;
                        }
                        break;
                }
            }
        };
        this.f6658s = new A(this);
        this.f6659t = -1;
        this.f6664y = new B(this);
        this.f6665z = new K3.E(29);
        this.f6632D = new ArrayDeque();
        this.f6641N = new D6.G(this, 16);
    }

    public static boolean I(r rVar) {
        rVar.getClass();
        Iterator it = rVar.f6804B.f6644c.o().iterator();
        boolean zI = false;
        while (it.hasNext()) {
            r rVar2 = (r) it.next();
            if (rVar2 != null) {
                zI = I(rVar2);
            }
            if (zI) {
                return true;
            }
        }
        return false;
    }

    public static boolean K(r rVar) {
        if (rVar == null) {
            return true;
        }
        return rVar.f6812J && (rVar.f6847z == null || K(rVar.f6805C));
    }

    public static boolean L(r rVar) {
        if (rVar == null) {
            return true;
        }
        I i10 = rVar.f6847z;
        return rVar.equals(i10.f6663x) && L(i10.f6662w);
    }

    public static void b0(r rVar) {
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "show: " + rVar);
        }
        if (rVar.f6809G) {
            rVar.f6809G = false;
            rVar.f6818Q = !rVar.f6818Q;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:436:0x0164  */
    /* JADX WARN: Removed duplicated region for block: B:486:0x022e A[PHI: r14
  0x022e: PHI (r14v26 int) = (r14v25 int), (r14v27 int) binds: [B:479:0x021e, B:484:0x022a] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:611:0x0553  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void A(java.util.ArrayList r24, java.util.ArrayList r25, int r26, int r27) {
        /*
            Method dump skipped, instructions count: 1658
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.I.A(java.util.ArrayList, java.util.ArrayList, int, int):void");
    }

    public final int B(String str, int i10, boolean z3) {
        ArrayList arrayList = this.d;
        if (arrayList == null || arrayList.isEmpty()) {
            return -1;
        }
        if (str == null && i10 < 0) {
            if (z3) {
                return 0;
            }
            return this.d.size() - 1;
        }
        int size = this.d.size() - 1;
        while (size >= 0) {
            C0381a c0381a = (C0381a) this.d.get(size);
            if ((str != null && str.equals(c0381a.f6728i)) || (i10 >= 0 && i10 == c0381a.f6738s)) {
                break;
            }
            size--;
        }
        if (size < 0) {
            return size;
        }
        if (!z3) {
            if (size == this.d.size() - 1) {
                return -1;
            }
            return size + 1;
        }
        while (size > 0) {
            C0381a c0381a2 = (C0381a) this.d.get(size - 1);
            if ((str == null || !str.equals(c0381a2.f6728i)) && (i10 < 0 || i10 != c0381a2.f6738s)) {
                return size;
            }
            size--;
        }
        return size;
    }

    public final r C(int i10) {
        X0.i iVar = this.f6644c;
        ArrayList arrayList = (ArrayList) iVar.f5315b;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            r rVar = (r) arrayList.get(size);
            if (rVar != null && rVar.f6806D == i10) {
                return rVar;
            }
        }
        for (P p9 : ((HashMap) iVar.f5316c).values()) {
            if (p9 != null) {
                r rVar2 = p9.f6696c;
                if (rVar2.f6806D == i10) {
                    return rVar2;
                }
            }
        }
        return null;
    }

    public final r D(String str) {
        X0.i iVar = this.f6644c;
        if (str != null) {
            ArrayList arrayList = (ArrayList) iVar.f5315b;
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                r rVar = (r) arrayList.get(size);
                if (rVar != null && str.equals(rVar.f6808F)) {
                    return rVar;
                }
            }
        }
        if (str != null) {
            for (P p9 : ((HashMap) iVar.f5316c).values()) {
                if (p9 != null) {
                    r rVar2 = p9.f6696c;
                    if (str.equals(rVar2.f6808F)) {
                        return rVar2;
                    }
                }
            }
        } else {
            iVar.getClass();
        }
        return null;
    }

    public final ViewGroup E(r rVar) {
        ViewGroup viewGroup = rVar.f6813L;
        if (viewGroup != null) {
            return viewGroup;
        }
        if (rVar.f6807E > 0 && this.f6661v.d()) {
            View viewC = this.f6661v.c(rVar.f6807E);
            if (viewC instanceof ViewGroup) {
                return (ViewGroup) viewC;
            }
        }
        return null;
    }

    public final B F() {
        r rVar = this.f6662w;
        return rVar != null ? rVar.f6847z.F() : this.f6664y;
    }

    public final K3.E G() {
        r rVar = this.f6662w;
        return rVar != null ? rVar.f6847z.G() : this.f6665z;
    }

    public final void H(r rVar) {
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "hide: " + rVar);
        }
        if (rVar.f6809G) {
            return;
        }
        rVar.f6809G = true;
        rVar.f6818Q = true ^ rVar.f6818Q;
        a0(rVar);
    }

    public final boolean J() {
        r rVar = this.f6662w;
        if (rVar == null) {
            return true;
        }
        return rVar.x() && this.f6662w.q().J();
    }

    public final boolean M() {
        return this.f6634F || this.f6635G;
    }

    public final void N(int i10, boolean z3) {
        HashMap map;
        C0399t c0399t;
        if (this.f6660u == null && i10 != -1) {
            throw new IllegalStateException("No activity");
        }
        if (z3 || i10 != this.f6659t) {
            this.f6659t = i10;
            X0.i iVar = this.f6644c;
            Iterator it = ((ArrayList) iVar.f5315b).iterator();
            while (true) {
                boolean zHasNext = it.hasNext();
                map = (HashMap) iVar.f5316c;
                if (!zHasNext) {
                    break;
                }
                P p9 = (P) map.get(((r) it.next()).f6833e);
                if (p9 != null) {
                    p9.k();
                }
            }
            for (P p10 : map.values()) {
                if (p10 != null) {
                    p10.k();
                    r rVar = p10.f6696c;
                    if (rVar.f6840s && !rVar.z()) {
                        if (rVar.f6841t && !((HashMap) iVar.d).containsKey(rVar.f6833e)) {
                            iVar.w(p10.o(), rVar.f6833e);
                        }
                        iVar.t(p10);
                    }
                }
            }
            c0();
            if (this.f6633E && (c0399t = this.f6660u) != null && this.f6659t == 7) {
                c0399t.f6854e.invalidateOptionsMenu();
                this.f6633E = false;
            }
        }
    }

    public final void O() {
        if (this.f6660u == null) {
            return;
        }
        this.f6634F = false;
        this.f6635G = false;
        this.f6640M.f6678f = false;
        for (r rVar : this.f6644c.p()) {
            if (rVar != null) {
                rVar.f6804B.O();
            }
        }
    }

    public final boolean P() {
        return Q(-1, 0);
    }

    public final boolean Q(int i10, int i11) {
        y(false);
        x(true);
        r rVar = this.f6663x;
        if (rVar != null && i10 < 0 && rVar.m().Q(-1, 0)) {
            return true;
        }
        boolean zR = R(this.f6638J, this.K, null, i10, i11);
        if (zR) {
            this.f6643b = true;
            try {
                T(this.f6638J, this.K);
            } finally {
                d();
            }
        }
        e0();
        u();
        ((HashMap) this.f6644c.f5316c).values().removeAll(Collections.singleton(null));
        return zR;
    }

    public final boolean R(ArrayList arrayList, ArrayList arrayList2, String str, int i10, int i11) {
        int iB = B(str, i10, (i11 & 1) != 0);
        if (iB < 0) {
            return false;
        }
        for (int size = this.d.size() - 1; size >= iB; size--) {
            arrayList.add((C0381a) this.d.remove(size));
            arrayList2.add(Boolean.TRUE);
        }
        return true;
    }

    public final void S(r rVar) {
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "remove: " + rVar + " nesting=" + rVar.f6846y);
        }
        boolean z3 = !rVar.z();
        if (!rVar.f6810H || z3) {
            X0.i iVar = this.f6644c;
            synchronized (((ArrayList) iVar.f5315b)) {
                ((ArrayList) iVar.f5315b).remove(rVar);
            }
            rVar.f6839r = false;
            if (I(rVar)) {
                this.f6633E = true;
            }
            rVar.f6840s = true;
            a0(rVar);
        }
    }

    public final void T(ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList.isEmpty()) {
            return;
        }
        if (arrayList.size() != arrayList2.size()) {
            throw new IllegalStateException("Internal error with the back stack records");
        }
        int size = arrayList.size();
        int i10 = 0;
        int i11 = 0;
        while (i10 < size) {
            if (!((C0381a) arrayList.get(i10)).f6735p) {
                if (i11 != i10) {
                    A(arrayList, arrayList2, i11, i10);
                }
                i11 = i10 + 1;
                if (((Boolean) arrayList2.get(i10)).booleanValue()) {
                    while (i11 < size && ((Boolean) arrayList2.get(i11)).booleanValue() && !((C0381a) arrayList.get(i11)).f6735p) {
                        i11++;
                    }
                }
                A(arrayList, arrayList2, i10, i11);
                i10 = i11 - 1;
            }
            i10++;
        }
        if (i11 != size) {
            A(arrayList, arrayList2, i11, size);
        }
    }

    public final void U(Bundle bundle) {
        X0.c cVar;
        P p9;
        Bundle bundle2;
        Bundle bundle3;
        for (String str : bundle.keySet()) {
            if (str.startsWith("result_") && (bundle3 = bundle.getBundle(str)) != null) {
                bundle3.setClassLoader(this.f6660u.f6852b.getClassLoader());
                this.f6650k.put(str.substring(7), bundle3);
            }
        }
        HashMap map = new HashMap();
        for (String str2 : bundle.keySet()) {
            if (str2.startsWith("fragment_") && (bundle2 = bundle.getBundle(str2)) != null) {
                bundle2.setClassLoader(this.f6660u.f6852b.getClassLoader());
                map.put(str2.substring(9), bundle2);
            }
        }
        X0.i iVar = this.f6644c;
        HashMap map2 = (HashMap) iVar.d;
        map2.clear();
        map2.putAll(map);
        J j10 = (J) bundle.getParcelable("state");
        if (j10 == null) {
            return;
        }
        HashMap map3 = (HashMap) iVar.f5316c;
        map3.clear();
        Iterator it = j10.f6666a.iterator();
        while (true) {
            boolean zHasNext = it.hasNext();
            cVar = this.f6652m;
            if (!zHasNext) {
                break;
            }
            Bundle bundleW = iVar.w(null, (String) it.next());
            if (bundleW != null) {
                r rVar = (r) this.f6640M.f6674a.get(((N) bundleW.getParcelable("state")).f6680b);
                if (rVar != null) {
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "restoreSaveState: re-attaching retained " + rVar);
                    }
                    p9 = new P(cVar, iVar, rVar, bundleW);
                } else {
                    p9 = new P(this.f6652m, this.f6644c, this.f6660u.f6852b.getClassLoader(), F(), bundleW);
                }
                r rVar2 = p9.f6696c;
                rVar2.f6830b = bundleW;
                rVar2.f6847z = this;
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "restoreSaveState: active (" + rVar2.f6833e + "): " + rVar2);
                }
                p9.m(this.f6660u.f6852b.getClassLoader());
                iVar.s(p9);
                p9.f6697e = this.f6659t;
            }
        }
        L l5 = this.f6640M;
        l5.getClass();
        Iterator it2 = new ArrayList(l5.f6674a.values()).iterator();
        while (it2.hasNext()) {
            r rVar3 = (r) it2.next();
            if (map3.get(rVar3.f6833e) == null) {
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "Discarding retained Fragment " + rVar3 + " that was not found in the set of active Fragments " + j10.f6666a);
                }
                this.f6640M.d(rVar3);
                rVar3.f6847z = this;
                P p10 = new P(cVar, iVar, rVar3);
                p10.f6697e = 1;
                p10.k();
                rVar3.f6840s = true;
                p10.k();
            }
        }
        ArrayList<String> arrayList = j10.f6667b;
        ((ArrayList) iVar.f5315b).clear();
        if (arrayList != null) {
            for (String str3 : arrayList) {
                r rVarJ = iVar.j(str3);
                if (rVarJ == null) {
                    throw new IllegalStateException(AbstractC1480a.k("No instantiated fragment for (", str3, ")"));
                }
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "restoreSaveState: added (" + str3 + "): " + rVarJ);
                }
                iVar.d(rVarJ);
            }
        }
        if (j10.f6668c != null) {
            this.d = new ArrayList(j10.f6668c.length);
            int i10 = 0;
            while (true) {
                C0382b[] c0382bArr = j10.f6668c;
                if (i10 >= c0382bArr.length) {
                    break;
                }
                C0382b c0382b = c0382bArr[i10];
                c0382b.getClass();
                C0381a c0381a = new C0381a(this);
                c0382b.a(c0381a);
                c0381a.f6738s = c0382b.f6745n;
                int i11 = 0;
                while (true) {
                    ArrayList arrayList2 = c0382b.f6741b;
                    if (i11 >= arrayList2.size()) {
                        break;
                    }
                    String str4 = (String) arrayList2.get(i11);
                    if (str4 != null) {
                        ((Q) c0381a.f6722a.get(i11)).f6699b = iVar.j(str4);
                    }
                    i11++;
                }
                c0381a.d(1);
                if (Log.isLoggable("FragmentManager", 2)) {
                    StringBuilder sbP = android.support.v4.media.session.a.p("restoreAllState: back stack #", i10, " (index ");
                    sbP.append(c0381a.f6738s);
                    sbP.append("): ");
                    sbP.append(c0381a);
                    Log.v("FragmentManager", sbP.toString());
                    PrintWriter printWriter = new PrintWriter(new T());
                    c0381a.g("  ", printWriter, false);
                    printWriter.close();
                }
                this.d.add(c0381a);
                i10++;
            }
        } else {
            this.d = null;
        }
        this.f6648i.set(j10.d);
        String str5 = j10.f6669e;
        if (str5 != null) {
            r rVarJ2 = iVar.j(str5);
            this.f6663x = rVarJ2;
            q(rVarJ2);
        }
        ArrayList arrayList3 = j10.f6670f;
        if (arrayList3 != null) {
            for (int i12 = 0; i12 < arrayList3.size(); i12++) {
                this.f6649j.put((String) arrayList3.get(i12), (C0383c) j10.f6671n.get(i12));
            }
        }
        this.f6632D = new ArrayDeque(j10.f6672o);
    }

    public final Bundle V() {
        int i10;
        ArrayList arrayList;
        C0382b[] c0382bArr;
        int size;
        Bundle bundle = new Bundle();
        Iterator it = e().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            C0389i c0389i = (C0389i) it.next();
            if (c0389i.f6770e) {
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "SpecialEffectsController: Forcing postponed operations");
                }
                c0389i.f6770e = false;
                c0389i.g();
            }
        }
        Iterator it2 = e().iterator();
        while (it2.hasNext()) {
            ((C0389i) it2.next()).i();
        }
        y(true);
        this.f6634F = true;
        this.f6640M.f6678f = true;
        X0.i iVar = this.f6644c;
        iVar.getClass();
        HashMap map = (HashMap) iVar.f5316c;
        ArrayList arrayList2 = new ArrayList(map.size());
        for (P p9 : map.values()) {
            if (p9 != null) {
                r rVar = p9.f6696c;
                iVar.w(p9.o(), rVar.f6833e);
                arrayList2.add(rVar.f6833e);
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "Saved state of " + rVar + ": " + rVar.f6830b);
                }
            }
        }
        HashMap map2 = (HashMap) this.f6644c.d;
        if (!map2.isEmpty()) {
            X0.i iVar2 = this.f6644c;
            synchronized (((ArrayList) iVar2.f5315b)) {
                try {
                    if (((ArrayList) iVar2.f5315b).isEmpty()) {
                        arrayList = null;
                    } else {
                        arrayList = new ArrayList(((ArrayList) iVar2.f5315b).size());
                        Iterator it3 = ((ArrayList) iVar2.f5315b).iterator();
                        while (it3.hasNext()) {
                            r rVar2 = (r) it3.next();
                            arrayList.add(rVar2.f6833e);
                            if (Log.isLoggable("FragmentManager", 2)) {
                                Log.v("FragmentManager", "saveAllState: adding fragment (" + rVar2.f6833e + "): " + rVar2);
                            }
                        }
                    }
                } finally {
                }
            }
            ArrayList arrayList3 = this.d;
            if (arrayList3 == null || (size = arrayList3.size()) <= 0) {
                c0382bArr = null;
            } else {
                c0382bArr = new C0382b[size];
                for (i10 = 0; i10 < size; i10++) {
                    c0382bArr[i10] = new C0382b((C0381a) this.d.get(i10));
                    if (Log.isLoggable("FragmentManager", 2)) {
                        StringBuilder sbP = android.support.v4.media.session.a.p("saveAllState: adding back stack #", i10, ": ");
                        sbP.append(this.d.get(i10));
                        Log.v("FragmentManager", sbP.toString());
                    }
                }
            }
            J j10 = new J();
            j10.f6669e = null;
            ArrayList arrayList4 = new ArrayList();
            j10.f6670f = arrayList4;
            ArrayList arrayList5 = new ArrayList();
            j10.f6671n = arrayList5;
            j10.f6666a = arrayList2;
            j10.f6667b = arrayList;
            j10.f6668c = c0382bArr;
            j10.d = this.f6648i.get();
            r rVar3 = this.f6663x;
            if (rVar3 != null) {
                j10.f6669e = rVar3.f6833e;
            }
            arrayList4.addAll(this.f6649j.keySet());
            arrayList5.addAll(this.f6649j.values());
            j10.f6672o = new ArrayList(this.f6632D);
            bundle.putParcelable("state", j10);
            for (String str : this.f6650k.keySet()) {
                bundle.putBundle(AbstractC1397b.b("result_", str), (Bundle) this.f6650k.get(str));
            }
            for (String str2 : map2.keySet()) {
                bundle.putBundle(AbstractC1397b.b("fragment_", str2), (Bundle) map2.get(str2));
            }
        } else if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "saveAllState: no fragments!");
        }
        return bundle;
    }

    public final void W() {
        synchronized (this.f6642a) {
            try {
                if (this.f6642a.size() == 1) {
                    this.f6660u.f6853c.removeCallbacks(this.f6641N);
                    this.f6660u.f6853c.post(this.f6641N);
                    e0();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void X(r rVar, boolean z3) {
        ViewGroup viewGroupE = E(rVar);
        if (viewGroupE == null || !(viewGroupE instanceof FragmentContainerView)) {
            return;
        }
        ((FragmentContainerView) viewGroupE).setDrawDisappearingViewsLast(!z3);
    }

    public final void Y(r rVar, EnumC0425w enumC0425w) {
        if (rVar.equals(this.f6644c.j(rVar.f6833e)) && (rVar.f6803A == null || rVar.f6847z == this)) {
            rVar.f6822U = enumC0425w;
            return;
        }
        throw new IllegalArgumentException("Fragment " + rVar + " is not an active fragment of FragmentManager " + this);
    }

    public final void Z(r rVar) {
        if (rVar != null) {
            if (!rVar.equals(this.f6644c.j(rVar.f6833e)) || (rVar.f6803A != null && rVar.f6847z != this)) {
                throw new IllegalArgumentException("Fragment " + rVar + " is not an active fragment of FragmentManager " + this);
            }
        }
        r rVar2 = this.f6663x;
        this.f6663x = rVar;
        q(rVar2);
        q(this.f6663x);
    }

    public final P a(r rVar) {
        String str = rVar.f6821T;
        if (str != null) {
            AbstractC1047c.c(rVar, str);
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "add: " + rVar);
        }
        P pF = f(rVar);
        rVar.f6847z = this;
        X0.i iVar = this.f6644c;
        iVar.s(pF);
        if (!rVar.f6810H) {
            iVar.d(rVar);
            rVar.f6840s = false;
            if (rVar.f6814M == null) {
                rVar.f6818Q = false;
            }
            if (I(rVar)) {
                this.f6633E = true;
            }
        }
        return pF;
    }

    public final void a0(r rVar) {
        ViewGroup viewGroupE = E(rVar);
        if (viewGroupE != null) {
            C0397q c0397q = rVar.f6817P;
            if ((c0397q == null ? 0 : c0397q.f6797e) + (c0397q == null ? 0 : c0397q.d) + (c0397q == null ? 0 : c0397q.f6796c) + (c0397q == null ? 0 : c0397q.f6795b) > 0) {
                if (viewGroupE.getTag(R.id.visible_removing_fragment_view_tag) == null) {
                    viewGroupE.setTag(R.id.visible_removing_fragment_view_tag, rVar);
                }
                r rVar2 = (r) viewGroupE.getTag(R.id.visible_removing_fragment_view_tag);
                C0397q c0397q2 = rVar.f6817P;
                boolean z3 = c0397q2 != null ? c0397q2.f6794a : false;
                if (rVar2.f6817P == null) {
                    return;
                }
                rVar2.k().f6794a = z3;
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void b(C0399t c0399t, AbstractC0402w abstractC0402w, r rVar) {
        if (this.f6660u != null) {
            throw new IllegalStateException("Already attached");
        }
        this.f6660u = c0399t;
        this.f6661v = abstractC0402w;
        this.f6662w = rVar;
        CopyOnWriteArrayList copyOnWriteArrayList = this.f6653n;
        if (rVar != 0) {
            copyOnWriteArrayList.add(new C(rVar));
        } else if (c0399t instanceof M) {
            copyOnWriteArrayList.add(c0399t);
        }
        if (this.f6662w != null) {
            e0();
        }
        if (c0399t instanceof androidx.activity.A) {
            androidx.activity.z zVarN = c0399t.f6854e.n();
            this.g = zVarN;
            zVarN.a(rVar != 0 ? rVar : c0399t, this.f6647h);
        }
        if (rVar != 0) {
            L l5 = rVar.f6847z.f6640M;
            HashMap map = l5.f6675b;
            L l9 = (L) map.get(rVar.f6833e);
            if (l9 == null) {
                l9 = new L(l5.d);
                map.put(rVar.f6833e, l9);
            }
            this.f6640M = l9;
        } else if (c0399t instanceof r0) {
            this.f6640M = (L) new X0.m(c0399t.f6854e.f(), L.g).v(L.class);
        } else {
            this.f6640M = new L(false);
        }
        this.f6640M.f6678f = M();
        this.f6644c.f5317e = this.f6640M;
        C0399t c0399t2 = this.f6660u;
        if ((c0399t2 instanceof C0.f) && rVar == 0) {
            C0.e eVarB = c0399t2.b();
            eVarB.c("android:support:fragments", new androidx.activity.d(this, 2));
            Bundle bundleA = eVarB.a("android:support:fragments");
            if (bundleA != null) {
                U(bundleA);
            }
        }
        C0399t c0399t3 = this.f6660u;
        if (c0399t3 instanceof androidx.activity.result.d) {
            androidx.activity.f fVar = c0399t3.f6854e.f6024r;
            String strB = AbstractC1397b.b("FragmentManager:", rVar != 0 ? AbstractC1397b.e(new StringBuilder(), rVar.f6833e, ":") : "");
            this.f6629A = fVar.c(android.support.v4.media.session.a.l(strB, "StartActivityForResult"), new D(2), new p3.i(this, 18));
            this.f6630B = fVar.c(android.support.v4.media.session.a.l(strB, "StartIntentSenderForResult"), new D(0), new G5.c(this));
            this.f6631C = fVar.c(android.support.v4.media.session.a.l(strB, "RequestPermissions"), new D(1), new l1.c(this, 21));
        }
        C0399t c0399t4 = this.f6660u;
        if (c0399t4 instanceof E.m) {
            c0399t4.g(this.f6654o);
        }
        C0399t c0399t5 = this.f6660u;
        if (c0399t5 instanceof E.n) {
            c0399t5.k(this.f6655p);
        }
        C0399t c0399t6 = this.f6660u;
        if (c0399t6 instanceof D.y) {
            c0399t6.i(this.f6656q);
        }
        C0399t c0399t7 = this.f6660u;
        if (c0399t7 instanceof D.z) {
            c0399t7.j(this.f6657r);
        }
        C0399t c0399t8 = this.f6660u;
        if ((c0399t8 instanceof InterfaceC0255n) && rVar == 0) {
            c0399t8.e(this.f6658s);
        }
    }

    public final void c(r rVar) {
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "attach: " + rVar);
        }
        if (rVar.f6810H) {
            rVar.f6810H = false;
            if (rVar.f6839r) {
                return;
            }
            this.f6644c.d(rVar);
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "add from attach: " + rVar);
            }
            if (I(rVar)) {
                this.f6633E = true;
            }
        }
    }

    public final void c0() {
        Iterator it = this.f6644c.n().iterator();
        while (it.hasNext()) {
            P p9 = (P) it.next();
            r rVar = p9.f6696c;
            if (rVar.f6815N) {
                if (this.f6643b) {
                    this.f6637I = true;
                } else {
                    rVar.f6815N = false;
                    p9.k();
                }
            }
        }
    }

    public final void d() {
        this.f6643b = false;
        this.K.clear();
        this.f6638J.clear();
    }

    public final void d0(RuntimeException runtimeException) {
        Log.e("FragmentManager", runtimeException.getMessage());
        Log.e("FragmentManager", "Activity state:");
        PrintWriter printWriter = new PrintWriter(new T());
        C0399t c0399t = this.f6660u;
        if (c0399t == null) {
            try {
                v("  ", null, printWriter, new String[0]);
                throw runtimeException;
            } catch (Exception e4) {
                Log.e("FragmentManager", "Failed dumping state", e4);
                throw runtimeException;
            }
        }
        try {
            c0399t.f6854e.dump("  ", null, printWriter, new String[0]);
            throw runtimeException;
        } catch (Exception e5) {
            Log.e("FragmentManager", "Failed dumping state", e5);
            throw runtimeException;
        }
    }

    public final HashSet e() {
        C0389i c0389i;
        HashSet hashSet = new HashSet();
        Iterator it = this.f6644c.n().iterator();
        while (it.hasNext()) {
            ViewGroup viewGroup = ((P) it.next()).f6696c.f6813L;
            if (viewGroup != null) {
                AbstractC1420h.f(G(), "factory");
                Object tag = viewGroup.getTag(R.id.special_effects_controller_view_tag);
                if (tag instanceof C0389i) {
                    c0389i = (C0389i) tag;
                } else {
                    c0389i = new C0389i(viewGroup);
                    viewGroup.setTag(R.id.special_effects_controller_view_tag, c0389i);
                }
                hashSet.add(c0389i);
            }
        }
        return hashSet;
    }

    public final void e0() {
        synchronized (this.f6642a) {
            try {
                if (!this.f6642a.isEmpty()) {
                    U6.g gVar = this.f6647h;
                    gVar.f6037a = true;
                    InterfaceC1379a interfaceC1379a = gVar.f6039c;
                    if (interfaceC1379a != null) {
                        interfaceC1379a.invoke();
                    }
                    return;
                }
                U6.g gVar2 = this.f6647h;
                ArrayList arrayList = this.d;
                gVar2.f6037a = (arrayList != null ? arrayList.size() : 0) > 0 && L(this.f6662w);
                InterfaceC1379a interfaceC1379a2 = gVar2.f6039c;
                if (interfaceC1379a2 != null) {
                    interfaceC1379a2.invoke();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final P f(r rVar) {
        String str = rVar.f6833e;
        X0.i iVar = this.f6644c;
        P p9 = (P) ((HashMap) iVar.f5316c).get(str);
        if (p9 != null) {
            return p9;
        }
        P p10 = new P(this.f6652m, iVar, rVar);
        p10.m(this.f6660u.f6852b.getClassLoader());
        p10.f6697e = this.f6659t;
        return p10;
    }

    public final void g(r rVar) {
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "detach: " + rVar);
        }
        if (rVar.f6810H) {
            return;
        }
        rVar.f6810H = true;
        if (rVar.f6839r) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "remove from detach: " + rVar);
            }
            X0.i iVar = this.f6644c;
            synchronized (((ArrayList) iVar.f5315b)) {
                ((ArrayList) iVar.f5315b).remove(rVar);
            }
            rVar.f6839r = false;
            if (I(rVar)) {
                this.f6633E = true;
            }
            a0(rVar);
        }
    }

    public final void h(boolean z3) {
        if (z3 && (this.f6660u instanceof E.m)) {
            d0(new IllegalStateException("Do not call dispatchConfigurationChanged() on host. Host implements OnConfigurationChangedProvider and automatically dispatches configuration changes to fragments."));
            throw null;
        }
        for (r rVar : this.f6644c.p()) {
            if (rVar != null) {
                rVar.K = true;
                if (z3) {
                    rVar.f6804B.h(true);
                }
            }
        }
    }

    public final boolean i() {
        if (this.f6659t < 1) {
            return false;
        }
        for (r rVar : this.f6644c.p()) {
            if (rVar != null) {
                if (!rVar.f6809G ? rVar.f6804B.i() : false) {
                    return true;
                }
            }
        }
        return false;
    }

    public final boolean j() {
        if (this.f6659t < 1) {
            return false;
        }
        ArrayList arrayList = null;
        boolean z3 = false;
        for (r rVar : this.f6644c.p()) {
            if (rVar != null && K(rVar)) {
                if (!rVar.f6809G ? rVar.f6804B.j() : false) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(rVar);
                    z3 = true;
                }
            }
        }
        if (this.f6645e != null) {
            for (int i10 = 0; i10 < this.f6645e.size(); i10++) {
                r rVar2 = (r) this.f6645e.get(i10);
                if (arrayList == null || !arrayList.contains(rVar2)) {
                    rVar2.getClass();
                }
            }
        }
        this.f6645e = arrayList;
        return z3;
    }

    public final void k() {
        Integer num;
        Integer num2;
        Integer num3;
        boolean zIsChangingConfigurations = true;
        this.f6636H = true;
        y(true);
        Iterator it = e().iterator();
        while (it.hasNext()) {
            ((C0389i) it.next()).i();
        }
        C0399t c0399t = this.f6660u;
        boolean z3 = c0399t instanceof r0;
        X0.i iVar = this.f6644c;
        if (z3) {
            zIsChangingConfigurations = ((L) iVar.f5317e).f6677e;
        } else {
            Context context = c0399t.f6852b;
            if (context instanceof Activity) {
                zIsChangingConfigurations = true ^ ((Activity) context).isChangingConfigurations();
            }
        }
        if (zIsChangingConfigurations) {
            Iterator it2 = this.f6649j.values().iterator();
            while (it2.hasNext()) {
                for (String str : ((C0383c) it2.next()).f6753a) {
                    L l5 = (L) iVar.f5317e;
                    l5.getClass();
                    if (Log.isLoggable("FragmentManager", 3)) {
                        Log.d("FragmentManager", "Clearing non-config state for saved state of Fragment " + str);
                    }
                    l5.c(str);
                }
            }
        }
        t(-1);
        C0399t c0399t2 = this.f6660u;
        if (c0399t2 instanceof E.n) {
            c0399t2.p(this.f6655p);
        }
        C0399t c0399t3 = this.f6660u;
        if (c0399t3 instanceof E.m) {
            c0399t3.m(this.f6654o);
        }
        C0399t c0399t4 = this.f6660u;
        if (c0399t4 instanceof D.y) {
            c0399t4.n(this.f6656q);
        }
        C0399t c0399t5 = this.f6660u;
        if (c0399t5 instanceof D.z) {
            c0399t5.o(this.f6657r);
        }
        C0399t c0399t6 = this.f6660u;
        if ((c0399t6 instanceof InterfaceC0255n) && this.f6662w == null) {
            c0399t6.l(this.f6658s);
        }
        this.f6660u = null;
        this.f6661v = null;
        this.f6662w = null;
        if (this.g != null) {
            Iterator it3 = this.f6647h.f6038b.iterator();
            while (it3.hasNext()) {
                ((InterfaceC0355c) it3.next()).cancel();
            }
            this.g = null;
        }
        X0.m mVar = this.f6629A;
        if (mVar != null) {
            androidx.activity.f fVar = (androidx.activity.f) mVar.d;
            ArrayList arrayList = fVar.d;
            String str2 = (String) mVar.f5323b;
            if (!arrayList.contains(str2) && (num3 = (Integer) fVar.f6007b.remove(str2)) != null) {
                fVar.f6006a.remove(num3);
            }
            fVar.f6009e.remove(str2);
            HashMap map = fVar.f6010f;
            if (map.containsKey(str2)) {
                StringBuilder sbQ = android.support.v4.media.session.a.q("Dropping pending result for request ", str2, ": ");
                sbQ.append(map.get(str2));
                Log.w("ActivityResultRegistry", sbQ.toString());
                map.remove(str2);
            }
            Bundle bundle = fVar.g;
            if (bundle.containsKey(str2)) {
                StringBuilder sbQ2 = android.support.v4.media.session.a.q("Dropping pending result for request ", str2, ": ");
                sbQ2.append(bundle.getParcelable(str2));
                Log.w("ActivityResultRegistry", sbQ2.toString());
                bundle.remove(str2);
            }
            android.support.v4.media.session.a.u(fVar.f6008c.get(str2));
            X0.m mVar2 = this.f6630B;
            androidx.activity.f fVar2 = (androidx.activity.f) mVar2.d;
            ArrayList arrayList2 = fVar2.d;
            String str3 = (String) mVar2.f5323b;
            if (!arrayList2.contains(str3) && (num2 = (Integer) fVar2.f6007b.remove(str3)) != null) {
                fVar2.f6006a.remove(num2);
            }
            fVar2.f6009e.remove(str3);
            HashMap map2 = fVar2.f6010f;
            if (map2.containsKey(str3)) {
                StringBuilder sbQ3 = android.support.v4.media.session.a.q("Dropping pending result for request ", str3, ": ");
                sbQ3.append(map2.get(str3));
                Log.w("ActivityResultRegistry", sbQ3.toString());
                map2.remove(str3);
            }
            Bundle bundle2 = fVar2.g;
            if (bundle2.containsKey(str3)) {
                StringBuilder sbQ4 = android.support.v4.media.session.a.q("Dropping pending result for request ", str3, ": ");
                sbQ4.append(bundle2.getParcelable(str3));
                Log.w("ActivityResultRegistry", sbQ4.toString());
                bundle2.remove(str3);
            }
            android.support.v4.media.session.a.u(fVar2.f6008c.get(str3));
            X0.m mVar3 = this.f6631C;
            androidx.activity.f fVar3 = (androidx.activity.f) mVar3.d;
            ArrayList arrayList3 = fVar3.d;
            String str4 = (String) mVar3.f5323b;
            if (!arrayList3.contains(str4) && (num = (Integer) fVar3.f6007b.remove(str4)) != null) {
                fVar3.f6006a.remove(num);
            }
            fVar3.f6009e.remove(str4);
            HashMap map3 = fVar3.f6010f;
            if (map3.containsKey(str4)) {
                StringBuilder sbQ5 = android.support.v4.media.session.a.q("Dropping pending result for request ", str4, ": ");
                sbQ5.append(map3.get(str4));
                Log.w("ActivityResultRegistry", sbQ5.toString());
                map3.remove(str4);
            }
            Bundle bundle3 = fVar3.g;
            if (bundle3.containsKey(str4)) {
                StringBuilder sbQ6 = android.support.v4.media.session.a.q("Dropping pending result for request ", str4, ": ");
                sbQ6.append(bundle3.getParcelable(str4));
                Log.w("ActivityResultRegistry", sbQ6.toString());
                bundle3.remove(str4);
            }
            android.support.v4.media.session.a.u(fVar3.f6008c.get(str4));
        }
    }

    public final void l(boolean z3) {
        if (z3 && (this.f6660u instanceof E.n)) {
            d0(new IllegalStateException("Do not call dispatchLowMemory() on host. Host implements OnTrimMemoryProvider and automatically dispatches low memory callbacks to fragments."));
            throw null;
        }
        for (r rVar : this.f6644c.p()) {
            if (rVar != null) {
                rVar.K = true;
                if (z3) {
                    rVar.f6804B.l(true);
                }
            }
        }
    }

    public final void m(boolean z3, boolean z9) {
        if (z9 && (this.f6660u instanceof D.y)) {
            d0(new IllegalStateException("Do not call dispatchMultiWindowModeChanged() on host. Host implements OnMultiWindowModeChangedProvider and automatically dispatches multi-window mode changes to fragments."));
            throw null;
        }
        for (r rVar : this.f6644c.p()) {
            if (rVar != null && z9) {
                rVar.f6804B.m(z3, true);
            }
        }
    }

    public final void n() {
        Iterator it = this.f6644c.o().iterator();
        while (it.hasNext()) {
            r rVar = (r) it.next();
            if (rVar != null) {
                rVar.y();
                rVar.f6804B.n();
            }
        }
    }

    public final boolean o() {
        if (this.f6659t < 1) {
            return false;
        }
        for (r rVar : this.f6644c.p()) {
            if (rVar != null) {
                if (!rVar.f6809G ? rVar.f6804B.o() : false) {
                    return true;
                }
            }
        }
        return false;
    }

    public final void p() {
        if (this.f6659t < 1) {
            return;
        }
        for (r rVar : this.f6644c.p()) {
            if (rVar != null && !rVar.f6809G) {
                rVar.f6804B.p();
            }
        }
    }

    public final void q(r rVar) {
        if (rVar != null) {
            if (rVar.equals(this.f6644c.j(rVar.f6833e))) {
                rVar.f6847z.getClass();
                boolean zL = L(rVar);
                Boolean bool = rVar.f6838q;
                if (bool == null || bool.booleanValue() != zL) {
                    rVar.f6838q = Boolean.valueOf(zL);
                    I i10 = rVar.f6804B;
                    i10.e0();
                    i10.q(i10.f6663x);
                }
            }
        }
    }

    public final void r(boolean z3, boolean z9) {
        if (z9 && (this.f6660u instanceof D.z)) {
            d0(new IllegalStateException("Do not call dispatchPictureInPictureModeChanged() on host. Host implements OnPictureInPictureModeChangedProvider and automatically dispatches picture-in-picture mode changes to fragments."));
            throw null;
        }
        for (r rVar : this.f6644c.p()) {
            if (rVar != null && z9) {
                rVar.f6804B.r(z3, true);
            }
        }
    }

    public final boolean s() {
        if (this.f6659t < 1) {
            return false;
        }
        boolean z3 = false;
        for (r rVar : this.f6644c.p()) {
            if (rVar != null && K(rVar)) {
                if (!rVar.f6809G ? rVar.f6804B.s() : false) {
                    z3 = true;
                }
            }
        }
        return z3;
    }

    public final void t(int i10) {
        try {
            this.f6643b = true;
            for (P p9 : ((HashMap) this.f6644c.f5316c).values()) {
                if (p9 != null) {
                    p9.f6697e = i10;
                }
            }
            N(i10, false);
            Iterator it = e().iterator();
            while (it.hasNext()) {
                ((C0389i) it.next()).i();
            }
            this.f6643b = false;
            y(true);
        } catch (Throwable th) {
            this.f6643b = false;
            throw th;
        }
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        r rVar = this.f6662w;
        if (rVar != null) {
            sb.append(rVar.getClass().getSimpleName());
            sb.append("{");
            sb.append(Integer.toHexString(System.identityHashCode(this.f6662w)));
            sb.append("}");
        } else {
            C0399t c0399t = this.f6660u;
            if (c0399t != null) {
                sb.append(c0399t.getClass().getSimpleName());
                sb.append("{");
                sb.append(Integer.toHexString(System.identityHashCode(this.f6660u)));
                sb.append("}");
            } else {
                sb.append("null");
            }
        }
        sb.append("}}");
        return sb.toString();
    }

    public final void u() {
        if (this.f6637I) {
            this.f6637I = false;
            c0();
        }
    }

    public final void v(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        int size;
        int size2;
        String strL = android.support.v4.media.session.a.l(str, "    ");
        X0.i iVar = this.f6644c;
        iVar.getClass();
        String str2 = str + "    ";
        HashMap map = (HashMap) iVar.f5316c;
        if (!map.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Active Fragments:");
            for (P p9 : map.values()) {
                printWriter.print(str);
                if (p9 != null) {
                    r rVar = p9.f6696c;
                    printWriter.println(rVar);
                    rVar.j(str2, fileDescriptor, printWriter, strArr);
                } else {
                    printWriter.println("null");
                }
            }
        }
        ArrayList arrayList = (ArrayList) iVar.f5315b;
        int size3 = arrayList.size();
        if (size3 > 0) {
            printWriter.print(str);
            printWriter.println("Added Fragments:");
            for (int i10 = 0; i10 < size3; i10++) {
                r rVar2 = (r) arrayList.get(i10);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i10);
                printWriter.print(": ");
                printWriter.println(rVar2.toString());
            }
        }
        ArrayList arrayList2 = this.f6645e;
        if (arrayList2 != null && (size2 = arrayList2.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Fragments Created Menus:");
            for (int i11 = 0; i11 < size2; i11++) {
                r rVar3 = (r) this.f6645e.get(i11);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i11);
                printWriter.print(": ");
                printWriter.println(rVar3.toString());
            }
        }
        ArrayList arrayList3 = this.d;
        if (arrayList3 != null && (size = arrayList3.size()) > 0) {
            printWriter.print(str);
            printWriter.println("Back Stack:");
            for (int i12 = 0; i12 < size; i12++) {
                C0381a c0381a = (C0381a) this.d.get(i12);
                printWriter.print(str);
                printWriter.print("  #");
                printWriter.print(i12);
                printWriter.print(": ");
                printWriter.println(c0381a.toString());
                c0381a.g(strL, printWriter, true);
            }
        }
        printWriter.print(str);
        printWriter.println("Back Stack Index: " + this.f6648i.get());
        synchronized (this.f6642a) {
            try {
                int size4 = this.f6642a.size();
                if (size4 > 0) {
                    printWriter.print(str);
                    printWriter.println("Pending Actions:");
                    for (int i13 = 0; i13 < size4; i13++) {
                        Object obj = (F) this.f6642a.get(i13);
                        printWriter.print(str);
                        printWriter.print("  #");
                        printWriter.print(i13);
                        printWriter.print(": ");
                        printWriter.println(obj);
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        printWriter.print(str);
        printWriter.println("FragmentManager misc state:");
        printWriter.print(str);
        printWriter.print("  mHost=");
        printWriter.println(this.f6660u);
        printWriter.print(str);
        printWriter.print("  mContainer=");
        printWriter.println(this.f6661v);
        if (this.f6662w != null) {
            printWriter.print(str);
            printWriter.print("  mParent=");
            printWriter.println(this.f6662w);
        }
        printWriter.print(str);
        printWriter.print("  mCurState=");
        printWriter.print(this.f6659t);
        printWriter.print(" mStateSaved=");
        printWriter.print(this.f6634F);
        printWriter.print(" mStopped=");
        printWriter.print(this.f6635G);
        printWriter.print(" mDestroyed=");
        printWriter.println(this.f6636H);
        if (this.f6633E) {
            printWriter.print(str);
            printWriter.print("  mNeedMenuInvalidate=");
            printWriter.println(this.f6633E);
        }
    }

    public final void w(F f10, boolean z3) {
        if (!z3) {
            if (this.f6660u == null) {
                if (!this.f6636H) {
                    throw new IllegalStateException("FragmentManager has not been attached to a host.");
                }
                throw new IllegalStateException("FragmentManager has been destroyed");
            }
            if (M()) {
                throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
            }
        }
        synchronized (this.f6642a) {
            try {
                if (this.f6660u == null) {
                    if (!z3) {
                        throw new IllegalStateException("Activity has been destroyed");
                    }
                } else {
                    this.f6642a.add(f10);
                    W();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void x(boolean z3) {
        if (this.f6643b) {
            throw new IllegalStateException("FragmentManager is already executing transactions");
        }
        if (this.f6660u == null) {
            if (!this.f6636H) {
                throw new IllegalStateException("FragmentManager has not been attached to a host.");
            }
            throw new IllegalStateException("FragmentManager has been destroyed");
        }
        if (Looper.myLooper() != this.f6660u.f6853c.getLooper()) {
            throw new IllegalStateException("Must be called from main thread of fragment host");
        }
        if (!z3 && M()) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
        }
        if (this.f6638J == null) {
            this.f6638J = new ArrayList();
            this.K = new ArrayList();
        }
    }

    public final boolean y(boolean z3) {
        boolean zA;
        x(z3);
        boolean z9 = false;
        while (true) {
            ArrayList arrayList = this.f6638J;
            ArrayList arrayList2 = this.K;
            synchronized (this.f6642a) {
                if (this.f6642a.isEmpty()) {
                    zA = false;
                } else {
                    try {
                        int size = this.f6642a.size();
                        zA = false;
                        for (int i10 = 0; i10 < size; i10++) {
                            zA |= ((F) this.f6642a.get(i10)).a(arrayList, arrayList2);
                        }
                    } finally {
                    }
                }
            }
            if (!zA) {
                e0();
                u();
                ((HashMap) this.f6644c.f5316c).values().removeAll(Collections.singleton(null));
                return z9;
            }
            z9 = true;
            this.f6643b = true;
            try {
                T(this.f6638J, this.K);
            } finally {
                d();
            }
        }
    }

    public final void z(F f10, boolean z3) {
        if (z3 && (this.f6660u == null || this.f6636H)) {
            return;
        }
        x(z3);
        if (f10.a(this.f6638J, this.K)) {
            this.f6643b = true;
            try {
                T(this.f6638J, this.K);
            } finally {
                d();
            }
        }
        e0();
        u();
        ((HashMap) this.f6644c.f5316c).values().removeAll(Collections.singleton(null));
    }
}
