package androidx.fragment.app;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import androidx.lifecycle.EnumC0424v;
import androidx.lifecycle.EnumC0425w;

/* renamed from: androidx.fragment.app.u */
/* loaded from: classes.dex */
public abstract class AbstractActivityC0400u extends androidx.activity.j implements D.d {

    /* renamed from: B */
    public boolean f6856B;

    /* renamed from: C */
    public boolean f6857C;

    /* renamed from: z */
    public final B.b f6859z = new B.b(new C0399t(this), 18);

    /* renamed from: A */
    public final androidx.lifecycle.F f6855A = new androidx.lifecycle.F(this);

    /* renamed from: D */
    public boolean f6858D = true;

    public AbstractActivityC0400u() {
        ((C0.e) this.f6018e.d).c("android:support:lifecycle", new androidx.activity.d(this, 1));
        final int i10 = 0;
        i(new Q.a(this) { // from class: androidx.fragment.app.s

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ AbstractActivityC0400u f6849b;

            {
                this.f6849b = this;
            }

            @Override // Q.a
            public final void d(Object obj) {
                switch (i10) {
                    case 0:
                        this.f6849b.f6859z.r();
                        break;
                    default:
                        this.f6849b.f6859z.r();
                        break;
                }
            }
        });
        final int i11 = 1;
        this.f6027u.add(new Q.a(this) { // from class: androidx.fragment.app.s

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ AbstractActivityC0400u f6849b;

            {
                this.f6849b = this;
            }

            @Override // Q.a
            public final void d(Object obj) {
                switch (i11) {
                    case 0:
                        this.f6849b.f6859z.r();
                        break;
                    default:
                        this.f6849b.f6859z.r();
                        break;
                }
            }
        });
        j(new androidx.activity.e(this, 1));
    }

    public static boolean v(I i10) {
        EnumC0425w enumC0425w = EnumC0425w.f7005c;
        boolean zV = false;
        for (r rVar : i10.f6644c.p()) {
            if (rVar != null) {
                C0399t c0399t = rVar.f6803A;
                if ((c0399t == null ? null : c0399t.f6854e) != null) {
                    zV |= v(rVar.m());
                }
                S s9 = rVar.f6824W;
                EnumC0425w enumC0425w2 = EnumC0425w.d;
                if (s9 != null) {
                    s9.e();
                    if (s9.f6708e.d.compareTo(enumC0425w2) >= 0) {
                        rVar.f6824W.f6708e.g(enumC0425w);
                        zV = true;
                    }
                }
                if (rVar.f6823V.d.compareTo(enumC0425w2) >= 0) {
                    rVar.f6823V.g(enumC0425w);
                    zV = true;
                }
            }
        }
        return zV;
    }

    /* JADX WARN: Removed duplicated region for block: B:82:0x0058  */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void dump(java.lang.String r6, java.io.FileDescriptor r7, java.io.PrintWriter r8, java.lang.String[] r9) {
        /*
            r5 = this;
            r0 = 0
            r1 = 1
            super.dump(r6, r7, r8, r9)
            if (r9 == 0) goto L6d
            int r2 = r9.length
            if (r2 <= 0) goto L6d
            r2 = r9[r0]
            r2.getClass()
            r3 = -1
            int r4 = r2.hashCode()
            switch(r4) {
                case -645125871: goto L44;
                case 100470631: goto L39;
                case 472614934: goto L2e;
                case 1159329357: goto L23;
                case 1455016274: goto L18;
                default: goto L17;
            }
        L17:
            goto L4e
        L18:
            java.lang.String r4 = "--autofill"
            boolean r2 = r2.equals(r4)
            if (r2 != 0) goto L21
            goto L4e
        L21:
            r3 = 4
            goto L4e
        L23:
            java.lang.String r4 = "--contentcapture"
            boolean r2 = r2.equals(r4)
            if (r2 != 0) goto L2c
            goto L4e
        L2c:
            r3 = 3
            goto L4e
        L2e:
            java.lang.String r4 = "--list-dumpables"
            boolean r2 = r2.equals(r4)
            if (r2 != 0) goto L37
            goto L4e
        L37:
            r3 = 2
            goto L4e
        L39:
            java.lang.String r4 = "--dump-dumpable"
            boolean r2 = r2.equals(r4)
            if (r2 != 0) goto L42
            goto L4e
        L42:
            r3 = r1
            goto L4e
        L44:
            java.lang.String r4 = "--translation"
            boolean r2 = r2.equals(r4)
            if (r2 != 0) goto L4d
            goto L4e
        L4d:
            r3 = r0
        L4e:
            switch(r3) {
                case 0: goto L66;
                case 1: goto L61;
                case 2: goto L61;
                case 3: goto L5a;
                case 4: goto L52;
                default: goto L51;
            }
        L51:
            goto L6d
        L52:
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 26
            if (r2 < r3) goto L6d
        L58:
            r0 = r1
            goto L6d
        L5a:
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 29
            if (r2 < r3) goto L6d
            goto L58
        L61:
            boolean r0 = a.AbstractC0338a.C()
            goto L6d
        L66:
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 31
            if (r2 < r3) goto L6d
            goto L58
        L6d:
            r0 = r0 ^ r1
            if (r0 != 0) goto L71
            return
        L71:
            r8.print(r6)
            java.lang.String r0 = "Local FragmentActivity "
            r8.print(r0)
            int r0 = java.lang.System.identityHashCode(r5)
            java.lang.String r0 = java.lang.Integer.toHexString(r0)
            r8.print(r0)
            java.lang.String r0 = " State:"
            r8.println(r0)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            r0.append(r6)
            java.lang.String r1 = "  "
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r8.print(r0)
            java.lang.String r1 = "mCreated="
            r8.print(r1)
            boolean r1 = r5.f6856B
            r8.print(r1)
            java.lang.String r1 = " mResumed="
            r8.print(r1)
            boolean r1 = r5.f6857C
            r8.print(r1)
            java.lang.String r1 = " mStopped="
            r8.print(r1)
            boolean r1 = r5.f6858D
            r8.print(r1)
            android.app.Application r1 = r5.getApplication()
            if (r1 == 0) goto Lc8
            X0.c r1 = X0.c.B(r5)
            r1.x(r0, r8)
        Lc8:
            B.b r0 = r5.f6859z
            java.lang.Object r0 = r0.f65b
            androidx.fragment.app.t r0 = (androidx.fragment.app.C0399t) r0
            androidx.fragment.app.I r0 = r0.d
            r0.v(r6, r7, r8, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.AbstractActivityC0400u.dump(java.lang.String, java.io.FileDescriptor, java.io.PrintWriter, java.lang.String[]):void");
    }

    @Override // androidx.activity.j, android.app.Activity
    public void onActivityResult(int i10, int i11, Intent intent) {
        this.f6859z.r();
        super.onActivityResult(i10, i11, intent);
    }

    @Override // androidx.activity.j, D.k, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f6855A.e(EnumC0424v.ON_CREATE);
        I i10 = ((C0399t) this.f6859z.f65b).d;
        i10.f6634F = false;
        i10.f6635G = false;
        i10.f6640M.f6678f = false;
        i10.t(1);
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((C0399t) this.f6859z.f65b).d.f6646f.onCreateView(view, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(view, str, context, attributeSet) : viewOnCreateView;
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        ((C0399t) this.f6859z.f65b).d.k();
        this.f6855A.e(EnumC0424v.ON_DESTROY);
    }

    @Override // androidx.activity.j, android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i10, MenuItem menuItem) {
        if (super.onMenuItemSelected(i10, menuItem)) {
            return true;
        }
        if (i10 == 6) {
            return ((C0399t) this.f6859z.f65b).d.i();
        }
        return false;
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        this.f6857C = false;
        ((C0399t) this.f6859z.f65b).d.t(5);
        this.f6855A.e(EnumC0424v.ON_PAUSE);
    }

    @Override // android.app.Activity
    public void onPostResume() {
        super.onPostResume();
        this.f6855A.e(EnumC0424v.ON_RESUME);
        I i10 = ((C0399t) this.f6859z.f65b).d;
        i10.f6634F = false;
        i10.f6635G = false;
        i10.f6640M.f6678f = false;
        i10.t(7);
    }

    @Override // androidx.activity.j, android.app.Activity
    public void onRequestPermissionsResult(int i10, String[] strArr, int[] iArr) {
        this.f6859z.r();
        super.onRequestPermissionsResult(i10, strArr, iArr);
    }

    @Override // android.app.Activity
    public void onResume() {
        B.b bVar = this.f6859z;
        bVar.r();
        super.onResume();
        this.f6857C = true;
        ((C0399t) bVar.f65b).d.y(true);
    }

    @Override // android.app.Activity
    public void onStart() {
        B.b bVar = this.f6859z;
        bVar.r();
        super.onStart();
        this.f6858D = false;
        boolean z3 = this.f6856B;
        C0399t c0399t = (C0399t) bVar.f65b;
        if (!z3) {
            this.f6856B = true;
            I i10 = c0399t.d;
            i10.f6634F = false;
            i10.f6635G = false;
            i10.f6640M.f6678f = false;
            i10.t(4);
        }
        c0399t.d.y(true);
        this.f6855A.e(EnumC0424v.ON_START);
        I i11 = c0399t.d;
        i11.f6634F = false;
        i11.f6635G = false;
        i11.f6640M.f6678f = false;
        i11.t(5);
    }

    @Override // android.app.Activity
    public final void onStateNotSaved() {
        this.f6859z.r();
    }

    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
        this.f6858D = true;
        while (v(u())) {
        }
        I i10 = ((C0399t) this.f6859z.f65b).d;
        i10.f6635G = true;
        i10.f6640M.f6678f = true;
        i10.t(4);
        this.f6855A.e(EnumC0424v.ON_STOP);
    }

    public final I u() {
        return ((C0399t) this.f6859z.f65b).d;
    }

    @Override // android.app.Activity, android.view.LayoutInflater.Factory
    public final View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View viewOnCreateView = ((C0399t) this.f6859z.f65b).d.f6646f.onCreateView(null, str, context, attributeSet);
        return viewOnCreateView == null ? super.onCreateView(str, context, attributeSet) : viewOnCreateView;
    }
}
