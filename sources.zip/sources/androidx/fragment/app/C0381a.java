package androidx.fragment.app;

import android.util.Log;
import j0.AbstractC1047c;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Iterator;

/* renamed from: androidx.fragment.app.a */
/* loaded from: classes.dex */
public final class C0381a implements F {

    /* renamed from: a */
    public final ArrayList f6722a;

    /* renamed from: b */
    public int f6723b;

    /* renamed from: c */
    public int f6724c;
    public int d;

    /* renamed from: e */
    public int f6725e;

    /* renamed from: f */
    public int f6726f;
    public boolean g;

    /* renamed from: h */
    public boolean f6727h;

    /* renamed from: i */
    public String f6728i;

    /* renamed from: j */
    public int f6729j;

    /* renamed from: k */
    public CharSequence f6730k;

    /* renamed from: l */
    public int f6731l;

    /* renamed from: m */
    public CharSequence f6732m;

    /* renamed from: n */
    public ArrayList f6733n;

    /* renamed from: o */
    public ArrayList f6734o;

    /* renamed from: p */
    public boolean f6735p;

    /* renamed from: q */
    public final I f6736q;

    /* renamed from: r */
    public boolean f6737r;

    /* renamed from: s */
    public int f6738s;

    /* renamed from: t */
    public boolean f6739t;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public C0381a(I i10) {
        this();
        i10.F();
        C0399t c0399t = i10.f6660u;
        if (c0399t != null) {
            c0399t.f6852b.getClassLoader();
        }
        this.f6738s = -1;
        this.f6739t = false;
        this.f6736q = i10;
    }

    @Override // androidx.fragment.app.F
    public final boolean a(ArrayList arrayList, ArrayList arrayList2) {
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(Boolean.FALSE);
        if (!this.g) {
            return true;
        }
        I i10 = this.f6736q;
        if (i10.d == null) {
            i10.d = new ArrayList();
        }
        i10.d.add(this);
        return true;
    }

    public final void b(Q q6) {
        this.f6722a.add(q6);
        q6.d = this.f6723b;
        q6.f6701e = this.f6724c;
        q6.f6702f = this.d;
        q6.g = this.f6725e;
    }

    public final void c(String str) {
        if (!this.f6727h) {
            throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
        }
        this.g = true;
        this.f6728i = str;
    }

    public final void d(int i10) {
        if (this.g) {
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "Bump nesting in " + this + " by " + i10);
            }
            ArrayList arrayList = this.f6722a;
            int size = arrayList.size();
            for (int i11 = 0; i11 < size; i11++) {
                Q q6 = (Q) arrayList.get(i11);
                r rVar = q6.f6699b;
                if (rVar != null) {
                    rVar.f6846y += i10;
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "Bump nesting of " + q6.f6699b + " to " + q6.f6699b.f6846y);
                    }
                }
            }
        }
    }

    public final int e(boolean z3) {
        if (this.f6737r) {
            throw new IllegalStateException("commit already called");
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Commit: " + this);
            PrintWriter printWriter = new PrintWriter(new T());
            g("  ", printWriter, true);
            printWriter.close();
        }
        this.f6737r = true;
        boolean z9 = this.g;
        I i10 = this.f6736q;
        if (z9) {
            this.f6738s = i10.f6648i.getAndIncrement();
        } else {
            this.f6738s = -1;
        }
        i10.w(this, z3);
        return this.f6738s;
    }

    public final void f(int i10, r rVar, String str, int i11) {
        String str2 = rVar.f6821T;
        if (str2 != null) {
            AbstractC1047c.c(rVar, str2);
        }
        Class<?> cls = rVar.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        if (str != null) {
            String str3 = rVar.f6808F;
            if (str3 != null && !str.equals(str3)) {
                throw new IllegalStateException("Can't change tag of fragment " + rVar + ": was " + rVar.f6808F + " now " + str);
            }
            rVar.f6808F = str;
        }
        if (i10 != 0) {
            if (i10 == -1) {
                throw new IllegalArgumentException("Can't add fragment " + rVar + " with tag " + str + " to container view with no id");
            }
            int i12 = rVar.f6806D;
            if (i12 != 0 && i12 != i10) {
                throw new IllegalStateException("Can't change container ID of fragment " + rVar + ": was " + rVar.f6806D + " now " + i10);
            }
            rVar.f6806D = i10;
            rVar.f6807E = i10;
        }
        b(new Q(i11, rVar));
        rVar.f6847z = this.f6736q;
    }

    public final void g(String str, PrintWriter printWriter, boolean z3) {
        String str2;
        if (z3) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f6728i);
            printWriter.print(" mIndex=");
            printWriter.print(this.f6738s);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f6737r);
            if (this.f6726f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f6726f));
            }
            if (this.f6723b != 0 || this.f6724c != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f6723b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f6724c));
            }
            if (this.d != 0 || this.f6725e != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f6725e));
            }
            if (this.f6729j != 0 || this.f6730k != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f6729j));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f6730k);
            }
            if (this.f6731l != 0 || this.f6732m != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f6731l));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f6732m);
            }
        }
        ArrayList arrayList = this.f6722a;
        if (arrayList.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            Q q6 = (Q) arrayList.get(i10);
            switch (q6.f6698a) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                    str2 = "DETACH";
                    break;
                case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                    str2 = "ATTACH";
                    break;
                case 8:
                    str2 = "SET_PRIMARY_NAV";
                    break;
                case 9:
                    str2 = "UNSET_PRIMARY_NAV";
                    break;
                case 10:
                    str2 = "OP_SET_MAX_LIFECYCLE";
                    break;
                default:
                    str2 = "cmd=" + q6.f6698a;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i10);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(q6.f6699b);
            if (z3) {
                if (q6.d != 0 || q6.f6701e != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(q6.d));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(q6.f6701e));
                }
                if (q6.f6702f != 0 || q6.g != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(q6.f6702f));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(q6.g));
                }
            }
        }
    }

    public final void h(r rVar) {
        I i10 = rVar.f6847z;
        if (i10 == null || i10 == this.f6736q) {
            b(new Q(3, rVar));
            return;
        }
        throw new IllegalStateException("Cannot remove Fragment attached to a different FragmentManager. Fragment " + rVar.toString() + " is already attached to a FragmentManager.");
    }

    public final void i(r rVar) {
        I i10;
        if (rVar == null || (i10 = rVar.f6847z) == null || i10 == this.f6736q) {
            b(new Q(8, rVar));
            return;
        }
        throw new IllegalStateException("Cannot setPrimaryNavigation for Fragment attached to a different FragmentManager. Fragment " + rVar.toString() + " is already attached to a FragmentManager.");
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f6738s >= 0) {
            sb.append(" #");
            sb.append(this.f6738s);
        }
        if (this.f6728i != null) {
            sb.append(" ");
            sb.append(this.f6728i);
        }
        sb.append("}");
        return sb.toString();
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public C0381a(C0381a c0381a) {
        this();
        c0381a.f6736q.F();
        C0399t c0399t = c0381a.f6736q.f6660u;
        if (c0399t != null) {
            c0399t.f6852b.getClassLoader();
        }
        Iterator it = c0381a.f6722a.iterator();
        while (it.hasNext()) {
            Q q6 = (Q) it.next();
            ArrayList arrayList = this.f6722a;
            Q q8 = new Q();
            q8.f6698a = q6.f6698a;
            q8.f6699b = q6.f6699b;
            q8.f6700c = q6.f6700c;
            q8.d = q6.d;
            q8.f6701e = q6.f6701e;
            q8.f6702f = q6.f6702f;
            q8.g = q6.g;
            q8.f6703h = q6.f6703h;
            q8.f6704i = q6.f6704i;
            arrayList.add(q8);
        }
        this.f6723b = c0381a.f6723b;
        this.f6724c = c0381a.f6724c;
        this.d = c0381a.d;
        this.f6725e = c0381a.f6725e;
        this.f6726f = c0381a.f6726f;
        this.g = c0381a.g;
        this.f6727h = c0381a.f6727h;
        this.f6728i = c0381a.f6728i;
        this.f6731l = c0381a.f6731l;
        this.f6732m = c0381a.f6732m;
        this.f6729j = c0381a.f6729j;
        this.f6730k = c0381a.f6730k;
        if (c0381a.f6733n != null) {
            ArrayList arrayList2 = new ArrayList();
            this.f6733n = arrayList2;
            arrayList2.addAll(c0381a.f6733n);
        }
        if (c0381a.f6734o != null) {
            ArrayList arrayList3 = new ArrayList();
            this.f6734o = arrayList3;
            arrayList3.addAll(c0381a.f6734o);
        }
        this.f6735p = c0381a.f6735p;
        this.f6738s = -1;
        this.f6739t = false;
        this.f6736q = c0381a.f6736q;
        this.f6737r = c0381a.f6737r;
        this.f6738s = c0381a.f6738s;
        this.f6739t = c0381a.f6739t;
    }

    public C0381a() {
        this.f6722a = new ArrayList();
        this.f6727h = true;
        this.f6735p = false;
    }
}
