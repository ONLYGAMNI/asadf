package androidx.fragment.app;

import android.view.View;

/* renamed from: androidx.fragment.app.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0397q {

    /* renamed from: a, reason: collision with root package name */
    public boolean f6794a;

    /* renamed from: b, reason: collision with root package name */
    public int f6795b;

    /* renamed from: c, reason: collision with root package name */
    public int f6796c;
    public int d;

    /* renamed from: e, reason: collision with root package name */
    public int f6797e;

    /* renamed from: f, reason: collision with root package name */
    public int f6798f;
    public Object g;

    /* renamed from: h, reason: collision with root package name */
    public Object f6799h;

    /* renamed from: i, reason: collision with root package name */
    public Object f6800i;

    /* renamed from: j, reason: collision with root package name */
    public float f6801j;

    /* renamed from: k, reason: collision with root package name */
    public View f6802k;
}
