package androidx.fragment.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.strictmode.WrongFragmentContainerViolation;
import androidx.fragment.app.strictmode.WrongNestedHierarchyViolation;
import androidx.lifecycle.EnumC0424v;
import androidx.lifecycle.EnumC0425w;
import androidx.lifecycle.e0;
import androidx.lifecycle.r0;
import com.tajir.tajir.R;
import j0.AbstractC1047c;
import j0.C1046b;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.WeakHashMap;
import n0.C1243a;
import r.C1339m;
import s2.AbstractC1397b;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class P {

    /* renamed from: a */
    public final X0.c f6694a;

    /* renamed from: b */
    public final X0.i f6695b;

    /* renamed from: c */
    public final r f6696c;
    public boolean d = false;

    /* renamed from: e */
    public int f6697e = -1;

    public P(X0.c cVar, X0.i iVar, r rVar) {
        this.f6694a = cVar;
        this.f6695b = iVar;
        this.f6696c = rVar;
    }

    public final void a() {
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "moveto ACTIVITY_CREATED: " + rVar);
        }
        Bundle bundle = rVar.f6830b;
        Bundle bundle2 = bundle != null ? bundle.getBundle("savedInstanceState") : null;
        rVar.f6804B.O();
        rVar.f6828a = 3;
        rVar.K = false;
        rVar.B(bundle2);
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onActivityCreated()"));
        }
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "moveto RESTORE_VIEW_STATE: " + rVar);
        }
        if (rVar.f6814M != null) {
            Bundle bundle3 = rVar.f6830b;
            Bundle bundle4 = bundle3 != null ? bundle3.getBundle("savedInstanceState") : null;
            SparseArray<Parcelable> sparseArray = rVar.f6832c;
            if (sparseArray != null) {
                rVar.f6814M.restoreHierarchyState(sparseArray);
                rVar.f6832c = null;
            }
            rVar.K = false;
            rVar.S(bundle4);
            if (!rVar.K) {
                throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onViewStateRestored()"));
            }
            if (rVar.f6814M != null) {
                rVar.f6824W.a(EnumC0424v.ON_CREATE);
            }
        }
        rVar.f6830b = null;
        I i10 = rVar.f6804B;
        i10.f6634F = false;
        i10.f6635G = false;
        i10.f6640M.f6678f = false;
        i10.t(4);
        this.f6694a.f(false);
    }

    public final void b() {
        r rVar;
        View view;
        View view2;
        int iIndexOfChild = -1;
        r rVar2 = this.f6696c;
        View view3 = rVar2.f6813L;
        while (true) {
            rVar = null;
            if (view3 == null) {
                break;
            }
            Object tag = view3.getTag(R.id.fragment_container_view_tag);
            r rVar3 = tag instanceof r ? (r) tag : null;
            if (rVar3 != null) {
                rVar = rVar3;
                break;
            } else {
                Object parent = view3.getParent();
                view3 = parent instanceof View ? (View) parent : null;
            }
        }
        r rVar4 = rVar2.f6805C;
        if (rVar != null && !rVar.equals(rVar4)) {
            int i10 = rVar2.f6807E;
            C1046b c1046b = AbstractC1047c.f11689a;
            StringBuilder sb = new StringBuilder("Attempting to nest fragment ");
            sb.append(rVar2);
            sb.append(" within the view of parent fragment ");
            sb.append(rVar);
            sb.append(" via container with ID ");
            AbstractC1047c.b(new WrongNestedHierarchyViolation(rVar2, AbstractC1397b.d(sb, i10, " without using parent's childFragmentManager")));
            AbstractC1047c.a(rVar2).getClass();
        }
        X0.i iVar = this.f6695b;
        iVar.getClass();
        ViewGroup viewGroup = rVar2.f6813L;
        if (viewGroup != null) {
            ArrayList arrayList = (ArrayList) iVar.f5315b;
            int iIndexOf = arrayList.indexOf(rVar2);
            int i11 = iIndexOf - 1;
            while (true) {
                if (i11 < 0) {
                    while (true) {
                        iIndexOf++;
                        if (iIndexOf >= arrayList.size()) {
                            break;
                        }
                        r rVar5 = (r) arrayList.get(iIndexOf);
                        if (rVar5.f6813L == viewGroup && (view = rVar5.f6814M) != null) {
                            iIndexOfChild = viewGroup.indexOfChild(view);
                            break;
                        }
                    }
                } else {
                    r rVar6 = (r) arrayList.get(i11);
                    if (rVar6.f6813L == viewGroup && (view2 = rVar6.f6814M) != null) {
                        iIndexOfChild = viewGroup.indexOfChild(view2) + 1;
                        break;
                    }
                    i11--;
                }
            }
        }
        rVar2.f6813L.addView(rVar2.f6814M, iIndexOfChild);
    }

    public final void c() {
        P p9;
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "moveto ATTACHED: " + rVar);
        }
        r rVar2 = rVar.f6835n;
        X0.i iVar = this.f6695b;
        if (rVar2 != null) {
            p9 = (P) ((HashMap) iVar.f5316c).get(rVar2.f6833e);
            if (p9 == null) {
                throw new IllegalStateException("Fragment " + rVar + " declared target fragment " + rVar.f6835n + " that does not belong to this FragmentManager!");
            }
            rVar.f6836o = rVar.f6835n.f6833e;
            rVar.f6835n = null;
        } else {
            String str = rVar.f6836o;
            if (str != null) {
                p9 = (P) ((HashMap) iVar.f5316c).get(str);
                if (p9 == null) {
                    StringBuilder sb = new StringBuilder("Fragment ");
                    sb.append(rVar);
                    sb.append(" declared target fragment ");
                    throw new IllegalStateException(AbstractC1397b.e(sb, rVar.f6836o, " that does not belong to this FragmentManager!"));
                }
            } else {
                p9 = null;
            }
        }
        if (p9 != null) {
            p9.k();
        }
        I i10 = rVar.f6847z;
        rVar.f6803A = i10.f6660u;
        rVar.f6805C = i10.f6662w;
        X0.c cVar = this.f6694a;
        cVar.o(false);
        ArrayList arrayList = rVar.f6829a0;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            r rVar3 = ((C0395o) it.next()).f6792a;
            rVar3.f6827Z.h();
            e0.g(rVar3);
            Bundle bundle = rVar3.f6830b;
            rVar3.f6827Z.i(bundle != null ? bundle.getBundle("registryState") : null);
        }
        arrayList.clear();
        rVar.f6804B.b(rVar.f6803A, rVar.i(), rVar);
        rVar.f6828a = 0;
        rVar.K = false;
        rVar.D(rVar.f6803A.f6852b);
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onAttach()"));
        }
        I i11 = rVar.f6847z;
        Iterator it2 = i11.f6653n.iterator();
        while (it2.hasNext()) {
            ((M) it2.next()).a(i11, rVar);
        }
        I i12 = rVar.f6804B;
        i12.f6634F = false;
        i12.f6635G = false;
        i12.f6640M.f6678f = false;
        i12.t(0);
        cVar.g(false);
    }

    public final int d() {
        Object next;
        r rVar = this.f6696c;
        if (rVar.f6847z == null) {
            return rVar.f6828a;
        }
        int iMin = this.f6697e;
        int iOrdinal = rVar.f6822U.ordinal();
        if (iOrdinal == 1) {
            iMin = Math.min(iMin, 0);
        } else if (iOrdinal == 2) {
            iMin = Math.min(iMin, 1);
        } else if (iOrdinal == 3) {
            iMin = Math.min(iMin, 5);
        } else if (iOrdinal != 4) {
            iMin = Math.min(iMin, -1);
        }
        if (rVar.f6842u) {
            if (rVar.f6843v) {
                iMin = Math.max(this.f6697e, 2);
                View view = rVar.f6814M;
                if (view != null && view.getParent() == null) {
                    iMin = Math.min(iMin, 2);
                }
            } else {
                iMin = this.f6697e < 4 ? Math.min(iMin, rVar.f6828a) : Math.min(iMin, 1);
            }
        }
        if (!rVar.f6839r) {
            iMin = Math.min(iMin, 1);
        }
        ViewGroup viewGroup = rVar.f6813L;
        if (viewGroup != null) {
            C0389i c0389iJ = C0389i.j(viewGroup, rVar.q());
            c0389iJ.getClass();
            V vH = c0389iJ.h(rVar);
            int i10 = vH != null ? vH.f6716b : 0;
            Iterator it = c0389iJ.f6769c.iterator();
            while (true) {
                if (!it.hasNext()) {
                    next = null;
                    break;
                }
                next = it.next();
                V v9 = (V) next;
                if (AbstractC1420h.a(v9.f6717c, rVar) && !v9.f6719f) {
                    break;
                }
            }
            V v10 = (V) next;
            i = v10 != null ? v10.f6716b : 0;
            int i11 = i10 == 0 ? -1 : W.f6721a[t.e.d(i10)];
            if (i11 != -1 && i11 != 1) {
                i = i10;
            }
        }
        if (i == 2) {
            iMin = Math.min(iMin, 6);
        } else if (i == 3) {
            iMin = Math.max(iMin, 3);
        } else if (rVar.f6840s) {
            iMin = rVar.z() ? Math.min(iMin, 1) : Math.min(iMin, -1);
        }
        if (rVar.f6815N && rVar.f6828a < 5) {
            iMin = Math.min(iMin, 4);
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "computeExpectedState() of " + iMin + " for " + rVar);
        }
        return iMin;
    }

    public final void e() {
        Bundle bundle;
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        final r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "moveto CREATED: " + rVar);
        }
        Bundle bundle2 = rVar.f6830b;
        Bundle bundle3 = bundle2 != null ? bundle2.getBundle("savedInstanceState") : null;
        if (rVar.f6820S) {
            rVar.f6828a = 1;
            Bundle bundle4 = rVar.f6830b;
            if (bundle4 == null || (bundle = bundle4.getBundle("childFragmentManager")) == null) {
                return;
            }
            rVar.f6804B.U(bundle);
            I i10 = rVar.f6804B;
            i10.f6634F = false;
            i10.f6635G = false;
            i10.f6640M.f6678f = false;
            i10.t(1);
            return;
        }
        X0.c cVar = this.f6694a;
        cVar.p(false);
        rVar.f6804B.O();
        rVar.f6828a = 1;
        rVar.K = false;
        rVar.f6823V.a(new androidx.lifecycle.B() { // from class: androidx.fragment.app.Fragment$6
            @Override // androidx.lifecycle.B
            public final void d(androidx.lifecycle.D d, EnumC0424v enumC0424v) {
                View view;
                if (enumC0424v != EnumC0424v.ON_STOP || (view = rVar.f6814M) == null) {
                    return;
                }
                view.cancelPendingInputEvents();
            }
        });
        rVar.E(bundle3);
        rVar.f6820S = true;
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onCreate()"));
        }
        rVar.f6823V.e(EnumC0424v.ON_CREATE);
        cVar.h(false);
    }

    public final void f() throws Resources.NotFoundException {
        String resourceName;
        r rVar = this.f6696c;
        if (rVar.f6842u) {
            return;
        }
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "moveto CREATE_VIEW: " + rVar);
        }
        Bundle bundle = rVar.f6830b;
        ViewGroup viewGroup = null;
        Bundle bundle2 = bundle != null ? bundle.getBundle("savedInstanceState") : null;
        LayoutInflater layoutInflaterJ = rVar.J(bundle2);
        rVar.f6819R = layoutInflaterJ;
        ViewGroup viewGroup2 = rVar.f6813L;
        if (viewGroup2 != null) {
            viewGroup = viewGroup2;
        } else {
            int i10 = rVar.f6807E;
            if (i10 != 0) {
                if (i10 == -1) {
                    throw new IllegalArgumentException(android.support.v4.media.session.a.k("Cannot create fragment ", rVar, " for a container view with no id"));
                }
                viewGroup = (ViewGroup) rVar.f6847z.f6661v.c(i10);
                if (viewGroup == null) {
                    if (!rVar.f6844w) {
                        try {
                            resourceName = rVar.r().getResourceName(rVar.f6807E);
                        } catch (Resources.NotFoundException unused) {
                            resourceName = "unknown";
                        }
                        throw new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(rVar.f6807E) + " (" + resourceName + ") for fragment " + rVar);
                    }
                } else if (!(viewGroup instanceof FragmentContainerView)) {
                    C1046b c1046b = AbstractC1047c.f11689a;
                    AbstractC1047c.b(new WrongFragmentContainerViolation(rVar, "Attempting to add fragment " + rVar + " to container " + viewGroup + " which is not a FragmentContainerView"));
                    AbstractC1047c.a(rVar).getClass();
                }
            }
        }
        rVar.f6813L = viewGroup;
        rVar.T(layoutInflaterJ, viewGroup, bundle2);
        if (rVar.f6814M != null) {
            if (Log.isLoggable("FragmentManager", 3)) {
                Log.d("FragmentManager", "moveto VIEW_CREATED: " + rVar);
            }
            rVar.f6814M.setSaveFromParentEnabled(false);
            rVar.f6814M.setTag(R.id.fragment_container_view_tag, rVar);
            if (viewGroup != null) {
                b();
            }
            if (rVar.f6809G) {
                rVar.f6814M.setVisibility(8);
            }
            View view = rVar.f6814M;
            WeakHashMap weakHashMap = R.X.f3966a;
            if (R.H.b(view)) {
                R.I.c(rVar.f6814M);
            } else {
                View view2 = rVar.f6814M;
                view2.addOnAttachStateChangeListener(new O(view2, 0));
            }
            Bundle bundle3 = rVar.f6830b;
            if (bundle3 != null) {
                bundle3.getBundle("savedInstanceState");
            }
            rVar.R(rVar.f6814M);
            rVar.f6804B.t(2);
            this.f6694a.v(false);
            int visibility = rVar.f6814M.getVisibility();
            rVar.k().f6801j = rVar.f6814M.getAlpha();
            if (rVar.f6813L != null && visibility == 0) {
                View viewFindFocus = rVar.f6814M.findFocus();
                if (viewFindFocus != null) {
                    rVar.k().f6802k = viewFindFocus;
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "requestFocus: Saved focused view " + viewFindFocus + " for Fragment " + rVar);
                    }
                }
                rVar.f6814M.setAlpha(0.0f);
            }
        }
        rVar.f6828a = 2;
    }

    public final void g() {
        r rVarJ;
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "movefrom CREATED: " + rVar);
        }
        boolean zIsChangingConfigurations = true;
        boolean z3 = rVar.f6840s && !rVar.z();
        X0.i iVar = this.f6695b;
        if (z3 && !rVar.f6841t) {
            iVar.w(null, rVar.f6833e);
        }
        if (!z3) {
            L l5 = (L) iVar.f5317e;
            if (!((l5.f6674a.containsKey(rVar.f6833e) && l5.d) ? l5.f6677e : true)) {
                String str = rVar.f6836o;
                if (str != null && (rVarJ = iVar.j(str)) != null && rVarJ.f6811I) {
                    rVar.f6835n = rVarJ;
                }
                rVar.f6828a = 0;
                return;
            }
        }
        C0399t c0399t = rVar.f6803A;
        if (c0399t instanceof r0) {
            zIsChangingConfigurations = ((L) iVar.f5317e).f6677e;
        } else {
            Context context = c0399t.f6852b;
            if (context instanceof Activity) {
                zIsChangingConfigurations = true ^ ((Activity) context).isChangingConfigurations();
            }
        }
        if ((z3 && !rVar.f6841t) || zIsChangingConfigurations) {
            ((L) iVar.f5317e).b(rVar);
        }
        rVar.f6804B.k();
        rVar.f6823V.e(EnumC0424v.ON_DESTROY);
        rVar.f6828a = 0;
        rVar.K = false;
        rVar.f6820S = false;
        rVar.G();
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onDestroy()"));
        }
        this.f6694a.i(false);
        Iterator it = iVar.n().iterator();
        while (it.hasNext()) {
            P p9 = (P) it.next();
            if (p9 != null) {
                String str2 = rVar.f6833e;
                r rVar2 = p9.f6696c;
                if (str2.equals(rVar2.f6836o)) {
                    rVar2.f6835n = rVar;
                    rVar2.f6836o = null;
                }
            }
        }
        String str3 = rVar.f6836o;
        if (str3 != null) {
            rVar.f6835n = iVar.j(str3);
        }
        iVar.t(this);
    }

    public final void h() {
        View view;
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "movefrom CREATE_VIEW: " + rVar);
        }
        ViewGroup viewGroup = rVar.f6813L;
        if (viewGroup != null && (view = rVar.f6814M) != null) {
            viewGroup.removeView(view);
        }
        rVar.f6804B.t(1);
        if (rVar.f6814M != null) {
            S s9 = rVar.f6824W;
            s9.e();
            if (s9.f6708e.d.compareTo(EnumC0425w.f7005c) >= 0) {
                rVar.f6824W.a(EnumC0424v.ON_DESTROY);
            }
        }
        rVar.f6828a = 1;
        rVar.K = false;
        rVar.H();
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onDestroyView()"));
        }
        C1339m c1339m = ((n0.c) X0.c.B(rVar).f5305c).f13225a;
        int iJ = c1339m.j();
        for (int i10 = 0; i10 < iJ; i10++) {
            ((C1243a) c1339m.k(i10)).l();
        }
        rVar.f6845x = false;
        this.f6694a.w(false);
        rVar.f6813L = null;
        rVar.f6814M = null;
        rVar.f6824W = null;
        rVar.f6825X.k(null);
        rVar.f6843v = false;
    }

    public final void i() {
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "movefrom ATTACHED: " + rVar);
        }
        rVar.f6828a = -1;
        rVar.K = false;
        rVar.I();
        rVar.f6819R = null;
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onDetach()"));
        }
        I i10 = rVar.f6804B;
        if (!i10.f6636H) {
            i10.k();
            rVar.f6804B = new I();
        }
        this.f6694a.j(false);
        rVar.f6828a = -1;
        rVar.f6803A = null;
        rVar.f6805C = null;
        rVar.f6847z = null;
        if (!rVar.f6840s || rVar.z()) {
            L l5 = (L) this.f6695b.f5317e;
            boolean z3 = true;
            if (l5.f6674a.containsKey(rVar.f6833e) && l5.d) {
                z3 = l5.f6677e;
            }
            if (!z3) {
                return;
            }
        }
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "initState called for fragment: " + rVar);
        }
        rVar.w();
    }

    public final void j() {
        r rVar = this.f6696c;
        if (rVar.f6842u && rVar.f6843v && !rVar.f6845x) {
            if (Log.isLoggable("FragmentManager", 3)) {
                Log.d("FragmentManager", "moveto CREATE_VIEW: " + rVar);
            }
            Bundle bundle = rVar.f6830b;
            Bundle bundle2 = bundle != null ? bundle.getBundle("savedInstanceState") : null;
            LayoutInflater layoutInflaterJ = rVar.J(bundle2);
            rVar.f6819R = layoutInflaterJ;
            rVar.T(layoutInflaterJ, null, bundle2);
            View view = rVar.f6814M;
            if (view != null) {
                view.setSaveFromParentEnabled(false);
                rVar.f6814M.setTag(R.id.fragment_container_view_tag, rVar);
                if (rVar.f6809G) {
                    rVar.f6814M.setVisibility(8);
                }
                Bundle bundle3 = rVar.f6830b;
                if (bundle3 != null) {
                    bundle3.getBundle("savedInstanceState");
                }
                rVar.R(rVar.f6814M);
                rVar.f6804B.t(2);
                this.f6694a.v(false);
                rVar.f6828a = 2;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:268:0x012d, code lost:
    
        continue;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void k() {
        /*
            Method dump skipped, instructions count: 488
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.P.k():void");
    }

    public final void l() {
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "movefrom RESUMED: " + rVar);
        }
        rVar.f6804B.t(5);
        if (rVar.f6814M != null) {
            rVar.f6824W.a(EnumC0424v.ON_PAUSE);
        }
        rVar.f6823V.e(EnumC0424v.ON_PAUSE);
        rVar.f6828a = 6;
        rVar.K = false;
        rVar.L();
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onPause()"));
        }
        this.f6694a.m(false);
    }

    public final void m(ClassLoader classLoader) {
        r rVar = this.f6696c;
        Bundle bundle = rVar.f6830b;
        if (bundle == null) {
            return;
        }
        bundle.setClassLoader(classLoader);
        if (rVar.f6830b.getBundle("savedInstanceState") == null) {
            rVar.f6830b.putBundle("savedInstanceState", new Bundle());
        }
        rVar.f6832c = rVar.f6830b.getSparseParcelableArray("viewState");
        rVar.d = rVar.f6830b.getBundle("viewRegistryState");
        N n9 = (N) rVar.f6830b.getParcelable("state");
        if (n9 != null) {
            rVar.f6836o = n9.f6689s;
            rVar.f6837p = n9.f6690t;
            rVar.f6816O = n9.f6691u;
        }
        if (rVar.f6816O) {
            return;
        }
        rVar.f6815N = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:55:0x0041  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void n() {
        /*
            r7 = this;
            r0 = 3
            java.lang.String r1 = "FragmentManager"
            boolean r0 = android.util.Log.isLoggable(r1, r0)
            androidx.fragment.app.r r2 = r7.f6696c
            if (r0 == 0) goto L1c
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r3 = "moveto RESUMED: "
            r0.<init>(r3)
            r0.append(r2)
            java.lang.String r0 = r0.toString()
            android.util.Log.d(r1, r0)
        L1c:
            androidx.fragment.app.q r0 = r2.f6817P
            r3 = 0
            if (r0 != 0) goto L23
            r0 = r3
            goto L25
        L23:
            android.view.View r0 = r0.f6802k
        L25:
            if (r0 == 0) goto L7d
            android.view.View r4 = r2.f6814M
            if (r0 != r4) goto L2c
            goto L36
        L2c:
            android.view.ViewParent r4 = r0.getParent()
        L30:
            if (r4 == 0) goto L7d
            android.view.View r5 = r2.f6814M
            if (r4 != r5) goto L78
        L36:
            boolean r4 = r0.requestFocus()
            r5 = 2
            boolean r5 = android.util.Log.isLoggable(r1, r5)
            if (r5 == 0) goto L7d
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            java.lang.String r6 = "requestFocus: Restoring focused view "
            r5.<init>(r6)
            r5.append(r0)
            java.lang.String r0 = " "
            r5.append(r0)
            if (r4 == 0) goto L55
            java.lang.String r0 = "succeeded"
            goto L57
        L55:
            java.lang.String r0 = "failed"
        L57:
            r5.append(r0)
            java.lang.String r0 = " on Fragment "
            r5.append(r0)
            r5.append(r2)
            java.lang.String r0 = " resulting in focused view "
            r5.append(r0)
            android.view.View r0 = r2.f6814M
            android.view.View r0 = r0.findFocus()
            r5.append(r0)
            java.lang.String r0 = r5.toString()
            android.util.Log.v(r1, r0)
            goto L7d
        L78:
            android.view.ViewParent r4 = r4.getParent()
            goto L30
        L7d:
            androidx.fragment.app.q r0 = r2.k()
            r0.f6802k = r3
            androidx.fragment.app.I r0 = r2.f6804B
            r0.O()
            androidx.fragment.app.I r0 = r2.f6804B
            r1 = 1
            r0.y(r1)
            r0 = 7
            r2.f6828a = r0
            r1 = 0
            r2.K = r1
            r2.N()
            boolean r4 = r2.K
            if (r4 == 0) goto Lc6
            androidx.lifecycle.F r4 = r2.f6823V
            androidx.lifecycle.v r5 = androidx.lifecycle.EnumC0424v.ON_RESUME
            r4.e(r5)
            android.view.View r4 = r2.f6814M
            if (r4 == 0) goto Lad
            androidx.fragment.app.S r4 = r2.f6824W
            androidx.lifecycle.F r4 = r4.f6708e
            r4.e(r5)
        Lad:
            androidx.fragment.app.I r4 = r2.f6804B
            r4.f6634F = r1
            r4.f6635G = r1
            androidx.fragment.app.L r5 = r4.f6640M
            r5.f6678f = r1
            r4.t(r0)
            X0.c r0 = r7.f6694a
            r0.r(r1)
            r2.f6830b = r3
            r2.f6832c = r3
            r2.d = r3
            return
        Lc6:
            androidx.fragment.app.X r0 = new androidx.fragment.app.X
            java.lang.String r1 = "Fragment "
            java.lang.String r3 = " did not call through to super.onResume()"
            java.lang.String r1 = android.support.v4.media.session.a.k(r1, r2, r3)
            r0.<init>(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.P.n():void");
    }

    public final Bundle o() {
        Bundle bundle;
        Bundle bundle2 = new Bundle();
        r rVar = this.f6696c;
        if (rVar.f6828a == -1 && (bundle = rVar.f6830b) != null) {
            bundle2.putAll(bundle);
        }
        bundle2.putParcelable("state", new N(rVar));
        if (rVar.f6828a > -1) {
            Bundle bundle3 = new Bundle();
            rVar.O(bundle3);
            if (!bundle3.isEmpty()) {
                bundle2.putBundle("savedInstanceState", bundle3);
            }
            this.f6694a.s(false);
            Bundle bundle4 = new Bundle();
            rVar.f6827Z.j(bundle4);
            if (!bundle4.isEmpty()) {
                bundle2.putBundle("registryState", bundle4);
            }
            Bundle bundleV = rVar.f6804B.V();
            if (!bundleV.isEmpty()) {
                bundle2.putBundle("childFragmentManager", bundleV);
            }
            if (rVar.f6814M != null) {
                p();
            }
            SparseArray<? extends Parcelable> sparseArray = rVar.f6832c;
            if (sparseArray != null) {
                bundle2.putSparseParcelableArray("viewState", sparseArray);
            }
            Bundle bundle5 = rVar.d;
            if (bundle5 != null) {
                bundle2.putBundle("viewRegistryState", bundle5);
            }
        }
        Bundle bundle6 = rVar.f6834f;
        if (bundle6 != null) {
            bundle2.putBundle("arguments", bundle6);
        }
        return bundle2;
    }

    public final void p() {
        r rVar = this.f6696c;
        if (rVar.f6814M == null) {
            return;
        }
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Saving view state for fragment " + rVar + " with view " + rVar.f6814M);
        }
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        rVar.f6814M.saveHierarchyState(sparseArray);
        if (sparseArray.size() > 0) {
            rVar.f6832c = sparseArray;
        }
        Bundle bundle = new Bundle();
        rVar.f6824W.f6709f.j(bundle);
        if (bundle.isEmpty()) {
            return;
        }
        rVar.d = bundle;
    }

    public final void q() {
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "moveto STARTED: " + rVar);
        }
        rVar.f6804B.O();
        rVar.f6804B.y(true);
        rVar.f6828a = 5;
        rVar.K = false;
        rVar.P();
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onStart()"));
        }
        androidx.lifecycle.F f10 = rVar.f6823V;
        EnumC0424v enumC0424v = EnumC0424v.ON_START;
        f10.e(enumC0424v);
        if (rVar.f6814M != null) {
            rVar.f6824W.f6708e.e(enumC0424v);
        }
        I i10 = rVar.f6804B;
        i10.f6634F = false;
        i10.f6635G = false;
        i10.f6640M.f6678f = false;
        i10.t(5);
        this.f6694a.t(false);
    }

    public final void r() {
        boolean zIsLoggable = Log.isLoggable("FragmentManager", 3);
        r rVar = this.f6696c;
        if (zIsLoggable) {
            Log.d("FragmentManager", "movefrom STARTED: " + rVar);
        }
        I i10 = rVar.f6804B;
        i10.f6635G = true;
        i10.f6640M.f6678f = true;
        i10.t(4);
        if (rVar.f6814M != null) {
            rVar.f6824W.a(EnumC0424v.ON_STOP);
        }
        rVar.f6823V.e(EnumC0424v.ON_STOP);
        rVar.f6828a = 4;
        rVar.K = false;
        rVar.Q();
        if (!rVar.K) {
            throw new X(android.support.v4.media.session.a.k("Fragment ", rVar, " did not call through to super.onStop()"));
        }
        this.f6694a.u(false);
    }

    public P(X0.c cVar, X0.i iVar, ClassLoader classLoader, B b7, Bundle bundle) {
        this.f6694a = cVar;
        this.f6695b = iVar;
        r rVarA = ((N) bundle.getParcelable("state")).a(b7);
        this.f6696c = rVarA;
        rVarA.f6830b = bundle;
        Bundle bundle2 = bundle.getBundle("arguments");
        if (bundle2 != null) {
            bundle2.setClassLoader(classLoader);
        }
        rVarA.a0(bundle2);
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Instantiated fragment " + rVarA);
        }
    }

    public P(X0.c cVar, X0.i iVar, r rVar, Bundle bundle) {
        this.f6694a = cVar;
        this.f6695b = iVar;
        this.f6696c = rVar;
        rVar.f6832c = null;
        rVar.d = null;
        rVar.f6846y = 0;
        rVar.f6843v = false;
        rVar.f6839r = false;
        r rVar2 = rVar.f6835n;
        rVar.f6836o = rVar2 != null ? rVar2.f6833e : null;
        rVar.f6835n = null;
        rVar.f6830b = bundle;
        rVar.f6834f = bundle.getBundle("arguments");
    }
}
