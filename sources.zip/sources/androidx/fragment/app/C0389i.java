package androidx.fragment.app;

import E5.C0065g;
import E5.RunnableC0066h;
import android.animation.Animator;
import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import com.tajir.tajir.R;
import f8.AbstractC0842j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.ListIterator;
import java.util.WeakHashMap;
import s2.AbstractC1397b;
import s8.AbstractC1420h;

/* renamed from: androidx.fragment.app.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0389i {

    /* renamed from: a, reason: collision with root package name */
    public final ViewGroup f6767a;

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f6768b;

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f6769c;
    public boolean d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f6770e;

    public C0389i(ViewGroup viewGroup) {
        AbstractC1420h.f(viewGroup, "container");
        this.f6767a = viewGroup;
        this.f6768b = new ArrayList();
        this.f6769c = new ArrayList();
    }

    public static final C0389i j(ViewGroup viewGroup, I i10) {
        AbstractC1420h.f(viewGroup, "container");
        AbstractC1420h.f(i10, "fragmentManager");
        AbstractC1420h.e(i10.G(), "fragmentManager.specialEffectsControllerFactory");
        Object tag = viewGroup.getTag(R.id.special_effects_controller_view_tag);
        if (tag instanceof C0389i) {
            return (C0389i) tag;
        }
        C0389i c0389i = new C0389i(viewGroup);
        viewGroup.setTag(R.id.special_effects_controller_view_tag, c0389i);
        return c0389i;
    }

    public final void a(int i10, int i11, P p9) {
        synchronized (this.f6768b) {
            M.d dVar = new M.d();
            r rVar = p9.f6696c;
            AbstractC1420h.e(rVar, "fragmentStateManager.fragment");
            V vH = h(rVar);
            if (vH != null) {
                vH.c(i10, i11);
                return;
            }
            final V v9 = new V(i10, i11, p9, dVar);
            this.f6768b.add(v9);
            final int i12 = 0;
            v9.d.add(new Runnable(this) { // from class: androidx.fragment.app.U

                /* renamed from: b, reason: collision with root package name */
                public final /* synthetic */ C0389i f6713b;

                {
                    this.f6713b = this;
                }

                @Override // java.lang.Runnable
                public final void run() {
                    switch (i12) {
                        case 0:
                            C0389i c0389i = this.f6713b;
                            AbstractC1420h.f(c0389i, "this$0");
                            V v10 = v9;
                            AbstractC1420h.f(v10, "$operation");
                            if (c0389i.f6768b.contains(v10)) {
                                int i13 = v10.f6715a;
                                View view = v10.f6717c.f6814M;
                                AbstractC1420h.e(view, "operation.fragment.mView");
                                android.support.v4.media.session.a.a(view, i13);
                                break;
                            }
                            break;
                        default:
                            C0389i c0389i2 = this.f6713b;
                            AbstractC1420h.f(c0389i2, "this$0");
                            V v11 = v9;
                            AbstractC1420h.f(v11, "$operation");
                            c0389i2.f6768b.remove(v11);
                            c0389i2.f6769c.remove(v11);
                            break;
                    }
                }
            });
            final int i13 = 1;
            v9.d.add(new Runnable(this) { // from class: androidx.fragment.app.U

                /* renamed from: b, reason: collision with root package name */
                public final /* synthetic */ C0389i f6713b;

                {
                    this.f6713b = this;
                }

                @Override // java.lang.Runnable
                public final void run() {
                    switch (i13) {
                        case 0:
                            C0389i c0389i = this.f6713b;
                            AbstractC1420h.f(c0389i, "this$0");
                            V v10 = v9;
                            AbstractC1420h.f(v10, "$operation");
                            if (c0389i.f6768b.contains(v10)) {
                                int i132 = v10.f6715a;
                                View view = v10.f6717c.f6814M;
                                AbstractC1420h.e(view, "operation.fragment.mView");
                                android.support.v4.media.session.a.a(view, i132);
                                break;
                            }
                            break;
                        default:
                            C0389i c0389i2 = this.f6713b;
                            AbstractC1420h.f(c0389i2, "this$0");
                            V v11 = v9;
                            AbstractC1420h.f(v11, "$operation");
                            c0389i2.f6768b.remove(v11);
                            c0389i2.f6769c.remove(v11);
                            break;
                    }
                }
            });
        }
    }

    public final void b(int i10, P p9) {
        AbstractC1397b.f(i10, "finalState");
        AbstractC1420h.f(p9, "fragmentStateManager");
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing add operation for fragment " + p9.f6696c);
        }
        a(i10, 2, p9);
    }

    public final void c(P p9) {
        AbstractC1420h.f(p9, "fragmentStateManager");
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing hide operation for fragment " + p9.f6696c);
        }
        a(3, 1, p9);
    }

    public final void d(P p9) {
        AbstractC1420h.f(p9, "fragmentStateManager");
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing remove operation for fragment " + p9.f6696c);
        }
        a(1, 3, p9);
    }

    public final void e(P p9) {
        AbstractC1420h.f(p9, "fragmentStateManager");
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Enqueuing show operation for fragment " + p9.f6696c);
        }
        a(2, 1, p9);
    }

    public final void f(ArrayList arrayList, boolean z3) throws Resources.NotFoundException {
        Object obj;
        Object next;
        ArrayList arrayList2;
        Iterator it = arrayList.iterator();
        while (true) {
            obj = null;
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            V v9 = (V) next;
            View view = v9.f6717c.f6814M;
            AbstractC1420h.e(view, "operation.fragment.mView");
            if (com.bumptech.glide.d.d(view) == 2 && v9.f6715a != 2) {
                break;
            }
        }
        V v10 = (V) next;
        ListIterator listIterator = arrayList.listIterator(arrayList.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                break;
            }
            Object objPrevious = listIterator.previous();
            V v11 = (V) objPrevious;
            View view2 = v11.f6717c.f6814M;
            AbstractC1420h.e(view2, "operation.fragment.mView");
            if (com.bumptech.glide.d.d(view2) != 2 && v11.f6715a == 2) {
                obj = objPrevious;
                break;
            }
        }
        V v12 = (V) obj;
        String str = " to ";
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Executing operations from " + v10 + " to " + v12);
        }
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        ArrayList arrayListR0 = AbstractC0842j.r0(arrayList);
        r rVar = ((V) AbstractC0842j.b0(arrayList)).f6717c;
        Iterator it2 = arrayList.iterator();
        while (it2.hasNext()) {
            C0397q c0397q = ((V) it2.next()).f6717c.f6817P;
            C0397q c0397q2 = rVar.f6817P;
            c0397q.f6795b = c0397q2.f6795b;
            c0397q.f6796c = c0397q2.f6796c;
            c0397q.d = c0397q2.d;
            c0397q.f6797e = c0397q2.f6797e;
        }
        Iterator it3 = arrayList.iterator();
        while (it3.hasNext()) {
            V v13 = (V) it3.next();
            M.d dVar = new M.d();
            v13.d();
            LinkedHashSet linkedHashSet = v13.f6718e;
            linkedHashSet.add(dVar);
            arrayList3.add(new C0384d(v13, dVar, z3));
            M.d dVar2 = new M.d();
            v13.d();
            linkedHashSet.add(dVar2);
            boolean z9 = !z3 ? v13 != v12 : v13 != v10;
            C0386f c0386f = new C0386f(0, v13, dVar2);
            int i10 = v13.f6715a;
            r rVar2 = v13.f6717c;
            if (i10 == 2) {
                if (z3) {
                    C0397q c0397q3 = rVar2.f6817P;
                } else {
                    rVar2.getClass();
                }
            } else if (z3) {
                C0397q c0397q4 = rVar2.f6817P;
            } else {
                rVar2.getClass();
            }
            if (v13.f6715a == 2) {
                if (z3) {
                    C0397q c0397q5 = rVar2.f6817P;
                } else {
                    C0397q c0397q6 = rVar2.f6817P;
                }
            }
            if (z9) {
                if (z3) {
                    C0397q c0397q7 = rVar2.f6817P;
                } else {
                    rVar2.getClass();
                }
            }
            arrayList4.add(c0386f);
            v13.d.add(new RunnableC0066h(arrayListR0, v13, this, 3));
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        ArrayList arrayList5 = new ArrayList();
        Iterator it4 = arrayList4.iterator();
        while (it4.hasNext()) {
            Object next2 = it4.next();
            if (!((C0386f) next2).l()) {
                arrayList5.add(next2);
            }
        }
        ArrayList arrayList6 = new ArrayList();
        Iterator it5 = arrayList5.iterator();
        while (it5.hasNext()) {
            ((C0386f) it5.next()).getClass();
        }
        Iterator it6 = arrayList6.iterator();
        while (it6.hasNext()) {
            ((C0386f) it6.next()).getClass();
        }
        Iterator it7 = arrayList4.iterator();
        while (it7.hasNext()) {
            C0386f c0386f2 = (C0386f) it7.next();
            linkedHashMap.put((V) c0386f2.f6758b, Boolean.FALSE);
            c0386f2.d();
        }
        boolean zContainsValue = linkedHashMap.containsValue(Boolean.TRUE);
        ViewGroup viewGroup = this.f6767a;
        Context context = viewGroup.getContext();
        ArrayList arrayList7 = new ArrayList();
        Iterator it8 = arrayList3.iterator();
        boolean z10 = false;
        while (it8.hasNext()) {
            C0384d c0384d = (C0384d) it8.next();
            if (c0384d.l()) {
                c0384d.d();
            } else {
                AbstractC1420h.e(context, "context");
                l1.d dVarQ = c0384d.q(context);
                if (dVarQ == null) {
                    c0384d.d();
                } else {
                    Animator animator = (Animator) dVarQ.f12858c;
                    if (animator == null) {
                        arrayList7.add(c0384d);
                    } else {
                        V v14 = (V) c0384d.f6758b;
                        r rVar3 = v14.f6717c;
                        arrayList2 = arrayList7;
                        if (AbstractC1420h.a(linkedHashMap.get(v14), Boolean.TRUE)) {
                            if (Log.isLoggable("FragmentManager", 2)) {
                                Log.v("FragmentManager", "Ignoring Animator set on " + rVar3 + " as this Fragment was involved in a Transition.");
                            }
                            c0384d.d();
                            arrayList7 = arrayList2;
                        } else {
                            boolean z11 = v14.f6715a == 3;
                            if (z11) {
                                arrayListR0.remove(v14);
                            }
                            View view3 = rVar3.f6814M;
                            viewGroup.startViewTransition(view3);
                            LinkedHashMap linkedHashMap2 = linkedHashMap;
                            V v15 = v12;
                            String str2 = str;
                            V v16 = v10;
                            ArrayList arrayList8 = arrayListR0;
                            Context context2 = context;
                            animator.addListener(new C0387g(this, view3, z11, v14, c0384d));
                            animator.setTarget(view3);
                            animator.start();
                            if (Log.isLoggable("FragmentManager", 2)) {
                                Log.v("FragmentManager", "Animator from operation " + v14 + " has started.");
                            }
                            ((M.d) c0384d.f6759c).b(new C0065g(15, animator, v14));
                            context = context2;
                            arrayList7 = arrayList2;
                            v10 = v16;
                            linkedHashMap = linkedHashMap2;
                            v12 = v15;
                            str = str2;
                            arrayListR0 = arrayList8;
                            z10 = true;
                        }
                    }
                }
            }
            arrayList2 = arrayList7;
            arrayList7 = arrayList2;
        }
        V v17 = v10;
        V v18 = v12;
        String str3 = str;
        ArrayList arrayList9 = arrayListR0;
        Context context3 = context;
        Iterator it9 = arrayList7.iterator();
        while (it9.hasNext()) {
            C0384d c0384d2 = (C0384d) it9.next();
            V v19 = (V) c0384d2.f6758b;
            r rVar4 = v19.f6717c;
            if (zContainsValue) {
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + rVar4 + " as Animations cannot run alongside Transitions.");
                }
                c0384d2.d();
            } else if (z10) {
                if (Log.isLoggable("FragmentManager", 2)) {
                    Log.v("FragmentManager", "Ignoring Animation set on " + rVar4 + " as Animations cannot run alongside Animators.");
                }
                c0384d2.d();
            } else {
                View view4 = rVar4.f6814M;
                AbstractC1420h.e(context3, "context");
                l1.d dVarQ2 = c0384d2.q(context3);
                if (dVarQ2 == null) {
                    throw new IllegalStateException("Required value was null.".toString());
                }
                Animation animation = (Animation) dVarQ2.f12857b;
                if (animation == null) {
                    throw new IllegalStateException("Required value was null.".toString());
                }
                if (v19.f6715a != 1) {
                    view4.startAnimation(animation);
                    c0384d2.d();
                } else {
                    viewGroup.startViewTransition(view4);
                    RunnableC0401v runnableC0401v = new RunnableC0401v(animation, viewGroup, view4);
                    runnableC0401v.setAnimationListener(new AnimationAnimationListenerC0388h(v19, this, view4, c0384d2));
                    view4.startAnimation(runnableC0401v);
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "Animation from operation " + v19 + " has started.");
                    }
                }
                ((M.d) c0384d2.f6759c).b(new L4.b(view4, this, c0384d2, v19));
            }
        }
        Iterator it10 = arrayList9.iterator();
        while (it10.hasNext()) {
            V v20 = (V) it10.next();
            View view5 = v20.f6717c.f6814M;
            int i11 = v20.f6715a;
            AbstractC1420h.e(view5, "view");
            android.support.v4.media.session.a.a(view5, i11);
        }
        arrayList9.clear();
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Completed executing operations from " + v17 + str3 + v18);
        }
    }

    public final void g() {
        if (this.f6770e) {
            return;
        }
        ViewGroup viewGroup = this.f6767a;
        WeakHashMap weakHashMap = R.X.f3966a;
        if (!R.H.b(viewGroup)) {
            i();
            this.d = false;
            return;
        }
        synchronized (this.f6768b) {
            try {
                if (!this.f6768b.isEmpty()) {
                    ArrayList arrayListR0 = AbstractC0842j.r0(this.f6769c);
                    this.f6769c.clear();
                    Iterator it = arrayListR0.iterator();
                    while (it.hasNext()) {
                        V v9 = (V) it.next();
                        if (Log.isLoggable("FragmentManager", 2)) {
                            Log.v("FragmentManager", "SpecialEffectsController: Cancelling operation " + v9);
                        }
                        v9.a();
                        if (!v9.g) {
                            this.f6769c.add(v9);
                        }
                    }
                    l();
                    ArrayList arrayListR02 = AbstractC0842j.r0(this.f6768b);
                    this.f6768b.clear();
                    this.f6769c.addAll(arrayListR02);
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Executing pending operations");
                    }
                    Iterator it2 = arrayListR02.iterator();
                    while (it2.hasNext()) {
                        ((V) it2.next()).d();
                    }
                    f(arrayListR02, this.d);
                    this.d = false;
                    if (Log.isLoggable("FragmentManager", 2)) {
                        Log.v("FragmentManager", "SpecialEffectsController: Finished executing pending operations");
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final V h(r rVar) {
        Object next;
        Iterator it = this.f6768b.iterator();
        while (true) {
            if (!it.hasNext()) {
                next = null;
                break;
            }
            next = it.next();
            V v9 = (V) next;
            if (AbstractC1420h.a(v9.f6717c, rVar) && !v9.f6719f) {
                break;
            }
        }
        return (V) next;
    }

    public final void i() {
        String str;
        String str2;
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "SpecialEffectsController: Forcing all operations to complete");
        }
        ViewGroup viewGroup = this.f6767a;
        WeakHashMap weakHashMap = R.X.f3966a;
        boolean zB = R.H.b(viewGroup);
        synchronized (this.f6768b) {
            try {
                l();
                Iterator it = this.f6768b.iterator();
                while (it.hasNext()) {
                    ((V) it.next()).d();
                }
                Iterator it2 = AbstractC0842j.r0(this.f6769c).iterator();
                while (it2.hasNext()) {
                    V v9 = (V) it2.next();
                    if (Log.isLoggable("FragmentManager", 2)) {
                        if (zB) {
                            str2 = "";
                        } else {
                            str2 = "Container " + this.f6767a + " is not attached to window. ";
                        }
                        Log.v("FragmentManager", "SpecialEffectsController: " + str2 + "Cancelling running operation " + v9);
                    }
                    v9.a();
                }
                Iterator it3 = AbstractC0842j.r0(this.f6768b).iterator();
                while (it3.hasNext()) {
                    V v10 = (V) it3.next();
                    if (Log.isLoggable("FragmentManager", 2)) {
                        if (zB) {
                            str = "";
                        } else {
                            str = "Container " + this.f6767a + " is not attached to window. ";
                        }
                        Log.v("FragmentManager", "SpecialEffectsController: " + str + "Cancelling pending operation " + v10);
                    }
                    v10.a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void k() {
        Object objPrevious;
        synchronized (this.f6768b) {
            try {
                l();
                ArrayList arrayList = this.f6768b;
                ListIterator listIterator = arrayList.listIterator(arrayList.size());
                while (true) {
                    if (!listIterator.hasPrevious()) {
                        objPrevious = null;
                        break;
                    }
                    objPrevious = listIterator.previous();
                    V v9 = (V) objPrevious;
                    View view = v9.f6717c.f6814M;
                    AbstractC1420h.e(view, "operation.fragment.mView");
                    int iD = com.bumptech.glide.d.d(view);
                    if (v9.f6715a == 2 && iD != 2) {
                        break;
                    }
                }
                this.f6770e = false;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void l() {
        Iterator it = this.f6768b.iterator();
        while (it.hasNext()) {
            V v9 = (V) it.next();
            int i10 = 2;
            if (v9.f6716b == 2) {
                int visibility = v9.f6717c.Y().getVisibility();
                if (visibility != 0) {
                    i10 = 4;
                    if (visibility != 4) {
                        if (visibility != 8) {
                            throw new IllegalArgumentException(android.support.v4.media.session.a.h(visibility, "Unknown visibility "));
                        }
                        i10 = 3;
                    }
                }
                v9.c(i10, 1);
            }
        }
    }
}
