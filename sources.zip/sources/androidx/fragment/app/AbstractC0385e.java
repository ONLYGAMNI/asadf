package androidx.fragment.app;

import android.content.Context;
import android.content.IntentFilter;
import android.net.Uri;
import android.util.SparseIntArray;
import android.view.MenuItem;
import android.view.View;
import f8.AbstractC0843k;
import java.io.File;
import java.nio.charset.Charset;
import java.util.LinkedHashSet;
import java.util.List;
import r.C1338l;
import s8.AbstractC1420h;
import v7.C1580k;

/* renamed from: androidx.fragment.app.e */
/* loaded from: classes.dex */
public abstract class AbstractC0385e implements y2.t {

    /* renamed from: a */
    public final /* synthetic */ int f6757a;

    /* renamed from: b */
    public Object f6758b;

    /* renamed from: c */
    public Object f6759c;

    public /* synthetic */ AbstractC0385e(int i10, Object obj, Object obj2) {
        this.f6757a = i10;
        this.f6758b = obj;
        this.f6759c = obj2;
    }

    public void c() {
        E5.G g = (E5.G) this.f6758b;
        if (g != null) {
            try {
                ((f.v) this.f6759c).f10488r.unregisterReceiver(g);
            } catch (IllegalArgumentException unused) {
            }
            this.f6758b = null;
        }
    }

    public void d() {
        V v9 = (V) this.f6758b;
        v9.getClass();
        M.d dVar = (M.d) this.f6759c;
        AbstractC1420h.f(dVar, "signal");
        LinkedHashSet linkedHashSet = v9.f6718e;
        if (linkedHashSet.remove(dVar) && linkedHashSet.isEmpty()) {
            v9.b();
        }
    }

    public abstract IntentFilter e();

    public abstract int f();

    public MenuItem g(MenuItem menuItem) {
        if (!(menuItem instanceof J.a)) {
            return menuItem;
        }
        J.a aVar = (J.a) menuItem;
        if (((C1338l) this.f6759c) == null) {
            this.f6759c = new C1338l();
        }
        MenuItem menuItem2 = (MenuItem) ((C1338l) this.f6759c).getOrDefault(aVar, null);
        if (menuItem2 != null) {
            return menuItem2;
        }
        k.s sVar = new k.s((Context) this.f6758b, aVar);
        ((C1338l) this.f6759c).put(aVar, sVar);
        return sVar;
    }

    public int h(int i10, int i11) {
        int iJ = j(i10);
        int i12 = 0;
        int i13 = 0;
        for (int i14 = 0; i14 < i10; i14++) {
            int iJ2 = j(i14);
            i12 += iJ2;
            if (i12 == i11) {
                i13++;
                i12 = 0;
            } else if (i12 > i11) {
                i13++;
                i12 = iJ2;
            }
        }
        return i12 + iJ > i11 ? i13 + 1 : i13;
    }

    public int i(int i10, int i11) {
        int iJ = j(i10);
        if (iJ == i11) {
            return 0;
        }
        int i12 = 0;
        for (int i13 = 0; i13 < i10; i13++) {
            int iJ2 = j(i13);
            i12 += iJ2;
            if (i12 == i11) {
                i12 = 0;
            } else if (i12 > i11) {
                i12 = iJ2;
            }
        }
        if (iJ + i12 <= i11) {
            return i12;
        }
        return 0;
    }

    public abstract int j(int i10);

    public void k() {
        ((SparseIntArray) this.f6758b).clear();
    }

    public boolean l() {
        V v9 = (V) this.f6758b;
        View view = v9.f6717c.f6814M;
        AbstractC1420h.e(view, "operation.fragment.mView");
        int iD = com.bumptech.glide.d.d(view);
        int i10 = v9.f6715a;
        return iD == i10 || !(iD == 2 || i10 == 2);
    }

    public abstract void m();

    @Override // y2.t
    public y2.s n(y2.y yVar) {
        Class cls = (Class) this.f6759c;
        return new z2.d((Context) this.f6758b, yVar.c(File.class, cls), yVar.c(Uri.class, cls), cls);
    }

    public String o(String str) {
        AbstractC1420h.f(str, "name");
        List list = (List) this.f6759c;
        int iN = AbstractC0843k.N(list);
        if (iN < 0) {
            return null;
        }
        int i10 = 0;
        while (true) {
            C1580k c1580k = (C1580k) list.get(i10);
            if (z8.n.v0(c1580k.f15812a, str)) {
                return c1580k.f15813b;
            }
            if (i10 == iN) {
                return null;
            }
            i10++;
        }
    }

    public void p() {
        c();
        IntentFilter intentFilterE = e();
        if (intentFilterE.countActions() == 0) {
            return;
        }
        if (((E5.G) this.f6758b) == null) {
            this.f6758b = new E5.G(6, this, false);
        }
        ((f.v) this.f6759c).f10488r.registerReceiver((E5.G) this.f6758b, intentFilterE);
    }

    /* JADX WARN: Removed duplicated region for block: B:144:0x00d1  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x00d8  */
    /* JADX WARN: Removed duplicated region for block: B:150:0x00f6  */
    /* JADX WARN: Removed duplicated region for block: B:170:0x0146 A[LOOP:1: B:113:0x0058->B:170:0x0146, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:176:0x0150 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public java.lang.String toString() {
        /*
            Method dump skipped, instructions count: 352
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.AbstractC0385e.toString():java.lang.String");
    }

    public AbstractC0385e(String str, List list) {
        this.f6757a = 4;
        AbstractC1420h.f(str, "content");
        AbstractC1420h.f(list, "parameters");
        this.f6758b = str;
        this.f6759c = list;
    }

    public AbstractC0385e(Context context) {
        this.f6757a = 3;
        this.f6758b = context;
    }

    public AbstractC0385e(T8.b bVar, Object obj, E7.a aVar, Charset charset) {
        this.f6757a = 5;
        AbstractC1420h.f(bVar, "format");
        AbstractC1420h.f(obj, "value");
        AbstractC1420h.f(charset, "charset");
        this.f6758b = obj;
    }

    public AbstractC0385e() {
        this.f6757a = 1;
        this.f6758b = new SparseIntArray();
        this.f6759c = new SparseIntArray();
    }

    public AbstractC0385e(f.v vVar) {
        this.f6757a = 2;
        this.f6759c = vVar;
    }
}
