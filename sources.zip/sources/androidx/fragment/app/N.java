package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.lifecycle.EnumC0425w;

/* loaded from: classes.dex */
public final class N implements Parcelable {
    public static final Parcelable.Creator<N> CREATOR = new S3.b(18);

    /* renamed from: a, reason: collision with root package name */
    public final String f6679a;

    /* renamed from: b, reason: collision with root package name */
    public final String f6680b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f6681c;
    public final int d;

    /* renamed from: e, reason: collision with root package name */
    public final int f6682e;

    /* renamed from: f, reason: collision with root package name */
    public final String f6683f;

    /* renamed from: n, reason: collision with root package name */
    public final boolean f6684n;

    /* renamed from: o, reason: collision with root package name */
    public final boolean f6685o;

    /* renamed from: p, reason: collision with root package name */
    public final boolean f6686p;

    /* renamed from: q, reason: collision with root package name */
    public final boolean f6687q;

    /* renamed from: r, reason: collision with root package name */
    public final int f6688r;

    /* renamed from: s, reason: collision with root package name */
    public final String f6689s;

    /* renamed from: t, reason: collision with root package name */
    public final int f6690t;

    /* renamed from: u, reason: collision with root package name */
    public final boolean f6691u;

    public N(r rVar) {
        this.f6679a = rVar.getClass().getName();
        this.f6680b = rVar.f6833e;
        this.f6681c = rVar.f6842u;
        this.d = rVar.f6806D;
        this.f6682e = rVar.f6807E;
        this.f6683f = rVar.f6808F;
        this.f6684n = rVar.f6811I;
        this.f6685o = rVar.f6840s;
        this.f6686p = rVar.f6810H;
        this.f6687q = rVar.f6809G;
        this.f6688r = rVar.f6822U.ordinal();
        this.f6689s = rVar.f6836o;
        this.f6690t = rVar.f6837p;
        this.f6691u = rVar.f6816O;
    }

    public final r a(B b7) {
        r rVarA = b7.a(this.f6679a);
        rVarA.f6833e = this.f6680b;
        rVarA.f6842u = this.f6681c;
        rVarA.f6844w = true;
        rVarA.f6806D = this.d;
        rVarA.f6807E = this.f6682e;
        rVarA.f6808F = this.f6683f;
        rVarA.f6811I = this.f6684n;
        rVarA.f6840s = this.f6685o;
        rVarA.f6810H = this.f6686p;
        rVarA.f6809G = this.f6687q;
        rVarA.f6822U = EnumC0425w.values()[this.f6688r];
        rVarA.f6836o = this.f6689s;
        rVarA.f6837p = this.f6690t;
        rVarA.f6816O = this.f6691u;
        return rVarA;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FragmentState{");
        sb.append(this.f6679a);
        sb.append(" (");
        sb.append(this.f6680b);
        sb.append(")}:");
        if (this.f6681c) {
            sb.append(" fromLayout");
        }
        int i10 = this.f6682e;
        if (i10 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(i10));
        }
        String str = this.f6683f;
        if (str != null && !str.isEmpty()) {
            sb.append(" tag=");
            sb.append(str);
        }
        if (this.f6684n) {
            sb.append(" retainInstance");
        }
        if (this.f6685o) {
            sb.append(" removing");
        }
        if (this.f6686p) {
            sb.append(" detached");
        }
        if (this.f6687q) {
            sb.append(" hidden");
        }
        String str2 = this.f6689s;
        if (str2 != null) {
            sb.append(" targetWho=");
            sb.append(str2);
            sb.append(" targetRequestCode=");
            sb.append(this.f6690t);
        }
        if (this.f6691u) {
            sb.append(" userVisibleHint");
        }
        return sb.toString();
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f6679a);
        parcel.writeString(this.f6680b);
        parcel.writeInt(this.f6681c ? 1 : 0);
        parcel.writeInt(this.d);
        parcel.writeInt(this.f6682e);
        parcel.writeString(this.f6683f);
        parcel.writeInt(this.f6684n ? 1 : 0);
        parcel.writeInt(this.f6685o ? 1 : 0);
        parcel.writeInt(this.f6686p ? 1 : 0);
        parcel.writeInt(this.f6687q ? 1 : 0);
        parcel.writeInt(this.f6688r);
        parcel.writeString(this.f6689s);
        parcel.writeInt(this.f6690t);
        parcel.writeInt(this.f6691u ? 1 : 0);
    }

    public N(Parcel parcel) {
        this.f6679a = parcel.readString();
        this.f6680b = parcel.readString();
        this.f6681c = parcel.readInt() != 0;
        this.d = parcel.readInt();
        this.f6682e = parcel.readInt();
        this.f6683f = parcel.readString();
        this.f6684n = parcel.readInt() != 0;
        this.f6685o = parcel.readInt() != 0;
        this.f6686p = parcel.readInt() != 0;
        this.f6687q = parcel.readInt() != 0;
        this.f6688r = parcel.readInt();
        this.f6689s = parcel.readString();
        this.f6690t = parcel.readInt();
        this.f6691u = parcel.readInt() != 0;
    }
}
