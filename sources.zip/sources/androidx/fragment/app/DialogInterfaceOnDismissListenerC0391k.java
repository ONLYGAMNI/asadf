package androidx.fragment.app;

import android.app.Dialog;
import android.content.DialogInterface;

/* renamed from: androidx.fragment.app.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class DialogInterfaceOnDismissListenerC0391k implements DialogInterface.OnDismissListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ DialogInterfaceOnCancelListenerC0394n f6772a;

    public DialogInterfaceOnDismissListenerC0391k(DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n) {
        this.f6772a = dialogInterfaceOnCancelListenerC0394n;
    }

    @Override // android.content.DialogInterface.OnDismissListener
    public final void onDismiss(DialogInterface dialogInterface) {
        DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n = this.f6772a;
        Dialog dialog = dialogInterfaceOnCancelListenerC0394n.f6787o0;
        if (dialog != null) {
            dialogInterfaceOnCancelListenerC0394n.onDismiss(dialog);
        }
    }
}
