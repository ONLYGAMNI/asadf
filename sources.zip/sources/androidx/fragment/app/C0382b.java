package androidx.fragment.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import androidx.lifecycle.EnumC0425w;
import java.util.ArrayList;

/* renamed from: androidx.fragment.app.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0382b implements Parcelable {
    public static final Parcelable.Creator<C0382b> CREATOR = new S3.b(14);

    /* renamed from: a, reason: collision with root package name */
    public final int[] f6740a;

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f6741b;

    /* renamed from: c, reason: collision with root package name */
    public final int[] f6742c;
    public final int[] d;

    /* renamed from: e, reason: collision with root package name */
    public final int f6743e;

    /* renamed from: f, reason: collision with root package name */
    public final String f6744f;

    /* renamed from: n, reason: collision with root package name */
    public final int f6745n;

    /* renamed from: o, reason: collision with root package name */
    public final int f6746o;

    /* renamed from: p, reason: collision with root package name */
    public final CharSequence f6747p;

    /* renamed from: q, reason: collision with root package name */
    public final int f6748q;

    /* renamed from: r, reason: collision with root package name */
    public final CharSequence f6749r;

    /* renamed from: s, reason: collision with root package name */
    public final ArrayList f6750s;

    /* renamed from: t, reason: collision with root package name */
    public final ArrayList f6751t;

    /* renamed from: u, reason: collision with root package name */
    public final boolean f6752u;

    public C0382b(C0381a c0381a) {
        int size = c0381a.f6722a.size();
        this.f6740a = new int[size * 6];
        if (!c0381a.g) {
            throw new IllegalStateException("Not on back stack");
        }
        this.f6741b = new ArrayList(size);
        this.f6742c = new int[size];
        this.d = new int[size];
        int i10 = 0;
        for (int i11 = 0; i11 < size; i11++) {
            Q q6 = (Q) c0381a.f6722a.get(i11);
            int i12 = i10 + 1;
            this.f6740a[i10] = q6.f6698a;
            ArrayList arrayList = this.f6741b;
            r rVar = q6.f6699b;
            arrayList.add(rVar != null ? rVar.f6833e : null);
            int[] iArr = this.f6740a;
            iArr[i12] = q6.f6700c ? 1 : 0;
            iArr[i10 + 2] = q6.d;
            iArr[i10 + 3] = q6.f6701e;
            int i13 = i10 + 5;
            iArr[i10 + 4] = q6.f6702f;
            i10 += 6;
            iArr[i13] = q6.g;
            this.f6742c[i11] = q6.f6703h.ordinal();
            this.d[i11] = q6.f6704i.ordinal();
        }
        this.f6743e = c0381a.f6726f;
        this.f6744f = c0381a.f6728i;
        this.f6745n = c0381a.f6738s;
        this.f6746o = c0381a.f6729j;
        this.f6747p = c0381a.f6730k;
        this.f6748q = c0381a.f6731l;
        this.f6749r = c0381a.f6732m;
        this.f6750s = c0381a.f6733n;
        this.f6751t = c0381a.f6734o;
        this.f6752u = c0381a.f6735p;
    }

    public final void a(C0381a c0381a) {
        int i10 = 0;
        int i11 = 0;
        while (true) {
            int[] iArr = this.f6740a;
            boolean z3 = true;
            if (i10 >= iArr.length) {
                c0381a.f6726f = this.f6743e;
                c0381a.f6728i = this.f6744f;
                c0381a.g = true;
                c0381a.f6729j = this.f6746o;
                c0381a.f6730k = this.f6747p;
                c0381a.f6731l = this.f6748q;
                c0381a.f6732m = this.f6749r;
                c0381a.f6733n = this.f6750s;
                c0381a.f6734o = this.f6751t;
                c0381a.f6735p = this.f6752u;
                return;
            }
            Q q6 = new Q();
            int i12 = i10 + 1;
            q6.f6698a = iArr[i10];
            if (Log.isLoggable("FragmentManager", 2)) {
                Log.v("FragmentManager", "Instantiate " + c0381a + " op #" + i11 + " base fragment #" + iArr[i12]);
            }
            q6.f6703h = EnumC0425w.values()[this.f6742c[i11]];
            q6.f6704i = EnumC0425w.values()[this.d[i11]];
            int i13 = i10 + 2;
            if (iArr[i12] == 0) {
                z3 = false;
            }
            q6.f6700c = z3;
            int i14 = iArr[i13];
            q6.d = i14;
            int i15 = iArr[i10 + 3];
            q6.f6701e = i15;
            int i16 = i10 + 5;
            int i17 = iArr[i10 + 4];
            q6.f6702f = i17;
            i10 += 6;
            int i18 = iArr[i16];
            q6.g = i18;
            c0381a.f6723b = i14;
            c0381a.f6724c = i15;
            c0381a.d = i17;
            c0381a.f6725e = i18;
            c0381a.b(q6);
            i11++;
        }
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeIntArray(this.f6740a);
        parcel.writeStringList(this.f6741b);
        parcel.writeIntArray(this.f6742c);
        parcel.writeIntArray(this.d);
        parcel.writeInt(this.f6743e);
        parcel.writeString(this.f6744f);
        parcel.writeInt(this.f6745n);
        parcel.writeInt(this.f6746o);
        TextUtils.writeToParcel(this.f6747p, parcel, 0);
        parcel.writeInt(this.f6748q);
        TextUtils.writeToParcel(this.f6749r, parcel, 0);
        parcel.writeStringList(this.f6750s);
        parcel.writeStringList(this.f6751t);
        parcel.writeInt(this.f6752u ? 1 : 0);
    }

    public C0382b(Parcel parcel) {
        this.f6740a = parcel.createIntArray();
        this.f6741b = parcel.createStringArrayList();
        this.f6742c = parcel.createIntArray();
        this.d = parcel.createIntArray();
        this.f6743e = parcel.readInt();
        this.f6744f = parcel.readString();
        this.f6745n = parcel.readInt();
        this.f6746o = parcel.readInt();
        Parcelable.Creator creator = TextUtils.CHAR_SEQUENCE_CREATOR;
        this.f6747p = (CharSequence) creator.createFromParcel(parcel);
        this.f6748q = parcel.readInt();
        this.f6749r = (CharSequence) creator.createFromParcel(parcel);
        this.f6750s = parcel.createStringArrayList();
        this.f6751t = parcel.createStringArrayList();
        this.f6752u = parcel.readInt() != 0;
    }
}
