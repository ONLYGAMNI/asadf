package androidx.fragment.app;

import java.lang.reflect.InvocationTargetException;
import r.C1338l;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public final class B {

    /* renamed from: b, reason: collision with root package name */
    public static final C1338l f6613b = new C1338l();

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ I f6614a;

    public B(I i10) {
        this.f6614a = i10;
    }

    public static Class b(ClassLoader classLoader, String str) throws ClassNotFoundException {
        C1338l c1338l = f6613b;
        C1338l c1338l2 = (C1338l) c1338l.getOrDefault(classLoader, null);
        if (c1338l2 == null) {
            c1338l2 = new C1338l();
            c1338l.put(classLoader, c1338l2);
        }
        Class cls = (Class) c1338l2.getOrDefault(str, null);
        if (cls != null) {
            return cls;
        }
        Class<?> cls2 = Class.forName(str, false, classLoader);
        c1338l2.put(str, cls2);
        return cls2;
    }

    public static Class c(ClassLoader classLoader, String str) {
        try {
            return b(classLoader, str);
        } catch (ClassCastException e4) {
            throw new Fragment$InstantiationException(AbstractC1480a.k("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), e4);
        } catch (ClassNotFoundException e5) {
            throw new Fragment$InstantiationException(AbstractC1480a.k("Unable to instantiate fragment ", str, ": make sure class name exists"), e5);
        }
    }

    public final r a(String str) {
        try {
            return (r) c(this.f6614a.f6660u.f6852b.getClassLoader(), str).getConstructor(null).newInstance(null);
        } catch (IllegalAccessException e4) {
            throw new Fragment$InstantiationException(AbstractC1480a.k("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e4);
        } catch (InstantiationException e5) {
            throw new Fragment$InstantiationException(AbstractC1480a.k("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e5);
        } catch (NoSuchMethodException e10) {
            throw new Fragment$InstantiationException(AbstractC1480a.k("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e10);
        } catch (InvocationTargetException e11) {
            throw new Fragment$InstantiationException(AbstractC1480a.k("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e11);
        }
    }
}
