package androidx.fragment.app;

/* loaded from: classes.dex */
public final class H implements F {

    /* renamed from: a */
    public final /* synthetic */ int f6626a;

    /* renamed from: b */
    public final String f6627b;

    /* renamed from: c */
    public final /* synthetic */ I f6628c;

    public /* synthetic */ H(I i10, String str, int i11) {
        this.f6626a = i11;
        this.f6628c = i10;
        this.f6627b = str;
    }

    /* JADX WARN: Code restructure failed: missing block: B:334:0x0364, code lost:
    
        r6.add(r9);
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:233:0x00b3  */
    @Override // androidx.fragment.app.F
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean a(java.util.ArrayList r20, java.util.ArrayList r21) {
        /*
            Method dump skipped, instructions count: 900
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.H.a(java.util.ArrayList, java.util.ArrayList):boolean");
    }
}
