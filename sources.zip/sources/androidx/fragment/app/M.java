package androidx.fragment.app;

/* loaded from: classes.dex */
public interface M {
    void a(I i10, r rVar);
}
