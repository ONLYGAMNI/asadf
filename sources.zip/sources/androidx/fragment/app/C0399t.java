package androidx.fragment.app;

import R.InterfaceC0255n;
import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.q0;
import androidx.lifecycle.r0;

/* renamed from: androidx.fragment.app.t */
/* loaded from: classes.dex */
public final class C0399t extends AbstractC0402w implements E.m, E.n, D.y, D.z, r0, androidx.activity.A, androidx.activity.result.d, C0.f, M, InterfaceC0255n {

    /* renamed from: a */
    public final Activity f6851a;

    /* renamed from: b */
    public final Context f6852b;

    /* renamed from: c */
    public final Handler f6853c;
    public final I d;

    /* renamed from: e */
    public final /* synthetic */ AbstractActivityC0400u f6854e;

    public C0399t(AbstractActivityC0400u abstractActivityC0400u) {
        this.f6854e = abstractActivityC0400u;
        Handler handler = new Handler();
        this.d = new I();
        this.f6851a = abstractActivityC0400u;
        this.f6852b = abstractActivityC0400u;
        this.f6853c = handler;
    }

    @Override // androidx.fragment.app.M
    public final void a(I i10, r rVar) {
        this.f6854e.getClass();
    }

    @Override // C0.f
    public final C0.e b() {
        return (C0.e) this.f6854e.f6018e.d;
    }

    @Override // androidx.fragment.app.AbstractC0402w
    public final View c(int i10) {
        return this.f6854e.findViewById(i10);
    }

    @Override // androidx.fragment.app.AbstractC0402w
    public final boolean d() {
        Window window = this.f6854e.getWindow();
        return (window == null || window.peekDecorView() == null) ? false : true;
    }

    public final void e(A a6) {
        this.f6854e.g(a6);
    }

    @Override // androidx.lifecycle.r0
    public final q0 f() {
        return this.f6854e.f();
    }

    public final void g(Q.a aVar) {
        this.f6854e.i(aVar);
    }

    @Override // androidx.lifecycle.D
    public final androidx.lifecycle.F h() {
        return this.f6854e.f6855A;
    }

    public final void i(z zVar) {
        this.f6854e.k(zVar);
    }

    public final void j(z zVar) {
        this.f6854e.l(zVar);
    }

    public final void k(z zVar) {
        this.f6854e.m(zVar);
    }

    public final void l(A a6) {
        this.f6854e.p(a6);
    }

    public final void m(z zVar) {
        this.f6854e.q(zVar);
    }

    public final void n(z zVar) {
        this.f6854e.r(zVar);
    }

    public final void o(z zVar) {
        this.f6854e.s(zVar);
    }

    public final void p(z zVar) {
        this.f6854e.t(zVar);
    }
}
