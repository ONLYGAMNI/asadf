package androidx.fragment.app;

import android.util.AndroidRuntimeException;

/* loaded from: classes.dex */
public final class X extends AndroidRuntimeException {
}
