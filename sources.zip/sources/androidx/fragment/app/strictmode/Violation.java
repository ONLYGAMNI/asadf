package androidx.fragment.app.strictmode;

import androidx.fragment.app.r;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class Violation extends RuntimeException {

    /* renamed from: a */
    public final r f6850a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Violation(r rVar, String str) {
        super(str);
        AbstractC1420h.f(rVar, "fragment");
        this.f6850a = rVar;
    }
}
