package androidx.fragment.app.strictmode;

/* loaded from: classes.dex */
public abstract class TargetFragmentUsageViolation extends Violation {
}
