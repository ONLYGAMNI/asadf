package androidx.fragment.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import s8.AbstractC1420h;

/* renamed from: androidx.fragment.app.g */
/* loaded from: classes.dex */
public final class C0387g extends AnimatorListenerAdapter {

    /* renamed from: a */
    public final /* synthetic */ C0389i f6760a;

    /* renamed from: b */
    public final /* synthetic */ View f6761b;

    /* renamed from: c */
    public final /* synthetic */ boolean f6762c;
    public final /* synthetic */ V d;

    /* renamed from: e */
    public final /* synthetic */ C0384d f6763e;

    public C0387g(C0389i c0389i, View view, boolean z3, V v9, C0384d c0384d) {
        this.f6760a = c0389i;
        this.f6761b = view;
        this.f6762c = z3;
        this.d = v9;
        this.f6763e = c0384d;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        AbstractC1420h.f(animator, "anim");
        ViewGroup viewGroup = this.f6760a.f6767a;
        View view = this.f6761b;
        viewGroup.endViewTransition(view);
        boolean z3 = this.f6762c;
        V v9 = this.d;
        if (z3) {
            int i10 = v9.f6715a;
            AbstractC1420h.e(view, "viewToAnimate");
            android.support.v4.media.session.a.a(view, i10);
        }
        this.f6763e.d();
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Animator from operation " + v9 + " has ended.");
        }
    }
}
