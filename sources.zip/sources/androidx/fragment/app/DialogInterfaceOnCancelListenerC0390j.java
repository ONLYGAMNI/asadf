package androidx.fragment.app;

import android.app.Dialog;
import android.content.DialogInterface;

/* renamed from: androidx.fragment.app.j */
/* loaded from: classes.dex */
public final class DialogInterfaceOnCancelListenerC0390j implements DialogInterface.OnCancelListener {

    /* renamed from: a */
    public final /* synthetic */ DialogInterfaceOnCancelListenerC0394n f6771a;

    public DialogInterfaceOnCancelListenerC0390j(DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n) {
        this.f6771a = dialogInterfaceOnCancelListenerC0394n;
    }

    @Override // android.content.DialogInterface.OnCancelListener
    public final void onCancel(DialogInterface dialogInterface) {
        DialogInterfaceOnCancelListenerC0394n dialogInterfaceOnCancelListenerC0394n = this.f6771a;
        Dialog dialog = dialogInterfaceOnCancelListenerC0394n.f6787o0;
        if (dialog != null) {
            dialogInterfaceOnCancelListenerC0394n.onCancel(dialog);
        }
    }
}
