package androidx.fragment.app;

import android.util.Log;
import java.io.Writer;

/* loaded from: classes.dex */
public final class T extends Writer {

    /* renamed from: b, reason: collision with root package name */
    public final StringBuilder f6711b = new StringBuilder(128);

    /* renamed from: a, reason: collision with root package name */
    public final String f6710a = "FragmentManager";

    public final void b() {
        StringBuilder sb = this.f6711b;
        if (sb.length() > 0) {
            Log.d(this.f6710a, sb.toString());
            sb.delete(0, sb.length());
        }
    }

    @Override // java.io.Writer, java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        b();
    }

    @Override // java.io.Writer, java.io.Flushable
    public final void flush() {
        b();
    }

    @Override // java.io.Writer
    public final void write(char[] cArr, int i10, int i11) {
        for (int i12 = 0; i12 < i11; i12++) {
            char c4 = cArr[i10 + i12];
            if (c4 == '\n') {
                b();
            } else {
                this.f6711b.append(c4);
            }
        }
    }
}
