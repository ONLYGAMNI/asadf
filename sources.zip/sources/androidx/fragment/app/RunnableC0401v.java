package androidx.fragment.app;

import R.ViewTreeObserverOnPreDrawListenerC0264x;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.Transformation;

/* renamed from: androidx.fragment.app.v, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class RunnableC0401v extends AnimationSet implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final ViewGroup f6860a;

    /* renamed from: b, reason: collision with root package name */
    public final View f6861b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f6862c;
    public boolean d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f6863e;

    public RunnableC0401v(Animation animation, ViewGroup viewGroup, View view) {
        super(false);
        this.f6863e = true;
        this.f6860a = viewGroup;
        this.f6861b = view;
        addAnimation(animation);
        viewGroup.post(this);
    }

    @Override // android.view.animation.AnimationSet, android.view.animation.Animation
    public final boolean getTransformation(long j10, Transformation transformation) {
        this.f6863e = true;
        if (this.f6862c) {
            return !this.d;
        }
        if (!super.getTransformation(j10, transformation)) {
            this.f6862c = true;
            ViewTreeObserverOnPreDrawListenerC0264x.a(this.f6860a, this);
        }
        return true;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean z3 = this.f6862c;
        ViewGroup viewGroup = this.f6860a;
        if (z3 || !this.f6863e) {
            viewGroup.endViewTransition(this.f6861b);
            this.d = true;
        } else {
            this.f6863e = false;
            viewGroup.post(this);
        }
    }

    @Override // android.view.animation.Animation
    public final boolean getTransformation(long j10, Transformation transformation, float f10) {
        this.f6863e = true;
        if (this.f6862c) {
            return !this.d;
        }
        if (!super.getTransformation(j10, transformation, f10)) {
            this.f6862c = true;
            ViewTreeObserverOnPreDrawListenerC0264x.a(this.f6860a, this);
        }
        return true;
    }
}
