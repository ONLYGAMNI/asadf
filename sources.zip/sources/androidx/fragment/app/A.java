package androidx.fragment.app;

/* loaded from: classes.dex */
public final class A {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ I f6612a;

    public A(I i10) {
        this.f6612a = i10;
    }
}
