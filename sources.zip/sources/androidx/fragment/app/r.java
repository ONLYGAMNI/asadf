package androidx.fragment.app;

import D.RunnableC0050a;
import a.AbstractC0338a;
import android.app.Application;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.EnumC0425w;
import androidx.lifecycle.e0;
import androidx.lifecycle.h0;
import androidx.lifecycle.l0;
import androidx.lifecycle.n0;
import androidx.lifecycle.q0;
import androidx.lifecycle.r0;
import com.tajir.tajir.R;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import m0.C1196e;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class r implements ComponentCallbacks, View.OnCreateContextMenuListener, androidx.lifecycle.D, r0, androidx.lifecycle.r, C0.f {
    public static final Object c0 = new Object();

    /* renamed from: A */
    public C0399t f6803A;

    /* renamed from: C */
    public r f6805C;

    /* renamed from: D */
    public int f6806D;

    /* renamed from: E */
    public int f6807E;

    /* renamed from: F */
    public String f6808F;

    /* renamed from: G */
    public boolean f6809G;

    /* renamed from: H */
    public boolean f6810H;

    /* renamed from: I */
    public boolean f6811I;
    public boolean K;

    /* renamed from: L */
    public ViewGroup f6813L;

    /* renamed from: M */
    public View f6814M;

    /* renamed from: N */
    public boolean f6815N;

    /* renamed from: P */
    public C0397q f6817P;

    /* renamed from: Q */
    public boolean f6818Q;

    /* renamed from: R */
    public LayoutInflater f6819R;

    /* renamed from: S */
    public boolean f6820S;

    /* renamed from: T */
    public String f6821T;

    /* renamed from: U */
    public EnumC0425w f6822U;

    /* renamed from: V */
    public androidx.lifecycle.F f6823V;

    /* renamed from: W */
    public S f6824W;

    /* renamed from: X */
    public final androidx.lifecycle.N f6825X;

    /* renamed from: Y */
    public h0 f6826Y;

    /* renamed from: Z */
    public com.bumptech.glide.manager.q f6827Z;

    /* renamed from: a0 */
    public final ArrayList f6829a0;

    /* renamed from: b */
    public Bundle f6830b;

    /* renamed from: b0 */
    public final C0395o f6831b0;

    /* renamed from: c */
    public SparseArray f6832c;
    public Bundle d;

    /* renamed from: f */
    public Bundle f6834f;

    /* renamed from: n */
    public r f6835n;

    /* renamed from: p */
    public int f6837p;

    /* renamed from: r */
    public boolean f6839r;

    /* renamed from: s */
    public boolean f6840s;

    /* renamed from: t */
    public boolean f6841t;

    /* renamed from: u */
    public boolean f6842u;

    /* renamed from: v */
    public boolean f6843v;

    /* renamed from: w */
    public boolean f6844w;

    /* renamed from: x */
    public boolean f6845x;

    /* renamed from: y */
    public int f6846y;

    /* renamed from: z */
    public I f6847z;

    /* renamed from: a */
    public int f6828a = -1;

    /* renamed from: e */
    public String f6833e = UUID.randomUUID().toString();

    /* renamed from: o */
    public String f6836o = null;

    /* renamed from: q */
    public Boolean f6838q = null;

    /* renamed from: B */
    public I f6804B = new I();

    /* renamed from: J */
    public final boolean f6812J = true;

    /* renamed from: O */
    public boolean f6816O = true;

    public r() {
        new D6.G(this, 15);
        this.f6822U = EnumC0425w.f7006e;
        this.f6825X = new androidx.lifecycle.N();
        new AtomicInteger();
        this.f6829a0 = new ArrayList();
        this.f6831b0 = new C0395o(this);
        v();
    }

    public final boolean A() {
        View view;
        return (!x() || y() || (view = this.f6814M) == null || view.getWindowToken() == null || this.f6814M.getVisibility() != 0) ? false : true;
    }

    public void B(Bundle bundle) {
        this.K = true;
    }

    public void C(int i10, int i11, Intent intent) {
        if (Log.isLoggable("FragmentManager", 2)) {
            Log.v("FragmentManager", "Fragment " + this + " received the following in onActivityResult(): requestCode: " + i10 + " resultCode: " + i11 + " data: " + intent);
        }
    }

    public void D(Context context) {
        this.K = true;
        C0399t c0399t = this.f6803A;
        if ((c0399t == null ? null : c0399t.f6851a) != null) {
            this.K = true;
        }
    }

    public void E(Bundle bundle) {
        Bundle bundle2;
        this.K = true;
        Bundle bundle3 = this.f6830b;
        if (bundle3 != null && (bundle2 = bundle3.getBundle("childFragmentManager")) != null) {
            this.f6804B.U(bundle2);
            I i10 = this.f6804B;
            i10.f6634F = false;
            i10.f6635G = false;
            i10.f6640M.f6678f = false;
            i10.t(1);
        }
        I i11 = this.f6804B;
        if (i11.f6659t >= 1) {
            return;
        }
        i11.f6634F = false;
        i11.f6635G = false;
        i11.f6640M.f6678f = false;
        i11.t(1);
    }

    public View F(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        return null;
    }

    public void G() {
        this.K = true;
    }

    public void H() {
        this.K = true;
    }

    public void I() {
        this.K = true;
    }

    public LayoutInflater J(Bundle bundle) {
        C0399t c0399t = this.f6803A;
        if (c0399t == null) {
            throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
        }
        AbstractActivityC0400u abstractActivityC0400u = c0399t.f6854e;
        LayoutInflater layoutInflaterCloneInContext = abstractActivityC0400u.getLayoutInflater().cloneInContext(abstractActivityC0400u);
        layoutInflaterCloneInContext.setFactory2(this.f6804B.f6646f);
        return layoutInflaterCloneInContext;
    }

    public void K(Context context, AttributeSet attributeSet, Bundle bundle) {
        this.K = true;
        C0399t c0399t = this.f6803A;
        if ((c0399t == null ? null : c0399t.f6851a) != null) {
            this.K = true;
        }
    }

    public void L() {
        this.K = true;
    }

    public void M(int i10, String[] strArr, int[] iArr) {
    }

    public void N() {
        this.K = true;
    }

    public void O(Bundle bundle) {
    }

    public void P() {
        this.K = true;
    }

    public void Q() {
        this.K = true;
    }

    public void S(Bundle bundle) {
        this.K = true;
    }

    public void T(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f6804B.O();
        this.f6845x = true;
        this.f6824W = new S(this, f(), new RunnableC0050a(this, 20));
        View viewF = F(layoutInflater, viewGroup);
        this.f6814M = viewF;
        if (viewF == null) {
            if (this.f6824W.f6708e != null) {
                throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
            }
            this.f6824W = null;
            return;
        }
        this.f6824W.e();
        if (Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "Setting ViewLifecycleOwner on View " + this.f6814M + " for Fragment " + this);
        }
        e0.l(this.f6814M, this.f6824W);
        View view = this.f6814M;
        S s9 = this.f6824W;
        AbstractC1420h.f(view, "<this>");
        view.setTag(R.id.view_tree_view_model_store_owner, s9);
        X0.f.x(this.f6814M, this.f6824W);
        this.f6825X.k(this.f6824W);
    }

    public final void U(int i10, String[] strArr) throws Exception {
        if (this.f6803A == null) {
            throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " not attached to Activity"));
        }
        I iQ = q();
        if (iQ.f6631C == null) {
            iQ.f6660u.getClass();
            return;
        }
        iQ.f6632D.addLast(new E(this.f6833e, i10));
        iQ.f6631C.B(strArr);
    }

    public final AbstractActivityC0400u V() {
        AbstractActivityC0400u abstractActivityC0400uG = g();
        if (abstractActivityC0400uG != null) {
            return abstractActivityC0400uG;
        }
        throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " not attached to an activity."));
    }

    public final Context W() {
        Context contextN = n();
        if (contextN != null) {
            return contextN;
        }
        throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " not attached to a context."));
    }

    public final r X() {
        r rVar = this.f6805C;
        if (rVar != null) {
            return rVar;
        }
        if (n() == null) {
            throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " is not attached to any Fragment or host"));
        }
        throw new IllegalStateException("Fragment " + this + " is not a child Fragment, it is directly attached to " + n());
    }

    public final View Y() {
        View view = this.f6814M;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
    }

    public final void Z(int i10, int i11, int i12, int i13) {
        if (this.f6817P == null && i10 == 0 && i11 == 0 && i12 == 0 && i13 == 0) {
            return;
        }
        k().f6795b = i10;
        k().f6796c = i11;
        k().d = i12;
        k().f6797e = i13;
    }

    public final void a0(Bundle bundle) {
        I i10 = this.f6847z;
        if (i10 != null) {
            if (i10 == null ? false : i10.M()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.f6834f = bundle;
    }

    @Override // C0.f
    public final C0.e b() {
        return (C0.e) this.f6827Z.d;
    }

    public final boolean b0(String str) {
        C0399t c0399t = this.f6803A;
        if (c0399t == null) {
            return false;
        }
        c0399t.getClass();
        if (AbstractC0338a.C() || !TextUtils.equals("android.permission.POST_NOTIFICATIONS", str)) {
            return D.c.c(c0399t.f6854e, str);
        }
        return false;
    }

    @Override // androidx.lifecycle.r
    public final n0 c() {
        Application application;
        if (this.f6847z == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (this.f6826Y == null) {
            Context applicationContext = W().getApplicationContext();
            while (true) {
                if (!(applicationContext instanceof ContextWrapper)) {
                    application = null;
                    break;
                }
                if (applicationContext instanceof Application) {
                    application = (Application) applicationContext;
                    break;
                }
                applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
            }
            if (application == null && Log.isLoggable("FragmentManager", 3)) {
                Log.d("FragmentManager", "Could not find Application instance from Context " + W().getApplicationContext() + ", you will need CreationExtras to use AndroidViewModel with the default ViewModelProvider.Factory");
            }
            this.f6826Y = new h0(application, this, this.f6834f);
        }
        return this.f6826Y;
    }

    @Override // androidx.lifecycle.r
    public final C1196e d() {
        Application application;
        Context applicationContext = W().getApplicationContext();
        while (true) {
            if (!(applicationContext instanceof ContextWrapper)) {
                application = null;
                break;
            }
            if (applicationContext instanceof Application) {
                application = (Application) applicationContext;
                break;
            }
            applicationContext = ((ContextWrapper) applicationContext).getBaseContext();
        }
        if (application == null && Log.isLoggable("FragmentManager", 3)) {
            Log.d("FragmentManager", "Could not find Application instance from Context " + W().getApplicationContext() + ", you will not be able to use AndroidViewModel with the default ViewModelProvider.Factory");
        }
        C1196e c1196e = new C1196e(0);
        LinkedHashMap linkedHashMap = c1196e.f12974a;
        if (application != null) {
            linkedHashMap.put(l0.f6992a, application);
        }
        linkedHashMap.put(e0.f6957a, this);
        linkedHashMap.put(e0.f6958b, this);
        Bundle bundle = this.f6834f;
        if (bundle != null) {
            linkedHashMap.put(e0.f6959c, bundle);
        }
        return c1196e;
    }

    @Override // androidx.lifecycle.r0
    public final q0 f() {
        if (this.f6847z == null) {
            throw new IllegalStateException("Can't access ViewModels from detached fragment");
        }
        if (p() == 1) {
            throw new IllegalStateException("Calling getViewModelStore() before a Fragment reaches onCreate() when using setMaxLifecycle(INITIALIZED) is not supported");
        }
        HashMap map = this.f6847z.f6640M.f6676c;
        q0 q0Var = (q0) map.get(this.f6833e);
        if (q0Var != null) {
            return q0Var;
        }
        q0 q0Var2 = new q0();
        map.put(this.f6833e, q0Var2);
        return q0Var2;
    }

    @Override // androidx.lifecycle.D
    public final androidx.lifecycle.F h() {
        return this.f6823V;
    }

    public AbstractC0402w i() {
        return new C0396p(this);
    }

    public void j(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String str2;
        printWriter.print(str);
        printWriter.print("mFragmentId=#");
        printWriter.print(Integer.toHexString(this.f6806D));
        printWriter.print(" mContainerId=#");
        printWriter.print(Integer.toHexString(this.f6807E));
        printWriter.print(" mTag=");
        printWriter.println(this.f6808F);
        printWriter.print(str);
        printWriter.print("mState=");
        printWriter.print(this.f6828a);
        printWriter.print(" mWho=");
        printWriter.print(this.f6833e);
        printWriter.print(" mBackStackNesting=");
        printWriter.println(this.f6846y);
        printWriter.print(str);
        printWriter.print("mAdded=");
        printWriter.print(this.f6839r);
        printWriter.print(" mRemoving=");
        printWriter.print(this.f6840s);
        printWriter.print(" mFromLayout=");
        printWriter.print(this.f6842u);
        printWriter.print(" mInLayout=");
        printWriter.println(this.f6843v);
        printWriter.print(str);
        printWriter.print("mHidden=");
        printWriter.print(this.f6809G);
        printWriter.print(" mDetached=");
        printWriter.print(this.f6810H);
        printWriter.print(" mMenuVisible=");
        printWriter.print(this.f6812J);
        printWriter.print(" mHasMenu=");
        printWriter.println(false);
        printWriter.print(str);
        printWriter.print("mRetainInstance=");
        printWriter.print(this.f6811I);
        printWriter.print(" mUserVisibleHint=");
        printWriter.println(this.f6816O);
        if (this.f6847z != null) {
            printWriter.print(str);
            printWriter.print("mFragmentManager=");
            printWriter.println(this.f6847z);
        }
        if (this.f6803A != null) {
            printWriter.print(str);
            printWriter.print("mHost=");
            printWriter.println(this.f6803A);
        }
        if (this.f6805C != null) {
            printWriter.print(str);
            printWriter.print("mParentFragment=");
            printWriter.println(this.f6805C);
        }
        if (this.f6834f != null) {
            printWriter.print(str);
            printWriter.print("mArguments=");
            printWriter.println(this.f6834f);
        }
        if (this.f6830b != null) {
            printWriter.print(str);
            printWriter.print("mSavedFragmentState=");
            printWriter.println(this.f6830b);
        }
        if (this.f6832c != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewState=");
            printWriter.println(this.f6832c);
        }
        if (this.d != null) {
            printWriter.print(str);
            printWriter.print("mSavedViewRegistryState=");
            printWriter.println(this.d);
        }
        r rVarJ = this.f6835n;
        if (rVarJ == null) {
            I i10 = this.f6847z;
            rVarJ = (i10 == null || (str2 = this.f6836o) == null) ? null : i10.f6644c.j(str2);
        }
        if (rVarJ != null) {
            printWriter.print(str);
            printWriter.print("mTarget=");
            printWriter.print(rVarJ);
            printWriter.print(" mTargetRequestCode=");
            printWriter.println(this.f6837p);
        }
        printWriter.print(str);
        printWriter.print("mPopDirection=");
        C0397q c0397q = this.f6817P;
        printWriter.println(c0397q == null ? false : c0397q.f6794a);
        C0397q c0397q2 = this.f6817P;
        if ((c0397q2 == null ? 0 : c0397q2.f6795b) != 0) {
            printWriter.print(str);
            printWriter.print("getEnterAnim=");
            C0397q c0397q3 = this.f6817P;
            printWriter.println(c0397q3 == null ? 0 : c0397q3.f6795b);
        }
        C0397q c0397q4 = this.f6817P;
        if ((c0397q4 == null ? 0 : c0397q4.f6796c) != 0) {
            printWriter.print(str);
            printWriter.print("getExitAnim=");
            C0397q c0397q5 = this.f6817P;
            printWriter.println(c0397q5 == null ? 0 : c0397q5.f6796c);
        }
        C0397q c0397q6 = this.f6817P;
        if ((c0397q6 == null ? 0 : c0397q6.d) != 0) {
            printWriter.print(str);
            printWriter.print("getPopEnterAnim=");
            C0397q c0397q7 = this.f6817P;
            printWriter.println(c0397q7 == null ? 0 : c0397q7.d);
        }
        C0397q c0397q8 = this.f6817P;
        if ((c0397q8 == null ? 0 : c0397q8.f6797e) != 0) {
            printWriter.print(str);
            printWriter.print("getPopExitAnim=");
            C0397q c0397q9 = this.f6817P;
            printWriter.println(c0397q9 != null ? c0397q9.f6797e : 0);
        }
        if (this.f6813L != null) {
            printWriter.print(str);
            printWriter.print("mContainer=");
            printWriter.println(this.f6813L);
        }
        if (this.f6814M != null) {
            printWriter.print(str);
            printWriter.print("mView=");
            printWriter.println(this.f6814M);
        }
        if (n() != null) {
            X0.c.B(this).x(str, printWriter);
        }
        printWriter.print(str);
        printWriter.println("Child " + this.f6804B + ":");
        this.f6804B.v(android.support.v4.media.session.a.l(str, "  "), fileDescriptor, printWriter, strArr);
    }

    public final C0397q k() {
        if (this.f6817P == null) {
            C0397q c0397q = new C0397q();
            Object obj = c0;
            c0397q.g = obj;
            c0397q.f6799h = obj;
            c0397q.f6800i = obj;
            c0397q.f6801j = 1.0f;
            c0397q.f6802k = null;
            this.f6817P = c0397q;
        }
        return this.f6817P;
    }

    /* renamed from: l */
    public final AbstractActivityC0400u g() {
        C0399t c0399t = this.f6803A;
        if (c0399t == null) {
            return null;
        }
        return (AbstractActivityC0400u) c0399t.f6851a;
    }

    public final I m() {
        if (this.f6803A != null) {
            return this.f6804B;
        }
        throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " has not been attached yet."));
    }

    public final Context n() {
        C0399t c0399t = this.f6803A;
        if (c0399t == null) {
            return null;
        }
        return c0399t.f6852b;
    }

    public final LayoutInflater o() {
        LayoutInflater layoutInflater = this.f6819R;
        if (layoutInflater != null) {
            return layoutInflater;
        }
        LayoutInflater layoutInflaterJ = J(null);
        this.f6819R = layoutInflaterJ;
        return layoutInflaterJ;
    }

    @Override // android.content.ComponentCallbacks
    public final void onConfigurationChanged(Configuration configuration) {
        this.K = true;
    }

    @Override // android.view.View.OnCreateContextMenuListener
    public final void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        V().onCreateContextMenu(contextMenu, view, contextMenuInfo);
    }

    @Override // android.content.ComponentCallbacks
    public final void onLowMemory() {
        this.K = true;
    }

    public final int p() {
        EnumC0425w enumC0425w = this.f6822U;
        return (enumC0425w == EnumC0425w.f7004b || this.f6805C == null) ? enumC0425w.ordinal() : Math.min(enumC0425w.ordinal(), this.f6805C.p());
    }

    public final I q() {
        I i10 = this.f6847z;
        if (i10 != null) {
            return i10;
        }
        throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " not associated with a fragment manager."));
    }

    public final Resources r() {
        return W().getResources();
    }

    public final String s(int i10) {
        return r().getString(i10);
    }

    public final void startActivityForResult(Intent intent, int i10) {
        if (this.f6803A == null) {
            throw new IllegalStateException(android.support.v4.media.session.a.k("Fragment ", this, " not attached to Activity"));
        }
        I iQ = q();
        if (iQ.f6629A != null) {
            iQ.f6632D.addLast(new E(this.f6833e, i10));
            iQ.f6629A.B(intent);
        } else {
            C0399t c0399t = iQ.f6660u;
            if (i10 == -1) {
                E.j.startActivity(c0399t.f6852b, intent, null);
            } else {
                c0399t.getClass();
                throw new IllegalStateException("Starting activity with a requestCode requires a FragmentActivity host");
            }
        }
    }

    public final String t(int i10, Object... objArr) {
        return r().getString(i10, objArr);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("} (");
        sb.append(this.f6833e);
        if (this.f6806D != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f6806D));
        }
        if (this.f6808F != null) {
            sb.append(" tag=");
            sb.append(this.f6808F);
        }
        sb.append(")");
        return sb.toString();
    }

    public final S u() {
        S s9 = this.f6824W;
        if (s9 != null) {
            return s9;
        }
        throw new IllegalStateException(android.support.v4.media.session.a.k("Can't access the Fragment View's LifecycleOwner for ", this, " when getView() is null i.e., before onCreateView() or after onDestroyView()"));
    }

    public final void v() {
        this.f6823V = new androidx.lifecycle.F(this);
        this.f6827Z = new com.bumptech.glide.manager.q(this);
        this.f6826Y = null;
        ArrayList arrayList = this.f6829a0;
        C0395o c0395o = this.f6831b0;
        if (arrayList.contains(c0395o)) {
            return;
        }
        if (this.f6828a < 0) {
            arrayList.add(c0395o);
            return;
        }
        r rVar = c0395o.f6792a;
        rVar.f6827Z.h();
        e0.g(rVar);
        Bundle bundle = rVar.f6830b;
        rVar.f6827Z.i(bundle != null ? bundle.getBundle("registryState") : null);
    }

    public final void w() {
        v();
        this.f6821T = this.f6833e;
        this.f6833e = UUID.randomUUID().toString();
        this.f6839r = false;
        this.f6840s = false;
        this.f6842u = false;
        this.f6843v = false;
        this.f6844w = false;
        this.f6846y = 0;
        this.f6847z = null;
        this.f6804B = new I();
        this.f6803A = null;
        this.f6806D = 0;
        this.f6807E = 0;
        this.f6808F = null;
        this.f6809G = false;
        this.f6810H = false;
    }

    public final boolean x() {
        return this.f6803A != null && this.f6839r;
    }

    public final boolean y() {
        if (!this.f6809G) {
            I i10 = this.f6847z;
            if (i10 == null) {
                return false;
            }
            r rVar = this.f6805C;
            i10.getClass();
            if (!(rVar == null ? false : rVar.y())) {
                return false;
            }
        }
        return true;
    }

    public final boolean z() {
        return this.f6846y > 0;
    }

    public void R(View view) {
    }
}
