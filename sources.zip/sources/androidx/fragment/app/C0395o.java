package androidx.fragment.app;

/* renamed from: androidx.fragment.app.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0395o {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ r f6792a;

    public C0395o(r rVar) {
        this.f6792a = rVar;
    }
}
