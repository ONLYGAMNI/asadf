package androidx.fragment.app;

import android.view.View;

/* renamed from: androidx.fragment.app.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0402w {
    public abstract View c(int i10);

    public abstract boolean d();
}
