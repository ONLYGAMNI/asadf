package androidx.profileinstaller;

import G0.b;
import android.content.Context;
import android.os.Build;
import b3.f;
import java.util.Collections;
import java.util.List;
import x0.AbstractC1627h;
import x0.RunnableC1625f;

/* loaded from: classes.dex */
public class ProfileInstallerInitializer implements b {
    @Override // G0.b
    public final List a() {
        return Collections.emptyList();
    }

    @Override // G0.b
    public final Object b(Context context) {
        if (Build.VERSION.SDK_INT < 24) {
            return new f(26);
        }
        AbstractC1627h.a(new RunnableC1625f(0, this, context.getApplicationContext()));
        return new f(26);
    }
}
