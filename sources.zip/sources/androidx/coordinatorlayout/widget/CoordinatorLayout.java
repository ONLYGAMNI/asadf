package androidx.coordinatorlayout.widget;

import A.a;
import B.b;
import B.c;
import B.d;
import B.e;
import B.g;
import B.h;
import B.j;
import B.k;
import B.l;
import E5.E;
import Q.f;
import R.AbstractC0252k;
import R.B0;
import R.C0260t;
import R.F;
import R.I;
import R.InterfaceC0259s;
import R.K;
import R.X;
import R.r;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import com.tajir.tajir.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.WeakHashMap;
import r.C1338l;

/* loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements r, InterfaceC0259s {

    /* renamed from: A */
    public static final String f6348A;

    /* renamed from: B */
    public static final Class[] f6349B;

    /* renamed from: C */
    public static final ThreadLocal f6350C;

    /* renamed from: D */
    public static final k f6351D;

    /* renamed from: E */
    public static final f f6352E;

    /* renamed from: a */
    public final ArrayList f6353a;

    /* renamed from: b */
    public final E f6354b;

    /* renamed from: c */
    public final ArrayList f6355c;
    public final ArrayList d;

    /* renamed from: e */
    public final int[] f6356e;

    /* renamed from: f */
    public final int[] f6357f;

    /* renamed from: n */
    public boolean f6358n;

    /* renamed from: o */
    public boolean f6359o;

    /* renamed from: p */
    public final int[] f6360p;

    /* renamed from: q */
    public View f6361q;

    /* renamed from: r */
    public View f6362r;

    /* renamed from: s */
    public h f6363s;

    /* renamed from: t */
    public boolean f6364t;

    /* renamed from: u */
    public B0 f6365u;

    /* renamed from: v */
    public boolean f6366v;

    /* renamed from: w */
    public Drawable f6367w;

    /* renamed from: x */
    public ViewGroup.OnHierarchyChangeListener f6368x;

    /* renamed from: y */
    public b f6369y;

    /* renamed from: z */
    public final C0260t f6370z;

    static {
        Package r12 = CoordinatorLayout.class.getPackage();
        f6348A = r12 != null ? r12.getName() : null;
        f6351D = new k(0);
        f6349B = new Class[]{Context.class, AttributeSet.class};
        f6350C = new ThreadLocal();
        f6352E = new f(12);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) throws Resources.NotFoundException {
        super(context, attributeSet, R.attr.coordinatorLayoutStyle);
        this.f6353a = new ArrayList();
        this.f6354b = new E(1);
        this.f6355c = new ArrayList();
        this.d = new ArrayList();
        this.f6356e = new int[2];
        this.f6357f = new int[2];
        this.f6370z = new C0260t();
        int[] iArr = a.f0a;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, R.attr.coordinatorLayoutStyle, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, iArr, attributeSet, typedArrayObtainStyledAttributes, R.attr.coordinatorLayoutStyle, 0);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            int[] intArray = resources.getIntArray(resourceId);
            this.f6360p = intArray;
            float f10 = resources.getDisplayMetrics().density;
            int length = intArray.length;
            for (int i10 = 0; i10 < length; i10++) {
                this.f6360p[i10] = (int) (r2[i10] * f10);
            }
        }
        this.f6367w = typedArrayObtainStyledAttributes.getDrawable(1);
        typedArrayObtainStyledAttributes.recycle();
        y();
        super.setOnHierarchyChangeListener(new B.f(this));
        WeakHashMap weakHashMap = X.f3966a;
        if (R.E.c(this) == 0) {
            R.E.s(this, 1);
        }
    }

    public static Rect g() {
        Rect rect = (Rect) f6352E.l();
        return rect == null ? new Rect() : rect;
    }

    public static void m(int i10, Rect rect, Rect rect2, g gVar, int i11, int i12) {
        int i13 = gVar.f69c;
        if (i13 == 0) {
            i13 = 17;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i13, i10);
        int i14 = gVar.d;
        if ((i14 & 7) == 0) {
            i14 |= 8388611;
        }
        if ((i14 & 112) == 0) {
            i14 |= 48;
        }
        int absoluteGravity2 = Gravity.getAbsoluteGravity(i14, i10);
        int i15 = absoluteGravity & 7;
        int i16 = absoluteGravity & 112;
        int i17 = absoluteGravity2 & 7;
        int i18 = absoluteGravity2 & 112;
        int iWidth = i17 != 1 ? i17 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int iHeight = i18 != 16 ? i18 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i15 == 1) {
            iWidth -= i11 / 2;
        } else if (i15 != 5) {
            iWidth -= i11;
        }
        if (i16 == 16) {
            iHeight -= i12 / 2;
        } else if (i16 != 80) {
            iHeight -= i12;
        }
        rect2.set(iWidth, iHeight, i11 + iWidth, i12 + iHeight);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static g o(View view) {
        g gVar = (g) view.getLayoutParams();
        if (!gVar.f68b) {
            if (view instanceof c) {
                d behavior = ((c) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                gVar.b(behavior);
                gVar.f68b = true;
            } else {
                e eVar = null;
                for (Class<?> superclass = view.getClass(); superclass != null; superclass = superclass.getSuperclass()) {
                    eVar = (e) superclass.getAnnotation(e.class);
                    if (eVar != null) {
                        break;
                    }
                }
                if (eVar != null) {
                    try {
                        gVar.b((d) eVar.value().getDeclaredConstructor(null).newInstance(null));
                    } catch (Exception e4) {
                        Log.e("CoordinatorLayout", "Default behavior class " + eVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e4);
                    }
                }
                gVar.f68b = true;
            }
        }
        return gVar;
    }

    public static void w(View view, int i10) {
        g gVar = (g) view.getLayoutParams();
        int i11 = gVar.f73i;
        if (i11 != i10) {
            WeakHashMap weakHashMap = X.f3966a;
            view.offsetLeftAndRight(i10 - i11);
            gVar.f73i = i10;
        }
    }

    public static void x(View view, int i10) {
        g gVar = (g) view.getLayoutParams();
        int i11 = gVar.f74j;
        if (i11 != i10) {
            WeakHashMap weakHashMap = X.f3966a;
            view.offsetTopAndBottom(i10 - i11);
            gVar.f74j = i10;
        }
    }

    @Override // R.r
    public final void a(View view, View view2, int i10, int i11) {
        C0260t c0260t = this.f6370z;
        if (i11 == 1) {
            c0260t.f4013b = i10;
        } else {
            c0260t.f4012a = i10;
        }
        this.f6362r = view2;
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            ((g) getChildAt(i12).getLayoutParams()).getClass();
        }
    }

    @Override // R.r
    public final void b(View view, int i10) {
        C0260t c0260t = this.f6370z;
        if (i10 == 1) {
            c0260t.f4013b = 0;
        } else {
            c0260t.f4012a = 0;
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            g gVar = (g) childAt.getLayoutParams();
            if (gVar.a(i10)) {
                d dVar = gVar.f67a;
                if (dVar != null) {
                    dVar.u(this, childAt, view, i10);
                }
                if (i10 == 0) {
                    gVar.f78n = false;
                } else if (i10 == 1) {
                    gVar.f79o = false;
                }
                gVar.f80p = false;
            }
        }
        this.f6362r = null;
    }

    @Override // R.r
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        d dVar;
        int childCount = getChildCount();
        boolean z3 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a(i12) && (dVar = gVar.f67a) != null) {
                    int[] iArr2 = this.f6356e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    dVar.o(this, childAt, view, i10, i11, iArr2, i12);
                    int[] iArr3 = this.f6356e;
                    iMax = i10 > 0 ? Math.max(iMax, iArr3[0]) : Math.min(iMax, iArr3[0]);
                    iMax2 = i11 > 0 ? Math.max(iMax2, iArr3[1]) : Math.min(iMax2, iArr3[1]);
                    z3 = true;
                }
            }
        }
        iArr[0] = iMax;
        iArr[1] = iMax2;
        if (z3) {
            q(1);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof g) && super.checkLayoutParams(layoutParams);
    }

    @Override // R.InterfaceC0259s
    public final void d(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        d dVar;
        int childCount = getChildCount();
        boolean z3 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt = getChildAt(i15);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a(i14) && (dVar = gVar.f67a) != null) {
                    int[] iArr2 = this.f6356e;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    dVar.p(this, childAt, i11, i12, i13, iArr2);
                    iMax = i12 > 0 ? Math.max(iMax, iArr2[0]) : Math.min(iMax, iArr2[0]);
                    iMax2 = i13 > 0 ? Math.max(iMax2, iArr2[1]) : Math.min(iMax2, iArr2[1]);
                    z3 = true;
                }
            }
        }
        iArr[0] = iArr[0] + iMax;
        iArr[1] = iArr[1] + iMax2;
        if (z3) {
            q(1);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j10) {
        d dVar = ((g) view.getLayoutParams()).f67a;
        if (dVar != null) {
            dVar.getClass();
        }
        return super.drawChild(canvas, view, j10);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f6367w;
        if ((drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState)) {
            invalidate();
        }
    }

    @Override // R.r
    public final void e(View view, int i10, int i11, int i12, int i13, int i14) {
        d(view, i10, i11, i12, i13, 0, this.f6357f);
    }

    @Override // R.r
    public final boolean f(View view, View view2, int i10, int i11) {
        int childCount = getChildCount();
        boolean z3 = false;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                d dVar = gVar.f67a;
                if (dVar != null) {
                    boolean zT = dVar.t(this, childAt, view, i10, i11);
                    z3 |= zT;
                    if (i11 == 0) {
                        gVar.f78n = zT;
                    } else if (i11 == 1) {
                        gVar.f79o = zT;
                    }
                } else if (i11 == 0) {
                    gVar.f78n = false;
                } else if (i11 == 1) {
                    gVar.f79o = false;
                }
            }
        }
        return z3;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new g();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new g(getContext(), attributeSet);
    }

    public final List<View> getDependencySortedChildren() {
        u();
        return Collections.unmodifiableList(this.f6353a);
    }

    public final B0 getLastWindowInsets() {
        return this.f6365u;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0260t c0260t = this.f6370z;
        return c0260t.f4013b | c0260t.f4012a;
    }

    public Drawable getStatusBarBackground() {
        return this.f6367w;
    }

    @Override // android.view.View
    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    @Override // android.view.View
    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    public final void h(g gVar, Rect rect, int i10, int i11) {
        int width = getWidth();
        int height = getHeight();
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) gVar).leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i10) - ((ViewGroup.MarginLayoutParams) gVar).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar).topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i11) - ((ViewGroup.MarginLayoutParams) gVar).bottomMargin));
        rect.set(iMax, iMax2, i10 + iMax, i11 + iMax2);
    }

    public final void i(View view) {
        List list = (List) ((C1338l) this.f6354b.f699c).getOrDefault(view, null);
        if (list == null || list.isEmpty()) {
            return;
        }
        for (int i10 = 0; i10 < list.size(); i10++) {
            View view2 = (View) list.get(i10);
            d dVar = ((g) view2.getLayoutParams()).f67a;
            if (dVar != null) {
                dVar.h(this, view2, view);
            }
        }
    }

    public final void j(View view, Rect rect, boolean z3) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z3) {
            l(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public final ArrayList k(View view) {
        C1338l c1338l = (C1338l) this.f6354b.f699c;
        int i10 = c1338l.f14616c;
        ArrayList arrayList = null;
        for (int i11 = 0; i11 < i10; i11++) {
            ArrayList arrayList2 = (ArrayList) c1338l.m(i11);
            if (arrayList2 != null && arrayList2.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(c1338l.i(i11));
            }
        }
        ArrayList arrayList3 = this.d;
        arrayList3.clear();
        if (arrayList != null) {
            arrayList3.addAll(arrayList);
        }
        return arrayList3;
    }

    public final void l(View view, Rect rect) {
        ThreadLocal threadLocal = l.f87a;
        rect.set(0, 0, view.getWidth(), view.getHeight());
        ThreadLocal threadLocal2 = l.f87a;
        Matrix matrix = (Matrix) threadLocal2.get();
        if (matrix == null) {
            matrix = new Matrix();
            threadLocal2.set(matrix);
        } else {
            matrix.reset();
        }
        l.a(this, view, matrix);
        ThreadLocal threadLocal3 = l.f88b;
        RectF rectF = (RectF) threadLocal3.get();
        if (rectF == null) {
            rectF = new RectF();
            threadLocal3.set(rectF);
        }
        rectF.set(rect);
        matrix.mapRect(rectF);
        rect.set((int) (rectF.left + 0.5f), (int) (rectF.top + 0.5f), (int) (rectF.right + 0.5f), (int) (rectF.bottom + 0.5f));
    }

    public final int n(int i10) {
        int[] iArr = this.f6360p;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i10);
            return 0;
        }
        if (i10 >= 0 && i10 < iArr.length) {
            return iArr[i10];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i10 + " out of range for " + this);
        return 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        v(false);
        if (this.f6364t) {
            if (this.f6363s == null) {
                this.f6363s = new h(this, 0);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f6363s);
        }
        if (this.f6365u == null) {
            WeakHashMap weakHashMap = X.f3966a;
            if (R.E.b(this)) {
                I.c(this);
            }
        }
        this.f6359o = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        v(false);
        if (this.f6364t && this.f6363s != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f6363s);
        }
        View view = this.f6362r;
        if (view != null) {
            b(view, 0);
        }
        this.f6359o = false;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f6366v || this.f6367w == null) {
            return;
        }
        B0 b02 = this.f6365u;
        int iD = b02 != null ? b02.d() : 0;
        if (iD > 0) {
            this.f6367w.setBounds(0, 0, getWidth(), iD);
            this.f6367w.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            v(true);
        }
        boolean zT = t(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            v(true);
        }
        return zT;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        d dVar;
        WeakHashMap weakHashMap = X.f3966a;
        int iD = F.d(this);
        ArrayList arrayList = this.f6353a;
        int size = arrayList.size();
        for (int i14 = 0; i14 < size; i14++) {
            View view = (View) arrayList.get(i14);
            if (view.getVisibility() != 8 && ((dVar = ((g) view.getLayoutParams()).f67a) == null || !dVar.l(this, view, iD))) {
                r(view, iD);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:164:0x0159  */
    /* JADX WARN: Removed duplicated region for block: B:167:0x0163  */
    /* JADX WARN: Removed duplicated region for block: B:170:0x0189  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onMeasure(int r32, int r33) {
        /*
            Method dump skipped, instructions count: 513
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a(0)) {
                    d dVar = gVar.f67a;
                }
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        d dVar;
        int childCount = getChildCount();
        boolean zN = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                g gVar = (g) childAt.getLayoutParams();
                if (gVar.a(0) && (dVar = gVar.f67a) != null) {
                    zN |= dVar.n(view);
                }
            }
        }
        return zN;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
        c(view, i10, i11, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        e(view, i10, i11, i12, i13, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        a(view, view2, i10, 0);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof j)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        j jVar = (j) parcelable;
        super.onRestoreInstanceState(jVar.f5637a);
        SparseArray sparseArray = jVar.f85c;
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id = childAt.getId();
            d dVar = o(childAt).f67a;
            if (id != -1 && dVar != null && (parcelable2 = (Parcelable) sparseArray.get(id)) != null) {
                dVar.r(childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        Parcelable parcelableS;
        j jVar = new j(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id = childAt.getId();
            d dVar = ((g) childAt.getLayoutParams()).f67a;
            if (id != -1 && dVar != null && (parcelableS = dVar.s(childAt)) != null) {
                sparseArray.append(id, parcelableS);
            }
        }
        jVar.f85c = sparseArray;
        return jVar;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        return f(view, view2, i10, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        b(view, 0);
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0015 A[PHI: r3
  0x0015: PHI (r3v4 boolean) = (r3v2 boolean), (r3v5 boolean) binds: [B:34:0x0022, B:29:0x0012] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:38:0x002f  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x0035  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0052  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.getActionMasked()
            android.view.View r3 = r0.f6361q
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L17
            boolean r3 = r0.t(r1, r4)
            if (r3 == 0) goto L15
            goto L18
        L15:
            r6 = r5
            goto L2a
        L17:
            r3 = r5
        L18:
            android.view.View r6 = r0.f6361q
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            B.g r6 = (B.g) r6
            B.d r6 = r6.f67a
            if (r6 == 0) goto L15
            android.view.View r7 = r0.f6361q
            boolean r6 = r6.v(r0, r7, r1)
        L2a:
            android.view.View r7 = r0.f6361q
            r8 = 0
            if (r7 != 0) goto L35
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L48
        L35:
            if (r3 == 0) goto L48
            long r11 = android.os.SystemClock.uptimeMillis()
            r15 = 0
            r16 = 0
            r13 = 3
            r14 = 0
            r9 = r11
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L48:
            if (r8 == 0) goto L4d
            r8.recycle()
        L4d:
            if (r2 == r4) goto L52
            r1 = 3
            if (r2 != r1) goto L55
        L52:
            r0.v(r5)
        L55:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final boolean p(View view, int i10, int i11) {
        f fVar = f6352E;
        Rect rectG = g();
        l(view, rectG);
        try {
            return rectG.contains(i10, i11);
        } finally {
            rectG.setEmpty();
            fVar.e(rectG);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:185:0x00e5  */
    /* JADX WARN: Removed duplicated region for block: B:262:0x029b  */
    /* JADX WARN: Removed duplicated region for block: B:265:0x02a7  */
    /* JADX WARN: Removed duplicated region for block: B:270:0x02cd  */
    /* JADX WARN: Removed duplicated region for block: B:274:0x02d8  */
    /* JADX WARN: Removed duplicated region for block: B:296:0x0044 A[EDGE_INSN: B:296:0x0044->B:160:0x0044 BREAK  A[LOOP:2: B:272:0x02d4->B:289:0x030d], SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void q(int r26) {
        /*
            Method dump skipped, instructions count: 824
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.q(int):void");
    }

    public final void r(View view, int i10) {
        Rect rectG;
        Rect rectG2;
        g gVar = (g) view.getLayoutParams();
        View view2 = gVar.f75k;
        if (view2 == null && gVar.f71f != -1) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        f fVar = f6352E;
        if (view2 != null) {
            rectG = g();
            rectG2 = g();
            try {
                l(view2, rectG);
                g gVar2 = (g) view.getLayoutParams();
                int measuredWidth = view.getMeasuredWidth();
                int measuredHeight = view.getMeasuredHeight();
                m(i10, rectG, rectG2, gVar2, measuredWidth, measuredHeight);
                h(gVar2, rectG2, measuredWidth, measuredHeight);
                view.layout(rectG2.left, rectG2.top, rectG2.right, rectG2.bottom);
                return;
            } finally {
                rectG.setEmpty();
                fVar.e(rectG);
                rectG2.setEmpty();
                fVar.e(rectG2);
            }
        }
        int i11 = gVar.f70e;
        if (i11 < 0) {
            g gVar3 = (g) view.getLayoutParams();
            rectG = g();
            rectG.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) gVar3).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar3).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) gVar3).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) gVar3).bottomMargin);
            if (this.f6365u != null) {
                WeakHashMap weakHashMap = X.f3966a;
                if (R.E.b(this) && !R.E.b(view)) {
                    rectG.left = this.f6365u.b() + rectG.left;
                    rectG.top = this.f6365u.d() + rectG.top;
                    rectG.right -= this.f6365u.c();
                    rectG.bottom -= this.f6365u.a();
                }
            }
            rectG2 = g();
            int i12 = gVar3.f69c;
            if ((i12 & 7) == 0) {
                i12 |= 8388611;
            }
            if ((i12 & 112) == 0) {
                i12 |= 48;
            }
            AbstractC0252k.b(i12, view.getMeasuredWidth(), view.getMeasuredHeight(), rectG, rectG2, i10);
            view.layout(rectG2.left, rectG2.top, rectG2.right, rectG2.bottom);
            return;
        }
        g gVar4 = (g) view.getLayoutParams();
        int i13 = gVar4.f69c;
        if (i13 == 0) {
            i13 = 8388661;
        }
        int absoluteGravity = Gravity.getAbsoluteGravity(i13, i10);
        int i14 = absoluteGravity & 7;
        int i15 = absoluteGravity & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth2 = view.getMeasuredWidth();
        int measuredHeight2 = view.getMeasuredHeight();
        if (i10 == 1) {
            i11 = width - i11;
        }
        int iN = n(i11) - measuredWidth2;
        if (i14 == 1) {
            iN += measuredWidth2 / 2;
        } else if (i14 == 5) {
            iN += measuredWidth2;
        }
        int i16 = i15 != 16 ? i15 != 80 ? 0 : measuredHeight2 : measuredHeight2 / 2;
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) gVar4).leftMargin, Math.min(iN, ((width - getPaddingRight()) - measuredWidth2) - ((ViewGroup.MarginLayoutParams) gVar4).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) gVar4).topMargin, Math.min(i16, ((height - getPaddingBottom()) - measuredHeight2) - ((ViewGroup.MarginLayoutParams) gVar4).bottomMargin));
        view.layout(iMax, iMax2, measuredWidth2 + iMax, measuredHeight2 + iMax2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z3) {
        d dVar = ((g) view.getLayoutParams()).f67a;
        if (dVar == null || !dVar.q(this, view, rect, z3)) {
            return super.requestChildRectangleOnScreen(view, rect, z3);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z3) {
        super.requestDisallowInterceptTouchEvent(z3);
        if (!z3 || this.f6358n) {
            return;
        }
        v(false);
        this.f6358n = true;
    }

    public final void s(View view, int i10, int i11, int i12) {
        measureChildWithMargins(view, i10, i11, i12, 0);
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z3) {
        super.setFitsSystemWindows(z3);
        y();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f6368x = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f6367w;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f6367w = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f6367w.setState(getDrawableState());
                }
                Drawable drawable3 = this.f6367w;
                WeakHashMap weakHashMap = X.f3966a;
                I.c.b(drawable3, F.d(this));
                this.f6367w.setVisible(getVisibility() == 0, false);
                this.f6367w.setCallback(this);
            }
            WeakHashMap weakHashMap2 = X.f3966a;
            R.E.k(this);
        }
    }

    public void setStatusBarBackgroundColor(int i10) {
        setStatusBarBackground(new ColorDrawable(i10));
    }

    public void setStatusBarBackgroundResource(int i10) {
        setStatusBarBackground(i10 != 0 ? E.j.getDrawable(getContext(), i10) : null);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z3 = i10 == 0;
        Drawable drawable = this.f6367w;
        if (drawable == null || drawable.isVisible() == z3) {
            return;
        }
        this.f6367w.setVisible(z3, false);
    }

    public final boolean t(MotionEvent motionEvent, int i10) {
        boolean z3;
        int actionMasked = motionEvent.getActionMasked();
        ArrayList arrayList = this.f6355c;
        arrayList.clear();
        boolean zIsChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i11 = childCount - 1; i11 >= 0; i11--) {
            arrayList.add(getChildAt(zIsChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i11) : i11));
        }
        k kVar = f6351D;
        if (kVar != null) {
            Collections.sort(arrayList, kVar);
        }
        int size = arrayList.size();
        MotionEvent motionEventObtain = null;
        boolean zK = false;
        boolean z9 = false;
        for (int i12 = 0; i12 < size; i12++) {
            View view = (View) arrayList.get(i12);
            g gVar = (g) view.getLayoutParams();
            d dVar = gVar.f67a;
            if (!(zK || z9) || actionMasked == 0) {
                if (!zK && dVar != null) {
                    if (i10 == 0) {
                        zK = dVar.k(this, view, motionEvent);
                    } else if (i10 == 1) {
                        zK = dVar.v(this, view, motionEvent);
                    }
                    if (zK) {
                        this.f6361q = view;
                    }
                }
                if (gVar.f67a == null) {
                    gVar.f77m = false;
                }
                boolean z10 = gVar.f77m;
                if (z10) {
                    z3 = true;
                } else {
                    gVar.f77m = z10;
                    z3 = z10;
                }
                z9 = z3 && !z10;
                if (z3 && !z9) {
                    break;
                }
            } else if (dVar != null) {
                if (motionEventObtain == null) {
                    long jUptimeMillis = SystemClock.uptimeMillis();
                    motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i10 == 0) {
                    dVar.k(this, view, motionEventObtain);
                } else if (i10 == 1) {
                    dVar.v(this, view, motionEventObtain);
                }
            }
        }
        arrayList.clear();
        return zK;
    }

    /* JADX WARN: Removed duplicated region for block: B:159:0x007c  */
    /* JADX WARN: Removed duplicated region for block: B:179:0x00bd  */
    /* JADX WARN: Removed duplicated region for block: B:200:0x0106  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void u() {
        /*
            Method dump skipped, instructions count: 402
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.u():void");
    }

    public final void v(boolean z3) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            d dVar = ((g) childAt.getLayoutParams()).f67a;
            if (dVar != null) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z3) {
                    dVar.k(this, childAt, motionEventObtain);
                } else {
                    dVar.v(this, childAt, motionEventObtain);
                }
                motionEventObtain.recycle();
            }
        }
        for (int i11 = 0; i11 < childCount; i11++) {
            ((g) getChildAt(i11).getLayoutParams()).f77m = false;
        }
        this.f6361q = null;
        this.f6358n = false;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f6367w;
    }

    public final void y() {
        WeakHashMap weakHashMap = X.f3966a;
        if (!R.E.b(this)) {
            K.u(this, null);
            return;
        }
        if (this.f6369y == null) {
            this.f6369y = new b(this, 0);
        }
        K.u(this, this.f6369y);
        setSystemUiVisibility(1280);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof g ? new g((g) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new g((ViewGroup.MarginLayoutParams) layoutParams) : new g(layoutParams);
    }
}
