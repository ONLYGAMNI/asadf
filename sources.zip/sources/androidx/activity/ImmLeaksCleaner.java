package androidx.activity;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0424v;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
final class ImmLeaksCleaner implements androidx.lifecycle.B {

    /* renamed from: b, reason: collision with root package name */
    public static int f5991b;

    /* renamed from: c, reason: collision with root package name */
    public static Field f5992c;
    public static Field d;

    /* renamed from: e, reason: collision with root package name */
    public static Field f5993e;

    /* renamed from: a, reason: collision with root package name */
    public Activity f5994a;

    @Override // androidx.lifecycle.B
    public final void d(D d10, EnumC0424v enumC0424v) throws IllegalAccessException, NoSuchFieldException, SecurityException, IllegalArgumentException {
        if (enumC0424v != EnumC0424v.ON_DESTROY) {
            return;
        }
        if (f5991b == 0) {
            try {
                f5991b = 2;
                Field declaredField = InputMethodManager.class.getDeclaredField("mServedView");
                d = declaredField;
                declaredField.setAccessible(true);
                Field declaredField2 = InputMethodManager.class.getDeclaredField("mNextServedView");
                f5993e = declaredField2;
                declaredField2.setAccessible(true);
                Field declaredField3 = InputMethodManager.class.getDeclaredField("mH");
                f5992c = declaredField3;
                declaredField3.setAccessible(true);
                f5991b = 1;
            } catch (NoSuchFieldException unused) {
            }
        }
        if (f5991b == 1) {
            InputMethodManager inputMethodManager = (InputMethodManager) this.f5994a.getSystemService("input_method");
            try {
                Object obj = f5992c.get(inputMethodManager);
                if (obj == null) {
                    return;
                }
                synchronized (obj) {
                    try {
                        try {
                            View view = (View) d.get(inputMethodManager);
                            if (view == null) {
                                return;
                            }
                            if (view.isAttachedToWindow()) {
                                return;
                            }
                            try {
                                f5993e.set(inputMethodManager, null);
                                inputMethodManager.isActive();
                            } catch (IllegalAccessException unused2) {
                            }
                        } catch (ClassCastException unused3) {
                        } catch (IllegalAccessException unused4) {
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            } catch (IllegalAccessException unused5) {
            }
        }
    }
}
