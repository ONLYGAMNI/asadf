package androidx.activity;

import android.os.Build;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0425w;
import androidx.lifecycle.F;
import f8.C0840h;
import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    public final Runnable f6061a;

    /* renamed from: b, reason: collision with root package name */
    public final C0840h f6062b = new C0840h();

    /* renamed from: c, reason: collision with root package name */
    public q f6063c;
    public final OnBackInvokedCallback d;

    /* renamed from: e, reason: collision with root package name */
    public OnBackInvokedDispatcher f6064e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f6065f;
    public boolean g;

    public z(Runnable runnable) {
        this.f6061a = runnable;
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 33) {
            this.d = i10 >= 34 ? w.f6057a.a(new r(this, 0), new r(this, 1), new s(this, 0), new s(this, 1)) : u.f6053a.a(new s(this, 2));
        }
    }

    public final void a(D d, q qVar) {
        AbstractC1420h.f(d, "owner");
        AbstractC1420h.f(qVar, "onBackPressedCallback");
        F fH = d.h();
        if (fH.d == EnumC0425w.f7003a) {
            return;
        }
        qVar.f6038b.add(new OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(this, fH, qVar));
        d();
        qVar.f6039c = new y(0, this, z.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0, 0);
    }

    public final void b() {
        Object objPrevious;
        C0840h c0840h = this.f6062b;
        ListIterator<E> listIterator = c0840h.listIterator(c0840h.size());
        while (true) {
            if (!listIterator.hasPrevious()) {
                objPrevious = null;
                break;
            } else {
                objPrevious = listIterator.previous();
                if (((q) objPrevious).f6037a) {
                    break;
                }
            }
        }
        q qVar = (q) objPrevious;
        this.f6063c = null;
        if (qVar != null) {
            qVar.a();
            return;
        }
        Runnable runnable = this.f6061a;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void c(boolean z3) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f6064e;
        OnBackInvokedCallback onBackInvokedCallback = this.d;
        if (onBackInvokedDispatcher == null || onBackInvokedCallback == null) {
            return;
        }
        u uVar = u.f6053a;
        if (z3 && !this.f6065f) {
            uVar.b(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.f6065f = true;
        } else {
            if (z3 || !this.f6065f) {
                return;
            }
            uVar.c(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f6065f = false;
        }
    }

    public final void d() {
        boolean z3 = this.g;
        C0840h c0840h = this.f6062b;
        boolean z9 = false;
        if (!(c0840h instanceof Collection) || !c0840h.isEmpty()) {
            Iterator<E> it = c0840h.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                } else if (((q) it.next()).f6037a) {
                    z9 = true;
                    break;
                }
            }
        }
        this.g = z9;
        if (z9 == z3 || Build.VERSION.SDK_INT < 33) {
            return;
        }
        c(z9);
    }
}
