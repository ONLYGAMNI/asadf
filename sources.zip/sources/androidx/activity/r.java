package androidx.activity;

import e8.C0803o;
import f8.C0840h;
import java.util.ListIterator;
import s8.AbstractC1420h;
import s8.AbstractC1421i;

/* loaded from: classes.dex */
public final class r extends AbstractC1421i implements r8.l {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6040a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ z f6041b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ r(z zVar, int i10) {
        super(1);
        this.f6040a = i10;
        this.f6041b = zVar;
    }

    @Override // r8.l
    public final Object invoke(Object obj) {
        Object objPrevious;
        Object objPrevious2;
        switch (this.f6040a) {
            case 0:
                AbstractC1420h.f((C0354b) obj, "backEvent");
                z zVar = this.f6041b;
                C0840h c0840h = zVar.f6062b;
                ListIterator listIterator = c0840h.listIterator(c0840h.size());
                while (true) {
                    if (listIterator.hasPrevious()) {
                        objPrevious = listIterator.previous();
                        if (((q) objPrevious).f6037a) {
                        }
                    } else {
                        objPrevious = null;
                    }
                }
                zVar.f6063c = (q) objPrevious;
                break;
            default:
                AbstractC1420h.f((C0354b) obj, "backEvent");
                C0840h c0840h2 = this.f6041b.f6062b;
                ListIterator listIterator2 = c0840h2.listIterator(c0840h2.size());
                while (true) {
                    if (listIterator2.hasPrevious()) {
                        objPrevious2 = listIterator2.previous();
                        if (((q) objPrevious2).f6037a) {
                        }
                    } else {
                        objPrevious2 = null;
                    }
                }
                break;
        }
        return C0803o.f10326a;
    }
}
