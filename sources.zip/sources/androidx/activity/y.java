package androidx.activity;

import e8.C0803o;
import r8.InterfaceC1379a;
import s8.AbstractC1419g;

/* loaded from: classes.dex */
public final /* synthetic */ class y extends AbstractC1419g implements InterfaceC1379a {

    /* renamed from: p, reason: collision with root package name */
    public final /* synthetic */ int f6060p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ y(int i10, Object obj, Class cls, String str, String str2, int i11, int i12) {
        super(i10, obj, cls, str, str2, i11);
        this.f6060p = i12;
    }

    @Override // r8.InterfaceC1379a
    public final Object invoke() {
        switch (this.f6060p) {
            case 0:
                ((z) this.f14960b).d();
                break;
            default:
                ((z) this.f14960b).d();
                break;
        }
        return C0803o.f10326a;
    }
}
