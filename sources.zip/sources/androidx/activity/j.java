package androidx.activity;

import D.RunnableC0050a;
import D6.G;
import R.InterfaceC0255n;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Trace;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.fragment.app.AbstractActivityC0400u;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0424v;
import androidx.lifecycle.EnumC0425w;
import androidx.lifecycle.F;
import androidx.lifecycle.b0;
import androidx.lifecycle.e0;
import androidx.lifecycle.h0;
import androidx.lifecycle.l0;
import androidx.lifecycle.n0;
import androidx.lifecycle.q0;
import androidx.lifecycle.r0;
import c.InterfaceC0493a;
import com.tajir.tajir.R;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;
import m0.C1196e;
import r3.C1352h;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class j extends D.k implements r0, androidx.lifecycle.r, C0.f, A, androidx.activity.result.d, E.m, E.n, D.y, D.z, InterfaceC0255n {

    /* renamed from: b */
    public final C1352h f6016b;

    /* renamed from: c */
    public final X0.m f6017c;
    public final F d;

    /* renamed from: e */
    public final com.bumptech.glide.manager.q f6018e;

    /* renamed from: f */
    public q0 f6019f;

    /* renamed from: n */
    public h0 f6020n;

    /* renamed from: o */
    public z f6021o;

    /* renamed from: p */
    public final i f6022p;

    /* renamed from: q */
    public final com.bumptech.glide.manager.q f6023q;

    /* renamed from: r */
    public final f f6024r;

    /* renamed from: s */
    public final CopyOnWriteArrayList f6025s;

    /* renamed from: t */
    public final CopyOnWriteArrayList f6026t;

    /* renamed from: u */
    public final CopyOnWriteArrayList f6027u;

    /* renamed from: v */
    public final CopyOnWriteArrayList f6028v;

    /* renamed from: w */
    public final CopyOnWriteArrayList f6029w;

    /* renamed from: x */
    public boolean f6030x;

    /* renamed from: y */
    public boolean f6031y;

    public j() {
        this.f397a = new F(this);
        this.f6016b = new C1352h();
        final AbstractActivityC0400u abstractActivityC0400u = (AbstractActivityC0400u) this;
        this.f6017c = new X0.m(new RunnableC0050a(abstractActivityC0400u, 16));
        F f10 = new F(this);
        this.d = f10;
        com.bumptech.glide.manager.q qVar = new com.bumptech.glide.manager.q((C0.f) this);
        this.f6018e = qVar;
        this.f6021o = null;
        i iVar = new i(abstractActivityC0400u);
        this.f6022p = iVar;
        this.f6023q = new com.bumptech.glide.manager.q(iVar, new J6.b(abstractActivityC0400u, 2));
        new AtomicInteger();
        this.f6024r = new f(abstractActivityC0400u);
        this.f6025s = new CopyOnWriteArrayList();
        this.f6026t = new CopyOnWriteArrayList();
        this.f6027u = new CopyOnWriteArrayList();
        this.f6028v = new CopyOnWriteArrayList();
        this.f6029w = new CopyOnWriteArrayList();
        this.f6030x = false;
        this.f6031y = false;
        int i10 = Build.VERSION.SDK_INT;
        f10.a(new androidx.lifecycle.B() { // from class: androidx.activity.ComponentActivity$2
            @Override // androidx.lifecycle.B
            public final void d(D d, EnumC0424v enumC0424v) {
                if (enumC0424v == EnumC0424v.ON_STOP) {
                    Window window = abstractActivityC0400u.getWindow();
                    View viewPeekDecorView = window != null ? window.peekDecorView() : null;
                    if (viewPeekDecorView != null) {
                        viewPeekDecorView.cancelPendingInputEvents();
                    }
                }
            }
        });
        f10.a(new androidx.lifecycle.B() { // from class: androidx.activity.ComponentActivity$3
            @Override // androidx.lifecycle.B
            public final void d(D d, EnumC0424v enumC0424v) {
                if (enumC0424v == EnumC0424v.ON_DESTROY) {
                    abstractActivityC0400u.f6016b.f14688a = null;
                    if (!abstractActivityC0400u.isChangingConfigurations()) {
                        abstractActivityC0400u.f().a();
                    }
                    i iVar2 = abstractActivityC0400u.f6022p;
                    j jVar = iVar2.d;
                    jVar.getWindow().getDecorView().removeCallbacks(iVar2);
                    jVar.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(iVar2);
                }
            }
        });
        f10.a(new androidx.lifecycle.B() { // from class: androidx.activity.ComponentActivity$4
            @Override // androidx.lifecycle.B
            public final void d(D d, EnumC0424v enumC0424v) {
                j jVar = abstractActivityC0400u;
                if (jVar.f6019f == null) {
                    h hVar = (h) jVar.getLastNonConfigurationInstance();
                    if (hVar != null) {
                        jVar.f6019f = hVar.f6012a;
                    }
                    if (jVar.f6019f == null) {
                        jVar.f6019f = new q0();
                    }
                }
                jVar.d.b(this);
            }
        });
        qVar.h();
        e0.g(this);
        if (i10 <= 23) {
            ImmLeaksCleaner immLeaksCleaner = new ImmLeaksCleaner();
            immLeaksCleaner.f5994a = this;
            f10.a(immLeaksCleaner);
        }
        ((C0.e) qVar.d).c("android:support:activity-result", new d(abstractActivityC0400u, 0));
        j(new e(abstractActivityC0400u, 0));
    }

    @Override // android.app.Activity
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        o();
        this.f6022p.a(getWindow().getDecorView());
        super.addContentView(view, layoutParams);
    }

    @Override // C0.f
    public final C0.e b() {
        return (C0.e) this.f6018e.d;
    }

    @Override // androidx.lifecycle.r
    public final n0 c() {
        if (this.f6020n == null) {
            this.f6020n = new h0(getApplication(), this, getIntent() != null ? getIntent().getExtras() : null);
        }
        return this.f6020n;
    }

    @Override // androidx.lifecycle.r
    public final C1196e d() {
        C1196e c1196e = new C1196e(0);
        Application application = getApplication();
        LinkedHashMap linkedHashMap = c1196e.f12974a;
        if (application != null) {
            linkedHashMap.put(l0.f6992a, getApplication());
        }
        linkedHashMap.put(e0.f6957a, this);
        linkedHashMap.put(e0.f6958b, this);
        if (getIntent() != null && getIntent().getExtras() != null) {
            linkedHashMap.put(e0.f6959c, getIntent().getExtras());
        }
        return c1196e;
    }

    @Override // androidx.lifecycle.r0
    public final q0 f() {
        if (getApplication() == null) {
            throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
        }
        if (this.f6019f == null) {
            h hVar = (h) getLastNonConfigurationInstance();
            if (hVar != null) {
                this.f6019f = hVar.f6012a;
            }
            if (this.f6019f == null) {
                this.f6019f = new q0();
            }
        }
        return this.f6019f;
    }

    public final void g(androidx.fragment.app.A a6) {
        X0.m mVar = this.f6017c;
        ((CopyOnWriteArrayList) mVar.f5324c).add(a6);
        ((Runnable) mVar.f5323b).run();
    }

    @Override // androidx.lifecycle.D
    public final F h() {
        return this.d;
    }

    public final void i(Q.a aVar) {
        this.f6025s.add(aVar);
    }

    public final void j(InterfaceC0493a interfaceC0493a) {
        C1352h c1352h = this.f6016b;
        c1352h.getClass();
        if (((Context) c1352h.f14688a) != null) {
            interfaceC0493a.a();
        }
        ((CopyOnWriteArraySet) c1352h.f14689b).add(interfaceC0493a);
    }

    public final void k(androidx.fragment.app.z zVar) {
        this.f6028v.add(zVar);
    }

    public final void l(androidx.fragment.app.z zVar) {
        this.f6029w.add(zVar);
    }

    public final void m(androidx.fragment.app.z zVar) {
        this.f6026t.add(zVar);
    }

    public final z n() {
        if (this.f6021o == null) {
            this.f6021o = new z(new G(this, 13));
            this.d.a(new androidx.lifecycle.B() { // from class: androidx.activity.ComponentActivity$6
                @Override // androidx.lifecycle.B
                public final void d(D d, EnumC0424v enumC0424v) {
                    if (enumC0424v != EnumC0424v.ON_CREATE || Build.VERSION.SDK_INT < 33) {
                        return;
                    }
                    z zVar = this.f5990a.f6021o;
                    OnBackInvokedDispatcher onBackInvokedDispatcherA = g.a((j) d);
                    zVar.getClass();
                    AbstractC1420h.f(onBackInvokedDispatcherA, "invoker");
                    zVar.f6064e = onBackInvokedDispatcherA;
                    zVar.c(zVar.g);
                }
            });
        }
        return this.f6021o;
    }

    public final void o() {
        e0.l(getWindow().getDecorView(), this);
        View decorView = getWindow().getDecorView();
        AbstractC1420h.f(decorView, "<this>");
        decorView.setTag(R.id.view_tree_view_model_store_owner, this);
        X0.f.x(getWindow().getDecorView(), this);
        View decorView2 = getWindow().getDecorView();
        AbstractC1420h.f(decorView2, "<this>");
        decorView2.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        View decorView3 = getWindow().getDecorView();
        AbstractC1420h.f(decorView3, "<this>");
        decorView3.setTag(R.id.report_drawn, this);
    }

    @Override // android.app.Activity
    public void onActivityResult(int i10, int i11, Intent intent) {
        if (this.f6024r.a(i10, i11, intent)) {
            return;
        }
        super.onActivityResult(i10, i11, intent);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        n().b();
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks
    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        Iterator it = this.f6025s.iterator();
        while (it.hasNext()) {
            ((Q.a) it.next()).d(configuration);
        }
    }

    @Override // D.k, android.app.Activity
    public void onCreate(Bundle bundle) {
        this.f6018e.i(bundle);
        C1352h c1352h = this.f6016b;
        c1352h.getClass();
        c1352h.f14688a = this;
        Iterator it = ((CopyOnWriteArraySet) c1352h.f14689b).iterator();
        while (it.hasNext()) {
            ((InterfaceC0493a) it.next()).a();
        }
        super.onCreate(bundle);
        int i10 = b0.f6944b;
        e0.k(this);
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onCreatePanelMenu(int i10, Menu menu) {
        if (i10 != 0) {
            return true;
        }
        super.onCreatePanelMenu(i10, menu);
        getMenuInflater();
        Iterator it = ((CopyOnWriteArrayList) this.f6017c.f5324c).iterator();
        while (it.hasNext()) {
            ((androidx.fragment.app.A) it.next()).f6612a.j();
        }
        return true;
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean onMenuItemSelected(int i10, MenuItem menuItem) {
        if (super.onMenuItemSelected(i10, menuItem)) {
            return true;
        }
        if (i10 != 0) {
            return false;
        }
        Iterator it = ((CopyOnWriteArrayList) this.f6017c.f5324c).iterator();
        while (it.hasNext()) {
            if (((androidx.fragment.app.A) it.next()).f6612a.o()) {
                return true;
            }
        }
        return false;
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z3) {
        if (this.f6030x) {
            return;
        }
        Iterator it = this.f6028v.iterator();
        while (it.hasNext()) {
            ((Q.a) it.next()).d(new D.l(z3));
        }
    }

    @Override // android.app.Activity
    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Iterator it = this.f6027u.iterator();
        while (it.hasNext()) {
            ((Q.a) it.next()).d(intent);
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public void onPanelClosed(int i10, Menu menu) {
        Iterator it = ((CopyOnWriteArrayList) this.f6017c.f5324c).iterator();
        while (it.hasNext()) {
            ((androidx.fragment.app.A) it.next()).f6612a.p();
        }
        super.onPanelClosed(i10, menu);
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z3) {
        if (this.f6031y) {
            return;
        }
        Iterator it = this.f6029w.iterator();
        while (it.hasNext()) {
            ((Q.a) it.next()).d(new D.A(z3));
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public final boolean onPreparePanel(int i10, View view, Menu menu) {
        if (i10 != 0) {
            return true;
        }
        super.onPreparePanel(i10, view, menu);
        Iterator it = ((CopyOnWriteArrayList) this.f6017c.f5324c).iterator();
        while (it.hasNext()) {
            ((androidx.fragment.app.A) it.next()).f6612a.s();
        }
        return true;
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i10, String[] strArr, int[] iArr) {
        if (this.f6024r.a(i10, -1, new Intent().putExtra("androidx.activity.result.contract.extra.PERMISSIONS", strArr).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", iArr))) {
            return;
        }
        super.onRequestPermissionsResult(i10, strArr, iArr);
    }

    @Override // android.app.Activity
    public final Object onRetainNonConfigurationInstance() {
        h hVar;
        q0 q0Var = this.f6019f;
        if (q0Var == null && (hVar = (h) getLastNonConfigurationInstance()) != null) {
            q0Var = hVar.f6012a;
        }
        if (q0Var == null) {
            return null;
        }
        h hVar2 = new h();
        hVar2.f6012a = q0Var;
        return hVar2;
    }

    @Override // D.k, android.app.Activity
    public void onSaveInstanceState(Bundle bundle) {
        F f10 = this.d;
        if (f10 instanceof F) {
            f10.g(EnumC0425w.f7005c);
        }
        super.onSaveInstanceState(bundle);
        this.f6018e.j(bundle);
    }

    @Override // android.app.Activity, android.content.ComponentCallbacks2
    public final void onTrimMemory(int i10) {
        super.onTrimMemory(i10);
        Iterator it = this.f6026t.iterator();
        while (it.hasNext()) {
            ((Q.a) it.next()).d(Integer.valueOf(i10));
        }
    }

    public final void p(androidx.fragment.app.A a6) {
        X0.m mVar = this.f6017c;
        ((CopyOnWriteArrayList) mVar.f5324c).remove(a6);
        android.support.v4.media.session.a.u(((HashMap) mVar.d).remove(a6));
        ((Runnable) mVar.f5323b).run();
    }

    public final void q(androidx.fragment.app.z zVar) {
        this.f6025s.remove(zVar);
    }

    public final void r(androidx.fragment.app.z zVar) {
        this.f6028v.remove(zVar);
    }

    @Override // android.app.Activity
    public final void reportFullyDrawn() {
        try {
            if (C3.f.l()) {
                Trace.beginSection("reportFullyDrawn() for ComponentActivity");
            }
            super.reportFullyDrawn();
            this.f6023q.e();
            Trace.endSection();
        } catch (Throwable th) {
            Trace.endSection();
            throw th;
        }
    }

    public final void s(androidx.fragment.app.z zVar) {
        this.f6029w.remove(zVar);
    }

    @Override // android.app.Activity
    public void setContentView(int i10) {
        o();
        this.f6022p.a(getWindow().getDecorView());
        super.setContentView(i10);
    }

    public final void t(androidx.fragment.app.z zVar) {
        this.f6026t.remove(zVar);
    }

    @Override // android.app.Activity
    public final void onMultiWindowModeChanged(boolean z3, Configuration configuration) {
        this.f6030x = true;
        try {
            super.onMultiWindowModeChanged(z3, configuration);
            this.f6030x = false;
            Iterator it = this.f6028v.iterator();
            while (it.hasNext()) {
                ((Q.a) it.next()).d(new D.l(0, z3));
            }
        } catch (Throwable th) {
            this.f6030x = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public final void onPictureInPictureModeChanged(boolean z3, Configuration configuration) {
        this.f6031y = true;
        try {
            super.onPictureInPictureModeChanged(z3, configuration);
            this.f6031y = false;
            Iterator it = this.f6029w.iterator();
            while (it.hasNext()) {
                ((Q.a) it.next()).d(new D.A(0, z3));
            }
        } catch (Throwable th) {
            this.f6031y = false;
            throw th;
        }
    }

    @Override // android.app.Activity
    public void setContentView(View view) {
        o();
        this.f6022p.a(getWindow().getDecorView());
        super.setContentView(view);
    }

    @Override // android.app.Activity
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        o();
        this.f6022p.a(getWindow().getDecorView());
        super.setContentView(view, layoutParams);
    }
}
