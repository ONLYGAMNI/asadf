package androidx.activity;

import e8.C0803o;
import f8.C0840h;
import java.util.ListIterator;
import r8.InterfaceC1379a;
import s8.AbstractC1421i;

/* loaded from: classes.dex */
public final class s extends AbstractC1421i implements InterfaceC1379a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6049a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ z f6050b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ s(z zVar, int i10) {
        super(0);
        this.f6049a = i10;
        this.f6050b = zVar;
    }

    @Override // r8.InterfaceC1379a
    public final Object invoke() {
        Object objPrevious;
        switch (this.f6049a) {
            case 0:
                this.f6050b.b();
                break;
            case 1:
                z zVar = this.f6050b;
                C0840h c0840h = zVar.f6062b;
                ListIterator listIterator = c0840h.listIterator(c0840h.size());
                while (true) {
                    if (listIterator.hasPrevious()) {
                        objPrevious = listIterator.previous();
                        if (((q) objPrevious).f6037a) {
                        }
                    } else {
                        objPrevious = null;
                    }
                }
                zVar.f6063c = null;
                break;
            default:
                this.f6050b.b();
                break;
        }
        return C0803o.f10326a;
    }
}
