package androidx.activity;

/* renamed from: androidx.activity.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0355c {
    void cancel();
}
