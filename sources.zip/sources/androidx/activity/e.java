package androidx.activity;

import android.os.Bundle;
import androidx.fragment.app.AbstractActivityC0400u;
import androidx.fragment.app.C0399t;
import c.InterfaceC0493a;
import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: classes.dex */
public final /* synthetic */ class e implements InterfaceC0493a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6004a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ j f6005b;

    public /* synthetic */ e(AbstractActivityC0400u abstractActivityC0400u, int i10) {
        this.f6004a = i10;
        this.f6005b = abstractActivityC0400u;
    }

    @Override // c.InterfaceC0493a
    public final void a() {
        switch (this.f6004a) {
            case 0:
                j jVar = this.f6005b;
                Bundle bundleA = ((C0.e) jVar.f6018e.d).a("android:support:activity-result");
                if (bundleA != null) {
                    f fVar = jVar.f6024r;
                    fVar.getClass();
                    ArrayList<Integer> integerArrayList = bundleA.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
                    ArrayList<String> stringArrayList = bundleA.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
                    if (stringArrayList != null && integerArrayList != null) {
                        fVar.d = bundleA.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
                        Bundle bundle = bundleA.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT");
                        Bundle bundle2 = fVar.g;
                        bundle2.putAll(bundle);
                        for (int i10 = 0; i10 < stringArrayList.size(); i10++) {
                            String str = stringArrayList.get(i10);
                            HashMap map = fVar.f6007b;
                            boolean zContainsKey = map.containsKey(str);
                            HashMap map2 = fVar.f6006a;
                            if (zContainsKey) {
                                Integer num = (Integer) map.remove(str);
                                if (!bundle2.containsKey(str)) {
                                    map2.remove(num);
                                }
                            }
                            Integer num2 = integerArrayList.get(i10);
                            num2.intValue();
                            String str2 = stringArrayList.get(i10);
                            map2.put(num2, str2);
                            map.put(str2, num2);
                        }
                        break;
                    }
                }
                break;
            default:
                C0399t c0399t = (C0399t) ((AbstractActivityC0400u) this.f6005b).f6859z.f65b;
                c0399t.d.b(c0399t, c0399t, null);
                break;
        }
    }
}
