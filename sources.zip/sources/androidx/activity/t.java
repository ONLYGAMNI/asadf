package androidx.activity;

import android.window.OnBackInvokedCallback;
import j4.InterfaceC1065b;
import java.lang.reflect.InvocationTargetException;
import r8.InterfaceC1379a;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final /* synthetic */ class t implements OnBackInvokedCallback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6051a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f6052b;

    public /* synthetic */ t(Object obj, int i10) {
        this.f6051a = i10;
        this.f6052b = obj;
    }

    public final void onBackInvoked() throws IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {
        switch (this.f6051a) {
            case 0:
                InterfaceC1379a interfaceC1379a = (InterfaceC1379a) this.f6052b;
                AbstractC1420h.f(interfaceC1379a, "$onBackInvoked");
                interfaceC1379a.invoke();
                break;
            case 1:
                ((f.v) this.f6052b).D();
                break;
            case 2:
                ((InterfaceC1065b) this.f6052b).a();
                break;
            default:
                ((Runnable) this.f6052b).run();
                break;
        }
    }
}
