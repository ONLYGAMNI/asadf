package androidx.activity;

import D.RunnableC0050a;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0424v;
import androidx.lifecycle.F;
import androidx.lifecycle.e0;
import com.tajir.tajir.R;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public class k extends Dialog implements D, A, C0.f {

    /* renamed from: a */
    public F f6032a;

    /* renamed from: b */
    public final com.bumptech.glide.manager.q f6033b;

    /* renamed from: c */
    public final z f6034c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public k(Context context, int i10) {
        super(context, i10);
        AbstractC1420h.f(context, "context");
        this.f6033b = new com.bumptech.glide.manager.q(this);
        this.f6034c = new z(new RunnableC0050a(this, 18));
    }

    public static void a(k kVar) {
        AbstractC1420h.f(kVar, "this$0");
        super.onBackPressed();
    }

    @Override // android.app.Dialog
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        AbstractC1420h.f(view, "view");
        d();
        super.addContentView(view, layoutParams);
    }

    @Override // C0.f
    public final C0.e b() {
        return (C0.e) this.f6033b.d;
    }

    public final F c() {
        F f10 = this.f6032a;
        if (f10 != null) {
            return f10;
        }
        F f11 = new F(this);
        this.f6032a = f11;
        return f11;
    }

    public final void d() {
        Window window = getWindow();
        AbstractC1420h.c(window);
        View decorView = window.getDecorView();
        AbstractC1420h.e(decorView, "window!!.decorView");
        e0.l(decorView, this);
        Window window2 = getWindow();
        AbstractC1420h.c(window2);
        View decorView2 = window2.getDecorView();
        AbstractC1420h.e(decorView2, "window!!.decorView");
        decorView2.setTag(R.id.view_tree_on_back_pressed_dispatcher_owner, this);
        Window window3 = getWindow();
        AbstractC1420h.c(window3);
        View decorView3 = window3.getDecorView();
        AbstractC1420h.e(decorView3, "window!!.decorView");
        X0.f.x(decorView3, this);
    }

    @Override // androidx.lifecycle.D
    public final F h() {
        return c();
    }

    @Override // android.app.Dialog
    public final void onBackPressed() {
        this.f6034c.b();
    }

    @Override // android.app.Dialog
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT >= 33) {
            OnBackInvokedDispatcher onBackInvokedDispatcher = getOnBackInvokedDispatcher();
            AbstractC1420h.e(onBackInvokedDispatcher, "onBackInvokedDispatcher");
            z zVar = this.f6034c;
            zVar.getClass();
            zVar.f6064e = onBackInvokedDispatcher;
            zVar.c(zVar.g);
        }
        this.f6033b.i(bundle);
        c().e(EnumC0424v.ON_CREATE);
    }

    @Override // android.app.Dialog
    public final Bundle onSaveInstanceState() {
        Bundle bundleOnSaveInstanceState = super.onSaveInstanceState();
        AbstractC1420h.e(bundleOnSaveInstanceState, "super.onSaveInstanceState()");
        this.f6033b.j(bundleOnSaveInstanceState);
        return bundleOnSaveInstanceState;
    }

    @Override // android.app.Dialog
    public void onStart() {
        super.onStart();
        c().e(EnumC0424v.ON_RESUME);
    }

    @Override // android.app.Dialog
    public void onStop() {
        c().e(EnumC0424v.ON_DESTROY);
        this.f6032a = null;
        super.onStop();
    }

    @Override // android.app.Dialog
    public void setContentView(int i10) {
        d();
        super.setContentView(i10);
    }

    @Override // android.app.Dialog
    public void setContentView(View view) {
        AbstractC1420h.f(view, "view");
        d();
        super.setContentView(view);
    }

    @Override // android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        AbstractC1420h.f(view, "view");
        d();
        super.setContentView(view, layoutParams);
    }
}
