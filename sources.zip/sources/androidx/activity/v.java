package androidx.activity;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import r8.InterfaceC1379a;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class v implements OnBackAnimationCallback {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ r8.l f6054a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ r8.l f6055b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ InterfaceC1379a f6056c;
    public final /* synthetic */ InterfaceC1379a d;

    public v(r8.l lVar, r8.l lVar2, InterfaceC1379a interfaceC1379a, InterfaceC1379a interfaceC1379a2) {
        this.f6054a = lVar;
        this.f6055b = lVar2;
        this.f6056c = interfaceC1379a;
        this.d = interfaceC1379a2;
    }

    public final void onBackCancelled() {
        this.d.invoke();
    }

    public final void onBackInvoked() {
        this.f6056c.invoke();
    }

    public final void onBackProgressed(BackEvent backEvent) {
        AbstractC1420h.f(backEvent, "backEvent");
        this.f6055b.invoke(new C0354b(backEvent));
    }

    public final void onBackStarted(BackEvent backEvent) {
        AbstractC1420h.f(backEvent, "backEvent");
        this.f6054a.invoke(new C0354b(backEvent));
    }
}
