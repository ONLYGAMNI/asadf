package androidx.activity;

/* loaded from: classes.dex */
public final class C {

    /* renamed from: a, reason: collision with root package name */
    public final int f5985a;

    /* renamed from: b, reason: collision with root package name */
    public final int f5986b;

    public C(int i10, int i11, r8.l lVar) {
        this.f5985a = i10;
        this.f5986b = i11;
    }
}
