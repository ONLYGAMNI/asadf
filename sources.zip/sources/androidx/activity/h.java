package androidx.activity;

import androidx.lifecycle.q0;

/* loaded from: classes.dex */
public final class h {

    /* renamed from: a, reason: collision with root package name */
    public q0 f6012a;
}
