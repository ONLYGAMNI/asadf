package androidx.activity;

import android.window.BackEvent;
import s8.AbstractC1420h;

/* renamed from: androidx.activity.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0354b {

    /* renamed from: a, reason: collision with root package name */
    public final float f5999a;

    /* renamed from: b, reason: collision with root package name */
    public final float f6000b;

    /* renamed from: c, reason: collision with root package name */
    public final float f6001c;
    public final int d;

    public C0354b(BackEvent backEvent) {
        AbstractC1420h.f(backEvent, "backEvent");
        C0353a c0353a = C0353a.f5998a;
        float fD = c0353a.d(backEvent);
        float fE = c0353a.e(backEvent);
        float fB = c0353a.b(backEvent);
        int iC = c0353a.c(backEvent);
        this.f5999a = fD;
        this.f6000b = fE;
        this.f6001c = fB;
        this.d = iC;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("BackEventCompat{touchX=");
        sb.append(this.f5999a);
        sb.append(", touchY=");
        sb.append(this.f6000b);
        sb.append(", progress=");
        sb.append(this.f6001c);
        sb.append(", swipeEdge=");
        return android.support.v4.media.session.a.n(sb, this.d, '}');
    }
}
