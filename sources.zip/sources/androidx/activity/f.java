package androidx.activity;

import D.AbstractC0051b;
import a.AbstractC0338a;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.fragment.app.AbstractActivityC0400u;
import java.util.ArrayList;
import java.util.HashMap;
import u8.AbstractC1529d;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f6006a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final HashMap f6007b = new HashMap();

    /* renamed from: c, reason: collision with root package name */
    public final HashMap f6008c = new HashMap();
    public ArrayList d = new ArrayList();

    /* renamed from: e, reason: collision with root package name */
    public final transient HashMap f6009e = new HashMap();

    /* renamed from: f, reason: collision with root package name */
    public final HashMap f6010f = new HashMap();
    public final Bundle g = new Bundle();

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ j f6011h;

    public f(AbstractActivityC0400u abstractActivityC0400u) {
        this.f6011h = abstractActivityC0400u;
    }

    public final boolean a(int i10, int i11, Intent intent) {
        androidx.activity.result.b bVar;
        String str = (String) this.f6006a.get(Integer.valueOf(i10));
        if (str == null) {
            return false;
        }
        androidx.activity.result.c cVar = (androidx.activity.result.c) this.f6009e.get(str);
        if (cVar == null || (bVar = cVar.f6044a) == null || !this.d.contains(str)) {
            this.f6010f.remove(str);
            this.g.putParcelable(str, new androidx.activity.result.a(intent, i11));
            return true;
        }
        bVar.f(cVar.f6045b.R(intent, i11));
        this.d.remove(str);
        return true;
    }

    public final void b(int i10, AbstractC0338a abstractC0338a, Object obj) {
        Bundle bundle;
        j jVar = this.f6011h;
        K8.d dVarY = abstractC0338a.y(jVar, obj);
        if (dVarY != null) {
            new Handler(Looper.getMainLooper()).post(new R0.i(this, i10, dVarY, 3));
            return;
        }
        Intent intentN = abstractC0338a.n(jVar, obj);
        if (intentN.getExtras() != null && intentN.getExtras().getClassLoader() == null) {
            intentN.setExtrasClassLoader(jVar.getClassLoader());
        }
        if (intentN.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
            Bundle bundleExtra = intentN.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            intentN.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
            bundle = bundleExtra;
        } else {
            bundle = null;
        }
        if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intentN.getAction())) {
            String[] stringArrayExtra = intentN.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
            if (stringArrayExtra == null) {
                stringArrayExtra = new String[0];
            }
            D.e.a(jVar, stringArrayExtra, i10);
            return;
        }
        if (!"androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(intentN.getAction())) {
            AbstractC0051b.b(jVar, intentN, i10, bundle);
            return;
        }
        androidx.activity.result.e eVar = (androidx.activity.result.e) intentN.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
            AbstractC0051b.c(jVar, eVar.f6046a, i10, eVar.f6047b, eVar.f6048c, eVar.d, 0, bundle);
        } catch (IntentSender.SendIntentException e4) {
            new Handler(Looper.getMainLooper()).post(new R0.i(this, i10, e4, 4));
        }
    }

    public final X0.m c(String str, AbstractC0338a abstractC0338a, androidx.activity.result.b bVar) {
        int i10;
        HashMap map;
        HashMap map2 = this.f6007b;
        if (((Integer) map2.get(str)) == null) {
            AbstractC1529d.f15478a.getClass();
            int iNextInt = AbstractC1529d.f15479b.a().nextInt(2147418112);
            while (true) {
                i10 = iNextInt + 65536;
                map = this.f6006a;
                if (!map.containsKey(Integer.valueOf(i10))) {
                    break;
                }
                AbstractC1529d.f15478a.getClass();
                iNextInt = AbstractC1529d.f15479b.a().nextInt(2147418112);
            }
            map.put(Integer.valueOf(i10), str);
            map2.put(str, Integer.valueOf(i10));
        }
        this.f6009e.put(str, new androidx.activity.result.c(bVar, abstractC0338a));
        HashMap map3 = this.f6010f;
        if (map3.containsKey(str)) {
            Object obj = map3.get(str);
            map3.remove(str);
            bVar.f(obj);
        }
        Bundle bundle = this.g;
        androidx.activity.result.a aVar = (androidx.activity.result.a) bundle.getParcelable(str);
        if (aVar != null) {
            bundle.remove(str);
            bVar.f(abstractC0338a.R(aVar.f6043b, aVar.f6042a));
        }
        return new X0.m(this, str, abstractC0338a, 17, false);
    }
}
