package androidx.activity;

import android.content.res.Resources;
import s8.AbstractC1420h;
import s8.AbstractC1421i;

/* loaded from: classes.dex */
public final class B extends AbstractC1421i implements r8.l {

    /* renamed from: a, reason: collision with root package name */
    public static final B f5984a = new B(1);

    @Override // r8.l
    public final Object invoke(Object obj) {
        Resources resources = (Resources) obj;
        AbstractC1420h.f(resources, "resources");
        return Boolean.valueOf((resources.getConfiguration().uiMode & 48) == 32);
    }
}
