package androidx.activity;

import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class l {

    /* renamed from: a, reason: collision with root package name */
    public static final int f6035a = Color.argb(230, 255, 255, 255);

    /* renamed from: b, reason: collision with root package name */
    public static final int f6036b = Color.argb(128, 27, 27, 27);

    public static void a(j jVar) {
        B b7 = B.f5984a;
        C c4 = new C(0, 0, b7);
        C c10 = new C(f6035a, f6036b, b7);
        AbstractC1420h.f(jVar, "<this>");
        View decorView = jVar.getWindow().getDecorView();
        AbstractC1420h.e(decorView, "window.decorView");
        Resources resources = decorView.getResources();
        AbstractC1420h.e(resources, "view.resources");
        boolean zBooleanValue = ((Boolean) b7.invoke(resources)).booleanValue();
        Resources resources2 = decorView.getResources();
        AbstractC1420h.e(resources2, "view.resources");
        boolean zBooleanValue2 = ((Boolean) b7.invoke(resources2)).booleanValue();
        int i10 = Build.VERSION.SDK_INT;
        p oVar = i10 >= 29 ? new o() : i10 >= 26 ? new n() : new m();
        Window window = jVar.getWindow();
        AbstractC1420h.e(window, "window");
        oVar.a(c4, c10, window, decorView, zBooleanValue, zBooleanValue2);
    }
}
