package androidx.activity;

import androidx.lifecycle.D;

/* loaded from: classes.dex */
public interface A extends D {
}
