package androidx.activity;

import f8.C0840h;
import r8.InterfaceC1379a;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class x implements InterfaceC0355c {

    /* renamed from: a, reason: collision with root package name */
    public final q f6058a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ z f6059b;

    public x(z zVar, q qVar) {
        AbstractC1420h.f(qVar, "onBackPressedCallback");
        this.f6059b = zVar;
        this.f6058a = qVar;
    }

    @Override // androidx.activity.InterfaceC0355c
    public final void cancel() {
        z zVar = this.f6059b;
        C0840h c0840h = zVar.f6062b;
        q qVar = this.f6058a;
        c0840h.remove(qVar);
        if (AbstractC1420h.a(zVar.f6063c, qVar)) {
            qVar.getClass();
            zVar.f6063c = null;
        }
        qVar.getClass();
        qVar.f6038b.remove(this);
        InterfaceC1379a interfaceC1379a = qVar.f6039c;
        if (interfaceC1379a != null) {
            interfaceC1379a.invoke();
        }
        qVar.f6039c = null;
    }
}
