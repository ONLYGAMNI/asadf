package androidx.activity;

import android.view.View;
import android.view.Window;

/* loaded from: classes.dex */
public interface p {
    void a(C c4, C c10, Window window, View view, boolean z3, boolean z9);
}
