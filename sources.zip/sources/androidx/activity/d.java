package androidx.activity;

import android.os.Bundle;
import android.os.Parcelable;
import androidx.fragment.app.AbstractActivityC0400u;
import androidx.fragment.app.I;
import androidx.lifecycle.EnumC0424v;
import androidx.lifecycle.c0;
import androidx.navigation.fragment.NavHostFragment;
import e8.C0795g;
import f8.AbstractC0843k;
import f8.AbstractC0857y;
import f8.C0840h;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import q0.C1302n;
import q0.C1303o;
import q0.F;
import q0.S;
import s2.AbstractC1397b;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final /* synthetic */ class d implements C0.d {

    /* renamed from: a */
    public final /* synthetic */ int f6002a;

    /* renamed from: b */
    public final /* synthetic */ Object f6003b;

    public /* synthetic */ d(Object obj, int i10) {
        this.f6002a = i10;
        this.f6003b = obj;
    }

    @Override // C0.d
    public final Bundle a() {
        AbstractActivityC0400u abstractActivityC0400u;
        Bundle bundle;
        Object obj = this.f6003b;
        switch (this.f6002a) {
            case 0:
                j jVar = (j) obj;
                jVar.getClass();
                Bundle bundle2 = new Bundle();
                f fVar = jVar.f6024r;
                fVar.getClass();
                HashMap map = fVar.f6007b;
                bundle2.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(map.values()));
                bundle2.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(map.keySet()));
                bundle2.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(fVar.d));
                bundle2.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) fVar.g.clone());
                return bundle2;
            case 1:
                break;
            case 2:
                return ((I) obj).V();
            case 3:
                return c0.a((c0) obj);
            case 4:
                F f10 = (F) obj;
                AbstractC1420h.f(f10, "$this_apply");
                ArrayList<String> arrayList = new ArrayList<>();
                Bundle bundle3 = new Bundle();
                for (Map.Entry entry : AbstractC0857y.G(f10.f14380u.f14419a).entrySet()) {
                    String str = (String) entry.getKey();
                    Bundle bundleH = ((S) entry.getValue()).h();
                    if (bundleH != null) {
                        arrayList.add(str);
                        bundle3.putBundle(str, bundleH);
                    }
                }
                if (!arrayList.isEmpty()) {
                    bundle = new Bundle();
                    bundle3.putStringArrayList("android-support-nav:controller:navigatorState:names", arrayList);
                    bundle.putBundle("android-support-nav:controller:navigatorState", bundle3);
                } else {
                    bundle = null;
                }
                C0840h c0840h = f10.g;
                if (!c0840h.isEmpty()) {
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    Parcelable[] parcelableArr = new Parcelable[c0840h.f10623c];
                    Iterator<E> it = c0840h.iterator();
                    int i10 = 0;
                    while (it.hasNext()) {
                        parcelableArr[i10] = new C1303o((C1302n) it.next());
                        i10++;
                    }
                    bundle.putParcelableArray("android-support-nav:controller:backStack", parcelableArr);
                }
                LinkedHashMap linkedHashMap = f10.f14371l;
                if (!linkedHashMap.isEmpty()) {
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    int[] iArr = new int[linkedHashMap.size()];
                    ArrayList<String> arrayList2 = new ArrayList<>();
                    int i11 = 0;
                    for (Map.Entry entry2 : linkedHashMap.entrySet()) {
                        int iIntValue = ((Number) entry2.getKey()).intValue();
                        String str2 = (String) entry2.getValue();
                        iArr[i11] = iIntValue;
                        arrayList2.add(str2);
                        i11++;
                    }
                    bundle.putIntArray("android-support-nav:controller:backStackDestIds", iArr);
                    bundle.putStringArrayList("android-support-nav:controller:backStackIds", arrayList2);
                }
                LinkedHashMap linkedHashMap2 = f10.f14372m;
                if (!linkedHashMap2.isEmpty()) {
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    ArrayList<String> arrayList3 = new ArrayList<>();
                    for (Map.Entry entry3 : linkedHashMap2.entrySet()) {
                        String str3 = (String) entry3.getKey();
                        C0840h c0840h2 = (C0840h) entry3.getValue();
                        arrayList3.add(str3);
                        Parcelable[] parcelableArr2 = new Parcelable[c0840h2.f10623c];
                        Iterator it2 = c0840h2.iterator();
                        int i12 = 0;
                        while (it2.hasNext()) {
                            Object next = it2.next();
                            int i13 = i12 + 1;
                            if (i12 < 0) {
                                AbstractC0843k.Q();
                                throw null;
                            }
                            parcelableArr2[i12] = (C1303o) next;
                            i12 = i13;
                        }
                        bundle.putParcelableArray(AbstractC1397b.b("android-support-nav:controller:backStackStates:", str3), parcelableArr2);
                    }
                    bundle.putStringArrayList("android-support-nav:controller:backStackStates", arrayList3);
                }
                if (f10.f14366f) {
                    if (bundle == null) {
                        bundle = new Bundle();
                    }
                    bundle.putBoolean("android-support-nav:controller:deepLinkHandled", f10.f14366f);
                }
                if (bundle != null) {
                    return bundle;
                }
                Bundle bundle4 = Bundle.EMPTY;
                AbstractC1420h.e(bundle4, "EMPTY");
                return bundle4;
            default:
                NavHostFragment navHostFragment = (NavHostFragment) obj;
                AbstractC1420h.f(navHostFragment, "this$0");
                int i14 = navHostFragment.f7021f0;
                if (i14 != 0) {
                    return android.support.v4.media.session.b.e(new C0795g("android-support-nav:fragment:graphId", Integer.valueOf(i14)));
                }
                Bundle bundle5 = Bundle.EMPTY;
                AbstractC1420h.e(bundle5, "{\n                    Bu…e.EMPTY\n                }");
                return bundle5;
        }
        do {
            abstractActivityC0400u = (AbstractActivityC0400u) obj;
        } while (AbstractActivityC0400u.v(abstractActivityC0400u.u()));
        abstractActivityC0400u.f6855A.e(EnumC0424v.ON_STOP);
        return new Bundle();
    }
}
