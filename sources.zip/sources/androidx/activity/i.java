package androidx.activity;

import D.RunnableC0050a;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.fragment.app.AbstractActivityC0400u;
import java.util.concurrent.Executor;

/* loaded from: classes.dex */
public final class i implements Executor, ViewTreeObserver.OnDrawListener, Runnable {

    /* renamed from: b, reason: collision with root package name */
    public Runnable f6014b;
    public final /* synthetic */ j d;

    /* renamed from: a, reason: collision with root package name */
    public final long f6013a = SystemClock.uptimeMillis() + 10000;

    /* renamed from: c, reason: collision with root package name */
    public boolean f6015c = false;

    public i(AbstractActivityC0400u abstractActivityC0400u) {
        this.d = abstractActivityC0400u;
    }

    public final void a(View view) {
        if (this.f6015c) {
            return;
        }
        this.f6015c = true;
        view.getViewTreeObserver().addOnDrawListener(this);
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.f6014b = runnable;
        View decorView = this.d.getWindow().getDecorView();
        if (!this.f6015c) {
            decorView.postOnAnimation(new RunnableC0050a(this, 17));
        } else if (Looper.myLooper() == Looper.getMainLooper()) {
            decorView.invalidate();
        } else {
            decorView.postInvalidate();
        }
    }

    @Override // android.view.ViewTreeObserver.OnDrawListener
    public final void onDraw() {
        boolean z3;
        Runnable runnable = this.f6014b;
        if (runnable == null) {
            if (SystemClock.uptimeMillis() > this.f6013a) {
                this.f6015c = false;
                this.d.getWindow().getDecorView().post(this);
                return;
            }
            return;
        }
        runnable.run();
        this.f6014b = null;
        com.bumptech.glide.manager.q qVar = this.d.f6023q;
        synchronized (qVar.f8951c) {
            z3 = qVar.f8950b;
        }
        if (z3) {
            this.f6015c = false;
            this.d.getWindow().getDecorView().post(this);
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.d.getWindow().getDecorView().getViewTreeObserver().removeOnDrawListener(this);
    }
}
