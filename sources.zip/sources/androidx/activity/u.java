package androidx.activity;

import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import r8.InterfaceC1379a;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class u {

    /* renamed from: a, reason: collision with root package name */
    public static final u f6053a = new u();

    public final OnBackInvokedCallback a(InterfaceC1379a interfaceC1379a) {
        AbstractC1420h.f(interfaceC1379a, "onBackInvoked");
        return new t(interfaceC1379a, 0);
    }

    public final void b(Object obj, int i10, Object obj2) {
        AbstractC1420h.f(obj, "dispatcher");
        AbstractC1420h.f(obj2, "callback");
        ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(i10, (OnBackInvokedCallback) obj2);
    }

    public final void c(Object obj, Object obj2) {
        AbstractC1420h.f(obj, "dispatcher");
        AbstractC1420h.f(obj2, "callback");
        ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
    }
}
