package androidx.activity;

import android.window.BackEvent;
import s8.AbstractC1420h;

/* renamed from: androidx.activity.a */
/* loaded from: classes.dex */
public final class C0353a {

    /* renamed from: a */
    public static final C0353a f5998a = new C0353a();

    public final BackEvent a(float f10, float f11, float f12, int i10) {
        return new BackEvent(f10, f11, f12, i10);
    }

    public final float b(BackEvent backEvent) {
        AbstractC1420h.f(backEvent, "backEvent");
        return backEvent.getProgress();
    }

    public final int c(BackEvent backEvent) {
        AbstractC1420h.f(backEvent, "backEvent");
        return backEvent.getSwipeEdge();
    }

    public final float d(BackEvent backEvent) {
        AbstractC1420h.f(backEvent, "backEvent");
        return backEvent.getTouchX();
    }

    public final float e(BackEvent backEvent) {
        AbstractC1420h.f(backEvent, "backEvent");
        return backEvent.getTouchY();
    }
}
