package androidx.activity;

import android.window.OnBackInvokedCallback;
import r8.InterfaceC1379a;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class w {

    /* renamed from: a, reason: collision with root package name */
    public static final w f6057a = new w();

    public final OnBackInvokedCallback a(r8.l lVar, r8.l lVar2, InterfaceC1379a interfaceC1379a, InterfaceC1379a interfaceC1379a2) {
        AbstractC1420h.f(lVar, "onBackStarted");
        AbstractC1420h.f(lVar2, "onBackProgressed");
        AbstractC1420h.f(interfaceC1379a, "onBackInvoked");
        AbstractC1420h.f(interfaceC1379a2, "onBackCancelled");
        return new v(lVar, lVar2, interfaceC1379a, interfaceC1379a2);
    }
}
