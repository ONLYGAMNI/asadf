package androidx.activity;

import java.util.concurrent.CopyOnWriteArrayList;
import r8.InterfaceC1379a;

/* loaded from: classes.dex */
public abstract class q {

    /* renamed from: a, reason: collision with root package name */
    public boolean f6037a;

    /* renamed from: b, reason: collision with root package name */
    public final CopyOnWriteArrayList f6038b = new CopyOnWriteArrayList();

    /* renamed from: c, reason: collision with root package name */
    public InterfaceC1379a f6039c;

    public q(boolean z3) {
        this.f6037a = z3;
    }

    public abstract void a();
}
