package androidx.activity.result;

import androidx.lifecycle.B;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0424v;

/* loaded from: classes.dex */
class ActivityResultRegistry$1 implements B {
    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        if (EnumC0424v.ON_START.equals(enumC0424v) || EnumC0424v.ON_STOP.equals(enumC0424v) || EnumC0424v.ON_DESTROY.equals(enumC0424v)) {
            throw null;
        }
    }
}
