package androidx.activity.result;

/* loaded from: classes.dex */
public interface b {
    void f(Object obj);
}
