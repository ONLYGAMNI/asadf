package androidx.activity.result;

/* loaded from: classes.dex */
public interface d {
}
