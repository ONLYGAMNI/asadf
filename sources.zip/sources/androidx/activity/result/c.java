package androidx.activity.result;

import a.AbstractC0338a;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final b f6044a;

    /* renamed from: b, reason: collision with root package name */
    public final AbstractC0338a f6045b;

    public c(b bVar, AbstractC0338a abstractC0338a) {
        this.f6044a = bVar;
        this.f6045b = abstractC0338a;
    }
}
