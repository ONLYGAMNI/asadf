package androidx.activity;

import R.C0;
import R.D0;
import android.os.Build;
import android.view.View;
import android.view.Window;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class m implements p {
    @Override // androidx.activity.p
    public void a(C c4, C c10, Window window, View view, boolean z3, boolean z9) {
        C0 d02;
        AbstractC1420h.f(c4, "statusBarStyle");
        AbstractC1420h.f(c10, "navigationBarStyle");
        AbstractC1420h.f(window, "window");
        AbstractC1420h.f(view, "view");
        O0.w.x(window, false);
        window.setStatusBarColor(z3 ? c4.f5986b : c4.f5985a);
        window.setNavigationBarColor(c10.f5986b);
        int i10 = Build.VERSION.SDK_INT;
        if (i10 >= 30) {
            d02 = new C0(window.getInsetsController());
            d02.f3956b = window;
        } else {
            d02 = i10 >= 26 ? new D0(window, view) : new C0(window, view);
        }
        d02.z(!z3);
    }
}
