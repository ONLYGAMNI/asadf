package androidx.activity;

import androidx.lifecycle.AbstractC0426x;
import androidx.lifecycle.D;
import androidx.lifecycle.EnumC0424v;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
final class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements androidx.lifecycle.B, InterfaceC0355c {

    /* renamed from: a */
    public final AbstractC0426x f5995a;

    /* renamed from: b */
    public final q f5996b;

    /* renamed from: c */
    public x f5997c;
    public final /* synthetic */ z d;

    public OnBackPressedDispatcher$LifecycleOnBackPressedCancellable(z zVar, AbstractC0426x abstractC0426x, q qVar) {
        AbstractC1420h.f(qVar, "onBackPressedCallback");
        this.d = zVar;
        this.f5995a = abstractC0426x;
        this.f5996b = qVar;
        abstractC0426x.a(this);
    }

    @Override // androidx.activity.InterfaceC0355c
    public final void cancel() {
        this.f5995a.b(this);
        q qVar = this.f5996b;
        qVar.getClass();
        qVar.f6038b.remove(this);
        x xVar = this.f5997c;
        if (xVar != null) {
            xVar.cancel();
        }
        this.f5997c = null;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        if (enumC0424v != EnumC0424v.ON_START) {
            if (enumC0424v != EnumC0424v.ON_STOP) {
                if (enumC0424v == EnumC0424v.ON_DESTROY) {
                    cancel();
                    return;
                }
                return;
            } else {
                x xVar = this.f5997c;
                if (xVar != null) {
                    xVar.cancel();
                    return;
                }
                return;
            }
        }
        z zVar = this.d;
        zVar.getClass();
        q qVar = this.f5996b;
        AbstractC1420h.f(qVar, "onBackPressedCallback");
        zVar.f6062b.j(qVar);
        x xVar2 = new x(zVar, qVar);
        qVar.f6038b.add(xVar2);
        zVar.d();
        qVar.f6039c = new y(0, zVar, z.class, "updateEnabledCallbacks", "updateEnabledCallbacks()V", 0, 1);
        this.f5997c = xVar2;
    }
}
