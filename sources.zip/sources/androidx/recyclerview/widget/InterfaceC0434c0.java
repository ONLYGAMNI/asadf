package androidx.recyclerview.widget;

import android.view.View;

/* renamed from: androidx.recyclerview.widget.c0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0434c0 {
    void onChildViewAttachedToWindow(View view);

    void onChildViewDetachedFromWindow(View view);
}
