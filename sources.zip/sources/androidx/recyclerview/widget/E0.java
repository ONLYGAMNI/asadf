package androidx.recyclerview.widget;

import android.view.View;

/* loaded from: classes.dex */
public final class E0 {

    /* renamed from: a, reason: collision with root package name */
    public final D0 f7068a;

    /* renamed from: b, reason: collision with root package name */
    public final C0 f7069b;

    public E0(D0 d02) {
        this.f7068a = d02;
        C0 c0 = new C0();
        c0.f7051a = 0;
        this.f7069b = c0;
    }

    public final View a(int i10, int i11, int i12, int i13) {
        D0 d02 = this.f7068a;
        int iD = d02.d();
        int iA = d02.a();
        int i14 = i11 > i10 ? 1 : -1;
        View view = null;
        while (i10 != i11) {
            View viewC = d02.c(i10);
            int iB = d02.b(viewC);
            int iE = d02.e(viewC);
            C0 c0 = this.f7069b;
            c0.f7052b = iD;
            c0.f7053c = iA;
            c0.d = iB;
            c0.f7054e = iE;
            if (i12 != 0) {
                c0.f7051a = i12;
                if (c0.a()) {
                    return viewC;
                }
            }
            if (i13 != 0) {
                c0.f7051a = i13;
                if (c0.a()) {
                    view = viewC;
                }
            }
            i10 += i14;
        }
        return view;
    }

    public final boolean b(View view) {
        D0 d02 = this.f7068a;
        int iD = d02.d();
        int iA = d02.a();
        int iB = d02.b(view);
        int iE = d02.e(view);
        C0 c0 = this.f7069b;
        c0.f7052b = iD;
        c0.f7053c = iA;
        c0.d = iB;
        c0.f7054e = iE;
        c0.f7051a = 24579;
        return c0.a();
    }
}
