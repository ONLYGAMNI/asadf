package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public final class H extends I {
    public final /* synthetic */ int d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ H(AbstractC0430a0 abstractC0430a0, int i10) {
        super(abstractC0430a0);
        this.d = i10;
    }

    @Override // androidx.recyclerview.widget.I
    public final int b(View view) {
        switch (this.d) {
            case 0:
                return this.f7089a.getDecoratedRight(view) + ((ViewGroup.MarginLayoutParams) ((C0432b0) view.getLayoutParams())).rightMargin;
            default:
                return this.f7089a.getDecoratedBottom(view) + ((ViewGroup.MarginLayoutParams) ((C0432b0) view.getLayoutParams())).bottomMargin;
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int c(View view) {
        switch (this.d) {
            case 0:
                C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
                return this.f7089a.getDecoratedMeasuredWidth(view) + ((ViewGroup.MarginLayoutParams) c0432b0).leftMargin + ((ViewGroup.MarginLayoutParams) c0432b0).rightMargin;
            default:
                C0432b0 c0432b02 = (C0432b0) view.getLayoutParams();
                return this.f7089a.getDecoratedMeasuredHeight(view) + ((ViewGroup.MarginLayoutParams) c0432b02).topMargin + ((ViewGroup.MarginLayoutParams) c0432b02).bottomMargin;
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int d(View view) {
        switch (this.d) {
            case 0:
                C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
                return this.f7089a.getDecoratedMeasuredHeight(view) + ((ViewGroup.MarginLayoutParams) c0432b0).topMargin + ((ViewGroup.MarginLayoutParams) c0432b0).bottomMargin;
            default:
                C0432b0 c0432b02 = (C0432b0) view.getLayoutParams();
                return this.f7089a.getDecoratedMeasuredWidth(view) + ((ViewGroup.MarginLayoutParams) c0432b02).leftMargin + ((ViewGroup.MarginLayoutParams) c0432b02).rightMargin;
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int e(View view) {
        switch (this.d) {
            case 0:
                return this.f7089a.getDecoratedLeft(view) - ((ViewGroup.MarginLayoutParams) ((C0432b0) view.getLayoutParams())).leftMargin;
            default:
                return this.f7089a.getDecoratedTop(view) - ((ViewGroup.MarginLayoutParams) ((C0432b0) view.getLayoutParams())).topMargin;
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int f() {
        switch (this.d) {
            case 0:
                return this.f7089a.getWidth();
            default:
                return this.f7089a.getHeight();
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int g() {
        switch (this.d) {
            case 0:
                AbstractC0430a0 abstractC0430a0 = this.f7089a;
                return abstractC0430a0.getWidth() - abstractC0430a0.getPaddingRight();
            default:
                AbstractC0430a0 abstractC0430a02 = this.f7089a;
                return abstractC0430a02.getHeight() - abstractC0430a02.getPaddingBottom();
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int h() {
        switch (this.d) {
            case 0:
                return this.f7089a.getPaddingRight();
            default:
                return this.f7089a.getPaddingBottom();
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int i() {
        switch (this.d) {
            case 0:
                return this.f7089a.getWidthMode();
            default:
                return this.f7089a.getHeightMode();
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int j() {
        switch (this.d) {
            case 0:
                return this.f7089a.getHeightMode();
            default:
                return this.f7089a.getWidthMode();
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int k() {
        switch (this.d) {
            case 0:
                return this.f7089a.getPaddingLeft();
            default:
                return this.f7089a.getPaddingTop();
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int l() {
        switch (this.d) {
            case 0:
                AbstractC0430a0 abstractC0430a0 = this.f7089a;
                return (abstractC0430a0.getWidth() - abstractC0430a0.getPaddingLeft()) - abstractC0430a0.getPaddingRight();
            default:
                AbstractC0430a0 abstractC0430a02 = this.f7089a;
                return (abstractC0430a02.getHeight() - abstractC0430a02.getPaddingTop()) - abstractC0430a02.getPaddingBottom();
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int n(View view) {
        switch (this.d) {
            case 0:
                AbstractC0430a0 abstractC0430a0 = this.f7089a;
                Rect rect = this.f7091c;
                abstractC0430a0.getTransformedBoundingBox(view, true, rect);
                return rect.right;
            default:
                AbstractC0430a0 abstractC0430a02 = this.f7089a;
                Rect rect2 = this.f7091c;
                abstractC0430a02.getTransformedBoundingBox(view, true, rect2);
                return rect2.bottom;
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final int o(View view) {
        switch (this.d) {
            case 0:
                AbstractC0430a0 abstractC0430a0 = this.f7089a;
                Rect rect = this.f7091c;
                abstractC0430a0.getTransformedBoundingBox(view, true, rect);
                return rect.left;
            default:
                AbstractC0430a0 abstractC0430a02 = this.f7089a;
                Rect rect2 = this.f7091c;
                abstractC0430a02.getTransformedBoundingBox(view, true, rect2);
                return rect2.top;
        }
    }

    @Override // androidx.recyclerview.widget.I
    public final void p(int i10) {
        switch (this.d) {
            case 0:
                this.f7089a.offsetChildrenHorizontal(i10);
                break;
            default:
                this.f7089a.offsetChildrenVertical(i10);
                break;
        }
    }
}
