package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class L implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f7093a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f7094b;

    public /* synthetic */ L(RecyclerView recyclerView, int i10) {
        this.f7093a = i10;
        this.f7094b = recyclerView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        RecyclerView recyclerView;
        RecyclerView recyclerView2;
        RecyclerView recyclerView3 = this.f7094b;
        switch (this.f7093a) {
            case 0:
                if (recyclerView3.mFirstLayoutComplete && !recyclerView3.isLayoutRequested()) {
                    if (!recyclerView3.mIsAttached) {
                        recyclerView3.requestLayout();
                        break;
                    } else if (!recyclerView3.mLayoutSuppressed) {
                        recyclerView3.consumePendingUpdateOperations();
                        break;
                    } else {
                        recyclerView3.mLayoutWasDefered = true;
                        break;
                    }
                }
                break;
            default:
                V v9 = recyclerView3.mItemAnimator;
                if (v9 != null) {
                    C0448l c0448l = (C0448l) v9;
                    ArrayList arrayList = c0448l.f7187h;
                    boolean z3 = !arrayList.isEmpty();
                    ArrayList arrayList2 = c0448l.f7189j;
                    boolean z9 = !arrayList2.isEmpty();
                    ArrayList arrayList3 = c0448l.f7190k;
                    boolean z10 = !arrayList3.isEmpty();
                    ArrayList arrayList4 = c0448l.f7188i;
                    boolean z11 = !arrayList4.isEmpty();
                    if (z3 || z9 || z11 || z10) {
                        Iterator it = arrayList.iterator();
                        while (true) {
                            boolean zHasNext = it.hasNext();
                            recyclerView2 = recyclerView3;
                            long j10 = c0448l.d;
                            if (zHasNext) {
                                s0 s0Var = (s0) it.next();
                                View view = s0Var.f7250a;
                                ViewPropertyAnimator viewPropertyAnimatorAnimate = view.animate();
                                c0448l.f7196q.add(s0Var);
                                viewPropertyAnimatorAnimate.setDuration(j10).alpha(0.0f).setListener(new C0441g(c0448l, s0Var, viewPropertyAnimatorAnimate, view)).start();
                                recyclerView3 = recyclerView2;
                            } else {
                                arrayList.clear();
                                if (z9) {
                                    ArrayList arrayList5 = new ArrayList();
                                    arrayList5.addAll(arrayList2);
                                    c0448l.f7192m.add(arrayList5);
                                    arrayList2.clear();
                                    RunnableC0439f runnableC0439f = new RunnableC0439f(c0448l, arrayList5, 0);
                                    if (z3) {
                                        View view2 = ((C0447k) arrayList5.get(0)).f7181a.f7250a;
                                        WeakHashMap weakHashMap = R.X.f3966a;
                                        R.E.n(view2, runnableC0439f, j10);
                                    } else {
                                        runnableC0439f.run();
                                    }
                                }
                                if (z10) {
                                    ArrayList arrayList6 = new ArrayList();
                                    arrayList6.addAll(arrayList3);
                                    c0448l.f7193n.add(arrayList6);
                                    arrayList3.clear();
                                    RunnableC0439f runnableC0439f2 = new RunnableC0439f(c0448l, arrayList6, 1);
                                    if (z3) {
                                        View view3 = ((C0446j) arrayList6.get(0)).f7176a.f7250a;
                                        WeakHashMap weakHashMap2 = R.X.f3966a;
                                        R.E.n(view3, runnableC0439f2, j10);
                                    } else {
                                        runnableC0439f2.run();
                                    }
                                }
                                if (z11) {
                                    ArrayList arrayList7 = new ArrayList();
                                    arrayList7.addAll(arrayList4);
                                    c0448l.f7191l.add(arrayList7);
                                    arrayList4.clear();
                                    RunnableC0439f runnableC0439f3 = new RunnableC0439f(c0448l, arrayList7, 2);
                                    if (z3 || z9 || z10) {
                                        if (!z3) {
                                            j10 = 0;
                                        }
                                        long jMax = Math.max(z9 ? c0448l.f7123e : 0L, z10 ? c0448l.f7124f : 0L) + j10;
                                        View view4 = ((s0) arrayList7.get(0)).f7250a;
                                        WeakHashMap weakHashMap3 = R.X.f3966a;
                                        R.E.n(view4, runnableC0439f3, jMax);
                                    } else {
                                        runnableC0439f3.run();
                                    }
                                }
                            }
                        }
                    } else {
                        recyclerView2 = recyclerView3;
                    }
                    recyclerView = recyclerView2;
                } else {
                    recyclerView = recyclerView3;
                }
                recyclerView.mPostedAnimatorRunner = false;
                break;
        }
    }
}
