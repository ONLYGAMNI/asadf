package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/* renamed from: androidx.recyclerview.widget.m */
/* loaded from: classes.dex */
public final class C0449m {

    /* renamed from: a */
    public final List f7199a;

    /* renamed from: b */
    public final int[] f7200b;

    /* renamed from: c */
    public final int[] f7201c;
    public final AbstractC0453q d;

    /* renamed from: e */
    public final int f7202e;

    /* renamed from: f */
    public final int f7203f;
    public final boolean g;

    public C0449m(AbstractC0453q abstractC0453q, ArrayList arrayList, int[] iArr, int[] iArr2, boolean z3) {
        this.f7199a = arrayList;
        this.f7200b = iArr;
        this.f7201c = iArr2;
        Arrays.fill(iArr, 0);
        Arrays.fill(iArr2, 0);
        this.d = abstractC0453q;
        int iH = abstractC0453q.h();
        this.f7202e = iH;
        int iG = abstractC0453q.g();
        this.f7203f = iG;
        this.g = z3;
        C0452p c0452p = arrayList.isEmpty() ? null : (C0452p) arrayList.get(0);
        if (c0452p == null || c0452p.f7221a != 0 || c0452p.f7222b != 0) {
            C0452p c0452p2 = new C0452p();
            c0452p2.f7221a = 0;
            c0452p2.f7222b = 0;
            c0452p2.d = false;
            c0452p2.f7223c = 0;
            c0452p2.f7224e = false;
            arrayList.add(0, c0452p2);
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            C0452p c0452p3 = (C0452p) arrayList.get(size);
            int i10 = c0452p3.f7221a;
            int i11 = c0452p3.f7223c;
            int i12 = i10 + i11;
            int i13 = c0452p3.f7222b + i11;
            boolean z9 = this.g;
            int[] iArr3 = this.f7201c;
            int[] iArr4 = this.f7200b;
            if (z9) {
                while (iH > i12) {
                    if (iArr4[iH - 1] == 0) {
                        b(iH, iG, size, false);
                    }
                    iH--;
                }
                while (iG > i13) {
                    if (iArr3[iG - 1] == 0) {
                        b(iH, iG, size, true);
                    }
                    iG--;
                }
            }
            for (int i14 = 0; i14 < c0452p3.f7223c; i14++) {
                int i15 = c0452p3.f7221a + i14;
                int i16 = c0452p3.f7222b + i14;
                int i17 = this.d.a(i15, i16) ? 1 : 2;
                iArr4[i15] = (i16 << 5) | i17;
                iArr3[i16] = (i15 << 5) | i17;
            }
            iH = c0452p3.f7221a;
            iG = c0452p3.f7222b;
        }
    }

    public static C0450n c(int i10, ArrayList arrayList, boolean z3) {
        int size = arrayList.size() - 1;
        while (size >= 0) {
            C0450n c0450n = (C0450n) arrayList.get(size);
            if (c0450n.f7209a == i10 && c0450n.f7211c == z3) {
                arrayList.remove(size);
                while (size < arrayList.size()) {
                    ((C0450n) arrayList.get(size)).f7210b += z3 ? 1 : -1;
                    size++;
                }
                return c0450n;
            }
            size--;
        }
        return null;
    }

    public final void a(G g) {
        C0452p c0452p;
        int i10;
        int[] iArr;
        C0435d c0435d = g instanceof C0435d ? (C0435d) g : new C0435d(g);
        ArrayList arrayList = new ArrayList();
        List list = this.f7199a;
        int size = list.size() - 1;
        int i11 = this.f7202e;
        int i12 = this.f7203f;
        while (size >= 0) {
            C0452p c0452p2 = (C0452p) list.get(size);
            int i13 = c0452p2.f7223c;
            int i14 = c0452p2.f7221a + i13;
            int i15 = c0452p2.f7222b + i13;
            int[] iArr2 = this.f7200b;
            boolean z3 = this.g;
            AbstractC0453q abstractC0453q = this.d;
            if (i14 < i11) {
                int i16 = i11 - i14;
                if (z3) {
                    int i17 = i16 - 1;
                    while (i17 >= 0) {
                        List list2 = list;
                        int i18 = i14 + i17;
                        int i19 = iArr2[i18];
                        int i20 = size;
                        int i21 = i19 & 31;
                        if (i21 != 0) {
                            iArr = iArr2;
                            if (i21 == 4 || i21 == 8) {
                                int i22 = i19 >> 5;
                                c0452p = c0452p2;
                                C0450n c0450nC = c(i22, arrayList, false);
                                i10 = i13;
                                c0435d.b(i18, c0450nC.f7210b - 1);
                                if (i21 == 4) {
                                    int i23 = c0450nC.f7210b - 1;
                                    abstractC0453q.getClass();
                                    c0435d.c(i23, 1);
                                }
                            } else {
                                if (i21 != 16) {
                                    StringBuilder sbP = android.support.v4.media.session.a.p("unknown flag for pos ", i18, " ");
                                    sbP.append(Long.toBinaryString(i21));
                                    throw new IllegalStateException(sbP.toString());
                                }
                                arrayList.add(new C0450n(i18, i18, true));
                                c0452p = c0452p2;
                                i10 = i13;
                            }
                        } else {
                            c0452p = c0452p2;
                            i10 = i13;
                            iArr = iArr2;
                            int i24 = 1;
                            c0435d.a(i18, 1);
                            Iterator it = arrayList.iterator();
                            while (it.hasNext()) {
                                ((C0450n) it.next()).f7210b -= i24;
                                i24 = 1;
                            }
                        }
                        i17--;
                        list = list2;
                        c0452p2 = c0452p;
                        size = i20;
                        iArr2 = iArr;
                        i13 = i10;
                    }
                } else {
                    c0435d.a(i14, i16);
                }
            }
            List list3 = list;
            int i25 = size;
            C0452p c0452p3 = c0452p2;
            int i26 = i13;
            int[] iArr3 = iArr2;
            if (i15 < i12) {
                int i27 = i12 - i15;
                if (z3) {
                    for (int i28 = i27 - 1; i28 >= 0; i28--) {
                        int i29 = i15 + i28;
                        int i30 = this.f7201c[i29];
                        int i31 = i30 & 31;
                        if (i31 == 0) {
                            int i32 = 1;
                            c0435d.d(i14, 1);
                            Iterator it2 = arrayList.iterator();
                            while (it2.hasNext()) {
                                ((C0450n) it2.next()).f7210b += i32;
                                i32 = 1;
                            }
                        } else if (i31 == 4 || i31 == 8) {
                            c0435d.b(c(i30 >> 5, arrayList, true).f7210b, i14);
                            if (i31 == 4) {
                                abstractC0453q.getClass();
                                c0435d.c(i14, 1);
                            }
                        } else {
                            if (i31 != 16) {
                                StringBuilder sbP2 = android.support.v4.media.session.a.p("unknown flag for pos ", i29, " ");
                                sbP2.append(Long.toBinaryString(i31));
                                throw new IllegalStateException(sbP2.toString());
                            }
                            arrayList.add(new C0450n(i29, i14, false));
                        }
                    }
                } else {
                    c0435d.d(i14, i27);
                }
            }
            int i33 = i26 - 1;
            while (i33 >= 0) {
                C0452p c0452p4 = c0452p3;
                int i34 = c0452p4.f7221a + i33;
                if ((iArr3[i34] & 31) == 2) {
                    abstractC0453q.getClass();
                    c0435d.c(i34, 1);
                }
                i33--;
                c0452p3 = c0452p4;
            }
            C0452p c0452p5 = c0452p3;
            i11 = c0452p5.f7221a;
            i12 = c0452p5.f7222b;
            size = i25 - 1;
            list = list3;
        }
        c0435d.e();
    }

    public final void b(int i10, int i11, int i12, boolean z3) {
        int i13;
        int i14;
        int i15;
        if (z3) {
            i11--;
            i14 = i10;
            i13 = i11;
        } else {
            i13 = i10 - 1;
            i14 = i13;
        }
        while (i12 >= 0) {
            C0452p c0452p = (C0452p) this.f7199a.get(i12);
            int i16 = c0452p.f7221a;
            int i17 = c0452p.f7223c;
            int i18 = i16 + i17;
            int i19 = c0452p.f7222b + i17;
            int[] iArr = this.f7200b;
            int[] iArr2 = this.f7201c;
            AbstractC0453q abstractC0453q = this.d;
            if (z3) {
                for (int i20 = i14 - 1; i20 >= i18; i20--) {
                    if (abstractC0453q.b(i20, i13)) {
                        i15 = abstractC0453q.a(i20, i13) ? 8 : 4;
                        iArr2[i13] = (i20 << 5) | 16;
                        iArr[i20] = (i13 << 5) | i15;
                        return;
                    }
                }
            } else {
                for (int i21 = i11 - 1; i21 >= i19; i21--) {
                    if (abstractC0453q.b(i13, i21)) {
                        i15 = abstractC0453q.a(i13, i21) ? 8 : 4;
                        int i22 = i10 - 1;
                        iArr[i22] = (i21 << 5) | 16;
                        iArr2[i21] = (i22 << 5) | i15;
                        return;
                    }
                }
            }
            i14 = c0452p.f7221a;
            i11 = c0452p.f7222b;
            i12--;
        }
    }
}
