package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: androidx.recyclerview.widget.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0443h extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ s0 f7159a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f7160b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f7161c;
    public final /* synthetic */ int d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f7162e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ C0448l f7163f;

    public C0443h(C0448l c0448l, s0 s0Var, int i10, View view, int i11, ViewPropertyAnimator viewPropertyAnimator) {
        this.f7163f = c0448l;
        this.f7159a = s0Var;
        this.f7160b = i10;
        this.f7161c = view;
        this.d = i11;
        this.f7162e = viewPropertyAnimator;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
        int i10 = this.f7160b;
        View view = this.f7161c;
        if (i10 != 0) {
            view.setTranslationX(0.0f);
        }
        if (this.d != 0) {
            view.setTranslationY(0.0f);
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        this.f7162e.setListener(null);
        C0448l c0448l = this.f7163f;
        s0 s0Var = this.f7159a;
        c0448l.c(s0Var);
        c0448l.f7195p.remove(s0Var);
        c0448l.i();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        this.f7163f.getClass();
    }
}
