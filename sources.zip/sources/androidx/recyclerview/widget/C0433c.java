package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0433c implements G {

    /* renamed from: a, reason: collision with root package name */
    public final Object f7141a;

    @Override // androidx.recyclerview.widget.G
    public void a(int i10, int i11) {
        ((N) this.f7141a).f7096a.f(i10, i11);
    }

    @Override // androidx.recyclerview.widget.G
    public void b(int i10, int i11) {
        ((N) this.f7141a).f7096a.c(i10, i11);
    }

    @Override // androidx.recyclerview.widget.G
    public void c(int i10, int i11) {
        ((N) this.f7141a).f7096a.d(i10, i11);
    }

    @Override // androidx.recyclerview.widget.G
    public void d(int i10, int i11) {
        ((N) this.f7141a).f7096a.e(i10, i11);
    }
}
