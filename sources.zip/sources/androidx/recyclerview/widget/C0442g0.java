package androidx.recyclerview.widget;

import java.util.ArrayList;

/* renamed from: androidx.recyclerview.widget.g0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0442g0 {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f7156a = new ArrayList();

    /* renamed from: b, reason: collision with root package name */
    public int f7157b = 5;

    /* renamed from: c, reason: collision with root package name */
    public long f7158c = 0;
    public long d = 0;
}
