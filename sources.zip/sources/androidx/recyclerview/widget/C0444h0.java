package androidx.recyclerview.widget;

import android.util.SparseArray;

/* renamed from: androidx.recyclerview.widget.h0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0444h0 {

    /* renamed from: a, reason: collision with root package name */
    public SparseArray f7164a;

    /* renamed from: b, reason: collision with root package name */
    public int f7165b;

    public final C0442g0 a(int i10) {
        SparseArray sparseArray = this.f7164a;
        C0442g0 c0442g0 = (C0442g0) sparseArray.get(i10);
        if (c0442g0 != null) {
            return c0442g0;
        }
        C0442g0 c0442g02 = new C0442g0();
        sparseArray.put(i10, c0442g02);
        return c0442g02;
    }
}
