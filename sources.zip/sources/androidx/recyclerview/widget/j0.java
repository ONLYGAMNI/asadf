package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public interface j0 {
}
