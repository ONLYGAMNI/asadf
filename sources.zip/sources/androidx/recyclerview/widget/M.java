package androidx.recyclerview.widget;

import android.view.View;

/* loaded from: classes.dex */
public final class M implements G0, T {

    /* renamed from: a */
    public final /* synthetic */ RecyclerView f7095a;

    public /* synthetic */ M(RecyclerView recyclerView) {
        this.f7095a = recyclerView;
    }

    public void a(C0429a c0429a) {
        int i10 = c0429a.f7130a;
        RecyclerView recyclerView = this.f7095a;
        if (i10 == 1) {
            recyclerView.mLayout.onItemsAdded(recyclerView, c0429a.f7131b, c0429a.d);
            return;
        }
        if (i10 == 2) {
            recyclerView.mLayout.onItemsRemoved(recyclerView, c0429a.f7131b, c0429a.d);
        } else if (i10 == 4) {
            recyclerView.mLayout.onItemsUpdated(recyclerView, c0429a.f7131b, c0429a.d, c0429a.f7132c);
        } else {
            if (i10 != 8) {
                return;
            }
            recyclerView.mLayout.onItemsMoved(recyclerView, c0429a.f7131b, c0429a.d, 1);
        }
    }

    public void b(int i10) {
        RecyclerView recyclerView = this.f7095a;
        View childAt = recyclerView.getChildAt(i10);
        if (childAt != null) {
            recyclerView.dispatchChildDetached(childAt);
            childAt.clearAnimation();
        }
        recyclerView.removeViewAt(i10);
    }
}
