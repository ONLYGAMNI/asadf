package androidx.recyclerview.widget;

import android.graphics.PointF;
import android.view.View;

/* loaded from: classes.dex */
public class K extends w0 {
    private static final int MAX_SCROLL_ON_FLING_DURATION = 100;
    private I mHorizontalHelper;
    private I mVerticalHelper;

    public static int a(View view, I i10) {
        return ((i10.c(view) / 2) + i10.e(view)) - ((i10.l() / 2) + i10.k());
    }

    public static View b(AbstractC0430a0 abstractC0430a0, I i10) {
        int childCount = abstractC0430a0.getChildCount();
        View view = null;
        if (childCount == 0) {
            return null;
        }
        int iL = (i10.l() / 2) + i10.k();
        int i11 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = abstractC0430a0.getChildAt(i12);
            int iAbs = Math.abs(((i10.c(childAt) / 2) + i10.e(childAt)) - iL);
            if (iAbs < i11) {
                view = childAt;
                i11 = iAbs;
            }
        }
        return view;
    }

    public final I c(AbstractC0430a0 abstractC0430a0) {
        I i10 = this.mHorizontalHelper;
        if (i10 == null || i10.f7089a != abstractC0430a0) {
            this.mHorizontalHelper = new H(abstractC0430a0, 0);
        }
        return this.mHorizontalHelper;
    }

    @Override // androidx.recyclerview.widget.w0
    public int[] calculateDistanceToFinalSnap(AbstractC0430a0 abstractC0430a0, View view) {
        int[] iArr = new int[2];
        if (abstractC0430a0.canScrollHorizontally()) {
            iArr[0] = a(view, c(abstractC0430a0));
        } else {
            iArr[0] = 0;
        }
        if (abstractC0430a0.canScrollVertically()) {
            iArr[1] = a(view, d(abstractC0430a0));
        } else {
            iArr[1] = 0;
        }
        return iArr;
    }

    @Override // androidx.recyclerview.widget.w0
    public F createSnapScroller(AbstractC0430a0 abstractC0430a0) {
        if (abstractC0430a0 instanceof n0) {
            return new J(this, this.mRecyclerView.getContext());
        }
        return null;
    }

    public final I d(AbstractC0430a0 abstractC0430a0) {
        I i10 = this.mVerticalHelper;
        if (i10 == null || i10.f7089a != abstractC0430a0) {
            this.mVerticalHelper = new H(abstractC0430a0, 1);
        }
        return this.mVerticalHelper;
    }

    @Override // androidx.recyclerview.widget.w0
    public View findSnapView(AbstractC0430a0 abstractC0430a0) {
        if (abstractC0430a0.canScrollVertically()) {
            return b(abstractC0430a0, d(abstractC0430a0));
        }
        if (abstractC0430a0.canScrollHorizontally()) {
            return b(abstractC0430a0, c(abstractC0430a0));
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // androidx.recyclerview.widget.w0
    public int findTargetSnapPosition(AbstractC0430a0 abstractC0430a0, int i10, int i11) {
        PointF pointFComputeScrollVectorForPosition;
        int itemCount = abstractC0430a0.getItemCount();
        if (itemCount == 0) {
            return -1;
        }
        View view = null;
        I iD = abstractC0430a0.canScrollVertically() ? d(abstractC0430a0) : abstractC0430a0.canScrollHorizontally() ? c(abstractC0430a0) : null;
        if (iD == null) {
            return -1;
        }
        int childCount = abstractC0430a0.getChildCount();
        boolean z3 = false;
        int i12 = Integer.MAX_VALUE;
        int i13 = Integer.MIN_VALUE;
        View view2 = null;
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = abstractC0430a0.getChildAt(i14);
            if (childAt != null) {
                int iA = a(childAt, iD);
                if (iA <= 0 && iA > i13) {
                    view2 = childAt;
                    i13 = iA;
                }
                if (iA >= 0 && iA < i12) {
                    view = childAt;
                    i12 = iA;
                }
            }
        }
        boolean z9 = !abstractC0430a0.canScrollHorizontally() ? i11 <= 0 : i10 <= 0;
        if (z9 && view != null) {
            return abstractC0430a0.getPosition(view);
        }
        if (!z9 && view2 != null) {
            return abstractC0430a0.getPosition(view2);
        }
        if (z9) {
            view = view2;
        }
        if (view == null) {
            return -1;
        }
        int position = abstractC0430a0.getPosition(view);
        int itemCount2 = abstractC0430a0.getItemCount();
        if ((abstractC0430a0 instanceof n0) && (pointFComputeScrollVectorForPosition = ((n0) abstractC0430a0).computeScrollVectorForPosition(itemCount2 - 1)) != null && (pointFComputeScrollVectorForPosition.x < 0.0f || pointFComputeScrollVectorForPosition.y < 0.0f)) {
            z3 = true;
        }
        int i15 = position + (z3 == z9 ? -1 : 1);
        if (i15 < 0 || i15 >= itemCount) {
            return -1;
        }
        return i15;
    }
}
