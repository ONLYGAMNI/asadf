package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: androidx.recyclerview.widget.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0441g extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f7152a = 1;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ s0 f7153b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f7154c;
    public final /* synthetic */ ViewPropertyAnimator d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0448l f7155e;

    public C0441g(C0448l c0448l, s0 s0Var, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.f7155e = c0448l;
        this.f7153b = s0Var;
        this.d = viewPropertyAnimator;
        this.f7154c = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        switch (this.f7152a) {
            case 1:
                this.f7154c.setAlpha(1.0f);
                break;
            default:
                super.onAnimationCancel(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.f7152a) {
            case 0:
                this.d.setListener(null);
                this.f7154c.setAlpha(1.0f);
                C0448l c0448l = this.f7155e;
                s0 s0Var = this.f7153b;
                c0448l.c(s0Var);
                c0448l.f7196q.remove(s0Var);
                c0448l.i();
                break;
            default:
                this.d.setListener(null);
                C0448l c0448l2 = this.f7155e;
                s0 s0Var2 = this.f7153b;
                c0448l2.c(s0Var2);
                c0448l2.f7194o.remove(s0Var2);
                c0448l2.i();
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        switch (this.f7152a) {
            case 0:
                this.f7155e.getClass();
                break;
            default:
                this.f7155e.getClass();
                break;
        }
    }

    public C0441g(C0448l c0448l, s0 s0Var, View view, ViewPropertyAnimator viewPropertyAnimator) {
        this.f7155e = c0448l;
        this.f7153b = s0Var;
        this.f7154c = view;
        this.d = viewPropertyAnimator;
    }
}
