package androidx.recyclerview.widget;

import android.view.ViewGroup;

/* loaded from: classes.dex */
public abstract class N {

    /* renamed from: a, reason: collision with root package name */
    public final O f7096a = new O();

    /* renamed from: b, reason: collision with root package name */
    public boolean f7097b = false;

    public abstract int a();

    public long b(int i10) {
        return -1L;
    }

    public int c(int i10) {
        return 0;
    }

    public abstract void d(s0 s0Var, int i10);

    public abstract s0 e(int i10, ViewGroup viewGroup);

    public void f(s0 s0Var) {
    }

    public void g(s0 s0Var) {
    }

    public void h(s0 s0Var) {
    }

    public final void i() {
        if (this.f7096a.a()) {
            throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
        }
        this.f7097b = true;
    }
}
