package androidx.recyclerview.widget;

import android.view.View;

/* loaded from: classes.dex */
public interface D0 {
    int a();

    int b(View view);

    View c(int i10);

    int d();

    int e(View view);
}
