package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.e0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0438e0 {
}
