package androidx.recyclerview.widget;

import R.C0240c;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public final class i0 {

    /* renamed from: a */
    public final ArrayList f7170a;

    /* renamed from: b */
    public ArrayList f7171b;

    /* renamed from: c */
    public final ArrayList f7172c;
    public final List d;

    /* renamed from: e */
    public int f7173e;

    /* renamed from: f */
    public int f7174f;
    public C0444h0 g;

    /* renamed from: h */
    public final /* synthetic */ RecyclerView f7175h;

    public i0(RecyclerView recyclerView) {
        this.f7175h = recyclerView;
        ArrayList arrayList = new ArrayList();
        this.f7170a = arrayList;
        this.f7171b = null;
        this.f7172c = new ArrayList();
        this.d = Collections.unmodifiableList(arrayList);
        this.f7173e = 2;
        this.f7174f = 2;
    }

    public static void d(ViewGroup viewGroup, boolean z3) {
        for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = viewGroup.getChildAt(childCount);
            if (childAt instanceof ViewGroup) {
                d((ViewGroup) childAt, true);
            }
        }
        if (z3) {
            if (viewGroup.getVisibility() == 4) {
                viewGroup.setVisibility(0);
                viewGroup.setVisibility(4);
            } else {
                int visibility = viewGroup.getVisibility();
                viewGroup.setVisibility(4);
                viewGroup.setVisibility(visibility);
            }
        }
    }

    public final void a(s0 s0Var, boolean z3) {
        RecyclerView.clearNestedRecyclerViewIfNotNested(s0Var);
        View view = s0Var.f7250a;
        RecyclerView recyclerView = this.f7175h;
        u0 u0Var = recyclerView.mAccessibilityDelegate;
        if (u0Var != null) {
            t0 t0Var = u0Var.f7296e;
            R.X.n(view, t0Var instanceof t0 ? (C0240c) t0Var.f7267e.remove(view) : null);
        }
        if (z3) {
            N n9 = recyclerView.mAdapter;
            if (n9 != null) {
                n9.h(s0Var);
            }
            if (recyclerView.mState != null) {
                recyclerView.mViewInfoStore.d(s0Var);
            }
        }
        s0Var.f7265r = null;
        C0444h0 c0444h0C = c();
        c0444h0C.getClass();
        int i10 = s0Var.f7254f;
        ArrayList arrayList = c0444h0C.a(i10).f7156a;
        if (((C0442g0) c0444h0C.f7164a.get(i10)).f7157b <= arrayList.size()) {
            return;
        }
        s0Var.r();
        arrayList.add(s0Var);
    }

    public final int b(int i10) {
        RecyclerView recyclerView = this.f7175h;
        if (i10 >= 0 && i10 < recyclerView.mState.b()) {
            return !recyclerView.mState.g ? i10 : recyclerView.mAdapterHelper.f(i10, 0);
        }
        StringBuilder sbP = android.support.v4.media.session.a.p("invalid position ", i10, ". State item count is ");
        sbP.append(recyclerView.mState.b());
        sbP.append(recyclerView.exceptionLabel());
        throw new IndexOutOfBoundsException(sbP.toString());
    }

    public final C0444h0 c() {
        if (this.g == null) {
            C0444h0 c0444h0 = new C0444h0();
            c0444h0.f7164a = new SparseArray();
            c0444h0.f7165b = 0;
            this.g = c0444h0;
        }
        return this.g;
    }

    public final void e() {
        ArrayList arrayList = this.f7172c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            f(size);
        }
        arrayList.clear();
        if (RecyclerView.ALLOW_THREAD_GAP_WORK) {
            C0457v c0457v = this.f7175h.mPrefetchRegistry;
            int[] iArr = c0457v.f7299c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            c0457v.d = 0;
        }
    }

    public final void f(int i10) {
        ArrayList arrayList = this.f7172c;
        a((s0) arrayList.get(i10), true);
        arrayList.remove(i10);
    }

    public final void g(View view) {
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        boolean zO = childViewHolderInt.o();
        RecyclerView recyclerView = this.f7175h;
        if (zO) {
            recyclerView.removeDetachedView(view, false);
        }
        if (childViewHolderInt.n()) {
            childViewHolderInt.f7261n.k(childViewHolderInt);
        } else if (childViewHolderInt.u()) {
            childViewHolderInt.f7257j &= -33;
        }
        h(childViewHolderInt);
        if (recyclerView.mItemAnimator == null || childViewHolderInt.l()) {
            return;
        }
        recyclerView.mItemAnimator.d(childViewHolderInt);
    }

    /* JADX WARN: Code restructure failed: missing block: B:126:0x0093, code lost:
    
        r5 = r5 - 1;
     */
    /* JADX WARN: Removed duplicated region for block: B:120:0x0078  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x0030  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void h(androidx.recyclerview.widget.s0 r12) {
        /*
            Method dump skipped, instructions count: 268
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.i0.h(androidx.recyclerview.widget.s0):void");
    }

    public final void i(View view) {
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        boolean zH = childViewHolderInt.h(12);
        RecyclerView recyclerView = this.f7175h;
        if (!zH && childViewHolderInt.p() && !recyclerView.canReuseUpdatedViewHolder(childViewHolderInt)) {
            if (this.f7171b == null) {
                this.f7171b = new ArrayList();
            }
            childViewHolderInt.f7261n = this;
            childViewHolderInt.f7262o = true;
            this.f7171b.add(childViewHolderInt);
            return;
        }
        if (childViewHolderInt.k() && !childViewHolderInt.m() && !recyclerView.mAdapter.f7097b) {
            throw new IllegalArgumentException(android.support.v4.media.session.a.i(recyclerView, new StringBuilder("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.")));
        }
        childViewHolderInt.f7261n = this;
        childViewHolderInt.f7262o = false;
        this.f7170a.add(childViewHolderInt);
    }

    /* JADX WARN: Removed duplicated region for block: B:373:0x0080  */
    /* JADX WARN: Removed duplicated region for block: B:374:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:440:0x01b5  */
    /* JADX WARN: Removed duplicated region for block: B:508:0x02f5  */
    /* JADX WARN: Removed duplicated region for block: B:510:0x02f8  */
    /* JADX WARN: Removed duplicated region for block: B:549:0x0390 A[PHI: r5 r10
  0x0390: PHI (r5v9 boolean) = (r5v8 boolean), (r5v12 boolean) binds: [B:458:0x020d, B:516:0x030b] A[DONT_GENERATE, DONT_INLINE]
  0x0390: PHI (r10v3 androidx.recyclerview.widget.s0) = (r10v2 androidx.recyclerview.widget.s0), (r10v6 androidx.recyclerview.widget.s0) binds: [B:458:0x020d, B:516:0x030b] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:576:0x0422  */
    /* JADX WARN: Removed duplicated region for block: B:624:0x04ff  */
    /* JADX WARN: Removed duplicated region for block: B:625:0x0509  */
    /* JADX WARN: Removed duplicated region for block: B:633:0x0524  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final androidx.recyclerview.widget.s0 j(int r21, long r22) {
        /*
            Method dump skipped, instructions count: 1369
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.i0.j(int, long):androidx.recyclerview.widget.s0");
    }

    public final void k(s0 s0Var) {
        if (s0Var.f7262o) {
            this.f7171b.remove(s0Var);
        } else {
            this.f7170a.remove(s0Var);
        }
        s0Var.f7261n = null;
        s0Var.f7262o = false;
        s0Var.f7257j &= -33;
    }

    public final void l() {
        AbstractC0430a0 abstractC0430a0 = this.f7175h.mLayout;
        this.f7174f = this.f7173e + (abstractC0430a0 != null ? abstractC0430a0.mPrefetchMaxCountObserved : 0);
        ArrayList arrayList = this.f7172c;
        for (int size = arrayList.size() - 1; size >= 0 && arrayList.size() > this.f7174f; size--) {
            f(size);
        }
    }
}
