package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.List;

/* renamed from: androidx.recyclerview.widget.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0431b {
    public final M d;

    /* renamed from: a, reason: collision with root package name */
    public final Q.e f7133a = new Q.e(30);

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f7134b = new ArrayList();

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f7135c = new ArrayList();

    /* renamed from: f, reason: collision with root package name */
    public int f7137f = 0;

    /* renamed from: e, reason: collision with root package name */
    public final C0433c f7136e = new C0433c(this);

    public C0431b(M m9) {
        this.d = m9;
    }

    public final boolean a(int i10) {
        ArrayList arrayList = this.f7135c;
        int size = arrayList.size();
        for (int i11 = 0; i11 < size; i11++) {
            C0429a c0429a = (C0429a) arrayList.get(i11);
            int i12 = c0429a.f7130a;
            if (i12 == 8) {
                if (f(c0429a.d, i11 + 1) == i10) {
                    return true;
                }
            } else if (i12 == 1) {
                int i13 = c0429a.f7131b;
                int i14 = c0429a.d + i13;
                while (i13 < i14) {
                    if (f(i13, i11 + 1) == i10) {
                        return true;
                    }
                    i13++;
                }
            } else {
                continue;
            }
        }
        return false;
    }

    public final void b() {
        ArrayList arrayList = this.f7135c;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.d.a((C0429a) arrayList.get(i10));
        }
        l(arrayList);
        this.f7137f = 0;
    }

    public final void c() {
        b();
        ArrayList arrayList = this.f7134b;
        int size = arrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            C0429a c0429a = (C0429a) arrayList.get(i10);
            int i11 = c0429a.f7130a;
            M m9 = this.d;
            if (i11 == 1) {
                m9.a(c0429a);
                int i12 = c0429a.f7131b;
                int i13 = c0429a.d;
                RecyclerView recyclerView = m9.f7095a;
                recyclerView.offsetPositionRecordsForInsert(i12, i13);
                recyclerView.mItemsAddedOrRemoved = true;
            } else if (i11 == 2) {
                m9.a(c0429a);
                int i14 = c0429a.f7131b;
                int i15 = c0429a.d;
                RecyclerView recyclerView2 = m9.f7095a;
                recyclerView2.offsetPositionRecordsForRemove(i14, i15, true);
                recyclerView2.mItemsAddedOrRemoved = true;
                recyclerView2.mState.f7227c += i15;
            } else if (i11 == 4) {
                m9.a(c0429a);
                int i16 = c0429a.f7131b;
                int i17 = c0429a.d;
                RecyclerView recyclerView3 = m9.f7095a;
                recyclerView3.viewRangeUpdate(i16, i17, null);
                recyclerView3.mItemsChanged = true;
            } else if (i11 == 8) {
                m9.a(c0429a);
                int i18 = c0429a.f7131b;
                int i19 = c0429a.d;
                RecyclerView recyclerView4 = m9.f7095a;
                recyclerView4.offsetPositionRecordsForMove(i18, i19);
                recyclerView4.mItemsAddedOrRemoved = true;
            }
        }
        l(arrayList);
        this.f7137f = 0;
    }

    public final void d(C0429a c0429a) {
        int i10;
        int i11 = c0429a.f7130a;
        if (i11 == 1 || i11 == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int iM = m(c0429a.f7131b, i11);
        int i12 = c0429a.f7131b;
        int i13 = c0429a.f7130a;
        if (i13 == 2) {
            i10 = 0;
        } else {
            if (i13 != 4) {
                throw new IllegalArgumentException("op should be remove or update." + c0429a);
            }
            i10 = 1;
        }
        int i14 = 1;
        for (int i15 = 1; i15 < c0429a.d; i15++) {
            int iM2 = m((i10 * i15) + c0429a.f7131b, c0429a.f7130a);
            int i16 = c0429a.f7130a;
            if (i16 == 2 ? iM2 != iM : !(i16 == 4 && iM2 == iM + 1)) {
                C0429a c0429aH = h(i16, iM, i14);
                e(c0429aH, i12);
                c0429aH.f7132c = null;
                this.f7133a.e(c0429aH);
                if (c0429a.f7130a == 4) {
                    i12 += i14;
                }
                i14 = 1;
                iM = iM2;
            } else {
                i14++;
            }
        }
        c0429a.f7132c = null;
        this.f7133a.e(c0429a);
        if (i14 > 0) {
            C0429a c0429aH2 = h(c0429a.f7130a, iM, i14);
            e(c0429aH2, i12);
            c0429aH2.f7132c = null;
            this.f7133a.e(c0429aH2);
        }
    }

    public final void e(C0429a c0429a, int i10) {
        M m9 = this.d;
        m9.a(c0429a);
        int i11 = c0429a.f7130a;
        RecyclerView recyclerView = m9.f7095a;
        if (i11 != 2) {
            if (i11 != 4) {
                throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
            }
            recyclerView.viewRangeUpdate(i10, c0429a.d, null);
            recyclerView.mItemsChanged = true;
            return;
        }
        int i12 = c0429a.d;
        recyclerView.offsetPositionRecordsForRemove(i10, i12, true);
        recyclerView.mItemsAddedOrRemoved = true;
        recyclerView.mState.f7227c += i12;
    }

    public final int f(int i10, int i11) {
        ArrayList arrayList = this.f7135c;
        int size = arrayList.size();
        while (i11 < size) {
            C0429a c0429a = (C0429a) arrayList.get(i11);
            int i12 = c0429a.f7130a;
            if (i12 == 8) {
                int i13 = c0429a.f7131b;
                if (i13 == i10) {
                    i10 = c0429a.d;
                } else {
                    if (i13 < i10) {
                        i10--;
                    }
                    if (c0429a.d <= i10) {
                        i10++;
                    }
                }
            } else {
                int i14 = c0429a.f7131b;
                if (i14 > i10) {
                    continue;
                } else if (i12 == 2) {
                    int i15 = c0429a.d;
                    if (i10 < i14 + i15) {
                        return -1;
                    }
                    i10 -= i15;
                } else if (i12 == 1) {
                    i10 += c0429a.d;
                }
            }
            i11++;
        }
        return i10;
    }

    public final boolean g() {
        return this.f7134b.size() > 0;
    }

    public final C0429a h(int i10, int i11, int i12) {
        C0429a c0429a = (C0429a) this.f7133a.l();
        if (c0429a != null) {
            c0429a.f7130a = i10;
            c0429a.f7131b = i11;
            c0429a.d = i12;
            c0429a.f7132c = null;
            return c0429a;
        }
        C0429a c0429a2 = new C0429a();
        c0429a2.f7130a = i10;
        c0429a2.f7131b = i11;
        c0429a2.d = i12;
        c0429a2.f7132c = null;
        return c0429a2;
    }

    public final void i(C0429a c0429a) {
        this.f7135c.add(c0429a);
        int i10 = c0429a.f7130a;
        M m9 = this.d;
        if (i10 == 1) {
            int i11 = c0429a.f7131b;
            int i12 = c0429a.d;
            RecyclerView recyclerView = m9.f7095a;
            recyclerView.offsetPositionRecordsForInsert(i11, i12);
            recyclerView.mItemsAddedOrRemoved = true;
            return;
        }
        if (i10 == 2) {
            int i13 = c0429a.f7131b;
            int i14 = c0429a.d;
            RecyclerView recyclerView2 = m9.f7095a;
            recyclerView2.offsetPositionRecordsForRemove(i13, i14, false);
            recyclerView2.mItemsAddedOrRemoved = true;
            return;
        }
        if (i10 == 4) {
            int i15 = c0429a.f7131b;
            int i16 = c0429a.d;
            RecyclerView recyclerView3 = m9.f7095a;
            recyclerView3.viewRangeUpdate(i15, i16, null);
            recyclerView3.mItemsChanged = true;
            return;
        }
        if (i10 != 8) {
            throw new IllegalArgumentException("Unknown update op type for " + c0429a);
        }
        int i17 = c0429a.f7131b;
        int i18 = c0429a.d;
        RecyclerView recyclerView4 = m9.f7095a;
        recyclerView4.offsetPositionRecordsForMove(i17, i18);
        recyclerView4.mItemsAddedOrRemoved = true;
    }

    /* JADX WARN: Removed duplicated region for block: B:197:0x00a0 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:198:0x0127 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:201:0x0115 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:215:0x0009 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x006e  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0088  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x009b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void j() {
        /*
            Method dump skipped, instructions count: 714
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.C0431b.j():void");
    }

    public final void k(C0429a c0429a) {
        c0429a.f7132c = null;
        this.f7133a.e(c0429a);
    }

    public final void l(List list) {
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            k((C0429a) list.get(i10));
        }
        list.clear();
    }

    public final int m(int i10, int i11) {
        int i12;
        int i13;
        ArrayList arrayList = this.f7135c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            C0429a c0429a = (C0429a) arrayList.get(size);
            int i14 = c0429a.f7130a;
            if (i14 == 8) {
                int i15 = c0429a.f7131b;
                int i16 = c0429a.d;
                if (i15 < i16) {
                    i13 = i15;
                    i12 = i16;
                } else {
                    i12 = i15;
                    i13 = i16;
                }
                if (i10 < i13 || i10 > i12) {
                    if (i10 < i15) {
                        if (i11 == 1) {
                            c0429a.f7131b = i15 + 1;
                            c0429a.d = i16 + 1;
                        } else if (i11 == 2) {
                            c0429a.f7131b = i15 - 1;
                            c0429a.d = i16 - 1;
                        }
                    }
                } else if (i13 == i15) {
                    if (i11 == 1) {
                        c0429a.d = i16 + 1;
                    } else if (i11 == 2) {
                        c0429a.d = i16 - 1;
                    }
                    i10++;
                } else {
                    if (i11 == 1) {
                        c0429a.f7131b = i15 + 1;
                    } else if (i11 == 2) {
                        c0429a.f7131b = i15 - 1;
                    }
                    i10--;
                }
            } else {
                int i17 = c0429a.f7131b;
                if (i17 <= i10) {
                    if (i14 == 1) {
                        i10 -= c0429a.d;
                    } else if (i14 == 2) {
                        i10 += c0429a.d;
                    }
                } else if (i11 == 1) {
                    c0429a.f7131b = i17 + 1;
                } else if (i11 == 2) {
                    c0429a.f7131b = i17 - 1;
                }
            }
        }
        for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
            C0429a c0429a2 = (C0429a) arrayList.get(size2);
            if (c0429a2.f7130a == 8) {
                int i18 = c0429a2.d;
                if (i18 == c0429a2.f7131b || i18 < 0) {
                    arrayList.remove(size2);
                    c0429a2.f7132c = null;
                    this.f7133a.e(c0429a2);
                }
            } else if (c0429a2.d <= 0) {
                arrayList.remove(size2);
                c0429a2.f7132c = null;
                this.f7133a.e(c0429a2);
            }
        }
        return i10;
    }
}
