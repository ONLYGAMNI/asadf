package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.f0 */
/* loaded from: classes.dex */
public abstract class AbstractC0440f0 {
    public void onScrollStateChanged(RecyclerView recyclerView, int i10) {
    }

    public void onScrolled(RecyclerView recyclerView, int i10, int i11) {
    }
}
