package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.AbstractC0385e;
import java.util.Arrays;
import s2.AbstractC1397b;

/* loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {

    /* renamed from: a */
    public boolean f7081a;

    /* renamed from: b */
    public int f7082b;

    /* renamed from: c */
    public int[] f7083c;
    public View[] d;

    /* renamed from: e */
    public final SparseIntArray f7084e;

    /* renamed from: f */
    public final SparseIntArray f7085f;
    public AbstractC0385e g;

    /* renamed from: h */
    public final Rect f7086h;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i10, int i11) {
        super(context, attributeSet, i10, i11);
        this.f7081a = false;
        this.f7082b = -1;
        this.f7084e = new SparseIntArray();
        this.f7085f = new SparseIntArray();
        this.g = new C0460y();
        this.f7086h = new Rect();
        y(AbstractC0430a0.getProperties(context, attributeSet, i10, i11).f7128b);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final boolean checkLayoutParams(C0432b0 c0432b0) {
        return c0432b0 instanceof C0461z;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void collectPrefetchPositionsForLayoutState(p0 p0Var, D d, Y y9) {
        int i10;
        int iJ = this.f7082b;
        for (int i11 = 0; i11 < this.f7082b && (i10 = d.d) >= 0 && i10 < p0Var.b() && iJ > 0; i11++) {
            int i12 = d.d;
            ((C0457v) y9).a(i12, Math.max(0, d.g));
            iJ -= this.g.j(i12);
            d.d += d.f7058e;
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final View findReferenceChild(i0 i0Var, p0 p0Var, int i10, int i11, int i12) {
        ensureLayoutState();
        int iK = this.mOrientationHelper.k();
        int iG = this.mOrientationHelper.g();
        int i13 = i11 > i10 ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i10 != i11) {
            View childAt = getChildAt(i10);
            int position = getPosition(childAt);
            if (position >= 0 && position < i12 && v(position, i0Var, p0Var) == 0) {
                if (((C0432b0) childAt.getLayoutParams()).f7138a.m()) {
                    if (view2 == null) {
                        view2 = childAt;
                    }
                } else {
                    if (this.mOrientationHelper.e(childAt) < iG && this.mOrientationHelper.b(childAt) >= iK) {
                        return childAt;
                    }
                    if (view == null) {
                        view = childAt;
                    }
                }
            }
            i10 += i13;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0430a0
    public final C0432b0 generateDefaultLayoutParams() {
        return this.mOrientation == 0 ? new C0461z(-2, -1) : new C0461z(-1, -2);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final C0432b0 generateLayoutParams(Context context, AttributeSet attributeSet) {
        C0461z c0461z = new C0461z(context, attributeSet);
        c0461z.f7317e = -1;
        c0461z.f7318f = 0;
        return c0461z;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final int getColumnCountForAccessibility(i0 i0Var, p0 p0Var) {
        if (this.mOrientation == 1) {
            return this.f7082b;
        }
        if (p0Var.b() < 1) {
            return 0;
        }
        return u(p0Var.b() - 1, i0Var, p0Var) + 1;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final int getRowCountForAccessibility(i0 i0Var, p0 p0Var) {
        if (this.mOrientation == 0) {
            return this.f7082b;
        }
        if (p0Var.b() < 1) {
            return 0;
        }
        return u(p0Var.b() - 1, i0Var, p0Var) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void layoutChunk(i0 i0Var, p0 p0Var, D d, C c4) {
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int iD;
        int iD2;
        int iD3;
        int childMeasureSpec;
        int childMeasureSpec2;
        boolean z3;
        int i18;
        View viewB;
        int iJ = this.mOrientationHelper.j();
        boolean z9 = iJ != 1073741824;
        int i19 = getChildCount() > 0 ? this.f7083c[this.f7082b] : 0;
        if (z9) {
            z();
        }
        boolean z10 = d.f7058e == 1;
        int iV = this.f7082b;
        if (!z10) {
            iV = v(d.d, i0Var, p0Var) + w(d.d, i0Var, p0Var);
        }
        int i20 = 0;
        while (i20 < this.f7082b && (i18 = d.d) >= 0 && i18 < p0Var.b() && iV > 0) {
            int i21 = d.d;
            int iW = w(i21, i0Var, p0Var);
            if (iW > this.f7082b) {
                StringBuilder sb = new StringBuilder("Item at position ");
                sb.append(i21);
                sb.append(" requires ");
                sb.append(iW);
                sb.append(" spans but GridLayoutManager has only ");
                throw new IllegalArgumentException(AbstractC1397b.d(sb, this.f7082b, " spans."));
            }
            iV -= iW;
            if (iV < 0 || (viewB = d.b(i0Var)) == null) {
                break;
            }
            this.d[i20] = viewB;
            i20++;
        }
        if (i20 == 0) {
            c4.f7049b = true;
            return;
        }
        if (z10) {
            i12 = 1;
            i11 = i20;
            i10 = 0;
        } else {
            i10 = i20 - 1;
            i11 = -1;
            i12 = -1;
        }
        int i22 = 0;
        while (i10 != i11) {
            View view = this.d[i10];
            C0461z c0461z = (C0461z) view.getLayoutParams();
            int iW2 = w(getPosition(view), i0Var, p0Var);
            c0461z.f7318f = iW2;
            c0461z.f7317e = i22;
            i22 += iW2;
            i10 += i12;
        }
        float f10 = 0.0f;
        int i23 = 0;
        for (int i24 = 0; i24 < i20; i24++) {
            View view2 = this.d[i24];
            if (d.f7063k != null) {
                z3 = false;
                if (z10) {
                    addDisappearingView(view2);
                } else {
                    addDisappearingView(view2, 0);
                }
            } else if (z10) {
                addView(view2);
                z3 = false;
            } else {
                z3 = false;
                addView(view2, 0);
            }
            calculateItemDecorationsForChild(view2, this.f7086h);
            x(view2, iJ, z3);
            int iC = this.mOrientationHelper.c(view2);
            if (iC > i23) {
                i23 = iC;
            }
            float fD = (this.mOrientationHelper.d(view2) * 1.0f) / ((C0461z) view2.getLayoutParams()).f7318f;
            if (fD > f10) {
                f10 = fD;
            }
        }
        if (z9) {
            r(Math.max(Math.round(f10 * this.f7082b), i19));
            i23 = 0;
            for (int i25 = 0; i25 < i20; i25++) {
                View view3 = this.d[i25];
                x(view3, 1073741824, true);
                int iC2 = this.mOrientationHelper.c(view3);
                if (iC2 > i23) {
                    i23 = iC2;
                }
            }
        }
        for (int i26 = 0; i26 < i20; i26++) {
            View view4 = this.d[i26];
            if (this.mOrientationHelper.c(view4) != i23) {
                C0461z c0461z2 = (C0461z) view4.getLayoutParams();
                Rect rect = c0461z2.f7139b;
                int i27 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) c0461z2).topMargin + ((ViewGroup.MarginLayoutParams) c0461z2).bottomMargin;
                int i28 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) c0461z2).leftMargin + ((ViewGroup.MarginLayoutParams) c0461z2).rightMargin;
                int iT = t(c0461z2.f7317e, c0461z2.f7318f);
                if (this.mOrientation == 1) {
                    childMeasureSpec2 = AbstractC0430a0.getChildMeasureSpec(iT, 1073741824, i28, ((ViewGroup.MarginLayoutParams) c0461z2).width, false);
                    childMeasureSpec = View.MeasureSpec.makeMeasureSpec(i23 - i27, 1073741824);
                } else {
                    int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i23 - i28, 1073741824);
                    childMeasureSpec = AbstractC0430a0.getChildMeasureSpec(iT, 1073741824, i27, ((ViewGroup.MarginLayoutParams) c0461z2).height, false);
                    childMeasureSpec2 = iMakeMeasureSpec;
                }
                if (shouldReMeasureChild(view4, childMeasureSpec2, childMeasureSpec, (C0432b0) view4.getLayoutParams())) {
                    view4.measure(childMeasureSpec2, childMeasureSpec);
                }
            }
        }
        int i29 = 0;
        c4.f7048a = i23;
        if (this.mOrientation != 1) {
            if (d.f7059f == -1) {
                int i30 = d.f7056b;
                i14 = i30 - i23;
                i13 = i30;
            } else {
                int i31 = d.f7056b;
                i13 = i31 + i23;
                i14 = i31;
            }
            i15 = 0;
            i16 = 0;
        } else if (d.f7059f == -1) {
            int i32 = d.f7056b;
            i14 = 0;
            i13 = 0;
            i16 = i32 - i23;
            i15 = i32;
        } else {
            i16 = d.f7056b;
            i15 = i16 + i23;
            i14 = 0;
            i13 = 0;
        }
        while (i29 < i20) {
            View view5 = this.d[i29];
            C0461z c0461z3 = (C0461z) view5.getLayoutParams();
            if (this.mOrientation == 1) {
                if (isLayoutRTL()) {
                    int paddingLeft = getPaddingLeft() + this.f7083c[this.f7082b - c0461z3.f7317e];
                    iD2 = paddingLeft;
                    iD = paddingLeft - this.mOrientationHelper.d(view5);
                } else {
                    int paddingLeft2 = getPaddingLeft() + this.f7083c[c0461z3.f7317e];
                    iD = paddingLeft2;
                    iD2 = this.mOrientationHelper.d(view5) + paddingLeft2;
                }
                i17 = i16;
                iD3 = i15;
            } else {
                int paddingTop = getPaddingTop() + this.f7083c[c0461z3.f7317e];
                i17 = paddingTop;
                iD = i14;
                iD2 = i13;
                iD3 = this.mOrientationHelper.d(view5) + paddingTop;
            }
            layoutDecoratedWithMargins(view5, iD, i17, iD2, iD3);
            if (c0461z3.f7138a.m() || c0461z3.f7138a.p()) {
                c4.f7050c = true;
            }
            c4.d |= view5.hasFocusable();
            i29++;
            i15 = iD3;
            i14 = iD;
            i13 = iD2;
            i16 = i17;
        }
        Arrays.fill(this.d, (Object) null);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void onAnchorReady(i0 i0Var, p0 p0Var, B b7, int i10) {
        super.onAnchorReady(i0Var, p0Var, b7, i10);
        z();
        if (p0Var.b() > 0 && !p0Var.g) {
            boolean z3 = i10 == 1;
            int iV = v(b7.f7040b, i0Var, p0Var);
            if (z3) {
                while (iV > 0) {
                    int i11 = b7.f7040b;
                    if (i11 <= 0) {
                        break;
                    }
                    int i12 = i11 - 1;
                    b7.f7040b = i12;
                    iV = v(i12, i0Var, p0Var);
                }
            } else {
                int iB = p0Var.b() - 1;
                int i13 = b7.f7040b;
                while (i13 < iB) {
                    int i14 = i13 + 1;
                    int iV2 = v(i14, i0Var, p0Var);
                    if (iV2 <= iV) {
                        break;
                    }
                    i13 = i14;
                    iV = iV2;
                }
                b7.f7040b = i13;
            }
        }
        s();
    }

    /* JADX WARN: Code restructure failed: missing block: B:145:0x00d1, code lost:
    
        if (r13 == (r2 > r15)) goto L136;
     */
    /* JADX WARN: Removed duplicated region for block: B:161:0x00f9  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x010f  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0430a0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final android.view.View onFocusSearchFailed(android.view.View r24, int r25, androidx.recyclerview.widget.i0 r26, androidx.recyclerview.widget.p0 r27) {
        /*
            Method dump skipped, instructions count: 317
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.onFocusSearchFailed(android.view.View, int, androidx.recyclerview.widget.i0, androidx.recyclerview.widget.p0):android.view.View");
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final void onInitializeAccessibilityNodeInfoForItem(i0 i0Var, p0 p0Var, View view, S.j jVar) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0461z)) {
            super.onInitializeAccessibilityNodeInfoForItem(view, jVar);
            return;
        }
        C0461z c0461z = (C0461z) layoutParams;
        int iU = u(c0461z.f7138a.f(), i0Var, p0Var);
        if (this.mOrientation == 0) {
            jVar.h(S.i.b(c0461z.f7317e, c0461z.f7318f, iU, 1, false));
        } else {
            jVar.h(S.i.b(iU, 1, c0461z.f7317e, c0461z.f7318f, false));
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final void onItemsAdded(RecyclerView recyclerView, int i10, int i11) {
        this.g.k();
        ((SparseIntArray) this.g.f6759c).clear();
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final void onItemsChanged(RecyclerView recyclerView) {
        this.g.k();
        ((SparseIntArray) this.g.f6759c).clear();
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final void onItemsMoved(RecyclerView recyclerView, int i10, int i11, int i12) {
        this.g.k();
        ((SparseIntArray) this.g.f6759c).clear();
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final void onItemsRemoved(RecyclerView recyclerView, int i10, int i11) {
        this.g.k();
        ((SparseIntArray) this.g.f6759c).clear();
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final void onItemsUpdated(RecyclerView recyclerView, int i10, int i11, Object obj) {
        this.g.k();
        ((SparseIntArray) this.g.f6759c).clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0430a0
    public void onLayoutChildren(i0 i0Var, p0 p0Var) {
        boolean z3 = p0Var.g;
        SparseIntArray sparseIntArray = this.f7085f;
        SparseIntArray sparseIntArray2 = this.f7084e;
        if (z3) {
            int childCount = getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                C0461z c0461z = (C0461z) getChildAt(i10).getLayoutParams();
                int iF = c0461z.f7138a.f();
                sparseIntArray2.put(iF, c0461z.f7318f);
                sparseIntArray.put(iF, c0461z.f7317e);
            }
        }
        super.onLayoutChildren(i0Var, p0Var);
        sparseIntArray2.clear();
        sparseIntArray.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0430a0
    public final void onLayoutCompleted(p0 p0Var) {
        super.onLayoutCompleted(p0Var);
        this.f7081a = false;
    }

    public final void r(int i10) {
        int i11;
        int[] iArr = this.f7083c;
        int i12 = this.f7082b;
        if (iArr == null || iArr.length != i12 + 1 || iArr[iArr.length - 1] != i10) {
            iArr = new int[i12 + 1];
        }
        int i13 = 0;
        iArr[0] = 0;
        int i14 = i10 / i12;
        int i15 = i10 % i12;
        int i16 = 0;
        for (int i17 = 1; i17 <= i12; i17++) {
            i13 += i15;
            if (i13 <= 0 || i12 - i13 >= i15) {
                i11 = i14;
            } else {
                i11 = i14 + 1;
                i13 -= i12;
            }
            i16 += i11;
            iArr[i17] = i16;
        }
        this.f7083c = iArr;
    }

    public final void s() {
        View[] viewArr = this.d;
        if (viewArr == null || viewArr.length != this.f7082b) {
            this.d = new View[this.f7082b];
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0430a0
    public final int scrollHorizontallyBy(int i10, i0 i0Var, p0 p0Var) {
        z();
        s();
        return super.scrollHorizontallyBy(i10, i0Var, p0Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0430a0
    public final int scrollVerticallyBy(int i10, i0 i0Var, p0 p0Var) {
        z();
        s();
        return super.scrollVerticallyBy(i10, i0Var, p0Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final void setMeasuredDimension(Rect rect, int i10, int i11) {
        int iChooseSize;
        int iChooseSize2;
        if (this.f7083c == null) {
            super.setMeasuredDimension(rect, i10, i11);
        }
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        if (this.mOrientation == 1) {
            iChooseSize2 = AbstractC0430a0.chooseSize(i11, rect.height() + paddingBottom, getMinimumHeight());
            int[] iArr = this.f7083c;
            iChooseSize = AbstractC0430a0.chooseSize(i10, iArr[iArr.length - 1] + paddingRight, getMinimumWidth());
        } else {
            iChooseSize = AbstractC0430a0.chooseSize(i10, rect.width() + paddingRight, getMinimumWidth());
            int[] iArr2 = this.f7083c;
            iChooseSize2 = AbstractC0430a0.chooseSize(i11, iArr2[iArr2.length - 1] + paddingBottom, getMinimumHeight());
        }
        setMeasuredDimension(iChooseSize, iChooseSize2);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void setStackFromEnd(boolean z3) {
        if (z3) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.setStackFromEnd(false);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.AbstractC0430a0
    public final boolean supportsPredictiveItemAnimations() {
        return this.mPendingSavedState == null && !this.f7081a;
    }

    public final int t(int i10, int i11) {
        if (this.mOrientation != 1 || !isLayoutRTL()) {
            int[] iArr = this.f7083c;
            return iArr[i11 + i10] - iArr[i10];
        }
        int[] iArr2 = this.f7083c;
        int i12 = this.f7082b;
        return iArr2[i12 - i10] - iArr2[(i12 - i10) - i11];
    }

    public final int u(int i10, i0 i0Var, p0 p0Var) {
        if (!p0Var.g) {
            return this.g.h(i10, this.f7082b);
        }
        int iB = i0Var.b(i10);
        if (iB != -1) {
            return this.g.h(iB, this.f7082b);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i10);
        return 0;
    }

    public final int v(int i10, i0 i0Var, p0 p0Var) {
        if (!p0Var.g) {
            return this.g.i(i10, this.f7082b);
        }
        int i11 = this.f7085f.get(i10, -1);
        if (i11 != -1) {
            return i11;
        }
        int iB = i0Var.b(i10);
        if (iB != -1) {
            return this.g.i(iB, this.f7082b);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i10);
        return 0;
    }

    public final int w(int i10, i0 i0Var, p0 p0Var) {
        if (!p0Var.g) {
            return this.g.j(i10);
        }
        int i11 = this.f7084e.get(i10, -1);
        if (i11 != -1) {
            return i11;
        }
        int iB = i0Var.b(i10);
        if (iB != -1) {
            return this.g.j(iB);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i10);
        return 1;
    }

    public final void x(View view, int i10, boolean z3) {
        int childMeasureSpec;
        int childMeasureSpec2;
        C0461z c0461z = (C0461z) view.getLayoutParams();
        Rect rect = c0461z.f7139b;
        int i11 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) c0461z).topMargin + ((ViewGroup.MarginLayoutParams) c0461z).bottomMargin;
        int i12 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) c0461z).leftMargin + ((ViewGroup.MarginLayoutParams) c0461z).rightMargin;
        int iT = t(c0461z.f7317e, c0461z.f7318f);
        if (this.mOrientation == 1) {
            childMeasureSpec2 = AbstractC0430a0.getChildMeasureSpec(iT, i10, i12, ((ViewGroup.MarginLayoutParams) c0461z).width, false);
            childMeasureSpec = AbstractC0430a0.getChildMeasureSpec(this.mOrientationHelper.l(), getHeightMode(), i11, ((ViewGroup.MarginLayoutParams) c0461z).height, true);
        } else {
            int childMeasureSpec3 = AbstractC0430a0.getChildMeasureSpec(iT, i10, i11, ((ViewGroup.MarginLayoutParams) c0461z).height, false);
            int childMeasureSpec4 = AbstractC0430a0.getChildMeasureSpec(this.mOrientationHelper.l(), getWidthMode(), i12, ((ViewGroup.MarginLayoutParams) c0461z).width, true);
            childMeasureSpec = childMeasureSpec3;
            childMeasureSpec2 = childMeasureSpec4;
        }
        C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
        if (z3 ? shouldReMeasureChild(view, childMeasureSpec2, childMeasureSpec, c0432b0) : shouldMeasureChild(view, childMeasureSpec2, childMeasureSpec, c0432b0)) {
            view.measure(childMeasureSpec2, childMeasureSpec);
        }
    }

    public final void y(int i10) {
        if (i10 == this.f7082b) {
            return;
        }
        this.f7081a = true;
        if (i10 < 1) {
            throw new IllegalArgumentException(android.support.v4.media.session.a.h(i10, "Span count should be at least 1. Provided "));
        }
        this.f7082b = i10;
        this.g.k();
        requestLayout();
    }

    public final void z() {
        int height;
        int paddingTop;
        if (getOrientation() == 1) {
            height = getWidth() - getPaddingRight();
            paddingTop = getPaddingLeft();
        } else {
            height = getHeight() - getPaddingBottom();
            paddingTop = getPaddingTop();
        }
        r(height - paddingTop);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public final C0432b0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            C0461z c0461z = new C0461z((ViewGroup.MarginLayoutParams) layoutParams);
            c0461z.f7317e = -1;
            c0461z.f7318f = 0;
            return c0461z;
        }
        C0461z c0461z2 = new C0461z(layoutParams);
        c0461z2.f7317e = -1;
        c0461z2.f7318f = 0;
        return c0461z2;
    }

    public GridLayoutManager(int i10, int i11) {
        super(i11);
        this.f7081a = false;
        this.f7082b = -1;
        this.f7084e = new SparseIntArray();
        this.f7085f = new SparseIntArray();
        this.g = new C0460y();
        this.f7086h = new Rect();
        y(i10);
    }
}
