package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class F0 {
    public static final Q.e d = new Q.e(20);

    /* renamed from: a, reason: collision with root package name */
    public int f7078a;

    /* renamed from: b, reason: collision with root package name */
    public U f7079b;

    /* renamed from: c, reason: collision with root package name */
    public U f7080c;

    public static F0 a() {
        F0 f02 = (F0) d.l();
        return f02 == null ? new F0() : f02;
    }
}
