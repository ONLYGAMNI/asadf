package androidx.recyclerview.widget;

import android.util.Log;
import android.view.animation.Interpolator;

/* loaded from: classes.dex */
public final class m0 {

    /* renamed from: a */
    public int f7204a;

    /* renamed from: b */
    public int f7205b;

    /* renamed from: c */
    public int f7206c;
    public int d;

    /* renamed from: e */
    public Interpolator f7207e;

    /* renamed from: f */
    public boolean f7208f;
    public int g;

    public final void a(RecyclerView recyclerView) {
        int i10 = this.d;
        if (i10 >= 0) {
            this.d = -1;
            recyclerView.jumpToPositionForSmoothScroller(i10);
            this.f7208f = false;
            return;
        }
        if (!this.f7208f) {
            this.g = 0;
            return;
        }
        Interpolator interpolator = this.f7207e;
        if (interpolator != null && this.f7206c < 1) {
            throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
        }
        int i11 = this.f7206c;
        if (i11 < 1) {
            throw new IllegalStateException("Scroll duration must be a positive number");
        }
        recyclerView.mViewFlinger.b(this.f7204a, this.f7205b, interpolator, i11);
        int i12 = this.g + 1;
        this.g = i12;
        if (i12 > 10) {
            Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
        }
        this.f7208f = false;
    }
}
