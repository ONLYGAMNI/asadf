package androidx.recyclerview.widget;

import android.graphics.PointF;

/* loaded from: classes.dex */
public interface n0 {
    PointF computeScrollVectorForPosition(int i10);
}
