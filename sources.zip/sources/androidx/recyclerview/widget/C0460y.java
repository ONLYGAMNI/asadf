package androidx.recyclerview.widget;

import androidx.fragment.app.AbstractC0385e;

/* renamed from: androidx.recyclerview.widget.y, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0460y extends AbstractC0385e {
    @Override // androidx.fragment.app.AbstractC0385e
    public final int i(int i10, int i11) {
        return i10 % i11;
    }

    @Override // androidx.fragment.app.AbstractC0385e
    public final int j(int i10) {
        return 1;
    }
}
