package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class l0 extends Z.b {
    public static final Parcelable.Creator<l0> CREATOR = new B.i(5);

    /* renamed from: c, reason: collision with root package name */
    public Parcelable f7198c;

    public l0(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f7198c = parcel.readParcelable(classLoader == null ? AbstractC0430a0.class.getClassLoader() : classLoader);
    }

    @Override // Z.b, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        super.writeToParcel(parcel, i10);
        parcel.writeParcelable(this.f7198c, 0);
    }
}
