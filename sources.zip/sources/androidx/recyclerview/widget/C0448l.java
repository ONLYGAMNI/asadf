package androidx.recyclerview.widget;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/* renamed from: androidx.recyclerview.widget.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0448l extends V {

    /* renamed from: s, reason: collision with root package name */
    public static TimeInterpolator f7186s;
    public boolean g;

    /* renamed from: h, reason: collision with root package name */
    public ArrayList f7187h;

    /* renamed from: i, reason: collision with root package name */
    public ArrayList f7188i;

    /* renamed from: j, reason: collision with root package name */
    public ArrayList f7189j;

    /* renamed from: k, reason: collision with root package name */
    public ArrayList f7190k;

    /* renamed from: l, reason: collision with root package name */
    public ArrayList f7191l;

    /* renamed from: m, reason: collision with root package name */
    public ArrayList f7192m;

    /* renamed from: n, reason: collision with root package name */
    public ArrayList f7193n;

    /* renamed from: o, reason: collision with root package name */
    public ArrayList f7194o;

    /* renamed from: p, reason: collision with root package name */
    public ArrayList f7195p;

    /* renamed from: q, reason: collision with root package name */
    public ArrayList f7196q;

    /* renamed from: r, reason: collision with root package name */
    public ArrayList f7197r;

    public static void h(ArrayList arrayList) {
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            ((s0) arrayList.get(size)).f7250a.animate().cancel();
        }
    }

    @Override // androidx.recyclerview.widget.V
    public final boolean a(s0 s0Var, s0 s0Var2, U u7, U u9) {
        int i10;
        int i11;
        int i12 = u7.f7118a;
        int i13 = u7.f7119b;
        if (s0Var2.t()) {
            int i14 = u7.f7118a;
            i11 = u7.f7119b;
            i10 = i14;
        } else {
            i10 = u9.f7118a;
            i11 = u9.f7119b;
        }
        if (s0Var == s0Var2) {
            return g(s0Var, i12, i13, i10, i11);
        }
        View view = s0Var.f7250a;
        float translationX = view.getTranslationX();
        float translationY = view.getTranslationY();
        float alpha = view.getAlpha();
        l(s0Var);
        view.setTranslationX(translationX);
        view.setTranslationY(translationY);
        view.setAlpha(alpha);
        l(s0Var2);
        float f10 = -((int) ((i10 - i12) - translationX));
        View view2 = s0Var2.f7250a;
        view2.setTranslationX(f10);
        view2.setTranslationY(-((int) ((i11 - i13) - translationY)));
        view2.setAlpha(0.0f);
        ArrayList arrayList = this.f7190k;
        C0446j c0446j = new C0446j();
        c0446j.f7176a = s0Var;
        c0446j.f7177b = s0Var2;
        c0446j.f7178c = i12;
        c0446j.d = i13;
        c0446j.f7179e = i10;
        c0446j.f7180f = i11;
        arrayList.add(c0446j);
        return true;
    }

    @Override // androidx.recyclerview.widget.V
    public final void d(s0 s0Var) {
        View view = s0Var.f7250a;
        view.animate().cancel();
        ArrayList arrayList = this.f7189j;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            if (((C0447k) arrayList.get(size)).f7181a == s0Var) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                c(s0Var);
                arrayList.remove(size);
            }
        }
        j(this.f7190k, s0Var);
        if (this.f7187h.remove(s0Var)) {
            view.setAlpha(1.0f);
            c(s0Var);
        }
        if (this.f7188i.remove(s0Var)) {
            view.setAlpha(1.0f);
            c(s0Var);
        }
        ArrayList arrayList2 = this.f7193n;
        for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
            ArrayList arrayList3 = (ArrayList) arrayList2.get(size2);
            j(arrayList3, s0Var);
            if (arrayList3.isEmpty()) {
                arrayList2.remove(size2);
            }
        }
        ArrayList arrayList4 = this.f7192m;
        for (int size3 = arrayList4.size() - 1; size3 >= 0; size3--) {
            ArrayList arrayList5 = (ArrayList) arrayList4.get(size3);
            int size4 = arrayList5.size() - 1;
            while (true) {
                if (size4 < 0) {
                    break;
                }
                if (((C0447k) arrayList5.get(size4)).f7181a == s0Var) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    c(s0Var);
                    arrayList5.remove(size4);
                    if (arrayList5.isEmpty()) {
                        arrayList4.remove(size3);
                    }
                } else {
                    size4--;
                }
            }
        }
        ArrayList arrayList6 = this.f7191l;
        for (int size5 = arrayList6.size() - 1; size5 >= 0; size5--) {
            ArrayList arrayList7 = (ArrayList) arrayList6.get(size5);
            if (arrayList7.remove(s0Var)) {
                view.setAlpha(1.0f);
                c(s0Var);
                if (arrayList7.isEmpty()) {
                    arrayList6.remove(size5);
                }
            }
        }
        this.f7196q.remove(s0Var);
        this.f7194o.remove(s0Var);
        this.f7197r.remove(s0Var);
        this.f7195p.remove(s0Var);
        i();
    }

    @Override // androidx.recyclerview.widget.V
    public final void e() {
        ArrayList arrayList = this.f7189j;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            C0447k c0447k = (C0447k) arrayList.get(size);
            View view = c0447k.f7181a.f7250a;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            c(c0447k.f7181a);
            arrayList.remove(size);
        }
        ArrayList arrayList2 = this.f7187h;
        for (int size2 = arrayList2.size() - 1; size2 >= 0; size2--) {
            c((s0) arrayList2.get(size2));
            arrayList2.remove(size2);
        }
        ArrayList arrayList3 = this.f7188i;
        int size3 = arrayList3.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            s0 s0Var = (s0) arrayList3.get(size3);
            s0Var.f7250a.setAlpha(1.0f);
            c(s0Var);
            arrayList3.remove(size3);
        }
        ArrayList arrayList4 = this.f7190k;
        for (int size4 = arrayList4.size() - 1; size4 >= 0; size4--) {
            C0446j c0446j = (C0446j) arrayList4.get(size4);
            s0 s0Var2 = c0446j.f7176a;
            if (s0Var2 != null) {
                k(c0446j, s0Var2);
            }
            s0 s0Var3 = c0446j.f7177b;
            if (s0Var3 != null) {
                k(c0446j, s0Var3);
            }
        }
        arrayList4.clear();
        if (f()) {
            ArrayList arrayList5 = this.f7192m;
            for (int size5 = arrayList5.size() - 1; size5 >= 0; size5--) {
                ArrayList arrayList6 = (ArrayList) arrayList5.get(size5);
                for (int size6 = arrayList6.size() - 1; size6 >= 0; size6--) {
                    C0447k c0447k2 = (C0447k) arrayList6.get(size6);
                    View view2 = c0447k2.f7181a.f7250a;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    c(c0447k2.f7181a);
                    arrayList6.remove(size6);
                    if (arrayList6.isEmpty()) {
                        arrayList5.remove(arrayList6);
                    }
                }
            }
            ArrayList arrayList7 = this.f7191l;
            for (int size7 = arrayList7.size() - 1; size7 >= 0; size7--) {
                ArrayList arrayList8 = (ArrayList) arrayList7.get(size7);
                for (int size8 = arrayList8.size() - 1; size8 >= 0; size8--) {
                    s0 s0Var4 = (s0) arrayList8.get(size8);
                    s0Var4.f7250a.setAlpha(1.0f);
                    c(s0Var4);
                    arrayList8.remove(size8);
                    if (arrayList8.isEmpty()) {
                        arrayList7.remove(arrayList8);
                    }
                }
            }
            ArrayList arrayList9 = this.f7193n;
            for (int size9 = arrayList9.size() - 1; size9 >= 0; size9--) {
                ArrayList arrayList10 = (ArrayList) arrayList9.get(size9);
                for (int size10 = arrayList10.size() - 1; size10 >= 0; size10--) {
                    C0446j c0446j2 = (C0446j) arrayList10.get(size10);
                    s0 s0Var5 = c0446j2.f7176a;
                    if (s0Var5 != null) {
                        k(c0446j2, s0Var5);
                    }
                    s0 s0Var6 = c0446j2.f7177b;
                    if (s0Var6 != null) {
                        k(c0446j2, s0Var6);
                    }
                    if (arrayList10.isEmpty()) {
                        arrayList9.remove(arrayList10);
                    }
                }
            }
            h(this.f7196q);
            h(this.f7195p);
            h(this.f7194o);
            h(this.f7197r);
            ArrayList arrayList11 = this.f7121b;
            if (arrayList11.size() > 0) {
                android.support.v4.media.session.a.u(arrayList11.get(0));
                throw null;
            }
            arrayList11.clear();
        }
    }

    @Override // androidx.recyclerview.widget.V
    public final boolean f() {
        return (this.f7188i.isEmpty() && this.f7190k.isEmpty() && this.f7189j.isEmpty() && this.f7187h.isEmpty() && this.f7195p.isEmpty() && this.f7196q.isEmpty() && this.f7194o.isEmpty() && this.f7197r.isEmpty() && this.f7192m.isEmpty() && this.f7191l.isEmpty() && this.f7193n.isEmpty()) ? false : true;
    }

    public final boolean g(s0 s0Var, int i10, int i11, int i12, int i13) {
        View view = s0Var.f7250a;
        int translationX = i10 + ((int) view.getTranslationX());
        int translationY = i11 + ((int) s0Var.f7250a.getTranslationY());
        l(s0Var);
        int i14 = i12 - translationX;
        int i15 = i13 - translationY;
        if (i14 == 0 && i15 == 0) {
            c(s0Var);
            return false;
        }
        if (i14 != 0) {
            view.setTranslationX(-i14);
        }
        if (i15 != 0) {
            view.setTranslationY(-i15);
        }
        ArrayList arrayList = this.f7189j;
        C0447k c0447k = new C0447k();
        c0447k.f7181a = s0Var;
        c0447k.f7182b = translationX;
        c0447k.f7183c = translationY;
        c0447k.d = i12;
        c0447k.f7184e = i13;
        arrayList.add(c0447k);
        return true;
    }

    public final void i() {
        if (f()) {
            return;
        }
        ArrayList arrayList = this.f7121b;
        if (arrayList.size() <= 0) {
            arrayList.clear();
        } else {
            android.support.v4.media.session.a.u(arrayList.get(0));
            throw null;
        }
    }

    public final void j(List list, s0 s0Var) {
        for (int size = list.size() - 1; size >= 0; size--) {
            C0446j c0446j = (C0446j) list.get(size);
            if (k(c0446j, s0Var) && c0446j.f7176a == null && c0446j.f7177b == null) {
                list.remove(c0446j);
            }
        }
    }

    public final boolean k(C0446j c0446j, s0 s0Var) {
        if (c0446j.f7177b == s0Var) {
            c0446j.f7177b = null;
        } else {
            if (c0446j.f7176a != s0Var) {
                return false;
            }
            c0446j.f7176a = null;
        }
        s0Var.f7250a.setAlpha(1.0f);
        View view = s0Var.f7250a;
        view.setTranslationX(0.0f);
        view.setTranslationY(0.0f);
        c(s0Var);
        return true;
    }

    public final void l(s0 s0Var) {
        if (f7186s == null) {
            f7186s = new ValueAnimator().getInterpolator();
        }
        s0Var.f7250a.animate().setInterpolator(f7186s);
        d(s0Var);
    }
}
