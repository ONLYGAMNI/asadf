package androidx.recyclerview.widget;

import android.view.View;

/* renamed from: androidx.recyclerview.widget.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0453q {

    /* renamed from: a, reason: collision with root package name */
    public static final B.k f7237a = new B.k(5);

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Not found exit edge by exit block: B:27:0x00c9
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.checkLoopExits(LoopRegionMaker.java:225)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeLoopRegion(LoopRegionMaker.java:195)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:62)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:66)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:95)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:106)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:66)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:95)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:106)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:66)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.makeEndlessLoop(LoopRegionMaker.java:281)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:64)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:66)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:124)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:66)
        	at jadx.core.dex.visitors.regions.maker.IfRegionMaker.process(IfRegionMaker.java:101)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:106)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:66)
        	at jadx.core.dex.visitors.regions.maker.LoopRegionMaker.process(LoopRegionMaker.java:124)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.traverse(RegionMaker.java:89)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeRegion(RegionMaker.java:66)
        	at jadx.core.dex.visitors.regions.maker.RegionMaker.makeMthRegion(RegionMaker.java:48)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:25)
        */
    public static androidx.recyclerview.widget.C0449m c(androidx.recyclerview.widget.AbstractC0453q r27, boolean r28) {
        /*
            Method dump skipped, instructions count: 653
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.AbstractC0453q.c(androidx.recyclerview.widget.q, boolean):androidx.recyclerview.widget.m");
    }

    public static int d(p0 p0Var, I i10, View view, View view2, AbstractC0430a0 abstractC0430a0, boolean z3) {
        if (abstractC0430a0.getChildCount() == 0 || p0Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z3) {
            return Math.abs(abstractC0430a0.getPosition(view) - abstractC0430a0.getPosition(view2)) + 1;
        }
        return Math.min(i10.l(), i10.b(view2) - i10.e(view));
    }

    public static int e(p0 p0Var, I i10, View view, View view2, AbstractC0430a0 abstractC0430a0, boolean z3, boolean z9) {
        if (abstractC0430a0.getChildCount() == 0 || p0Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        int iMax = z9 ? Math.max(0, (p0Var.b() - Math.max(abstractC0430a0.getPosition(view), abstractC0430a0.getPosition(view2))) - 1) : Math.max(0, Math.min(abstractC0430a0.getPosition(view), abstractC0430a0.getPosition(view2)));
        if (z3) {
            return Math.round((iMax * (Math.abs(i10.b(view2) - i10.e(view)) / (Math.abs(abstractC0430a0.getPosition(view) - abstractC0430a0.getPosition(view2)) + 1))) + (i10.k() - i10.e(view)));
        }
        return iMax;
    }

    public static int f(p0 p0Var, I i10, View view, View view2, AbstractC0430a0 abstractC0430a0, boolean z3) {
        if (abstractC0430a0.getChildCount() == 0 || p0Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z3) {
            return p0Var.b();
        }
        return (int) (((i10.b(view2) - i10.e(view)) / (Math.abs(abstractC0430a0.getPosition(view) - abstractC0430a0.getPosition(view2)) + 1)) * p0Var.b());
    }

    public abstract boolean a(int i10, int i11);

    public abstract boolean b(int i10, int i11);

    public abstract int g();

    public abstract int h();
}
