package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.a, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0429a {

    /* renamed from: a, reason: collision with root package name */
    public int f7130a;

    /* renamed from: b, reason: collision with root package name */
    public int f7131b;

    /* renamed from: c, reason: collision with root package name */
    public Object f7132c;
    public int d;

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0429a.class != obj.getClass()) {
            return false;
        }
        C0429a c0429a = (C0429a) obj;
        int i10 = this.f7130a;
        if (i10 != c0429a.f7130a) {
            return false;
        }
        if (i10 == 8 && Math.abs(this.d - this.f7131b) == 1 && this.d == c0429a.f7131b && this.f7131b == c0429a.d) {
            return true;
        }
        if (this.d != c0429a.d || this.f7131b != c0429a.f7131b) {
            return false;
        }
        Object obj2 = this.f7132c;
        if (obj2 != null) {
            if (!obj2.equals(c0429a.f7132c)) {
                return false;
            }
        } else if (c0429a.f7132c != null) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return (((this.f7130a * 31) + this.f7131b) * 31) + this.d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("[");
        int i10 = this.f7130a;
        sb.append(i10 != 1 ? i10 != 2 ? i10 != 4 ? i10 != 8 ? "??" : "mv" : "up" : "rm" : "add");
        sb.append(",s:");
        sb.append(this.f7131b);
        sb.append("c:");
        sb.append(this.d);
        sb.append(",p:");
        sb.append(this.f7132c);
        sb.append("]");
        return sb.toString();
    }
}
