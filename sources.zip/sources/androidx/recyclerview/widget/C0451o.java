package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0451o {

    /* renamed from: a, reason: collision with root package name */
    public int f7212a;

    /* renamed from: b, reason: collision with root package name */
    public int f7213b;

    /* renamed from: c, reason: collision with root package name */
    public int f7214c;
    public int d;
}
