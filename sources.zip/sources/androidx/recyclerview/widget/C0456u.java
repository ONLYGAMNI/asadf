package androidx.recyclerview.widget;

import android.R;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import java.util.WeakHashMap;

/* renamed from: androidx.recyclerview.widget.u, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0456u extends W implements InterfaceC0438e0 {

    /* renamed from: C, reason: collision with root package name */
    public static final int[] f7268C = {R.attr.state_pressed};

    /* renamed from: D, reason: collision with root package name */
    public static final int[] f7269D = new int[0];

    /* renamed from: A, reason: collision with root package name */
    public int f7270A;

    /* renamed from: B, reason: collision with root package name */
    public final r f7271B;

    /* renamed from: a, reason: collision with root package name */
    public final int f7272a;

    /* renamed from: b, reason: collision with root package name */
    public final int f7273b;

    /* renamed from: c, reason: collision with root package name */
    public final StateListDrawable f7274c;
    public final Drawable d;

    /* renamed from: e, reason: collision with root package name */
    public final int f7275e;

    /* renamed from: f, reason: collision with root package name */
    public final int f7276f;
    public final StateListDrawable g;

    /* renamed from: h, reason: collision with root package name */
    public final Drawable f7277h;

    /* renamed from: i, reason: collision with root package name */
    public final int f7278i;

    /* renamed from: j, reason: collision with root package name */
    public final int f7279j;

    /* renamed from: k, reason: collision with root package name */
    public int f7280k;

    /* renamed from: l, reason: collision with root package name */
    public int f7281l;

    /* renamed from: m, reason: collision with root package name */
    public float f7282m;

    /* renamed from: n, reason: collision with root package name */
    public int f7283n;

    /* renamed from: o, reason: collision with root package name */
    public int f7284o;

    /* renamed from: p, reason: collision with root package name */
    public float f7285p;

    /* renamed from: s, reason: collision with root package name */
    public final RecyclerView f7288s;

    /* renamed from: z, reason: collision with root package name */
    public final ValueAnimator f7295z;

    /* renamed from: q, reason: collision with root package name */
    public int f7286q = 0;

    /* renamed from: r, reason: collision with root package name */
    public int f7287r = 0;

    /* renamed from: t, reason: collision with root package name */
    public boolean f7289t = false;

    /* renamed from: u, reason: collision with root package name */
    public boolean f7290u = false;

    /* renamed from: v, reason: collision with root package name */
    public int f7291v = 0;

    /* renamed from: w, reason: collision with root package name */
    public int f7292w = 0;

    /* renamed from: x, reason: collision with root package name */
    public final int[] f7293x = new int[2];

    /* renamed from: y, reason: collision with root package name */
    public final int[] f7294y = new int[2];

    public C0456u(RecyclerView recyclerView, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i10, int i11, int i12) {
        ValueAnimator valueAnimatorOfFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
        this.f7295z = valueAnimatorOfFloat;
        this.f7270A = 0;
        r rVar = new r(this, 0);
        this.f7271B = rVar;
        F6.j jVar = new F6.j(this, 2);
        this.f7274c = stateListDrawable;
        this.d = drawable;
        this.g = stateListDrawable2;
        this.f7277h = drawable2;
        this.f7275e = Math.max(i10, stateListDrawable.getIntrinsicWidth());
        this.f7276f = Math.max(i10, drawable.getIntrinsicWidth());
        this.f7278i = Math.max(i10, stateListDrawable2.getIntrinsicWidth());
        this.f7279j = Math.max(i10, drawable2.getIntrinsicWidth());
        this.f7272a = i11;
        this.f7273b = i12;
        stateListDrawable.setAlpha(255);
        drawable.setAlpha(255);
        valueAnimatorOfFloat.addListener(new C0454s(this));
        valueAnimatorOfFloat.addUpdateListener(new C0455t(this));
        RecyclerView recyclerView2 = this.f7288s;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            recyclerView2.removeItemDecoration(this);
            this.f7288s.removeOnItemTouchListener(this);
            this.f7288s.removeOnScrollListener(jVar);
            this.f7288s.removeCallbacks(rVar);
        }
        this.f7288s = recyclerView;
        if (recyclerView != null) {
            recyclerView.addItemDecoration(this);
            this.f7288s.addOnItemTouchListener(this);
            this.f7288s.addOnScrollListener(jVar);
        }
    }

    public static int f(float f10, float f11, int[] iArr, int i10, int i11, int i12) {
        int i13 = iArr[1] - iArr[0];
        if (i13 == 0) {
            return 0;
        }
        int i14 = i10 - i12;
        int i15 = (int) (((f11 - f10) / i13) * i14);
        int i16 = i11 + i15;
        if (i16 >= i14 || i16 < 0) {
            return 0;
        }
        return i15;
    }

    @Override // androidx.recyclerview.widget.W
    public final void c(Canvas canvas, RecyclerView recyclerView) {
        int i10 = this.f7286q;
        RecyclerView recyclerView2 = this.f7288s;
        if (i10 != recyclerView2.getWidth() || this.f7287r != recyclerView2.getHeight()) {
            this.f7286q = recyclerView2.getWidth();
            this.f7287r = recyclerView2.getHeight();
            g(0);
            return;
        }
        if (this.f7270A != 0) {
            if (this.f7289t) {
                int i11 = this.f7286q;
                int i12 = this.f7275e;
                int i13 = i11 - i12;
                int i14 = this.f7281l;
                int i15 = this.f7280k;
                int i16 = i14 - (i15 / 2);
                StateListDrawable stateListDrawable = this.f7274c;
                stateListDrawable.setBounds(0, 0, i12, i15);
                int i17 = this.f7287r;
                int i18 = this.f7276f;
                Drawable drawable = this.d;
                drawable.setBounds(0, 0, i18, i17);
                WeakHashMap weakHashMap = R.X.f3966a;
                if (R.F.d(recyclerView2) == 1) {
                    drawable.draw(canvas);
                    canvas.translate(i12, i16);
                    canvas.scale(-1.0f, 1.0f);
                    stateListDrawable.draw(canvas);
                    canvas.scale(1.0f, 1.0f);
                    canvas.translate(-i12, -i16);
                } else {
                    canvas.translate(i13, 0.0f);
                    drawable.draw(canvas);
                    canvas.translate(0.0f, i16);
                    stateListDrawable.draw(canvas);
                    canvas.translate(-i13, -i16);
                }
            }
            if (this.f7290u) {
                int i19 = this.f7287r;
                int i20 = this.f7278i;
                int i21 = i19 - i20;
                int i22 = this.f7284o;
                int i23 = this.f7283n;
                int i24 = i22 - (i23 / 2);
                StateListDrawable stateListDrawable2 = this.g;
                stateListDrawable2.setBounds(0, 0, i23, i20);
                int i25 = this.f7286q;
                int i26 = this.f7279j;
                Drawable drawable2 = this.f7277h;
                drawable2.setBounds(0, 0, i25, i26);
                canvas.translate(0.0f, i21);
                drawable2.draw(canvas);
                canvas.translate(i24, 0.0f);
                stateListDrawable2.draw(canvas);
                canvas.translate(-i24, -i21);
            }
        }
    }

    public final boolean d(float f10, float f11) {
        if (f11 >= this.f7287r - this.f7278i) {
            int i10 = this.f7284o;
            int i11 = this.f7283n;
            if (f10 >= i10 - (i11 / 2) && f10 <= (i11 / 2) + i10) {
                return true;
            }
        }
        return false;
    }

    public final boolean e(float f10, float f11) {
        RecyclerView recyclerView = this.f7288s;
        WeakHashMap weakHashMap = R.X.f3966a;
        boolean z3 = R.F.d(recyclerView) == 1;
        int i10 = this.f7275e;
        if (z3) {
            if (f10 > i10 / 2) {
                return false;
            }
        } else if (f10 < this.f7286q - i10) {
            return false;
        }
        int i11 = this.f7281l;
        int i12 = this.f7280k / 2;
        return f11 >= ((float) (i11 - i12)) && f11 <= ((float) (i12 + i11));
    }

    public final void g(int i10) {
        r rVar = this.f7271B;
        StateListDrawable stateListDrawable = this.f7274c;
        if (i10 == 2 && this.f7291v != 2) {
            stateListDrawable.setState(f7268C);
            this.f7288s.removeCallbacks(rVar);
        }
        if (i10 == 0) {
            this.f7288s.invalidate();
        } else {
            h();
        }
        if (this.f7291v == 2 && i10 != 2) {
            stateListDrawable.setState(f7269D);
            this.f7288s.removeCallbacks(rVar);
            this.f7288s.postDelayed(rVar, 1200);
        } else if (i10 == 1) {
            this.f7288s.removeCallbacks(rVar);
            this.f7288s.postDelayed(rVar, 1500);
        }
        this.f7291v = i10;
    }

    public final void h() {
        int i10 = this.f7270A;
        ValueAnimator valueAnimator = this.f7295z;
        if (i10 != 0) {
            if (i10 != 3) {
                return;
            } else {
                valueAnimator.cancel();
            }
        }
        this.f7270A = 1;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 1.0f);
        valueAnimator.setDuration(500L);
        valueAnimator.setStartDelay(0L);
        valueAnimator.start();
    }
}
