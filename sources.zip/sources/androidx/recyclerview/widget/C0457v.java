package androidx.recyclerview.widget;

import java.util.Arrays;

/* renamed from: androidx.recyclerview.widget.v */
/* loaded from: classes.dex */
public final class C0457v implements Y {

    /* renamed from: a */
    public int f7297a;

    /* renamed from: b */
    public int f7298b;

    /* renamed from: c */
    public int[] f7299c;
    public int d;

    public final void a(int i10, int i11) {
        if (i10 < 0) {
            throw new IllegalArgumentException("Layout positions must be non-negative");
        }
        if (i11 < 0) {
            throw new IllegalArgumentException("Pixel distance must be non-negative");
        }
        int i12 = this.d;
        int i13 = i12 * 2;
        int[] iArr = this.f7299c;
        if (iArr == null) {
            int[] iArr2 = new int[4];
            this.f7299c = iArr2;
            Arrays.fill(iArr2, -1);
        } else if (i13 >= iArr.length) {
            int[] iArr3 = new int[i12 * 4];
            this.f7299c = iArr3;
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
        }
        int[] iArr4 = this.f7299c;
        iArr4[i13] = i10;
        iArr4[i13 + 1] = i11;
        this.d++;
    }

    public final void b(RecyclerView recyclerView, boolean z3) {
        this.d = 0;
        int[] iArr = this.f7299c;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        AbstractC0430a0 abstractC0430a0 = recyclerView.mLayout;
        if (recyclerView.mAdapter == null || abstractC0430a0 == null || !abstractC0430a0.isItemPrefetchEnabled()) {
            return;
        }
        if (z3) {
            if (!recyclerView.mAdapterHelper.g()) {
                abstractC0430a0.collectInitialPrefetchPositions(recyclerView.mAdapter.a(), this);
            }
        } else if (!recyclerView.hasPendingAdapterUpdates()) {
            abstractC0430a0.collectAdjacentPrefetchPositions(this.f7297a, this.f7298b, recyclerView.mState, this);
        }
        int i10 = this.d;
        if (i10 > abstractC0430a0.mPrefetchMaxCountObserved) {
            abstractC0430a0.mPrefetchMaxCountObserved = i10;
            abstractC0430a0.mPrefetchMaxObservedInInitialPrefetch = z3;
            recyclerView.mRecycler.l();
        }
    }
}
