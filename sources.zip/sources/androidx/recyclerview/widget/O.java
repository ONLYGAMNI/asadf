package androidx.recyclerview.widget;

import android.database.Observable;

/* loaded from: classes.dex */
public final class O extends Observable {
    public final boolean a() {
        return !((Observable) this).mObservers.isEmpty();
    }

    public final void b() {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            ((P) ((Observable) this).mObservers.get(size)).onChanged();
        }
    }

    public final void c(int i10, int i11) {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            ((P) ((Observable) this).mObservers.get(size)).onItemRangeMoved(i10, i11, 1);
        }
    }

    public final void d(int i10, int i11) {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            ((P) ((Observable) this).mObservers.get(size)).onItemRangeChanged(i10, i11, null);
        }
    }

    public final void e(int i10, int i11) {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            ((P) ((Observable) this).mObservers.get(size)).onItemRangeInserted(i10, i11);
        }
    }

    public final void f(int i10, int i11) {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            ((P) ((Observable) this).mObservers.get(size)).onItemRangeRemoved(i10, i11);
        }
    }
}
