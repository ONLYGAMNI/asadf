package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0458w {

    /* renamed from: a, reason: collision with root package name */
    public boolean f7302a;

    /* renamed from: b, reason: collision with root package name */
    public int f7303b;

    /* renamed from: c, reason: collision with root package name */
    public int f7304c;
    public RecyclerView d;

    /* renamed from: e, reason: collision with root package name */
    public int f7305e;
}
