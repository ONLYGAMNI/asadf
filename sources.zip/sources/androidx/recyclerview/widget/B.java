package androidx.recyclerview.widget;

import android.view.View;

/* loaded from: classes.dex */
public final class B {

    /* renamed from: a, reason: collision with root package name */
    public I f7039a;

    /* renamed from: b, reason: collision with root package name */
    public int f7040b;

    /* renamed from: c, reason: collision with root package name */
    public int f7041c;
    public boolean d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f7042e;

    public B() {
        d();
    }

    public final void a() {
        this.f7041c = this.d ? this.f7039a.g() : this.f7039a.k();
    }

    public final void b(View view, int i10) {
        if (this.d) {
            this.f7041c = this.f7039a.m() + this.f7039a.b(view);
        } else {
            this.f7041c = this.f7039a.e(view);
        }
        this.f7040b = i10;
    }

    public final void c(View view, int i10) {
        int iM = this.f7039a.m();
        if (iM >= 0) {
            b(view, i10);
            return;
        }
        this.f7040b = i10;
        if (!this.d) {
            int iE = this.f7039a.e(view);
            int iK = iE - this.f7039a.k();
            this.f7041c = iE;
            if (iK > 0) {
                int iG = (this.f7039a.g() - Math.min(0, (this.f7039a.g() - iM) - this.f7039a.b(view))) - (this.f7039a.c(view) + iE);
                if (iG < 0) {
                    this.f7041c -= Math.min(iK, -iG);
                    return;
                }
                return;
            }
            return;
        }
        int iG2 = (this.f7039a.g() - iM) - this.f7039a.b(view);
        this.f7041c = this.f7039a.g() - iG2;
        if (iG2 > 0) {
            int iC = this.f7041c - this.f7039a.c(view);
            int iK2 = this.f7039a.k();
            int iMin = iC - (Math.min(this.f7039a.e(view) - iK2, 0) + iK2);
            if (iMin < 0) {
                this.f7041c = Math.min(iG2, -iMin) + this.f7041c;
            }
        }
    }

    public final void d() {
        this.f7040b = -1;
        this.f7041c = Integer.MIN_VALUE;
        this.d = false;
        this.f7042e = false;
    }

    public final String toString() {
        return "AnchorInfo{mPosition=" + this.f7040b + ", mCoordinate=" + this.f7041c + ", mLayoutFromEnd=" + this.d + ", mValid=" + this.f7042e + '}';
    }
}
