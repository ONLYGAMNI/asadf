package androidx.recyclerview.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.WeakHashMap;
import r.C1338l;
import y0.AbstractC1660a;

/* renamed from: androidx.recyclerview.widget.a0 */
/* loaded from: classes.dex */
public abstract class AbstractC0430a0 {
    boolean mAutoMeasure;
    C0437e mChildHelper;
    private int mHeight;
    private int mHeightMode;
    E0 mHorizontalBoundCheck;
    private final D0 mHorizontalBoundCheckCallback;
    boolean mIsAttachedToWindow;
    private boolean mItemPrefetchEnabled;
    private boolean mMeasurementCacheEnabled;
    int mPrefetchMaxCountObserved;
    boolean mPrefetchMaxObservedInInitialPrefetch;
    RecyclerView mRecyclerView;
    boolean mRequestedSimpleAnimations;
    o0 mSmoothScroller;
    E0 mVerticalBoundCheck;
    private final D0 mVerticalBoundCheckCallback;
    private int mWidth;
    private int mWidthMode;

    public AbstractC0430a0() {
        X x9 = new X(this, 0);
        this.mHorizontalBoundCheckCallback = x9;
        X x10 = new X(this, 1);
        this.mVerticalBoundCheckCallback = x10;
        this.mHorizontalBoundCheck = new E0(x9);
        this.mVerticalBoundCheck = new E0(x10);
        this.mRequestedSimpleAnimations = false;
        this.mIsAttachedToWindow = false;
        this.mAutoMeasure = false;
        this.mMeasurementCacheEnabled = true;
        this.mItemPrefetchEnabled = true;
    }

    public static boolean b(int i10, int i11, int i12) {
        int mode = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i11);
        if (i12 > 0 && i10 != i12) {
            return false;
        }
        if (mode == Integer.MIN_VALUE) {
            return size >= i10;
        }
        if (mode != 0) {
            return mode == 1073741824 && size == i10;
        }
        return true;
    }

    public static int chooseSize(int i10, int i11, int i12) {
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        return mode != Integer.MIN_VALUE ? mode != 1073741824 ? Math.max(i11, i12) : size : Math.min(size, Math.max(i11, i12));
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x000c A[PHI: r3
  0x000c: PHI (r3v5 int) = (r3v0 int), (r3v2 int), (r3v0 int) binds: [B:24:0x0010, B:28:0x0016, B:21:0x000a] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x000e  */
    @java.lang.Deprecated
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int getChildMeasureSpec(int r1, int r2, int r3, boolean r4) {
        /*
            int r1 = r1 - r2
            r2 = 0
            int r1 = java.lang.Math.max(r2, r1)
            r0 = 1073741824(0x40000000, float:2.0)
            if (r4 == 0) goto L10
            if (r3 < 0) goto Le
        Lc:
            r2 = r0
            goto L1e
        Le:
            r3 = r2
            goto L1e
        L10:
            if (r3 < 0) goto L13
            goto Lc
        L13:
            r4 = -1
            if (r3 != r4) goto L18
            r3 = r1
            goto Lc
        L18:
            r4 = -2
            if (r3 != r4) goto Le
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1
        L1e:
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r2)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.AbstractC0430a0.getChildMeasureSpec(int, int, int, boolean):int");
    }

    public static Z getProperties(Context context, AttributeSet attributeSet, int i10, int i11) {
        Z z3 = new Z();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC1660a.f16277a, i10, i11);
        z3.f7127a = typedArrayObtainStyledAttributes.getInt(0, 1);
        z3.f7128b = typedArrayObtainStyledAttributes.getInt(10, 1);
        z3.f7129c = typedArrayObtainStyledAttributes.getBoolean(9, false);
        z3.d = typedArrayObtainStyledAttributes.getBoolean(11, false);
        typedArrayObtainStyledAttributes.recycle();
        return z3;
    }

    public final void a(View view, int i10, boolean z3) {
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (z3 || childViewHolderInt.m()) {
            C1338l c1338l = this.mRecyclerView.mViewInfoStore.f7087a;
            F0 f0A = (F0) c1338l.getOrDefault(childViewHolderInt, null);
            if (f0A == null) {
                f0A = F0.a();
                c1338l.put(childViewHolderInt, f0A);
            }
            f0A.f7078a |= 1;
        } else {
            this.mRecyclerView.mViewInfoStore.c(childViewHolderInt);
        }
        C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
        if (childViewHolderInt.u() || childViewHolderInt.n()) {
            if (childViewHolderInt.n()) {
                childViewHolderInt.f7261n.k(childViewHolderInt);
            } else {
                childViewHolderInt.f7257j &= -33;
            }
            this.mChildHelper.b(view, i10, view.getLayoutParams(), false);
        } else if (view.getParent() == this.mRecyclerView) {
            int iJ = this.mChildHelper.j(view);
            if (i10 == -1) {
                i10 = this.mChildHelper.e();
            }
            if (iJ == -1) {
                StringBuilder sb = new StringBuilder("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                sb.append(this.mRecyclerView.indexOfChild(view));
                throw new IllegalStateException(android.support.v4.media.session.a.i(this.mRecyclerView, sb));
            }
            if (iJ != i10) {
                this.mRecyclerView.mLayout.moveView(iJ, i10);
            }
        } else {
            this.mChildHelper.a(view, i10, false);
            c0432b0.f7140c = true;
            o0 o0Var = this.mSmoothScroller;
            if (o0Var != null && o0Var.f7218e && o0Var.f7216b.getChildLayoutPosition(view) == o0Var.f7215a) {
                o0Var.f7219f = view;
            }
        }
        if (c0432b0.d) {
            childViewHolderInt.f7250a.invalidate();
            c0432b0.d = false;
        }
    }

    public void addDisappearingView(View view) {
        addDisappearingView(view, -1);
    }

    public void addView(View view) {
        addView(view, -1);
    }

    public void assertInLayoutOrScroll(String str) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            recyclerView.assertInLayoutOrScroll(str);
        }
    }

    public void assertNotInLayoutOrScroll(String str) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            recyclerView.assertNotInLayoutOrScroll(str);
        }
    }

    public void attachView(View view, int i10, C0432b0 c0432b0) {
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (childViewHolderInt.m()) {
            C1338l c1338l = this.mRecyclerView.mViewInfoStore.f7087a;
            F0 f0A = (F0) c1338l.getOrDefault(childViewHolderInt, null);
            if (f0A == null) {
                f0A = F0.a();
                c1338l.put(childViewHolderInt, f0A);
            }
            f0A.f7078a |= 1;
        } else {
            this.mRecyclerView.mViewInfoStore.c(childViewHolderInt);
        }
        this.mChildHelper.b(view, i10, c0432b0, childViewHolderInt.m());
    }

    public final void c(i0 i0Var, int i10, View view) {
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (childViewHolderInt.t()) {
            return;
        }
        if (childViewHolderInt.k() && !childViewHolderInt.m() && !this.mRecyclerView.mAdapter.f7097b) {
            removeViewAt(i10);
            i0Var.h(childViewHolderInt);
        } else {
            detachViewAt(i10);
            i0Var.i(view);
            this.mRecyclerView.mViewInfoStore.c(childViewHolderInt);
        }
    }

    public void calculateItemDecorationsForChild(View view, Rect rect) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null) {
            rect.set(0, 0, 0, 0);
        } else {
            rect.set(recyclerView.getItemDecorInsetsForChild(view));
        }
    }

    public abstract boolean canScrollHorizontally();

    public abstract boolean canScrollVertically();

    public boolean checkLayoutParams(C0432b0 c0432b0) {
        return c0432b0 != null;
    }

    public void collectAdjacentPrefetchPositions(int i10, int i11, p0 p0Var, Y y9) {
    }

    public void collectInitialPrefetchPositions(int i10, Y y9) {
    }

    public abstract int computeHorizontalScrollExtent(p0 p0Var);

    public abstract int computeHorizontalScrollOffset(p0 p0Var);

    public abstract int computeHorizontalScrollRange(p0 p0Var);

    public abstract int computeVerticalScrollExtent(p0 p0Var);

    public abstract int computeVerticalScrollOffset(p0 p0Var);

    public abstract int computeVerticalScrollRange(p0 p0Var);

    public void detachAndScrapAttachedViews(i0 i0Var) {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            c(i0Var, childCount, getChildAt(childCount));
        }
    }

    public void detachAndScrapView(View view, i0 i0Var) {
        c(i0Var, this.mChildHelper.j(view), view);
    }

    public void detachAndScrapViewAt(int i10, i0 i0Var) {
        c(i0Var, i10, getChildAt(i10));
    }

    public void detachView(View view) {
        int iJ = this.mChildHelper.j(view);
        if (iJ >= 0) {
            this.mChildHelper.c(iJ);
        }
    }

    public void detachViewAt(int i10) {
        getChildAt(i10);
        this.mChildHelper.c(i10);
    }

    public void dispatchAttachedToWindow(RecyclerView recyclerView) {
        this.mIsAttachedToWindow = true;
        onAttachedToWindow(recyclerView);
    }

    public void dispatchDetachedFromWindow(RecyclerView recyclerView, i0 i0Var) {
        this.mIsAttachedToWindow = false;
        onDetachedFromWindow(recyclerView, i0Var);
    }

    public void endAnimation(View view) {
        V v9 = this.mRecyclerView.mItemAnimator;
        if (v9 != null) {
            v9.d(RecyclerView.getChildViewHolderInt(view));
        }
    }

    public View findContainingItemView(View view) {
        View viewFindContainingItemView;
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null || (viewFindContainingItemView = recyclerView.findContainingItemView(view)) == null || this.mChildHelper.k(viewFindContainingItemView)) {
            return null;
        }
        return viewFindContainingItemView;
    }

    public View findViewByPosition(int i10) {
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(childAt);
            if (childViewHolderInt != null && childViewHolderInt.f() == i10 && !childViewHolderInt.t() && (this.mRecyclerView.mState.g || !childViewHolderInt.m())) {
                return childAt;
            }
        }
        return null;
    }

    public abstract C0432b0 generateDefaultLayoutParams();

    public C0432b0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0432b0 ? new C0432b0((C0432b0) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0432b0((ViewGroup.MarginLayoutParams) layoutParams) : new C0432b0(layoutParams);
    }

    public int getBaseline() {
        return -1;
    }

    public int getBottomDecorationHeight(View view) {
        return ((C0432b0) view.getLayoutParams()).f7139b.bottom;
    }

    public View getChildAt(int i10) {
        C0437e c0437e = this.mChildHelper;
        if (c0437e != null) {
            return c0437e.d(i10);
        }
        return null;
    }

    public int getChildCount() {
        C0437e c0437e = this.mChildHelper;
        if (c0437e != null) {
            return c0437e.e();
        }
        return 0;
    }

    public boolean getClipToPadding() {
        RecyclerView recyclerView = this.mRecyclerView;
        return recyclerView != null && recyclerView.mClipToPadding;
    }

    public int getColumnCountForAccessibility(i0 i0Var, p0 p0Var) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null || recyclerView.mAdapter == null || !canScrollHorizontally()) {
            return 1;
        }
        return this.mRecyclerView.mAdapter.a();
    }

    public int getDecoratedBottom(View view) {
        return getBottomDecorationHeight(view) + view.getBottom();
    }

    public void getDecoratedBoundsWithMargins(View view, Rect rect) {
        RecyclerView.getDecoratedBoundsWithMarginsInt(view, rect);
    }

    public int getDecoratedLeft(View view) {
        return view.getLeft() - getLeftDecorationWidth(view);
    }

    public int getDecoratedMeasuredHeight(View view) {
        Rect rect = ((C0432b0) view.getLayoutParams()).f7139b;
        return view.getMeasuredHeight() + rect.top + rect.bottom;
    }

    public int getDecoratedMeasuredWidth(View view) {
        Rect rect = ((C0432b0) view.getLayoutParams()).f7139b;
        return view.getMeasuredWidth() + rect.left + rect.right;
    }

    public int getDecoratedRight(View view) {
        return getRightDecorationWidth(view) + view.getRight();
    }

    public int getDecoratedTop(View view) {
        return view.getTop() - getTopDecorationHeight(view);
    }

    public View getFocusedChild() {
        View focusedChild;
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.mChildHelper.k(focusedChild)) {
            return null;
        }
        return focusedChild;
    }

    public int getHeight() {
        return this.mHeight;
    }

    public int getHeightMode() {
        return this.mHeightMode;
    }

    public int getItemCount() {
        RecyclerView recyclerView = this.mRecyclerView;
        N adapter = recyclerView != null ? recyclerView.getAdapter() : null;
        if (adapter != null) {
            return adapter.a();
        }
        return 0;
    }

    public int getItemViewType(View view) {
        return RecyclerView.getChildViewHolderInt(view).f7254f;
    }

    public int getLayoutDirection() {
        RecyclerView recyclerView = this.mRecyclerView;
        WeakHashMap weakHashMap = R.X.f3966a;
        return R.F.d(recyclerView);
    }

    public int getLeftDecorationWidth(View view) {
        return ((C0432b0) view.getLayoutParams()).f7139b.left;
    }

    public int getMinimumHeight() {
        RecyclerView recyclerView = this.mRecyclerView;
        WeakHashMap weakHashMap = R.X.f3966a;
        return R.E.d(recyclerView);
    }

    public int getMinimumWidth() {
        RecyclerView recyclerView = this.mRecyclerView;
        WeakHashMap weakHashMap = R.X.f3966a;
        return R.E.e(recyclerView);
    }

    public int getPaddingBottom() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            return recyclerView.getPaddingBottom();
        }
        return 0;
    }

    public int getPaddingEnd() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null) {
            return 0;
        }
        WeakHashMap weakHashMap = R.X.f3966a;
        return R.F.e(recyclerView);
    }

    public int getPaddingLeft() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            return recyclerView.getPaddingLeft();
        }
        return 0;
    }

    public int getPaddingRight() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            return recyclerView.getPaddingRight();
        }
        return 0;
    }

    public int getPaddingStart() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null) {
            return 0;
        }
        WeakHashMap weakHashMap = R.X.f3966a;
        return R.F.f(recyclerView);
    }

    public int getPaddingTop() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            return recyclerView.getPaddingTop();
        }
        return 0;
    }

    public int getPosition(View view) {
        return ((C0432b0) view.getLayoutParams()).f7138a.f();
    }

    public int getRightDecorationWidth(View view) {
        return ((C0432b0) view.getLayoutParams()).f7139b.right;
    }

    public int getRowCountForAccessibility(i0 i0Var, p0 p0Var) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null || recyclerView.mAdapter == null || !canScrollVertically()) {
            return 1;
        }
        return this.mRecyclerView.mAdapter.a();
    }

    public int getSelectionModeForAccessibility(i0 i0Var, p0 p0Var) {
        return 0;
    }

    public int getTopDecorationHeight(View view) {
        return ((C0432b0) view.getLayoutParams()).f7139b.top;
    }

    public void getTransformedBoundingBox(View view, boolean z3, Rect rect) {
        Matrix matrix;
        if (z3) {
            Rect rect2 = ((C0432b0) view.getLayoutParams()).f7139b;
            rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
        } else {
            rect.set(0, 0, view.getWidth(), view.getHeight());
        }
        if (this.mRecyclerView != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
            RectF rectF = this.mRecyclerView.mTempRectF;
            rectF.set(rect);
            matrix.mapRect(rectF);
            rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
        }
        rect.offset(view.getLeft(), view.getTop());
    }

    public int getWidth() {
        return this.mWidth;
    }

    public int getWidthMode() {
        return this.mWidthMode;
    }

    public boolean hasFlexibleChildInBothOrientations() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            ViewGroup.LayoutParams layoutParams = getChildAt(i10).getLayoutParams();
            if (layoutParams.width < 0 && layoutParams.height < 0) {
                return true;
            }
        }
        return false;
    }

    public boolean hasFocus() {
        RecyclerView recyclerView = this.mRecyclerView;
        return recyclerView != null && recyclerView.hasFocus();
    }

    public void ignoreView(View view) {
        ViewParent parent = view.getParent();
        RecyclerView recyclerView = this.mRecyclerView;
        if (parent != recyclerView || recyclerView.indexOfChild(view) == -1) {
            throw new IllegalArgumentException(android.support.v4.media.session.a.i(this.mRecyclerView, new StringBuilder("View should be fully attached to be ignored")));
        }
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        childViewHolderInt.e(128);
        this.mRecyclerView.mViewInfoStore.d(childViewHolderInt);
    }

    public boolean isAttachedToWindow() {
        return this.mIsAttachedToWindow;
    }

    public boolean isAutoMeasureEnabled() {
        return this.mAutoMeasure;
    }

    public boolean isFocused() {
        RecyclerView recyclerView = this.mRecyclerView;
        return recyclerView != null && recyclerView.isFocused();
    }

    public final boolean isItemPrefetchEnabled() {
        return this.mItemPrefetchEnabled;
    }

    public boolean isLayoutHierarchical(i0 i0Var, p0 p0Var) {
        return false;
    }

    public boolean isMeasurementCacheEnabled() {
        return this.mMeasurementCacheEnabled;
    }

    public boolean isSmoothScrolling() {
        o0 o0Var = this.mSmoothScroller;
        return o0Var != null && o0Var.f7218e;
    }

    public boolean isViewPartiallyVisible(View view, boolean z3, boolean z9) {
        boolean z10 = this.mHorizontalBoundCheck.b(view) && this.mVerticalBoundCheck.b(view);
        return z3 ? z10 : !z10;
    }

    public void layoutDecorated(View view, int i10, int i11, int i12, int i13) {
        Rect rect = ((C0432b0) view.getLayoutParams()).f7139b;
        view.layout(i10 + rect.left, i11 + rect.top, i12 - rect.right, i13 - rect.bottom);
    }

    public void layoutDecoratedWithMargins(View view, int i10, int i11, int i12, int i13) {
        C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
        Rect rect = c0432b0.f7139b;
        view.layout(i10 + rect.left + ((ViewGroup.MarginLayoutParams) c0432b0).leftMargin, i11 + rect.top + ((ViewGroup.MarginLayoutParams) c0432b0).topMargin, (i12 - rect.right) - ((ViewGroup.MarginLayoutParams) c0432b0).rightMargin, (i13 - rect.bottom) - ((ViewGroup.MarginLayoutParams) c0432b0).bottomMargin);
    }

    public void measureChild(View view, int i10, int i11) {
        C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
        Rect itemDecorInsetsForChild = this.mRecyclerView.getItemDecorInsetsForChild(view);
        int i12 = itemDecorInsetsForChild.left + itemDecorInsetsForChild.right + i10;
        int i13 = itemDecorInsetsForChild.top + itemDecorInsetsForChild.bottom + i11;
        int childMeasureSpec = getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingRight() + getPaddingLeft() + i12, ((ViewGroup.MarginLayoutParams) c0432b0).width, canScrollHorizontally());
        int childMeasureSpec2 = getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingBottom() + getPaddingTop() + i13, ((ViewGroup.MarginLayoutParams) c0432b0).height, canScrollVertically());
        if (shouldMeasureChild(view, childMeasureSpec, childMeasureSpec2, c0432b0)) {
            view.measure(childMeasureSpec, childMeasureSpec2);
        }
    }

    public void measureChildWithMargins(View view, int i10, int i11) {
        C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
        Rect itemDecorInsetsForChild = this.mRecyclerView.getItemDecorInsetsForChild(view);
        int i12 = itemDecorInsetsForChild.left + itemDecorInsetsForChild.right + i10;
        int i13 = itemDecorInsetsForChild.top + itemDecorInsetsForChild.bottom + i11;
        int childMeasureSpec = getChildMeasureSpec(getWidth(), getWidthMode(), getPaddingRight() + getPaddingLeft() + ((ViewGroup.MarginLayoutParams) c0432b0).leftMargin + ((ViewGroup.MarginLayoutParams) c0432b0).rightMargin + i12, ((ViewGroup.MarginLayoutParams) c0432b0).width, canScrollHorizontally());
        int childMeasureSpec2 = getChildMeasureSpec(getHeight(), getHeightMode(), getPaddingBottom() + getPaddingTop() + ((ViewGroup.MarginLayoutParams) c0432b0).topMargin + ((ViewGroup.MarginLayoutParams) c0432b0).bottomMargin + i13, ((ViewGroup.MarginLayoutParams) c0432b0).height, canScrollVertically());
        if (shouldMeasureChild(view, childMeasureSpec, childMeasureSpec2, c0432b0)) {
            view.measure(childMeasureSpec, childMeasureSpec2);
        }
    }

    public void moveView(int i10, int i11) {
        View childAt = getChildAt(i10);
        if (childAt != null) {
            detachViewAt(i10);
            attachView(childAt, i11);
        } else {
            throw new IllegalArgumentException("Cannot move a child from non-existing index:" + i10 + this.mRecyclerView.toString());
        }
    }

    public void offsetChildrenHorizontal(int i10) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            recyclerView.offsetChildrenHorizontal(i10);
        }
    }

    public void offsetChildrenVertical(int i10) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            recyclerView.offsetChildrenVertical(i10);
        }
    }

    public void onAdapterChanged(N n9, N n10) {
    }

    public boolean onAddFocusables(RecyclerView recyclerView, ArrayList<View> arrayList, int i10, int i11) {
        return false;
    }

    public void onAttachedToWindow(RecyclerView recyclerView) {
    }

    @Deprecated
    public void onDetachedFromWindow(RecyclerView recyclerView) {
    }

    public View onFocusSearchFailed(View view, int i10, i0 i0Var, p0 p0Var) {
        return null;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.mRecyclerView;
        onInitializeAccessibilityEvent(recyclerView.mRecycler, recyclerView.mState, accessibilityEvent);
    }

    public void onInitializeAccessibilityNodeInfo(S.j jVar) {
        RecyclerView recyclerView = this.mRecyclerView;
        onInitializeAccessibilityNodeInfo(recyclerView.mRecycler, recyclerView.mState, jVar);
    }

    public void onInitializeAccessibilityNodeInfoForItem(View view, S.j jVar) {
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (childViewHolderInt == null || childViewHolderInt.m() || this.mChildHelper.k(childViewHolderInt.f7250a)) {
            return;
        }
        RecyclerView recyclerView = this.mRecyclerView;
        onInitializeAccessibilityNodeInfoForItem(recyclerView.mRecycler, recyclerView.mState, view, jVar);
    }

    public View onInterceptFocusSearch(View view, int i10) {
        return null;
    }

    public void onItemsAdded(RecyclerView recyclerView, int i10, int i11) {
    }

    public void onItemsChanged(RecyclerView recyclerView) {
    }

    public void onItemsMoved(RecyclerView recyclerView, int i10, int i11, int i12) {
    }

    public void onItemsRemoved(RecyclerView recyclerView, int i10, int i11) {
    }

    public void onItemsUpdated(RecyclerView recyclerView, int i10, int i11) {
    }

    public abstract void onLayoutChildren(i0 i0Var, p0 p0Var);

    public abstract void onLayoutCompleted(p0 p0Var);

    public void onMeasure(i0 i0Var, p0 p0Var, int i10, int i11) {
        this.mRecyclerView.defaultOnMeasure(i10, i11);
    }

    @Deprecated
    public boolean onRequestChildFocus(RecyclerView recyclerView, View view, View view2) {
        return isSmoothScrolling() || recyclerView.isComputingLayout();
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
    }

    public Parcelable onSaveInstanceState() {
        return null;
    }

    public void onScrollStateChanged(int i10) {
    }

    public void onSmoothScrollerStopped(o0 o0Var) {
        if (this.mSmoothScroller == o0Var) {
            this.mSmoothScroller = null;
        }
    }

    public boolean performAccessibilityAction(int i10, Bundle bundle) {
        RecyclerView recyclerView = this.mRecyclerView;
        return performAccessibilityAction(recyclerView.mRecycler, recyclerView.mState, i10, bundle);
    }

    public boolean performAccessibilityActionForItem(i0 i0Var, p0 p0Var, View view, int i10, Bundle bundle) {
        return false;
    }

    public void postOnAnimation(Runnable runnable) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            WeakHashMap weakHashMap = R.X.f3966a;
            R.E.m(recyclerView, runnable);
        }
    }

    public void removeAllViews() {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            C0437e c0437e = this.mChildHelper;
            int iF = c0437e.f(childCount);
            M m9 = c0437e.f7146a;
            View childAt = m9.f7095a.getChildAt(iF);
            if (childAt != null) {
                if (c0437e.f7147b.f(iF)) {
                    c0437e.l(childAt);
                }
                m9.b(iF);
            }
        }
    }

    public void removeAndRecycleAllViews(i0 i0Var) {
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            if (!RecyclerView.getChildViewHolderInt(getChildAt(childCount)).t()) {
                removeAndRecycleViewAt(childCount, i0Var);
            }
        }
    }

    public void removeAndRecycleScrapInt(i0 i0Var) {
        ArrayList arrayList;
        int size = i0Var.f7170a.size();
        int i10 = size - 1;
        while (true) {
            arrayList = i0Var.f7170a;
            if (i10 < 0) {
                break;
            }
            View view = ((s0) arrayList.get(i10)).f7250a;
            s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (!childViewHolderInt.t()) {
                childViewHolderInt.s(false);
                if (childViewHolderInt.o()) {
                    this.mRecyclerView.removeDetachedView(view, false);
                }
                V v9 = this.mRecyclerView.mItemAnimator;
                if (v9 != null) {
                    v9.d(childViewHolderInt);
                }
                childViewHolderInt.s(true);
                s0 childViewHolderInt2 = RecyclerView.getChildViewHolderInt(view);
                childViewHolderInt2.f7261n = null;
                childViewHolderInt2.f7262o = false;
                childViewHolderInt2.f7257j &= -33;
                i0Var.h(childViewHolderInt2);
            }
            i10--;
        }
        arrayList.clear();
        ArrayList arrayList2 = i0Var.f7171b;
        if (arrayList2 != null) {
            arrayList2.clear();
        }
        if (size > 0) {
            this.mRecyclerView.invalidate();
        }
    }

    public void removeAndRecycleView(View view, i0 i0Var) {
        removeView(view);
        i0Var.g(view);
    }

    public void removeAndRecycleViewAt(int i10, i0 i0Var) {
        View childAt = getChildAt(i10);
        removeViewAt(i10);
        i0Var.g(childAt);
    }

    public boolean removeCallbacks(Runnable runnable) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            return recyclerView.removeCallbacks(runnable);
        }
        return false;
    }

    public void removeDetachedView(View view) {
        this.mRecyclerView.removeDetachedView(view, false);
    }

    public void removeView(View view) {
        C0437e c0437e = this.mChildHelper;
        M m9 = c0437e.f7146a;
        int iIndexOfChild = m9.f7095a.indexOfChild(view);
        if (iIndexOfChild < 0) {
            return;
        }
        if (c0437e.f7147b.f(iIndexOfChild)) {
            c0437e.l(view);
        }
        m9.b(iIndexOfChild);
    }

    public void removeViewAt(int i10) {
        if (getChildAt(i10) != null) {
            C0437e c0437e = this.mChildHelper;
            int iF = c0437e.f(i10);
            M m9 = c0437e.f7146a;
            View childAt = m9.f7095a.getChildAt(iF);
            if (childAt == null) {
                return;
            }
            if (c0437e.f7147b.f(iF)) {
                c0437e.l(childAt);
            }
            m9.b(iF);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:64:0x00b6  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public boolean requestChildRectangleOnScreen(androidx.recyclerview.widget.RecyclerView r9, android.view.View r10, android.graphics.Rect r11, boolean r12, boolean r13) {
        /*
            r8 = this;
            int r0 = r8.getPaddingLeft()
            int r1 = r8.getPaddingTop()
            int r2 = r8.getWidth()
            int r3 = r8.getPaddingRight()
            int r2 = r2 - r3
            int r3 = r8.getHeight()
            int r4 = r8.getPaddingBottom()
            int r3 = r3 - r4
            int r4 = r10.getLeft()
            int r5 = r11.left
            int r4 = r4 + r5
            int r5 = r10.getScrollX()
            int r4 = r4 - r5
            int r5 = r10.getTop()
            int r6 = r11.top
            int r5 = r5 + r6
            int r10 = r10.getScrollY()
            int r5 = r5 - r10
            int r10 = r11.width()
            int r10 = r10 + r4
            int r11 = r11.height()
            int r11 = r11 + r5
            int r4 = r4 - r0
            r0 = 0
            int r6 = java.lang.Math.min(r0, r4)
            int r5 = r5 - r1
            int r1 = java.lang.Math.min(r0, r5)
            int r10 = r10 - r2
            int r2 = java.lang.Math.max(r0, r10)
            int r11 = r11 - r3
            int r11 = java.lang.Math.max(r0, r11)
            int r3 = r8.getLayoutDirection()
            r7 = 1
            if (r3 != r7) goto L60
            if (r2 == 0) goto L5b
            goto L68
        L5b:
            int r2 = java.lang.Math.max(r6, r10)
            goto L68
        L60:
            if (r6 == 0) goto L63
            goto L67
        L63:
            int r6 = java.lang.Math.min(r4, r2)
        L67:
            r2 = r6
        L68:
            if (r1 == 0) goto L6b
            goto L6f
        L6b:
            int r1 = java.lang.Math.min(r5, r11)
        L6f:
            int[] r10 = new int[]{r2, r1}
            r11 = r10[r0]
            r10 = r10[r7]
            if (r13 == 0) goto Lb6
            android.view.View r13 = r9.getFocusedChild()
            if (r13 != 0) goto L80
            goto Lbb
        L80:
            int r1 = r8.getPaddingLeft()
            int r2 = r8.getPaddingTop()
            int r3 = r8.getWidth()
            int r4 = r8.getPaddingRight()
            int r3 = r3 - r4
            int r4 = r8.getHeight()
            int r5 = r8.getPaddingBottom()
            int r4 = r4 - r5
            androidx.recyclerview.widget.RecyclerView r5 = r8.mRecyclerView
            android.graphics.Rect r5 = r5.mTempRect
            r8.getDecoratedBoundsWithMargins(r13, r5)
            int r13 = r5.left
            int r13 = r13 - r11
            if (r13 >= r3) goto Lbb
            int r13 = r5.right
            int r13 = r13 - r11
            if (r13 <= r1) goto Lbb
            int r13 = r5.top
            int r13 = r13 - r10
            if (r13 >= r4) goto Lbb
            int r13 = r5.bottom
            int r13 = r13 - r10
            if (r13 > r2) goto Lb6
            goto Lbb
        Lb6:
            if (r11 != 0) goto Lbc
            if (r10 == 0) goto Lbb
            goto Lbc
        Lbb:
            return r0
        Lbc:
            if (r12 == 0) goto Lc2
            r9.scrollBy(r11, r10)
            goto Lc5
        Lc2:
            r9.smoothScrollBy(r11, r10)
        Lc5:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.AbstractC0430a0.requestChildRectangleOnScreen(androidx.recyclerview.widget.RecyclerView, android.view.View, android.graphics.Rect, boolean, boolean):boolean");
    }

    public void requestLayout() {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView != null) {
            recyclerView.requestLayout();
        }
    }

    public void requestSimpleAnimationsInNextLayout() {
        this.mRequestedSimpleAnimations = true;
    }

    public abstract int scrollHorizontallyBy(int i10, i0 i0Var, p0 p0Var);

    public abstract void scrollToPosition(int i10);

    public abstract int scrollVerticallyBy(int i10, i0 i0Var, p0 p0Var);

    @Deprecated
    public void setAutoMeasureEnabled(boolean z3) {
        this.mAutoMeasure = z3;
    }

    public void setExactMeasureSpecsFrom(RecyclerView recyclerView) {
        setMeasureSpecs(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
    }

    public final void setItemPrefetchEnabled(boolean z3) {
        if (z3 != this.mItemPrefetchEnabled) {
            this.mItemPrefetchEnabled = z3;
            this.mPrefetchMaxCountObserved = 0;
            RecyclerView recyclerView = this.mRecyclerView;
            if (recyclerView != null) {
                recyclerView.mRecycler.l();
            }
        }
    }

    public void setMeasureSpecs(int i10, int i11) {
        this.mWidth = View.MeasureSpec.getSize(i10);
        int mode = View.MeasureSpec.getMode(i10);
        this.mWidthMode = mode;
        if (mode == 0 && !RecyclerView.ALLOW_SIZE_IN_UNSPECIFIED_SPEC) {
            this.mWidth = 0;
        }
        this.mHeight = View.MeasureSpec.getSize(i11);
        int mode2 = View.MeasureSpec.getMode(i11);
        this.mHeightMode = mode2;
        if (mode2 != 0 || RecyclerView.ALLOW_SIZE_IN_UNSPECIFIED_SPEC) {
            return;
        }
        this.mHeight = 0;
    }

    public void setMeasuredDimension(Rect rect, int i10, int i11) {
        setMeasuredDimension(chooseSize(i10, getPaddingRight() + getPaddingLeft() + rect.width(), getMinimumWidth()), chooseSize(i11, getPaddingBottom() + getPaddingTop() + rect.height(), getMinimumHeight()));
    }

    public void setMeasuredDimensionFromChildren(int i10, int i11) {
        int childCount = getChildCount();
        if (childCount == 0) {
            this.mRecyclerView.defaultOnMeasure(i10, i11);
            return;
        }
        int i12 = Integer.MIN_VALUE;
        int i13 = Integer.MAX_VALUE;
        int i14 = Integer.MIN_VALUE;
        int i15 = Integer.MAX_VALUE;
        for (int i16 = 0; i16 < childCount; i16++) {
            View childAt = getChildAt(i16);
            Rect rect = this.mRecyclerView.mTempRect;
            getDecoratedBoundsWithMargins(childAt, rect);
            int i17 = rect.left;
            if (i17 < i15) {
                i15 = i17;
            }
            int i18 = rect.right;
            if (i18 > i12) {
                i12 = i18;
            }
            int i19 = rect.top;
            if (i19 < i13) {
                i13 = i19;
            }
            int i20 = rect.bottom;
            if (i20 > i14) {
                i14 = i20;
            }
        }
        this.mRecyclerView.mTempRect.set(i15, i13, i12, i14);
        setMeasuredDimension(this.mRecyclerView.mTempRect, i10, i11);
    }

    public void setMeasurementCacheEnabled(boolean z3) {
        this.mMeasurementCacheEnabled = z3;
    }

    public void setRecyclerView(RecyclerView recyclerView) {
        if (recyclerView == null) {
            this.mRecyclerView = null;
            this.mChildHelper = null;
            this.mWidth = 0;
            this.mHeight = 0;
        } else {
            this.mRecyclerView = recyclerView;
            this.mChildHelper = recyclerView.mChildHelper;
            this.mWidth = recyclerView.getWidth();
            this.mHeight = recyclerView.getHeight();
        }
        this.mWidthMode = 1073741824;
        this.mHeightMode = 1073741824;
    }

    public boolean shouldMeasureChild(View view, int i10, int i11, C0432b0 c0432b0) {
        return (!view.isLayoutRequested() && this.mMeasurementCacheEnabled && b(view.getWidth(), i10, ((ViewGroup.MarginLayoutParams) c0432b0).width) && b(view.getHeight(), i11, ((ViewGroup.MarginLayoutParams) c0432b0).height)) ? false : true;
    }

    public boolean shouldMeasureTwice() {
        return false;
    }

    public boolean shouldReMeasureChild(View view, int i10, int i11, C0432b0 c0432b0) {
        return (this.mMeasurementCacheEnabled && b(view.getMeasuredWidth(), i10, ((ViewGroup.MarginLayoutParams) c0432b0).width) && b(view.getMeasuredHeight(), i11, ((ViewGroup.MarginLayoutParams) c0432b0).height)) ? false : true;
    }

    public abstract void smoothScrollToPosition(RecyclerView recyclerView, p0 p0Var, int i10);

    public void startSmoothScroll(o0 o0Var) {
        o0 o0Var2 = this.mSmoothScroller;
        if (o0Var2 != null && o0Var != o0Var2 && o0Var2.f7218e) {
            o0Var2.d();
        }
        this.mSmoothScroller = o0Var;
        RecyclerView recyclerView = this.mRecyclerView;
        o0Var.getClass();
        r0 r0Var = recyclerView.mViewFlinger;
        r0Var.f7245n.removeCallbacks(r0Var);
        r0Var.f7242c.abortAnimation();
        if (o0Var.f7220h) {
            Log.w("RecyclerView", "An instance of " + o0Var.getClass().getSimpleName() + " was started more than once. Each instance of" + o0Var.getClass().getSimpleName() + " is intended to only be used once. You should create a new instance for each use.");
        }
        o0Var.f7216b = recyclerView;
        o0Var.f7217c = this;
        int i10 = o0Var.f7215a;
        if (i10 == -1) {
            throw new IllegalArgumentException("Invalid target position");
        }
        recyclerView.mState.f7225a = i10;
        o0Var.f7218e = true;
        o0Var.d = true;
        o0Var.f7219f = recyclerView.mLayout.findViewByPosition(i10);
        o0Var.f7216b.mViewFlinger.a();
        o0Var.f7220h = true;
    }

    public void stopIgnoringView(View view) {
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        childViewHolderInt.f7257j &= -129;
        childViewHolderInt.r();
        childViewHolderInt.e(4);
    }

    public void stopSmoothScroller() {
        o0 o0Var = this.mSmoothScroller;
        if (o0Var != null) {
            o0Var.d();
        }
    }

    public boolean supportsPredictiveItemAnimations() {
        return false;
    }

    public void addDisappearingView(View view, int i10) {
        a(view, i10, true);
    }

    public void addView(View view, int i10) {
        a(view, i10, false);
    }

    public void onDetachedFromWindow(RecyclerView recyclerView, i0 i0Var) {
        onDetachedFromWindow(recyclerView);
    }

    public void onInitializeAccessibilityEvent(i0 i0Var, p0 p0Var, AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null || accessibilityEvent == null) {
            return;
        }
        boolean z3 = true;
        if (!recyclerView.canScrollVertically(1) && !this.mRecyclerView.canScrollVertically(-1) && !this.mRecyclerView.canScrollHorizontally(-1) && !this.mRecyclerView.canScrollHorizontally(1)) {
            z3 = false;
        }
        accessibilityEvent.setScrollable(z3);
        N n9 = this.mRecyclerView.mAdapter;
        if (n9 != null) {
            accessibilityEvent.setItemCount(n9.a());
        }
    }

    public void onInitializeAccessibilityNodeInfo(i0 i0Var, p0 p0Var, S.j jVar) {
        if (this.mRecyclerView.canScrollVertically(-1) || this.mRecyclerView.canScrollHorizontally(-1)) {
            jVar.a(8192);
            jVar.j(true);
        }
        if (this.mRecyclerView.canScrollVertically(1) || this.mRecyclerView.canScrollHorizontally(1)) {
            jVar.a(4096);
            jVar.j(true);
        }
        AccessibilityNodeInfo.CollectionInfo collectionInfoObtain = AccessibilityNodeInfo.CollectionInfo.obtain(getRowCountForAccessibility(i0Var, p0Var), getColumnCountForAccessibility(i0Var, p0Var), isLayoutHierarchical(i0Var, p0Var), getSelectionModeForAccessibility(i0Var, p0Var));
        jVar.getClass();
        jVar.f4177a.setCollectionInfo(collectionInfoObtain);
    }

    public void onItemsUpdated(RecyclerView recyclerView, int i10, int i11, Object obj) {
        onItemsUpdated(recyclerView, i10, i11);
    }

    public boolean onRequestChildFocus(RecyclerView recyclerView, p0 p0Var, View view, View view2) {
        return onRequestChildFocus(recyclerView, view, view2);
    }

    public boolean performAccessibilityAction(i0 i0Var, p0 p0Var, int i10, Bundle bundle) {
        int height;
        int width;
        int i11;
        int i12;
        RecyclerView recyclerView = this.mRecyclerView;
        if (recyclerView == null) {
            return false;
        }
        if (i10 == 4096) {
            height = recyclerView.canScrollVertically(1) ? (getHeight() - getPaddingTop()) - getPaddingBottom() : 0;
            if (this.mRecyclerView.canScrollHorizontally(1)) {
                width = (getWidth() - getPaddingLeft()) - getPaddingRight();
                i11 = height;
                i12 = width;
            }
            i11 = height;
            i12 = 0;
        } else if (i10 != 8192) {
            i12 = 0;
            i11 = 0;
        } else {
            height = recyclerView.canScrollVertically(-1) ? -((getHeight() - getPaddingTop()) - getPaddingBottom()) : 0;
            if (this.mRecyclerView.canScrollHorizontally(-1)) {
                width = -((getWidth() - getPaddingLeft()) - getPaddingRight());
                i11 = height;
                i12 = width;
            }
            i11 = height;
            i12 = 0;
        }
        if (i11 == 0 && i12 == 0) {
            return false;
        }
        this.mRecyclerView.smoothScrollBy(i12, i11, null, Integer.MIN_VALUE, true);
        return true;
    }

    public boolean performAccessibilityActionForItem(View view, int i10, Bundle bundle) {
        RecyclerView recyclerView = this.mRecyclerView;
        return performAccessibilityActionForItem(recyclerView.mRecycler, recyclerView.mState, view, i10, bundle);
    }

    /* JADX WARN: Removed duplicated region for block: B:33:0x001a  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0022  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static int getChildMeasureSpec(int r4, int r5, int r6, int r7, boolean r8) {
        /*
            int r4 = r4 - r6
            r6 = 0
            int r4 = java.lang.Math.max(r6, r4)
            r0 = -2
            r1 = -1
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1073741824(0x40000000, float:2.0)
            if (r8 == 0) goto L1d
            if (r7 < 0) goto L12
        L10:
            r5 = r3
            goto L30
        L12:
            if (r7 != r1) goto L1a
            if (r5 == r2) goto L22
            if (r5 == 0) goto L1a
            if (r5 == r3) goto L22
        L1a:
            r5 = r6
            r7 = r5
            goto L30
        L1d:
            if (r7 < 0) goto L20
            goto L10
        L20:
            if (r7 != r1) goto L24
        L22:
            r7 = r4
            goto L30
        L24:
            if (r7 != r0) goto L1a
            if (r5 == r2) goto L2e
            if (r5 != r3) goto L2b
            goto L2e
        L2b:
            r7 = r4
            r5 = r6
            goto L30
        L2e:
            r7 = r4
            r5 = r2
        L30:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r5)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.AbstractC0430a0.getChildMeasureSpec(int, int, int, int, boolean):int");
    }

    public void onInitializeAccessibilityNodeInfoForItem(i0 i0Var, p0 p0Var, View view, S.j jVar) {
        jVar.h(S.i.b(canScrollVertically() ? getPosition(view) : 0, 1, canScrollHorizontally() ? getPosition(view) : 0, 1, false));
    }

    public C0432b0 generateLayoutParams(Context context, AttributeSet attributeSet) {
        return new C0432b0(context, attributeSet);
    }

    public void setMeasuredDimension(int i10, int i11) {
        this.mRecyclerView.setMeasuredDimension(i10, i11);
    }

    public void attachView(View view, int i10) {
        attachView(view, i10, (C0432b0) view.getLayoutParams());
    }

    public void attachView(View view) {
        attachView(view, -1);
    }

    public boolean requestChildRectangleOnScreen(RecyclerView recyclerView, View view, Rect rect, boolean z3) {
        return requestChildRectangleOnScreen(recyclerView, view, rect, z3, false);
    }
}
