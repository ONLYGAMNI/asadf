package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.ViewGroup;

/* renamed from: androidx.recyclerview.widget.b0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public class C0432b0 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a, reason: collision with root package name */
    public s0 f7138a;

    /* renamed from: b, reason: collision with root package name */
    public final Rect f7139b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f7140c;
    public boolean d;

    public C0432b0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f7139b = new Rect();
        this.f7140c = true;
        this.d = false;
    }

    public C0432b0(int i10, int i11) {
        super(i10, i11);
        this.f7139b = new Rect();
        this.f7140c = true;
        this.d = false;
    }

    public C0432b0(ViewGroup.MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
        this.f7139b = new Rect();
        this.f7140c = true;
        this.d = false;
    }

    public C0432b0(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f7139b = new Rect();
        this.f7140c = true;
        this.d = false;
    }

    public C0432b0(C0432b0 c0432b0) {
        super((ViewGroup.LayoutParams) c0432b0);
        this.f7139b = new Rect();
        this.f7140c = true;
        this.d = false;
    }
}
