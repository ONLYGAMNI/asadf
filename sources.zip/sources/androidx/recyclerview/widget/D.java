package androidx.recyclerview.widget;

import android.view.View;
import java.util.List;

/* loaded from: classes.dex */
public final class D {

    /* renamed from: a, reason: collision with root package name */
    public boolean f7055a;

    /* renamed from: b, reason: collision with root package name */
    public int f7056b;

    /* renamed from: c, reason: collision with root package name */
    public int f7057c;
    public int d;

    /* renamed from: e, reason: collision with root package name */
    public int f7058e;

    /* renamed from: f, reason: collision with root package name */
    public int f7059f;
    public int g;

    /* renamed from: h, reason: collision with root package name */
    public int f7060h;

    /* renamed from: i, reason: collision with root package name */
    public int f7061i;

    /* renamed from: j, reason: collision with root package name */
    public int f7062j;

    /* renamed from: k, reason: collision with root package name */
    public List f7063k;

    /* renamed from: l, reason: collision with root package name */
    public boolean f7064l;

    public final void a(View view) {
        int iF;
        int size = this.f7063k.size();
        View view2 = null;
        int i10 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        for (int i11 = 0; i11 < size; i11++) {
            View view3 = ((s0) this.f7063k.get(i11)).f7250a;
            C0432b0 c0432b0 = (C0432b0) view3.getLayoutParams();
            if (view3 != view && !c0432b0.f7138a.m() && (iF = (c0432b0.f7138a.f() - this.d) * this.f7058e) >= 0 && iF < i10) {
                view2 = view3;
                if (iF == 0) {
                    break;
                } else {
                    i10 = iF;
                }
            }
        }
        if (view2 == null) {
            this.d = -1;
        } else {
            this.d = ((C0432b0) view2.getLayoutParams()).f7138a.f();
        }
    }

    public final View b(i0 i0Var) {
        List list = this.f7063k;
        if (list == null) {
            View view = i0Var.j(this.d, Long.MAX_VALUE).f7250a;
            this.d += this.f7058e;
            return view;
        }
        int size = list.size();
        for (int i10 = 0; i10 < size; i10++) {
            View view2 = ((s0) this.f7063k.get(i10)).f7250a;
            C0432b0 c0432b0 = (C0432b0) view2.getLayoutParams();
            if (!c0432b0.f7138a.m() && this.d == c0432b0.f7138a.f()) {
                a(view2);
                return view2;
            }
        }
        return null;
    }
}
