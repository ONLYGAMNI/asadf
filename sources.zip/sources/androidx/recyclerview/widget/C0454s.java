package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* renamed from: androidx.recyclerview.widget.s */
/* loaded from: classes.dex */
public final class C0454s extends AnimatorListenerAdapter {

    /* renamed from: a */
    public final /* synthetic */ int f7246a = 0;

    /* renamed from: b */
    public boolean f7247b = false;

    /* renamed from: c */
    public final /* synthetic */ Object f7248c;

    public C0454s(h4.i iVar) {
        this.f7248c = iVar;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        switch (this.f7246a) {
            case 0:
                this.f7247b = true;
                break;
            default:
                super.onAnimationCancel(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.f7246a) {
            case 0:
                if (!this.f7247b) {
                    C0456u c0456u = (C0456u) this.f7248c;
                    if (((Float) c0456u.f7295z.getAnimatedValue()).floatValue() != 0.0f) {
                        c0456u.f7270A = 2;
                        c0456u.f7288s.invalidate();
                        break;
                    } else {
                        c0456u.f7270A = 0;
                        c0456u.g(0);
                        break;
                    }
                } else {
                    this.f7247b = false;
                    break;
                }
            default:
                h4.i iVar = (h4.i) this.f7248c;
                iVar.f10980r = 0;
                iVar.f10974l = null;
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        switch (this.f7246a) {
            case 1:
                h4.i iVar = (h4.i) this.f7248c;
                iVar.f10981s.a(0, this.f7247b);
                iVar.f10980r = 2;
                iVar.f10974l = animator;
                break;
            default:
                super.onAnimationStart(animator);
                break;
        }
    }

    public C0454s(C0456u c0456u) {
        this.f7248c = c0456u;
    }
}
