package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class E implements Parcelable {
    public static final Parcelable.Creator<E> CREATOR = new S3.b(19);

    /* renamed from: a, reason: collision with root package name */
    public int f7065a;

    /* renamed from: b, reason: collision with root package name */
    public int f7066b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f7067c;

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i10) {
        parcel.writeInt(this.f7065a);
        parcel.writeInt(this.f7066b);
        parcel.writeInt(this.f7067c ? 1 : 0);
    }
}
