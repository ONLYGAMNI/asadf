package androidx.recyclerview.widget;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/* loaded from: classes.dex */
public final class J extends F {

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ K f7092q;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public J(K k10, Context context) {
        super(context);
        this.f7092q = k10;
    }

    @Override // androidx.recyclerview.widget.F, androidx.recyclerview.widget.o0
    public final void c(View view, m0 m0Var) {
        K k10 = this.f7092q;
        int[] iArrCalculateDistanceToFinalSnap = k10.calculateDistanceToFinalSnap(k10.mRecyclerView.getLayoutManager(), view);
        int i10 = iArrCalculateDistanceToFinalSnap[0];
        int i11 = iArrCalculateDistanceToFinalSnap[1];
        int i12 = i(Math.max(Math.abs(i10), Math.abs(i11)));
        if (i12 > 0) {
            DecelerateInterpolator decelerateInterpolator = this.f7071j;
            m0Var.f7204a = i10;
            m0Var.f7205b = i11;
            m0Var.f7206c = i12;
            m0Var.f7207e = decelerateInterpolator;
            m0Var.f7208f = true;
        }
    }

    @Override // androidx.recyclerview.widget.F
    public final float h(DisplayMetrics displayMetrics) {
        return 100.0f / displayMetrics.densityDpi;
    }

    @Override // androidx.recyclerview.widget.F
    public final int j(int i10) {
        return Math.min(100, super.j(i10));
    }
}
