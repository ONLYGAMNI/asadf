package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class k0 extends P {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f7185a;

    public k0(RecyclerView recyclerView) {
        this.f7185a = recyclerView;
    }

    public final void a() {
        boolean z3 = RecyclerView.POST_UPDATES_ON_ANIMATION;
        RecyclerView recyclerView = this.f7185a;
        if (!z3 || !recyclerView.mHasFixedSize || !recyclerView.mIsAttached) {
            recyclerView.mAdapterUpdateDuringMeasure = true;
            recyclerView.requestLayout();
        } else {
            Runnable runnable = recyclerView.mUpdateChildViewsRunnable;
            WeakHashMap weakHashMap = R.X.f3966a;
            R.E.m(recyclerView, runnable);
        }
    }

    @Override // androidx.recyclerview.widget.P
    public final void onChanged() {
        RecyclerView recyclerView = this.f7185a;
        recyclerView.assertNotInLayoutOrScroll(null);
        recyclerView.mState.f7229f = true;
        recyclerView.processDataSetCompletelyChanged(true);
        if (recyclerView.mAdapterHelper.g()) {
            return;
        }
        recyclerView.requestLayout();
    }

    @Override // androidx.recyclerview.widget.P
    public final void onItemRangeChanged(int i10, int i11, Object obj) {
        RecyclerView recyclerView = this.f7185a;
        recyclerView.assertNotInLayoutOrScroll(null);
        C0431b c0431b = recyclerView.mAdapterHelper;
        if (i11 < 1) {
            c0431b.getClass();
            return;
        }
        ArrayList arrayList = c0431b.f7134b;
        arrayList.add(c0431b.h(4, i10, i11));
        c0431b.f7137f |= 4;
        if (arrayList.size() == 1) {
            a();
        }
    }

    @Override // androidx.recyclerview.widget.P
    public final void onItemRangeInserted(int i10, int i11) {
        RecyclerView recyclerView = this.f7185a;
        recyclerView.assertNotInLayoutOrScroll(null);
        C0431b c0431b = recyclerView.mAdapterHelper;
        if (i11 < 1) {
            c0431b.getClass();
            return;
        }
        ArrayList arrayList = c0431b.f7134b;
        arrayList.add(c0431b.h(1, i10, i11));
        c0431b.f7137f |= 1;
        if (arrayList.size() == 1) {
            a();
        }
    }

    @Override // androidx.recyclerview.widget.P
    public final void onItemRangeMoved(int i10, int i11, int i12) {
        RecyclerView recyclerView = this.f7185a;
        recyclerView.assertNotInLayoutOrScroll(null);
        C0431b c0431b = recyclerView.mAdapterHelper;
        c0431b.getClass();
        if (i10 == i11) {
            return;
        }
        ArrayList arrayList = c0431b.f7134b;
        arrayList.add(c0431b.h(8, i10, i11));
        c0431b.f7137f |= 8;
        if (arrayList.size() == 1) {
            a();
        }
    }

    @Override // androidx.recyclerview.widget.P
    public final void onItemRangeRemoved(int i10, int i11) {
        RecyclerView recyclerView = this.f7185a;
        recyclerView.assertNotInLayoutOrScroll(null);
        C0431b c0431b = recyclerView.mAdapterHelper;
        if (i11 < 1) {
            c0431b.getClass();
            return;
        }
        ArrayList arrayList = c0431b.f7134b;
        arrayList.add(c0431b.h(2, i10, i11));
        c0431b.f7137f |= 2;
        if (arrayList.size() == 1) {
            a();
        }
    }
}
