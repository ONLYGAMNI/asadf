package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0446j {

    /* renamed from: a, reason: collision with root package name */
    public s0 f7176a;

    /* renamed from: b, reason: collision with root package name */
    public s0 f7177b;

    /* renamed from: c, reason: collision with root package name */
    public int f7178c;
    public int d;

    /* renamed from: e, reason: collision with root package name */
    public int f7179e;

    /* renamed from: f, reason: collision with root package name */
    public int f7180f;

    public final String toString() {
        StringBuilder sb = new StringBuilder("ChangeInfo{oldHolder=");
        sb.append(this.f7176a);
        sb.append(", newHolder=");
        sb.append(this.f7177b);
        sb.append(", fromX=");
        sb.append(this.f7178c);
        sb.append(", fromY=");
        sb.append(this.d);
        sb.append(", toX=");
        sb.append(this.f7179e);
        sb.append(", toY=");
        return android.support.v4.media.session.a.n(sb, this.f7180f, '}');
    }
}
