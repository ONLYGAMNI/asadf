package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.z, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0461z extends C0432b0 {

    /* renamed from: e, reason: collision with root package name */
    public int f7317e;

    /* renamed from: f, reason: collision with root package name */
    public int f7318f;

    public C0461z(int i10, int i11) {
        super(i10, i11);
        this.f7317e = -1;
        this.f7318f = 0;
    }
}
