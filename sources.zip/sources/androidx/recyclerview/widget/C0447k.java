package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0447k {

    /* renamed from: a, reason: collision with root package name */
    public s0 f7181a;

    /* renamed from: b, reason: collision with root package name */
    public int f7182b;

    /* renamed from: c, reason: collision with root package name */
    public int f7183c;
    public int d;

    /* renamed from: e, reason: collision with root package name */
    public int f7184e;
}
