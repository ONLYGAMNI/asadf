package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public interface G {
    void a(int i10, int i11);

    void b(int i10, int i11);

    void c(int i10, int i11);

    void d(int i10, int i11);
}
