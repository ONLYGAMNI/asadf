package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class C {

    /* renamed from: a, reason: collision with root package name */
    public int f7048a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f7049b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f7050c;
    public boolean d;
}
