package androidx.recyclerview.widget;

import android.view.View;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class B0 {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f7043a = new ArrayList();

    /* renamed from: b, reason: collision with root package name */
    public int f7044b = Integer.MIN_VALUE;

    /* renamed from: c, reason: collision with root package name */
    public int f7045c = Integer.MIN_VALUE;
    public int d = 0;

    /* renamed from: e, reason: collision with root package name */
    public final int f7046e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ StaggeredGridLayoutManager f7047f;

    public B0(StaggeredGridLayoutManager staggeredGridLayoutManager, int i10) {
        this.f7047f = staggeredGridLayoutManager;
        this.f7046e = i10;
    }

    public final void a() {
        View view = (View) this.f7043a.get(r0.size() - 1);
        y0 y0Var = (y0) view.getLayoutParams();
        this.f7045c = this.f7047f.f7100c.b(view);
        y0Var.getClass();
    }

    public final void b() {
        this.f7043a.clear();
        this.f7044b = Integer.MIN_VALUE;
        this.f7045c = Integer.MIN_VALUE;
        this.d = 0;
    }

    public final int c() {
        return this.f7047f.f7103h ? e(r1.size() - 1, -1) : e(0, this.f7043a.size());
    }

    public final int d() {
        return this.f7047f.f7103h ? e(0, this.f7043a.size()) : e(r1.size() - 1, -1);
    }

    public final int e(int i10, int i11) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f7047f;
        int iK = staggeredGridLayoutManager.f7100c.k();
        int iG = staggeredGridLayoutManager.f7100c.g();
        int i12 = i11 > i10 ? 1 : -1;
        while (i10 != i11) {
            View view = (View) this.f7043a.get(i10);
            int iE = staggeredGridLayoutManager.f7100c.e(view);
            int iB = staggeredGridLayoutManager.f7100c.b(view);
            boolean z3 = iE <= iG;
            boolean z9 = iB >= iK;
            if (z3 && z9 && (iE < iK || iB > iG)) {
                return staggeredGridLayoutManager.getPosition(view);
            }
            i10 += i12;
        }
        return -1;
    }

    public final int f(int i10) {
        int i11 = this.f7045c;
        if (i11 != Integer.MIN_VALUE) {
            return i11;
        }
        if (this.f7043a.size() == 0) {
            return i10;
        }
        a();
        return this.f7045c;
    }

    public final View g(int i10, int i11) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f7047f;
        ArrayList arrayList = this.f7043a;
        View view = null;
        if (i11 != -1) {
            int size = arrayList.size() - 1;
            while (size >= 0) {
                View view2 = (View) arrayList.get(size);
                if ((staggeredGridLayoutManager.f7103h && staggeredGridLayoutManager.getPosition(view2) >= i10) || ((!staggeredGridLayoutManager.f7103h && staggeredGridLayoutManager.getPosition(view2) <= i10) || !view2.hasFocusable())) {
                    break;
                }
                size--;
                view = view2;
            }
        } else {
            int size2 = arrayList.size();
            int i12 = 0;
            while (i12 < size2) {
                View view3 = (View) arrayList.get(i12);
                if ((staggeredGridLayoutManager.f7103h && staggeredGridLayoutManager.getPosition(view3) <= i10) || ((!staggeredGridLayoutManager.f7103h && staggeredGridLayoutManager.getPosition(view3) >= i10) || !view3.hasFocusable())) {
                    break;
                }
                i12++;
                view = view3;
            }
        }
        return view;
    }

    public final int h(int i10) {
        int i11 = this.f7044b;
        if (i11 != Integer.MIN_VALUE) {
            return i11;
        }
        if (this.f7043a.size() == 0) {
            return i10;
        }
        View view = (View) this.f7043a.get(0);
        y0 y0Var = (y0) view.getLayoutParams();
        this.f7044b = this.f7047f.f7100c.e(view);
        y0Var.getClass();
        return this.f7044b;
    }
}
