package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0452p {

    /* renamed from: a, reason: collision with root package name */
    public int f7221a;

    /* renamed from: b, reason: collision with root package name */
    public int f7222b;

    /* renamed from: c, reason: collision with root package name */
    public int f7223c;
    public boolean d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f7224e;
}
