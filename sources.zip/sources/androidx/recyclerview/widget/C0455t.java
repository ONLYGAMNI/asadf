package androidx.recyclerview.widget;

import android.animation.ValueAnimator;

/* renamed from: androidx.recyclerview.widget.t */
/* loaded from: classes.dex */
public final class C0455t implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a */
    public final /* synthetic */ C0456u f7266a;

    public C0455t(C0456u c0456u) {
        this.f7266a = c0456u;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        int iFloatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
        C0456u c0456u = this.f7266a;
        c0456u.f7274c.setAlpha(iFloatValue);
        c0456u.d.setAlpha(iFloatValue);
        c0456u.f7288s.invalidate();
    }
}
