package androidx.recyclerview.widget;

import r.C1331e;
import r.C1338l;

/* loaded from: classes.dex */
public final class H0 {

    /* renamed from: a, reason: collision with root package name */
    public final C1338l f7087a = new C1338l();

    /* renamed from: b, reason: collision with root package name */
    public final C1331e f7088b = new C1331e();

    public final void a(s0 s0Var, U u7) {
        C1338l c1338l = this.f7087a;
        F0 f0A = (F0) c1338l.getOrDefault(s0Var, null);
        if (f0A == null) {
            f0A = F0.a();
            c1338l.put(s0Var, f0A);
        }
        f0A.f7080c = u7;
        f0A.f7078a |= 8;
    }

    public final U b(s0 s0Var, int i10) {
        F0 f02;
        U u7;
        C1338l c1338l = this.f7087a;
        int iF = c1338l.f(s0Var);
        if (iF >= 0 && (f02 = (F0) c1338l.m(iF)) != null) {
            int i11 = f02.f7078a;
            if ((i11 & i10) != 0) {
                int i12 = i11 & (~i10);
                f02.f7078a = i12;
                if (i10 == 4) {
                    u7 = f02.f7079b;
                } else {
                    if (i10 != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    u7 = f02.f7080c;
                }
                if ((i12 & 12) == 0) {
                    c1338l.k(iF);
                    f02.f7078a = 0;
                    f02.f7079b = null;
                    f02.f7080c = null;
                    F0.d.e(f02);
                }
                return u7;
            }
        }
        return null;
    }

    public final void c(s0 s0Var) {
        F0 f02 = (F0) this.f7087a.getOrDefault(s0Var, null);
        if (f02 == null) {
            return;
        }
        f02.f7078a &= -2;
    }

    public final void d(s0 s0Var) {
        C1331e c1331e = this.f7088b;
        int iJ = c1331e.j() - 1;
        while (true) {
            if (iJ < 0) {
                break;
            }
            if (s0Var == c1331e.k(iJ)) {
                Object[] objArr = c1331e.f14597c;
                Object obj = objArr[iJ];
                Object obj2 = C1331e.f14594e;
                if (obj != obj2) {
                    objArr[iJ] = obj2;
                    c1331e.f14595a = true;
                }
            } else {
                iJ--;
            }
        }
        F0 f02 = (F0) this.f7087a.remove(s0Var);
        if (f02 != null) {
            f02.f7078a = 0;
            f02.f7079b = null;
            f02.f7080c = null;
            F0.d.e(f02);
        }
    }
}
