package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;

/* loaded from: classes.dex */
public abstract class I {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0430a0 f7089a;

    /* renamed from: b, reason: collision with root package name */
    public int f7090b = Integer.MIN_VALUE;

    /* renamed from: c, reason: collision with root package name */
    public final Rect f7091c = new Rect();

    public I(AbstractC0430a0 abstractC0430a0) {
        this.f7089a = abstractC0430a0;
    }

    public static I a(AbstractC0430a0 abstractC0430a0, int i10) {
        if (i10 == 0) {
            return new H(abstractC0430a0, 0);
        }
        if (i10 == 1) {
            return new H(abstractC0430a0, 1);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    public abstract int b(View view);

    public abstract int c(View view);

    public abstract int d(View view);

    public abstract int e(View view);

    public abstract int f();

    public abstract int g();

    public abstract int h();

    public abstract int i();

    public abstract int j();

    public abstract int k();

    public abstract int l();

    public final int m() {
        if (Integer.MIN_VALUE == this.f7090b) {
            return 0;
        }
        return l() - this.f7090b;
    }

    public abstract int n(View view);

    public abstract int o(View view);

    public abstract void p(int i10);
}
