package androidx.recyclerview.widget;

import android.graphics.PointF;
import android.util.Log;
import android.view.View;

/* loaded from: classes.dex */
public abstract class o0 {

    /* renamed from: a */
    public int f7215a = -1;

    /* renamed from: b */
    public RecyclerView f7216b;

    /* renamed from: c */
    public AbstractC0430a0 f7217c;
    public boolean d;

    /* renamed from: e */
    public boolean f7218e;

    /* renamed from: f */
    public View f7219f;
    public final m0 g;

    /* renamed from: h */
    public boolean f7220h;

    public o0() {
        m0 m0Var = new m0();
        m0Var.d = -1;
        m0Var.f7208f = false;
        m0Var.g = 0;
        m0Var.f7204a = 0;
        m0Var.f7205b = 0;
        m0Var.f7206c = Integer.MIN_VALUE;
        m0Var.f7207e = null;
        this.g = m0Var;
    }

    public PointF a(int i10) {
        Object obj = this.f7217c;
        if (obj instanceof n0) {
            return ((n0) obj).computeScrollVectorForPosition(i10);
        }
        Log.w("RecyclerView", "You should override computeScrollVectorForPosition when the LayoutManager does not implement " + n0.class.getCanonicalName());
        return null;
    }

    /* JADX WARN: Removed duplicated region for block: B:107:0x00f2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void b(int r8, int r9) {
        /*
            Method dump skipped, instructions count: 271
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.o0.b(int, int):void");
    }

    public abstract void c(View view, m0 m0Var);

    public final void d() {
        if (this.f7218e) {
            this.f7218e = false;
            F f10 = (F) this;
            f10.f7077p = 0;
            f10.f7076o = 0;
            f10.f7072k = null;
            this.f7216b.mState.f7225a = -1;
            this.f7219f = null;
            this.f7215a = -1;
            this.d = false;
            this.f7217c.onSmoothScrollerStopped(this);
            this.f7217c = null;
            this.f7216b = null;
        }
    }
}
