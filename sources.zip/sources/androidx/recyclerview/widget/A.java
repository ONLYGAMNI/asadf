package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class A {

    /* renamed from: a, reason: collision with root package name */
    public boolean f7023a;

    /* renamed from: b, reason: collision with root package name */
    public int f7024b;

    /* renamed from: c, reason: collision with root package name */
    public int f7025c;
    public int d;

    /* renamed from: e, reason: collision with root package name */
    public int f7026e;

    /* renamed from: f, reason: collision with root package name */
    public int f7027f;
    public int g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f7028h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f7029i;

    public final String toString() {
        StringBuilder sb = new StringBuilder("LayoutState{mAvailable=");
        sb.append(this.f7024b);
        sb.append(", mCurrentPosition=");
        sb.append(this.f7025c);
        sb.append(", mItemDirection=");
        sb.append(this.d);
        sb.append(", mLayoutDirection=");
        sb.append(this.f7026e);
        sb.append(", mStartLine=");
        sb.append(this.f7027f);
        sb.append(", mEndLine=");
        return android.support.v4.media.session.a.n(sb, this.g, '}');
    }
}
