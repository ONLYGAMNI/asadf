package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.d, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0435d implements G {

    /* renamed from: a, reason: collision with root package name */
    public final G f7142a;

    /* renamed from: b, reason: collision with root package name */
    public int f7143b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f7144c = -1;
    public int d = -1;

    /* renamed from: e, reason: collision with root package name */
    public Object f7145e = null;

    public C0435d(G g) {
        this.f7142a = g;
    }

    @Override // androidx.recyclerview.widget.G
    public final void a(int i10, int i11) {
        int i12;
        if (this.f7143b == 2 && (i12 = this.f7144c) >= i10 && i12 <= i10 + i11) {
            this.d += i11;
            this.f7144c = i10;
        } else {
            e();
            this.f7144c = i10;
            this.d = i11;
            this.f7143b = 2;
        }
    }

    @Override // androidx.recyclerview.widget.G
    public final void b(int i10, int i11) {
        e();
        this.f7142a.b(i10, i11);
    }

    @Override // androidx.recyclerview.widget.G
    public final void c(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        if (this.f7143b == 3 && i10 <= (i13 = this.d + (i12 = this.f7144c)) && (i14 = i10 + i11) >= i12 && this.f7145e == null) {
            this.f7144c = Math.min(i10, i12);
            this.d = Math.max(i13, i14) - this.f7144c;
            return;
        }
        e();
        this.f7144c = i10;
        this.d = i11;
        this.f7145e = null;
        this.f7143b = 3;
    }

    @Override // androidx.recyclerview.widget.G
    public final void d(int i10, int i11) {
        int i12;
        if (this.f7143b == 1 && i10 >= (i12 = this.f7144c)) {
            int i13 = this.d;
            if (i10 <= i12 + i13) {
                this.d = i13 + i11;
                this.f7144c = Math.min(i10, i12);
                return;
            }
        }
        e();
        this.f7144c = i10;
        this.d = i11;
        this.f7143b = 1;
    }

    public final void e() {
        int i10 = this.f7143b;
        if (i10 == 0) {
            return;
        }
        G g = this.f7142a;
        if (i10 == 1) {
            g.d(this.f7144c, this.d);
        } else if (i10 == 2) {
            g.a(this.f7144c, this.d);
        } else if (i10 == 3) {
            g.c(this.f7144c, this.d);
        }
        this.f7145e = null;
        this.f7143b = 0;
    }
}
