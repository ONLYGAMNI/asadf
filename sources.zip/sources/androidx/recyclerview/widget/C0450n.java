package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.n, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0450n {

    /* renamed from: a, reason: collision with root package name */
    public final int f7209a;

    /* renamed from: b, reason: collision with root package name */
    public int f7210b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f7211c;

    public C0450n(int i10, int i11, boolean z3) {
        this.f7209a = i10;
        this.f7210b = i11;
        this.f7211c = z3;
    }
}
