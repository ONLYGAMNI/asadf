package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* renamed from: androidx.recyclerview.widget.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0445i extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f7166a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ C0446j f7167b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f7168c;
    public final /* synthetic */ View d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ C0448l f7169e;

    public /* synthetic */ C0445i(C0448l c0448l, C0446j c0446j, ViewPropertyAnimator viewPropertyAnimator, View view, int i10) {
        this.f7166a = i10;
        this.f7169e = c0448l;
        this.f7167b = c0446j;
        this.f7168c = viewPropertyAnimator;
        this.d = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        switch (this.f7166a) {
            case 0:
                this.f7168c.setListener(null);
                View view = this.d;
                view.setAlpha(1.0f);
                view.setTranslationX(0.0f);
                view.setTranslationY(0.0f);
                C0446j c0446j = this.f7167b;
                s0 s0Var = c0446j.f7176a;
                C0448l c0448l = this.f7169e;
                c0448l.c(s0Var);
                c0448l.f7197r.remove(c0446j.f7176a);
                c0448l.i();
                break;
            default:
                this.f7168c.setListener(null);
                View view2 = this.d;
                view2.setAlpha(1.0f);
                view2.setTranslationX(0.0f);
                view2.setTranslationY(0.0f);
                C0446j c0446j2 = this.f7167b;
                s0 s0Var2 = c0446j2.f7177b;
                C0448l c0448l2 = this.f7169e;
                c0448l2.c(s0Var2);
                c0448l2.f7197r.remove(c0446j2.f7177b);
                c0448l2.i();
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        switch (this.f7166a) {
            case 0:
                s0 s0Var = this.f7167b.f7176a;
                this.f7169e.getClass();
                break;
            default:
                s0 s0Var2 = this.f7167b.f7177b;
                this.f7169e.getClass();
                break;
        }
    }
}
