package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.WeakHashMap;

/* renamed from: androidx.recyclerview.widget.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0437e {

    /* renamed from: a, reason: collision with root package name */
    public final M f7146a;

    /* renamed from: b, reason: collision with root package name */
    public final K3.O f7147b = new K3.O(2);

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f7148c = new ArrayList();

    public C0437e(M m9) {
        this.f7146a = m9;
    }

    public final void a(View view, int i10, boolean z3) {
        M m9 = this.f7146a;
        int childCount = i10 < 0 ? m9.f7095a.getChildCount() : f(i10);
        this.f7147b.e(childCount, z3);
        if (z3) {
            i(view);
        }
        RecyclerView recyclerView = m9.f7095a;
        recyclerView.addView(view, childCount);
        recyclerView.dispatchChildAttached(view);
    }

    public final void b(View view, int i10, ViewGroup.LayoutParams layoutParams, boolean z3) {
        M m9 = this.f7146a;
        int childCount = i10 < 0 ? m9.f7095a.getChildCount() : f(i10);
        this.f7147b.e(childCount, z3);
        if (z3) {
            i(view);
        }
        m9.getClass();
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        RecyclerView recyclerView = m9.f7095a;
        if (childViewHolderInt != null) {
            if (!childViewHolderInt.o() && !childViewHolderInt.t()) {
                StringBuilder sb = new StringBuilder("Called attach on a child which is not detached: ");
                sb.append(childViewHolderInt);
                throw new IllegalArgumentException(android.support.v4.media.session.a.i(recyclerView, sb));
            }
            childViewHolderInt.f7257j &= -257;
        }
        recyclerView.attachViewToParent(view, childCount, layoutParams);
    }

    public final void c(int i10) {
        s0 childViewHolderInt;
        int iF = f(i10);
        this.f7147b.f(iF);
        RecyclerView recyclerView = this.f7146a.f7095a;
        View childAt = recyclerView.getChildAt(iF);
        if (childAt != null && (childViewHolderInt = RecyclerView.getChildViewHolderInt(childAt)) != null) {
            if (childViewHolderInt.o() && !childViewHolderInt.t()) {
                StringBuilder sb = new StringBuilder("called detach on an already detached child ");
                sb.append(childViewHolderInt);
                throw new IllegalArgumentException(android.support.v4.media.session.a.i(recyclerView, sb));
            }
            childViewHolderInt.e(256);
        }
        recyclerView.detachViewFromParent(iF);
    }

    public final View d(int i10) {
        return this.f7146a.f7095a.getChildAt(f(i10));
    }

    public final int e() {
        return this.f7146a.f7095a.getChildCount() - this.f7148c.size();
    }

    public final int f(int i10) {
        if (i10 < 0) {
            return -1;
        }
        int childCount = this.f7146a.f7095a.getChildCount();
        int i11 = i10;
        while (i11 < childCount) {
            K3.O o9 = this.f7147b;
            int iB = i10 - (i11 - o9.b(i11));
            if (iB == 0) {
                while (o9.d(i11)) {
                    i11++;
                }
                return i11;
            }
            i11 += iB;
        }
        return -1;
    }

    public final View g(int i10) {
        return this.f7146a.f7095a.getChildAt(i10);
    }

    public final int h() {
        return this.f7146a.f7095a.getChildCount();
    }

    public final void i(View view) {
        this.f7148c.add(view);
        M m9 = this.f7146a;
        m9.getClass();
        s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
        if (childViewHolderInt != null) {
            int i10 = childViewHolderInt.f7264q;
            if (i10 != -1) {
                childViewHolderInt.f7263p = i10;
            } else {
                WeakHashMap weakHashMap = R.X.f3966a;
                childViewHolderInt.f7263p = R.E.c(childViewHolderInt.f7250a);
            }
            m9.f7095a.setChildImportantForAccessibilityInternal(childViewHolderInt, 4);
        }
    }

    public final int j(View view) {
        int iIndexOfChild = this.f7146a.f7095a.indexOfChild(view);
        if (iIndexOfChild == -1) {
            return -1;
        }
        K3.O o9 = this.f7147b;
        if (o9.d(iIndexOfChild)) {
            return -1;
        }
        return iIndexOfChild - o9.b(iIndexOfChild);
    }

    public final boolean k(View view) {
        return this.f7148c.contains(view);
    }

    public final void l(View view) {
        if (this.f7148c.remove(view)) {
            M m9 = this.f7146a;
            m9.getClass();
            s0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt != null) {
                m9.f7095a.setChildImportantForAccessibilityInternal(childViewHolderInt, childViewHolderInt.f7263p);
                childViewHolderInt.f7263p = 0;
            }
        }
    }

    public final String toString() {
        return this.f7147b.toString() + ", hidden list:" + this.f7148c.size();
    }
}
