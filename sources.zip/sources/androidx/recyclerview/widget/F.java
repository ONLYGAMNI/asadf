package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/* loaded from: classes.dex */
public class F extends o0 {

    /* renamed from: k, reason: collision with root package name */
    public PointF f7072k;

    /* renamed from: l, reason: collision with root package name */
    public final DisplayMetrics f7073l;

    /* renamed from: n, reason: collision with root package name */
    public float f7075n;

    /* renamed from: i, reason: collision with root package name */
    public final LinearInterpolator f7070i = new LinearInterpolator();

    /* renamed from: j, reason: collision with root package name */
    public final DecelerateInterpolator f7071j = new DecelerateInterpolator();

    /* renamed from: m, reason: collision with root package name */
    public boolean f7074m = false;

    /* renamed from: o, reason: collision with root package name */
    public int f7076o = 0;

    /* renamed from: p, reason: collision with root package name */
    public int f7077p = 0;

    public F(Context context) {
        this.f7073l = context.getResources().getDisplayMetrics();
    }

    public static int e(int i10, int i11, int i12, int i13, int i14) {
        if (i14 == -1) {
            return i12 - i10;
        }
        if (i14 != 0) {
            if (i14 == 1) {
                return i13 - i11;
            }
            throw new IllegalArgumentException("snap preference should be one of the constants defined in SmoothScroller, starting with SNAP_");
        }
        int i15 = i12 - i10;
        if (i15 > 0) {
            return i15;
        }
        int i16 = i13 - i11;
        if (i16 < 0) {
            return i16;
        }
        return 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x0013  */
    @Override // androidx.recyclerview.widget.o0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void c(android.view.View r5, androidx.recyclerview.widget.m0 r6) {
        /*
            r4 = this;
            android.graphics.PointF r0 = r4.f7072k
            r1 = 1
            if (r0 == 0) goto L13
            float r0 = r0.x
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 != 0) goto Ld
            goto L13
        Ld:
            if (r0 <= 0) goto L11
            r0 = r1
            goto L14
        L11:
            r0 = -1
            goto L14
        L13:
            r0 = 0
        L14:
            int r0 = r4.f(r5, r0)
            int r2 = r4.k()
            int r5 = r4.g(r5, r2)
            int r2 = r0 * r0
            int r3 = r5 * r5
            int r3 = r3 + r2
            double r2 = (double) r3
            double r2 = java.lang.Math.sqrt(r2)
            int r2 = (int) r2
            int r2 = r4.i(r2)
            if (r2 <= 0) goto L3f
            int r0 = -r0
            int r5 = -r5
            android.view.animation.DecelerateInterpolator r3 = r4.f7071j
            r6.f7204a = r0
            r6.f7205b = r5
            r6.f7206c = r2
            r6.f7207e = r3
            r6.f7208f = r1
        L3f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.F.c(android.view.View, androidx.recyclerview.widget.m0):void");
    }

    public int f(View view, int i10) {
        AbstractC0430a0 abstractC0430a0 = this.f7217c;
        if (abstractC0430a0 == null || !abstractC0430a0.canScrollHorizontally()) {
            return 0;
        }
        C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
        return e(abstractC0430a0.getDecoratedLeft(view) - ((ViewGroup.MarginLayoutParams) c0432b0).leftMargin, abstractC0430a0.getDecoratedRight(view) + ((ViewGroup.MarginLayoutParams) c0432b0).rightMargin, abstractC0430a0.getPaddingLeft(), abstractC0430a0.getWidth() - abstractC0430a0.getPaddingRight(), i10);
    }

    public int g(View view, int i10) {
        AbstractC0430a0 abstractC0430a0 = this.f7217c;
        if (abstractC0430a0 == null || !abstractC0430a0.canScrollVertically()) {
            return 0;
        }
        C0432b0 c0432b0 = (C0432b0) view.getLayoutParams();
        return e(abstractC0430a0.getDecoratedTop(view) - ((ViewGroup.MarginLayoutParams) c0432b0).topMargin, abstractC0430a0.getDecoratedBottom(view) + ((ViewGroup.MarginLayoutParams) c0432b0).bottomMargin, abstractC0430a0.getPaddingTop(), abstractC0430a0.getHeight() - abstractC0430a0.getPaddingBottom(), i10);
    }

    public float h(DisplayMetrics displayMetrics) {
        return 25.0f / displayMetrics.densityDpi;
    }

    public int i(int i10) {
        return (int) Math.ceil(j(i10) / 0.3356d);
    }

    public int j(int i10) {
        float fAbs = Math.abs(i10);
        if (!this.f7074m) {
            this.f7075n = h(this.f7073l);
            this.f7074m = true;
        }
        return (int) Math.ceil(fAbs * this.f7075n);
    }

    public int k() {
        PointF pointF = this.f7072k;
        if (pointF != null) {
            float f10 = pointF.y;
            if (f10 != 0.0f) {
                return f10 > 0.0f ? 1 : -1;
            }
        }
        return 0;
    }
}
