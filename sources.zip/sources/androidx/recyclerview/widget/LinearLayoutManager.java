package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

/* loaded from: classes.dex */
public class LinearLayoutManager extends AbstractC0430a0 implements n0 {
    static final boolean DEBUG = false;
    public static final int HORIZONTAL = 0;
    public static final int INVALID_OFFSET = Integer.MIN_VALUE;
    private static final float MAX_SCROLL_FACTOR = 0.33333334f;
    private static final String TAG = "LinearLayoutManager";
    public static final int VERTICAL = 1;
    final B mAnchorInfo;
    private int mInitialPrefetchItemCount;
    private boolean mLastStackFromEnd;
    private final C mLayoutChunkResult;
    private D mLayoutState;
    int mOrientation;
    I mOrientationHelper;
    E mPendingSavedState;
    int mPendingScrollPosition;
    int mPendingScrollPositionOffset;
    private boolean mRecycleChildrenOnDetach;
    private int[] mReusableIntPair;
    private boolean mReverseLayout;
    boolean mShouldReverseLayout;
    private boolean mSmoothScrollbarEnabled;
    private boolean mStackFromEnd;

    public LinearLayoutManager(int i10) {
        this.mOrientation = 1;
        this.mReverseLayout = DEBUG;
        this.mShouldReverseLayout = DEBUG;
        this.mStackFromEnd = DEBUG;
        this.mSmoothScrollbarEnabled = true;
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
        this.mPendingSavedState = null;
        this.mAnchorInfo = new B();
        this.mLayoutChunkResult = new C();
        this.mInitialPrefetchItemCount = 2;
        this.mReusableIntPair = new int[2];
        setOrientation(i10);
        setReverseLayout(DEBUG);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void assertNotInLayoutOrScroll(String str) {
        if (this.mPendingSavedState == null) {
            super.assertNotInLayoutOrScroll(str);
        }
    }

    public void calculateExtraLayoutSpace(p0 p0Var, int[] iArr) {
        int i10;
        int extraLayoutSpace = getExtraLayoutSpace(p0Var);
        if (this.mLayoutState.f7059f == -1) {
            i10 = 0;
        } else {
            i10 = extraLayoutSpace;
            extraLayoutSpace = 0;
        }
        iArr[0] = extraLayoutSpace;
        iArr[1] = i10;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public boolean canScrollHorizontally() {
        if (this.mOrientation == 0) {
            return true;
        }
        return DEBUG;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public boolean canScrollVertically() {
        if (this.mOrientation == 1) {
            return true;
        }
        return DEBUG;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void collectAdjacentPrefetchPositions(int i10, int i11, p0 p0Var, Y y9) {
        if (this.mOrientation != 0) {
            i10 = i11;
        }
        if (getChildCount() == 0 || i10 == 0) {
            return;
        }
        ensureLayoutState();
        o(i10 > 0 ? 1 : -1, Math.abs(i10), true, p0Var);
        collectPrefetchPositionsForLayoutState(p0Var, this.mLayoutState, y9);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void collectInitialPrefetchPositions(int i10, Y y9) {
        boolean z3;
        int i11;
        E e4 = this.mPendingSavedState;
        if (e4 == null || (i11 = e4.f7065a) < 0) {
            n();
            z3 = this.mShouldReverseLayout;
            i11 = this.mPendingScrollPosition;
            if (i11 == -1) {
                i11 = z3 ? i10 - 1 : 0;
            }
        } else {
            z3 = e4.f7067c;
        }
        int i12 = z3 ? -1 : 1;
        for (int i13 = 0; i13 < this.mInitialPrefetchItemCount && i11 >= 0 && i11 < i10; i13++) {
            ((C0457v) y9).a(i11, 0);
            i11 += i12;
        }
    }

    public void collectPrefetchPositionsForLayoutState(p0 p0Var, D d, Y y9) {
        int i10 = d.d;
        if (i10 < 0 || i10 >= p0Var.b()) {
            return;
        }
        ((C0457v) y9).a(i10, Math.max(0, d.g));
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int computeHorizontalScrollExtent(p0 p0Var) {
        return d(p0Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int computeHorizontalScrollOffset(p0 p0Var) {
        return e(p0Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int computeHorizontalScrollRange(p0 p0Var) {
        return f(p0Var);
    }

    @Override // androidx.recyclerview.widget.n0
    public PointF computeScrollVectorForPosition(int i10) {
        if (getChildCount() == 0) {
            return null;
        }
        boolean z3 = DEBUG;
        if (i10 < getPosition(getChildAt(0))) {
            z3 = true;
        }
        int i11 = z3 != this.mShouldReverseLayout ? -1 : 1;
        return this.mOrientation == 0 ? new PointF(i11, 0.0f) : new PointF(0.0f, i11);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int computeVerticalScrollExtent(p0 p0Var) {
        return d(p0Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int computeVerticalScrollOffset(p0 p0Var) {
        return e(p0Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int computeVerticalScrollRange(p0 p0Var) {
        return f(p0Var);
    }

    public int convertFocusDirectionToLayoutDirection(int i10) {
        return i10 != 1 ? i10 != 2 ? i10 != 17 ? i10 != 33 ? i10 != 66 ? (i10 == 130 && this.mOrientation == 1) ? 1 : Integer.MIN_VALUE : this.mOrientation == 0 ? 1 : Integer.MIN_VALUE : this.mOrientation == 1 ? -1 : Integer.MIN_VALUE : this.mOrientation == 0 ? -1 : Integer.MIN_VALUE : (this.mOrientation != 1 && isLayoutRTL()) ? -1 : 1 : (this.mOrientation != 1 && isLayoutRTL()) ? 1 : -1;
    }

    public D createLayoutState() {
        D d = new D();
        d.f7055a = true;
        d.f7060h = 0;
        d.f7061i = 0;
        d.f7063k = null;
        return d;
    }

    public final int d(p0 p0Var) {
        if (getChildCount() == 0) {
            return 0;
        }
        ensureLayoutState();
        return AbstractC0453q.d(p0Var, this.mOrientationHelper, findFirstVisibleChildClosestToStart(!this.mSmoothScrollbarEnabled, true), findFirstVisibleChildClosestToEnd(!this.mSmoothScrollbarEnabled, true), this, this.mSmoothScrollbarEnabled);
    }

    public final int e(p0 p0Var) {
        if (getChildCount() == 0) {
            return 0;
        }
        ensureLayoutState();
        return AbstractC0453q.e(p0Var, this.mOrientationHelper, findFirstVisibleChildClosestToStart(!this.mSmoothScrollbarEnabled, true), findFirstVisibleChildClosestToEnd(!this.mSmoothScrollbarEnabled, true), this, this.mSmoothScrollbarEnabled, this.mShouldReverseLayout);
    }

    public void ensureLayoutState() {
        if (this.mLayoutState == null) {
            this.mLayoutState = createLayoutState();
        }
    }

    public final int f(p0 p0Var) {
        if (getChildCount() == 0) {
            return 0;
        }
        ensureLayoutState();
        return AbstractC0453q.f(p0Var, this.mOrientationHelper, findFirstVisibleChildClosestToStart(!this.mSmoothScrollbarEnabled, true), findFirstVisibleChildClosestToEnd(!this.mSmoothScrollbarEnabled, true), this, this.mSmoothScrollbarEnabled);
    }

    public int fill(i0 i0Var, D d, p0 p0Var, boolean z3) {
        int i10;
        int i11 = d.f7057c;
        int i12 = d.g;
        if (i12 != Integer.MIN_VALUE) {
            if (i11 < 0) {
                d.g = i12 + i11;
            }
            l(i0Var, d);
        }
        int i13 = d.f7057c + d.f7060h;
        C c4 = this.mLayoutChunkResult;
        while (true) {
            if ((!d.f7064l && i13 <= 0) || (i10 = d.d) < 0 || i10 >= p0Var.b()) {
                break;
            }
            c4.f7048a = 0;
            c4.f7049b = DEBUG;
            c4.f7050c = DEBUG;
            c4.d = DEBUG;
            layoutChunk(i0Var, p0Var, d, c4);
            if (!c4.f7049b) {
                int i14 = d.f7056b;
                int i15 = c4.f7048a;
                d.f7056b = (d.f7059f * i15) + i14;
                if (!c4.f7050c || d.f7063k != null || !p0Var.g) {
                    d.f7057c -= i15;
                    i13 -= i15;
                }
                int i16 = d.g;
                if (i16 != Integer.MIN_VALUE) {
                    int i17 = i16 + i15;
                    d.g = i17;
                    int i18 = d.f7057c;
                    if (i18 < 0) {
                        d.g = i17 + i18;
                    }
                    l(i0Var, d);
                }
                if (z3 && c4.d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i11 - d.f7057c;
    }

    public int findFirstCompletelyVisibleItemPosition() {
        View viewFindOneVisibleChild = findOneVisibleChild(0, getChildCount(), true, DEBUG);
        if (viewFindOneVisibleChild == null) {
            return -1;
        }
        return getPosition(viewFindOneVisibleChild);
    }

    public View findFirstVisibleChildClosestToEnd(boolean z3, boolean z9) {
        return this.mShouldReverseLayout ? findOneVisibleChild(0, getChildCount(), z3, z9) : findOneVisibleChild(getChildCount() - 1, -1, z3, z9);
    }

    public View findFirstVisibleChildClosestToStart(boolean z3, boolean z9) {
        return this.mShouldReverseLayout ? findOneVisibleChild(getChildCount() - 1, -1, z3, z9) : findOneVisibleChild(0, getChildCount(), z3, z9);
    }

    public int findFirstVisibleItemPosition() {
        View viewFindOneVisibleChild = findOneVisibleChild(0, getChildCount(), DEBUG, true);
        if (viewFindOneVisibleChild == null) {
            return -1;
        }
        return getPosition(viewFindOneVisibleChild);
    }

    public int findLastCompletelyVisibleItemPosition() {
        View viewFindOneVisibleChild = findOneVisibleChild(getChildCount() - 1, -1, true, DEBUG);
        if (viewFindOneVisibleChild == null) {
            return -1;
        }
        return getPosition(viewFindOneVisibleChild);
    }

    public int findLastVisibleItemPosition() {
        View viewFindOneVisibleChild = findOneVisibleChild(getChildCount() - 1, -1, DEBUG, true);
        if (viewFindOneVisibleChild == null) {
            return -1;
        }
        return getPosition(viewFindOneVisibleChild);
    }

    public View findOnePartiallyOrCompletelyInvisibleChild(int i10, int i11) {
        int i12;
        int i13;
        ensureLayoutState();
        if (i11 <= i10 && i11 >= i10) {
            return getChildAt(i10);
        }
        if (this.mOrientationHelper.e(getChildAt(i10)) < this.mOrientationHelper.k()) {
            i12 = 16644;
            i13 = 16388;
        } else {
            i12 = 4161;
            i13 = 4097;
        }
        return this.mOrientation == 0 ? this.mHorizontalBoundCheck.a(i10, i11, i12, i13) : this.mVerticalBoundCheck.a(i10, i11, i12, i13);
    }

    public View findOneVisibleChild(int i10, int i11, boolean z3, boolean z9) {
        ensureLayoutState();
        int i12 = z3 ? 24579 : 320;
        int i13 = z9 ? 320 : 0;
        return this.mOrientation == 0 ? this.mHorizontalBoundCheck.a(i10, i11, i12, i13) : this.mVerticalBoundCheck.a(i10, i11, i12, i13);
    }

    public View findReferenceChild(i0 i0Var, p0 p0Var, int i10, int i11, int i12) {
        ensureLayoutState();
        int iK = this.mOrientationHelper.k();
        int iG = this.mOrientationHelper.g();
        int i13 = i11 > i10 ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i10 != i11) {
            View childAt = getChildAt(i10);
            int position = getPosition(childAt);
            if (position >= 0 && position < i12) {
                if (((C0432b0) childAt.getLayoutParams()).f7138a.m()) {
                    if (view2 == null) {
                        view2 = childAt;
                    }
                } else {
                    if (this.mOrientationHelper.e(childAt) < iG && this.mOrientationHelper.b(childAt) >= iK) {
                        return childAt;
                    }
                    if (view == null) {
                        view = childAt;
                    }
                }
            }
            i10 += i13;
        }
        return view != null ? view : view2;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public View findViewByPosition(int i10) {
        int childCount = getChildCount();
        if (childCount == 0) {
            return null;
        }
        int position = i10 - getPosition(getChildAt(0));
        if (position >= 0 && position < childCount) {
            View childAt = getChildAt(position);
            if (getPosition(childAt) == i10) {
                return childAt;
            }
        }
        return super.findViewByPosition(i10);
    }

    public final int g(int i10, i0 i0Var, p0 p0Var, boolean z3) {
        int iG;
        int iG2 = this.mOrientationHelper.g() - i10;
        if (iG2 <= 0) {
            return 0;
        }
        int i11 = -scrollBy(-iG2, i0Var, p0Var);
        int i12 = i10 + i11;
        if (!z3 || (iG = this.mOrientationHelper.g() - i12) <= 0) {
            return i11;
        }
        this.mOrientationHelper.p(iG);
        return iG + i11;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public C0432b0 generateDefaultLayoutParams() {
        return new C0432b0(-2, -2);
    }

    @Deprecated
    public int getExtraLayoutSpace(p0 p0Var) {
        if (p0Var.f7225a != -1) {
            return this.mOrientationHelper.l();
        }
        return 0;
    }

    public int getInitialPrefetchItemCount() {
        return this.mInitialPrefetchItemCount;
    }

    public int getOrientation() {
        return this.mOrientation;
    }

    public boolean getRecycleChildrenOnDetach() {
        return this.mRecycleChildrenOnDetach;
    }

    public boolean getReverseLayout() {
        return this.mReverseLayout;
    }

    public boolean getStackFromEnd() {
        return this.mStackFromEnd;
    }

    public final int h(int i10, i0 i0Var, p0 p0Var, boolean z3) {
        int iK;
        int iK2 = i10 - this.mOrientationHelper.k();
        if (iK2 <= 0) {
            return 0;
        }
        int i11 = -scrollBy(iK2, i0Var, p0Var);
        int i12 = i10 + i11;
        if (!z3 || (iK = i12 - this.mOrientationHelper.k()) <= 0) {
            return i11;
        }
        this.mOrientationHelper.p(-iK);
        return i11 - iK;
    }

    public final View i() {
        return getChildAt(this.mShouldReverseLayout ? 0 : getChildCount() - 1);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public boolean isAutoMeasureEnabled() {
        return true;
    }

    public boolean isLayoutRTL() {
        if (getLayoutDirection() == 1) {
            return true;
        }
        return DEBUG;
    }

    public boolean isSmoothScrollbarEnabled() {
        return this.mSmoothScrollbarEnabled;
    }

    public final View j() {
        return getChildAt(this.mShouldReverseLayout ? getChildCount() - 1 : 0);
    }

    public final void k() {
        Log.d(TAG, "internal representation of views on the screen");
        for (int i10 = 0; i10 < getChildCount(); i10++) {
            View childAt = getChildAt(i10);
            Log.d(TAG, "item " + getPosition(childAt) + ", coord:" + this.mOrientationHelper.e(childAt));
        }
        Log.d(TAG, "==============");
    }

    public final void l(i0 i0Var, D d) {
        if (!d.f7055a || d.f7064l) {
            return;
        }
        int i10 = d.g;
        int i11 = d.f7061i;
        if (d.f7059f == -1) {
            int childCount = getChildCount();
            if (i10 < 0) {
                return;
            }
            int iF = (this.mOrientationHelper.f() - i10) + i11;
            if (this.mShouldReverseLayout) {
                for (int i12 = 0; i12 < childCount; i12++) {
                    View childAt = getChildAt(i12);
                    if (this.mOrientationHelper.e(childAt) < iF || this.mOrientationHelper.o(childAt) < iF) {
                        m(i0Var, 0, i12);
                        return;
                    }
                }
                return;
            }
            int i13 = childCount - 1;
            for (int i14 = i13; i14 >= 0; i14--) {
                View childAt2 = getChildAt(i14);
                if (this.mOrientationHelper.e(childAt2) < iF || this.mOrientationHelper.o(childAt2) < iF) {
                    m(i0Var, i13, i14);
                    return;
                }
            }
            return;
        }
        if (i10 < 0) {
            return;
        }
        int i15 = i10 - i11;
        int childCount2 = getChildCount();
        if (!this.mShouldReverseLayout) {
            for (int i16 = 0; i16 < childCount2; i16++) {
                View childAt3 = getChildAt(i16);
                if (this.mOrientationHelper.b(childAt3) > i15 || this.mOrientationHelper.n(childAt3) > i15) {
                    m(i0Var, 0, i16);
                    return;
                }
            }
            return;
        }
        int i17 = childCount2 - 1;
        for (int i18 = i17; i18 >= 0; i18--) {
            View childAt4 = getChildAt(i18);
            if (this.mOrientationHelper.b(childAt4) > i15 || this.mOrientationHelper.n(childAt4) > i15) {
                m(i0Var, i17, i18);
                return;
            }
        }
    }

    public void layoutChunk(i0 i0Var, p0 p0Var, D d, C c4) {
        int i10;
        int i11;
        int i12;
        int paddingLeft;
        int iD;
        View viewB = d.b(i0Var);
        if (viewB == null) {
            c4.f7049b = true;
            return;
        }
        C0432b0 c0432b0 = (C0432b0) viewB.getLayoutParams();
        if (d.f7063k == null) {
            if (this.mShouldReverseLayout == (d.f7059f == -1)) {
                addView(viewB);
            } else {
                addView(viewB, 0);
            }
        } else {
            if (this.mShouldReverseLayout == (d.f7059f == -1)) {
                addDisappearingView(viewB);
            } else {
                addDisappearingView(viewB, 0);
            }
        }
        measureChildWithMargins(viewB, 0, 0);
        c4.f7048a = this.mOrientationHelper.c(viewB);
        if (this.mOrientation == 1) {
            if (isLayoutRTL()) {
                iD = getWidth() - getPaddingRight();
                paddingLeft = iD - this.mOrientationHelper.d(viewB);
            } else {
                paddingLeft = getPaddingLeft();
                iD = this.mOrientationHelper.d(viewB) + paddingLeft;
            }
            if (d.f7059f == -1) {
                int i13 = d.f7056b;
                i12 = i13;
                i11 = iD;
                i10 = i13 - c4.f7048a;
            } else {
                int i14 = d.f7056b;
                i10 = i14;
                i11 = iD;
                i12 = c4.f7048a + i14;
            }
        } else {
            int paddingTop = getPaddingTop();
            int iD2 = this.mOrientationHelper.d(viewB) + paddingTop;
            if (d.f7059f == -1) {
                int i15 = d.f7056b;
                i11 = i15;
                i10 = paddingTop;
                i12 = iD2;
                paddingLeft = i15 - c4.f7048a;
            } else {
                int i16 = d.f7056b;
                i10 = paddingTop;
                i11 = c4.f7048a + i16;
                i12 = iD2;
                paddingLeft = i16;
            }
        }
        layoutDecoratedWithMargins(viewB, paddingLeft, i10, i11, i12);
        if (c0432b0.f7138a.m() || c0432b0.f7138a.p()) {
            c4.f7050c = true;
        }
        c4.d = viewB.hasFocusable();
    }

    public final void m(i0 i0Var, int i10, int i11) {
        if (i10 == i11) {
            return;
        }
        if (i11 <= i10) {
            while (i10 > i11) {
                removeAndRecycleViewAt(i10, i0Var);
                i10--;
            }
        } else {
            for (int i12 = i11 - 1; i12 >= i10; i12--) {
                removeAndRecycleViewAt(i12, i0Var);
            }
        }
    }

    public final void n() {
        if (this.mOrientation == 1 || !isLayoutRTL()) {
            this.mShouldReverseLayout = this.mReverseLayout;
        } else {
            this.mShouldReverseLayout = !this.mReverseLayout;
        }
    }

    public final void o(int i10, int i11, boolean z3, p0 p0Var) {
        int iK;
        this.mLayoutState.f7064l = resolveIsInfinite();
        this.mLayoutState.f7059f = i10;
        int[] iArr = this.mReusableIntPair;
        boolean z9 = DEBUG;
        iArr[0] = 0;
        iArr[1] = 0;
        calculateExtraLayoutSpace(p0Var, iArr);
        int iMax = Math.max(0, this.mReusableIntPair[0]);
        int iMax2 = Math.max(0, this.mReusableIntPair[1]);
        if (i10 == 1) {
            z9 = true;
        }
        D d = this.mLayoutState;
        int i12 = z9 ? iMax2 : iMax;
        d.f7060h = i12;
        if (!z9) {
            iMax = iMax2;
        }
        d.f7061i = iMax;
        if (z9) {
            d.f7060h = this.mOrientationHelper.h() + i12;
            View viewI = i();
            D d10 = this.mLayoutState;
            d10.f7058e = this.mShouldReverseLayout ? -1 : 1;
            int position = getPosition(viewI);
            D d11 = this.mLayoutState;
            d10.d = position + d11.f7058e;
            d11.f7056b = this.mOrientationHelper.b(viewI);
            iK = this.mOrientationHelper.b(viewI) - this.mOrientationHelper.g();
        } else {
            View viewJ = j();
            D d12 = this.mLayoutState;
            d12.f7060h = this.mOrientationHelper.k() + d12.f7060h;
            D d13 = this.mLayoutState;
            d13.f7058e = this.mShouldReverseLayout ? 1 : -1;
            int position2 = getPosition(viewJ);
            D d14 = this.mLayoutState;
            d13.d = position2 + d14.f7058e;
            d14.f7056b = this.mOrientationHelper.e(viewJ);
            iK = (-this.mOrientationHelper.e(viewJ)) + this.mOrientationHelper.k();
        }
        D d15 = this.mLayoutState;
        d15.f7057c = i11;
        if (z3) {
            d15.f7057c = i11 - iK;
        }
        d15.g = iK;
    }

    public void onAnchorReady(i0 i0Var, p0 p0Var, B b7, int i10) {
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void onDetachedFromWindow(RecyclerView recyclerView, i0 i0Var) {
        onDetachedFromWindow(recyclerView);
        if (this.mRecycleChildrenOnDetach) {
            removeAndRecycleAllViews(i0Var);
            i0Var.f7170a.clear();
            i0Var.e();
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public View onFocusSearchFailed(View view, int i10, i0 i0Var, p0 p0Var) {
        int iConvertFocusDirectionToLayoutDirection;
        n();
        if (getChildCount() == 0 || (iConvertFocusDirectionToLayoutDirection = convertFocusDirectionToLayoutDirection(i10)) == Integer.MIN_VALUE) {
            return null;
        }
        ensureLayoutState();
        o(iConvertFocusDirectionToLayoutDirection, (int) (this.mOrientationHelper.l() * MAX_SCROLL_FACTOR), DEBUG, p0Var);
        D d = this.mLayoutState;
        d.g = Integer.MIN_VALUE;
        d.f7055a = DEBUG;
        fill(i0Var, d, p0Var, true);
        View viewFindOnePartiallyOrCompletelyInvisibleChild = iConvertFocusDirectionToLayoutDirection == -1 ? this.mShouldReverseLayout ? findOnePartiallyOrCompletelyInvisibleChild(getChildCount() - 1, -1) : findOnePartiallyOrCompletelyInvisibleChild(0, getChildCount()) : this.mShouldReverseLayout ? findOnePartiallyOrCompletelyInvisibleChild(0, getChildCount()) : findOnePartiallyOrCompletelyInvisibleChild(getChildCount() - 1, -1);
        View viewJ = iConvertFocusDirectionToLayoutDirection == -1 ? j() : i();
        if (!viewJ.hasFocusable()) {
            return viewFindOnePartiallyOrCompletelyInvisibleChild;
        }
        if (viewFindOnePartiallyOrCompletelyInvisibleChild == null) {
            return null;
        }
        return viewJ;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        if (getChildCount() > 0) {
            accessibilityEvent.setFromIndex(findFirstVisibleItemPosition());
            accessibilityEvent.setToIndex(findLastVisibleItemPosition());
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:296:0x0175  */
    /* JADX WARN: Removed duplicated region for block: B:305:0x01a6  */
    /* JADX WARN: Removed duplicated region for block: B:332:0x0244  */
    @Override // androidx.recyclerview.widget.AbstractC0430a0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onLayoutChildren(androidx.recyclerview.widget.i0 r14, androidx.recyclerview.widget.p0 r15) {
        /*
            Method dump skipped, instructions count: 1107
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.LinearLayoutManager.onLayoutChildren(androidx.recyclerview.widget.i0, androidx.recyclerview.widget.p0):void");
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void onLayoutCompleted(p0 p0Var) {
        this.mPendingSavedState = null;
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
        this.mAnchorInfo.d();
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof E) {
            this.mPendingSavedState = (E) parcelable;
            requestLayout();
        }
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public Parcelable onSaveInstanceState() {
        E e4 = this.mPendingSavedState;
        if (e4 != null) {
            E e5 = new E();
            e5.f7065a = e4.f7065a;
            e5.f7066b = e4.f7066b;
            e5.f7067c = e4.f7067c;
            return e5;
        }
        E e10 = new E();
        if (getChildCount() > 0) {
            ensureLayoutState();
            boolean z3 = this.mLastStackFromEnd ^ this.mShouldReverseLayout;
            e10.f7067c = z3;
            if (z3) {
                View viewI = i();
                e10.f7066b = this.mOrientationHelper.g() - this.mOrientationHelper.b(viewI);
                e10.f7065a = getPosition(viewI);
            } else {
                View viewJ = j();
                e10.f7065a = getPosition(viewJ);
                e10.f7066b = this.mOrientationHelper.e(viewJ) - this.mOrientationHelper.k();
            }
        } else {
            e10.f7065a = -1;
        }
        return e10;
    }

    public final void p(int i10, int i11) {
        this.mLayoutState.f7057c = this.mOrientationHelper.g() - i11;
        D d = this.mLayoutState;
        d.f7058e = this.mShouldReverseLayout ? -1 : 1;
        d.d = i10;
        d.f7059f = 1;
        d.f7056b = i11;
        d.g = Integer.MIN_VALUE;
    }

    public void prepareForDrop(View view, View view2, int i10, int i11) {
        assertNotInLayoutOrScroll("Cannot drop a view during a scroll or layout calculation");
        ensureLayoutState();
        n();
        int position = getPosition(view);
        int position2 = getPosition(view2);
        char c4 = position < position2 ? (char) 1 : (char) 65535;
        if (this.mShouldReverseLayout) {
            if (c4 == 1) {
                scrollToPositionWithOffset(position2, this.mOrientationHelper.g() - (this.mOrientationHelper.c(view) + this.mOrientationHelper.e(view2)));
                return;
            } else {
                scrollToPositionWithOffset(position2, this.mOrientationHelper.g() - this.mOrientationHelper.b(view2));
                return;
            }
        }
        if (c4 == 65535) {
            scrollToPositionWithOffset(position2, this.mOrientationHelper.e(view2));
        } else {
            scrollToPositionWithOffset(position2, this.mOrientationHelper.b(view2) - this.mOrientationHelper.c(view));
        }
    }

    public final void q(int i10, int i11) {
        this.mLayoutState.f7057c = i11 - this.mOrientationHelper.k();
        D d = this.mLayoutState;
        d.d = i10;
        d.f7058e = this.mShouldReverseLayout ? 1 : -1;
        d.f7059f = -1;
        d.f7056b = i11;
        d.g = Integer.MIN_VALUE;
    }

    public boolean resolveIsInfinite() {
        if (this.mOrientationHelper.i() == 0 && this.mOrientationHelper.f() == 0) {
            return true;
        }
        return DEBUG;
    }

    public int scrollBy(int i10, i0 i0Var, p0 p0Var) {
        if (getChildCount() == 0 || i10 == 0) {
            return 0;
        }
        ensureLayoutState();
        this.mLayoutState.f7055a = true;
        int i11 = i10 > 0 ? 1 : -1;
        int iAbs = Math.abs(i10);
        o(i11, iAbs, true, p0Var);
        D d = this.mLayoutState;
        int iFill = fill(i0Var, d, p0Var, DEBUG) + d.g;
        if (iFill < 0) {
            return 0;
        }
        if (iAbs > iFill) {
            i10 = i11 * iFill;
        }
        this.mOrientationHelper.p(-i10);
        this.mLayoutState.f7062j = i10;
        return i10;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int scrollHorizontallyBy(int i10, i0 i0Var, p0 p0Var) {
        if (this.mOrientation == 1) {
            return 0;
        }
        return scrollBy(i10, i0Var, p0Var);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void scrollToPosition(int i10) {
        this.mPendingScrollPosition = i10;
        this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
        E e4 = this.mPendingSavedState;
        if (e4 != null) {
            e4.f7065a = -1;
        }
        requestLayout();
    }

    public void scrollToPositionWithOffset(int i10, int i11) {
        this.mPendingScrollPosition = i10;
        this.mPendingScrollPositionOffset = i11;
        E e4 = this.mPendingSavedState;
        if (e4 != null) {
            e4.f7065a = -1;
        }
        requestLayout();
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public int scrollVerticallyBy(int i10, i0 i0Var, p0 p0Var) {
        if (this.mOrientation == 0) {
            return 0;
        }
        return scrollBy(i10, i0Var, p0Var);
    }

    public void setInitialPrefetchItemCount(int i10) {
        this.mInitialPrefetchItemCount = i10;
    }

    public void setOrientation(int i10) {
        if (i10 != 0 && i10 != 1) {
            throw new IllegalArgumentException(android.support.v4.media.session.a.h(i10, "invalid orientation:"));
        }
        assertNotInLayoutOrScroll(null);
        if (i10 != this.mOrientation || this.mOrientationHelper == null) {
            I iA = I.a(this, i10);
            this.mOrientationHelper = iA;
            this.mAnchorInfo.f7039a = iA;
            this.mOrientation = i10;
            requestLayout();
        }
    }

    public void setRecycleChildrenOnDetach(boolean z3) {
        this.mRecycleChildrenOnDetach = z3;
    }

    public void setReverseLayout(boolean z3) {
        assertNotInLayoutOrScroll(null);
        if (z3 == this.mReverseLayout) {
            return;
        }
        this.mReverseLayout = z3;
        requestLayout();
    }

    public void setSmoothScrollbarEnabled(boolean z3) {
        this.mSmoothScrollbarEnabled = z3;
    }

    public void setStackFromEnd(boolean z3) {
        assertNotInLayoutOrScroll(null);
        if (this.mStackFromEnd == z3) {
            return;
        }
        this.mStackFromEnd = z3;
        requestLayout();
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public boolean shouldMeasureTwice() {
        if (getHeightMode() == 1073741824 || getWidthMode() == 1073741824 || !hasFlexibleChildInBothOrientations()) {
            return DEBUG;
        }
        return true;
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public void smoothScrollToPosition(RecyclerView recyclerView, p0 p0Var, int i10) {
        F f10 = new F(recyclerView.getContext());
        f10.f7215a = i10;
        startSmoothScroll(f10);
    }

    @Override // androidx.recyclerview.widget.AbstractC0430a0
    public boolean supportsPredictiveItemAnimations() {
        if (this.mPendingSavedState == null && this.mLastStackFromEnd == this.mStackFromEnd) {
            return true;
        }
        return DEBUG;
    }

    public void validateChildOrder() {
        Log.d(TAG, "validating child count " + getChildCount());
        if (getChildCount() < 1) {
            return;
        }
        int position = getPosition(getChildAt(0));
        int iE = this.mOrientationHelper.e(getChildAt(0));
        if (this.mShouldReverseLayout) {
            for (int i10 = 1; i10 < getChildCount(); i10++) {
                View childAt = getChildAt(i10);
                int position2 = getPosition(childAt);
                int iE2 = this.mOrientationHelper.e(childAt);
                if (position2 < position) {
                    k();
                    StringBuilder sb = new StringBuilder("detected invalid position. loc invalid? ");
                    sb.append(iE2 < iE);
                    throw new RuntimeException(sb.toString());
                }
                if (iE2 > iE) {
                    k();
                    throw new RuntimeException("detected invalid location");
                }
            }
            return;
        }
        for (int i11 = 1; i11 < getChildCount(); i11++) {
            View childAt2 = getChildAt(i11);
            int position3 = getPosition(childAt2);
            int iE3 = this.mOrientationHelper.e(childAt2);
            if (position3 < position) {
                k();
                StringBuilder sb2 = new StringBuilder("detected invalid position. loc invalid? ");
                sb2.append(iE3 < iE);
                throw new RuntimeException(sb2.toString());
            }
            if (iE3 < iE) {
                k();
                throw new RuntimeException("detected invalid location");
            }
        }
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i10, int i11) {
        this.mOrientation = 1;
        this.mReverseLayout = DEBUG;
        this.mShouldReverseLayout = DEBUG;
        this.mStackFromEnd = DEBUG;
        this.mSmoothScrollbarEnabled = true;
        this.mPendingScrollPosition = -1;
        this.mPendingScrollPositionOffset = Integer.MIN_VALUE;
        this.mPendingSavedState = null;
        this.mAnchorInfo = new B();
        this.mLayoutChunkResult = new C();
        this.mInitialPrefetchItemCount = 2;
        this.mReusableIntPair = new int[2];
        Z properties = AbstractC0430a0.getProperties(context, attributeSet, i10, i11);
        setOrientation(properties.f7127a);
        setReverseLayout(properties.f7129c);
        setStackFromEnd(properties.d);
    }
}
