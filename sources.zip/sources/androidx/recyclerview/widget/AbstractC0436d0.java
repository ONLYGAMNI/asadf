package androidx.recyclerview.widget;

/* renamed from: androidx.recyclerview.widget.d0, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0436d0 {
    public abstract boolean onFling(int i10, int i11);
}
