package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class C0 {

    /* renamed from: a, reason: collision with root package name */
    public int f7051a;

    /* renamed from: b, reason: collision with root package name */
    public int f7052b;

    /* renamed from: c, reason: collision with root package name */
    public int f7053c;
    public int d;

    /* renamed from: e, reason: collision with root package name */
    public int f7054e;

    public final boolean a() {
        int i10 = this.f7051a;
        int i11 = 2;
        if ((i10 & 7) != 0) {
            int i12 = this.d;
            int i13 = this.f7052b;
            if (((i12 > i13 ? 1 : i12 == i13 ? 2 : 4) & i10) == 0) {
                return false;
            }
        }
        if ((i10 & 112) != 0) {
            int i14 = this.d;
            int i15 = this.f7053c;
            if ((((i14 > i15 ? 1 : i14 == i15 ? 2 : 4) << 4) & i10) == 0) {
                return false;
            }
        }
        if ((i10 & 1792) != 0) {
            int i16 = this.f7054e;
            int i17 = this.f7052b;
            if ((((i16 > i17 ? 1 : i16 == i17 ? 2 : 4) << 8) & i10) == 0) {
                return false;
            }
        }
        if ((i10 & 28672) != 0) {
            int i18 = this.f7054e;
            int i19 = this.f7053c;
            if (i18 > i19) {
                i11 = 1;
            } else if (i18 != i19) {
                i11 = 4;
            }
            if ((i10 & (i11 << 12)) == 0) {
                return false;
            }
        }
        return true;
    }
}
