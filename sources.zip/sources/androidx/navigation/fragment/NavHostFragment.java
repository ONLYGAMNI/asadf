package androidx.navigation.fragment;

import A3.a;
import E0.g;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.C0381a;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.r;
import com.bumptech.glide.d;
import com.tajir.tajir.R;
import e8.C0799k;
import q0.F;
import q0.U;
import s0.l;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public class NavHostFragment extends r {

    /* renamed from: d0, reason: collision with root package name */
    public final C0799k f7019d0 = d.u(new g(this, 15));

    /* renamed from: e0, reason: collision with root package name */
    public View f7020e0;

    /* renamed from: f0, reason: collision with root package name */
    public int f7021f0;

    /* renamed from: g0, reason: collision with root package name */
    public boolean f7022g0;

    @Override // androidx.fragment.app.r
    public final void D(Context context) {
        AbstractC1420h.f(context, "context");
        super.D(context);
        if (this.f7022g0) {
            C0381a c0381a = new C0381a(q());
            c0381a.i(this);
            c0381a.e(false);
        }
    }

    @Override // androidx.fragment.app.r
    public final void E(Bundle bundle) {
        c0();
        if (bundle != null && bundle.getBoolean("android-support-nav:fragment:defaultHost", false)) {
            this.f7022g0 = true;
            C0381a c0381a = new C0381a(q());
            c0381a.i(this);
            c0381a.e(false);
        }
        super.E(bundle);
    }

    @Override // androidx.fragment.app.r
    public final View F(LayoutInflater layoutInflater, ViewGroup viewGroup) {
        AbstractC1420h.f(layoutInflater, "inflater");
        Context context = layoutInflater.getContext();
        AbstractC1420h.e(context, "inflater.context");
        FragmentContainerView fragmentContainerView = new FragmentContainerView(context);
        int i10 = this.f6806D;
        if (i10 == 0 || i10 == -1) {
            i10 = R.id.nav_host_fragment_container;
        }
        fragmentContainerView.setId(i10);
        return fragmentContainerView;
    }

    @Override // androidx.fragment.app.r
    public final void H() {
        this.K = true;
        View view = this.f7020e0;
        if (view != null && a.j(view) == c0()) {
            view.setTag(R.id.nav_controller_view_tag, null);
        }
        this.f7020e0 = null;
    }

    @Override // androidx.fragment.app.r
    public final void K(Context context, AttributeSet attributeSet, Bundle bundle) {
        AbstractC1420h.f(context, "context");
        AbstractC1420h.f(attributeSet, "attrs");
        super.K(context, attributeSet, bundle);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, U.f14421b);
        AbstractC1420h.e(typedArrayObtainStyledAttributes, "context.obtainStyledAttr…yleable.NavHost\n        )");
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0);
        if (resourceId != 0) {
            this.f7021f0 = resourceId;
        }
        typedArrayObtainStyledAttributes.recycle();
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, l.f14903c);
        AbstractC1420h.e(typedArrayObtainStyledAttributes2, "context.obtainStyledAttr…tyleable.NavHostFragment)");
        if (typedArrayObtainStyledAttributes2.getBoolean(0, false)) {
            this.f7022g0 = true;
        }
        typedArrayObtainStyledAttributes2.recycle();
    }

    @Override // androidx.fragment.app.r
    public final void O(Bundle bundle) {
        if (this.f7022g0) {
            bundle.putBoolean("android-support-nav:fragment:defaultHost", true);
        }
    }

    @Override // androidx.fragment.app.r
    public final void R(View view) {
        AbstractC1420h.f(view, "view");
        if (!(view instanceof ViewGroup)) {
            throw new IllegalStateException(("created host view " + view + " is not a ViewGroup").toString());
        }
        view.setTag(R.id.nav_controller_view_tag, c0());
        if (view.getParent() != null) {
            Object parent = view.getParent();
            AbstractC1420h.d(parent, "null cannot be cast to non-null type android.view.View");
            View view2 = (View) parent;
            this.f7020e0 = view2;
            if (view2.getId() == this.f6806D) {
                View view3 = this.f7020e0;
                AbstractC1420h.c(view3);
                view3.setTag(R.id.nav_controller_view_tag, c0());
            }
        }
    }

    public final F c0() {
        return (F) this.f7019d0.getValue();
    }
}
