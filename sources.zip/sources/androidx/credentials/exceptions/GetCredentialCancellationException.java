package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class GetCredentialCancellationException extends GetCredentialException {
    public GetCredentialCancellationException() {
        super("android.credentials.GetCredentialException.TYPE_USER_CANCELED", null);
    }
}
