package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class GetCredentialProviderConfigurationException extends GetCredentialException {
    public GetCredentialProviderConfigurationException() {
        super("androidx.credentials.TYPE_GET_CREDENTIAL_PROVIDER_CONFIGURATION_EXCEPTION", null);
    }
}
