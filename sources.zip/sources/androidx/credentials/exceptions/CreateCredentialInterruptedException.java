package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class CreateCredentialInterruptedException extends CreateCredentialException {
    public CreateCredentialInterruptedException() {
        super("android.credentials.CreateCredentialException.TYPE_INTERRUPTED", null);
    }
}
