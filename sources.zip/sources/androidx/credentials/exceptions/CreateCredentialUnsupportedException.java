package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class CreateCredentialUnsupportedException extends CreateCredentialException {
    public CreateCredentialUnsupportedException() {
        super("androidx.credentials.TYPE_CREATE_CREDENTIAL_UNSUPPORTED_EXCEPTION", null);
    }
}
