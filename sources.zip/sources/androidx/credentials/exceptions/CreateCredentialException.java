package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public abstract class CreateCredentialException extends Exception {
    public CreateCredentialException(String str, CharSequence charSequence) {
        super(charSequence != null ? charSequence.toString() : null);
    }
}
