package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public abstract class GetCredentialException extends Exception {
    public GetCredentialException(String str, CharSequence charSequence) {
        super(charSequence != null ? charSequence.toString() : null);
    }
}
