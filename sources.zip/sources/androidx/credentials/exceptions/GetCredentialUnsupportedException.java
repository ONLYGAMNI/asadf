package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class GetCredentialUnsupportedException extends GetCredentialException {
    public GetCredentialUnsupportedException() {
        super("androidx.credentials.TYPE_GET_CREDENTIAL_UNSUPPORTED_EXCEPTION", null);
    }
}
