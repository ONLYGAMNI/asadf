package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class GetCredentialInterruptedException extends GetCredentialException {
    public GetCredentialInterruptedException() {
        super("android.credentials.GetCredentialException.TYPE_INTERRUPTED", null);
    }
}
