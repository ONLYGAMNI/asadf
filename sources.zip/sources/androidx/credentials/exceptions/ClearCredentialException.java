package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public abstract class ClearCredentialException extends Exception {
    public ClearCredentialException(String str, CharSequence charSequence) {
        super(charSequence != null ? charSequence.toString() : null);
    }
}
