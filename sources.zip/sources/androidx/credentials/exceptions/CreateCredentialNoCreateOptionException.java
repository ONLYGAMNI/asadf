package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class CreateCredentialNoCreateOptionException extends CreateCredentialException {
    public CreateCredentialNoCreateOptionException() {
        super("android.credentials.CreateCredentialException.TYPE_NO_CREATE_OPTIONS", null);
    }
}
