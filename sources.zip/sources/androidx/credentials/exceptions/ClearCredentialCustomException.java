package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class ClearCredentialCustomException extends ClearCredentialException {
}
