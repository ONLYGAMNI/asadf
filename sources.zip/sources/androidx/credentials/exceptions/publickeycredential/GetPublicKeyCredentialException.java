package androidx.credentials.exceptions.publickeycredential;

import androidx.credentials.exceptions.GetCredentialException;

/* loaded from: classes.dex */
public class GetPublicKeyCredentialException extends GetCredentialException {
}
