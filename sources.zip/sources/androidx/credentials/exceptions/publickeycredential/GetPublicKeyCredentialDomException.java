package androidx.credentials.exceptions.publickeycredential;

/* loaded from: classes.dex */
public final class GetPublicKeyCredentialDomException extends GetPublicKeyCredentialException {
}
