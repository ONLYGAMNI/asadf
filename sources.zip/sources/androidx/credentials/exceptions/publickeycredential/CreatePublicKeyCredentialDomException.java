package androidx.credentials.exceptions.publickeycredential;

/* loaded from: classes.dex */
public final class CreatePublicKeyCredentialDomException extends CreatePublicKeyCredentialException {
}
