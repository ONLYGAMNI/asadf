package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class CreateCredentialUnknownException extends CreateCredentialException {
    public CreateCredentialUnknownException() {
        super("android.credentials.CreateCredentialException.TYPE_UNKNOWN", null);
    }
}
