package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class GetCredentialUnknownException extends GetCredentialException {
    public GetCredentialUnknownException() {
        super("android.credentials.GetCredentialException.TYPE_UNKNOWN", null);
    }
}
