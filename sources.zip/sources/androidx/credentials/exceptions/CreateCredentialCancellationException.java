package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class CreateCredentialCancellationException extends CreateCredentialException {
    public CreateCredentialCancellationException() {
        super("android.credentials.CreateCredentialException.TYPE_USER_CANCELED", null);
    }
}
