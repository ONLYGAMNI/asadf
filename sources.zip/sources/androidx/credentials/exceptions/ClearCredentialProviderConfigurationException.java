package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class ClearCredentialProviderConfigurationException extends ClearCredentialException {
    public ClearCredentialProviderConfigurationException() {
        super("androidx.credentials.TYPE_CLEAR_CREDENTIAL_PROVIDER_CONFIGURATION_EXCEPTION", null);
    }
}
