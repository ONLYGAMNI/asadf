package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class ClearCredentialUnknownException extends ClearCredentialException {
    public ClearCredentialUnknownException() {
        super("android.credentials.ClearCredentialStateException.TYPE_UNKNOWN", null);
    }
}
