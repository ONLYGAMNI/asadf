package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class ClearCredentialUnsupportedException extends ClearCredentialException {
    public ClearCredentialUnsupportedException() {
        super("androidx.credentials.TYPE_CLEAR_CREDENTIAL_UNSUPPORTED_EXCEPTION", null);
    }
}
