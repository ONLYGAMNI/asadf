package androidx.credentials.exceptions;

/* loaded from: classes.dex */
public final class NoCredentialException extends GetCredentialException {
    public NoCredentialException() {
        super("android.credentials.GetCredentialException.TYPE_NO_CREDENTIAL", null);
    }
}
