package androidx.credentials.internal;

/* loaded from: classes.dex */
public final class FrameworkClassParsingException extends Exception {
}
