package androidx.credentials.playservices;

import W.a;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class CredentialProviderMetadataHolder extends Service {

    /* renamed from: a, reason: collision with root package name */
    public final a f6416a = new a();

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        AbstractC1420h.f(intent, "intent");
        return this.f6416a;
    }
}
