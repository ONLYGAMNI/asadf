package androidx.credentials.playservices;

import B.b;
import D3.a;
import E6.C0080d;
import F3.C0103u;
import W.c;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Looper;
import android.os.ResultReceiver;
import android.util.Log;
import androidx.credentials.playservices.HiddenActivity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.d;
import com.google.android.gms.common.api.e;
import com.google.android.gms.common.api.f;
import com.google.android.gms.common.api.internal.AbstractC0584y;
import com.google.android.gms.common.api.internal.C0561a;
import com.google.android.gms.common.api.j;
import com.google.android.gms.common.internal.K;
import com.google.android.gms.internal.p000authapi.zbaw;
import com.google.android.gms.internal.p000authapi.zbbg;
import com.google.android.gms.tasks.OnFailureListener;
import l3.l;
import l3.r;
import l3.t;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public class HiddenActivity extends Activity {

    /* renamed from: c, reason: collision with root package name */
    public static final /* synthetic */ int f6417c = 0;

    /* renamed from: a, reason: collision with root package name */
    public ResultReceiver f6418a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f6419b;

    public final void a(ResultReceiver resultReceiver, String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putBoolean("FAILURE_RESPONSE", true);
        bundle.putString("EXCEPTION_TYPE", str);
        bundle.putString("EXCEPTION_MESSAGE", str2);
        resultReceiver.send(f.API_PRIORITY_OTHER, bundle);
        finish();
    }

    @Override // android.app.Activity
    public final void onActivityResult(int i10, int i11, Intent intent) {
        super.onActivityResult(i10, i11, intent);
        Bundle bundle = new Bundle();
        bundle.putBoolean("FAILURE_RESPONSE", false);
        bundle.putInt("ACTIVITY_REQUEST_CODE", i10);
        bundle.putParcelable("RESULT_DATA", intent);
        ResultReceiver resultReceiver = this.f6418a;
        if (resultReceiver != null) {
            resultReceiver.send(i11, bundle);
        }
        this.f6419b = false;
        finish();
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @Override // android.app.Activity
    public final void onCreate(Bundle bundle) {
        final int i10 = 2;
        final int i11 = 3;
        final int i12 = 1;
        super.onCreate(bundle);
        final int i13 = 0;
        overridePendingTransition(0, 0);
        String stringExtra = getIntent().getStringExtra("TYPE");
        ResultReceiver resultReceiver = (ResultReceiver) getIntent().getParcelableExtra("RESULT_RECEIVER");
        this.f6418a = resultReceiver;
        if (resultReceiver == null) {
            finish();
        }
        if (bundle != null) {
            this.f6419b = bundle.getBoolean("androidx.credentials.playservices.AWAITING_RESULT", false);
        }
        if (this.f6419b) {
            return;
        }
        if (stringExtra != null) {
            switch (stringExtra.hashCode()) {
                case -441061071:
                    if (stringExtra.equals("BEGIN_SIGN_IN")) {
                        l3.f fVar = (l3.f) getIntent().getParcelableExtra("REQUEST_TYPE");
                        if ((fVar != null ? new zbbg((Activity) this, new t()).beginSignIn(fVar).addOnSuccessListener(new C0080d(9, new c(this, getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), 0))).addOnFailureListener(new OnFailureListener(this) { // from class: W.b

                            /* renamed from: b, reason: collision with root package name */
                            public final /* synthetic */ HiddenActivity f5159b;

                            {
                                this.f5159b = this;
                            }

                            @Override // com.google.android.gms.tasks.OnFailureListener
                            public final void onFailure(Exception exc) {
                                String str = "CREATE_UNKNOWN";
                                String str2 = "GET_NO_CREDENTIALS";
                                HiddenActivity hiddenActivity = this.f5159b;
                                switch (i11) {
                                    case 0:
                                        int i14 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str = "CREATE_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver2 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver2);
                                        hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                        break;
                                    case 1:
                                        int i15 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str = "CREATE_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver3 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver3);
                                        hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                        break;
                                    case 2:
                                        int i16 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str2 = "GET_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver4 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver4);
                                        hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                        break;
                                    default:
                                        int i17 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str2 = "GET_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver5 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver5);
                                        hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                        break;
                                }
                            }
                        }) : null) == null) {
                            Log.i("HiddenActivity", "During begin sign in, params is null, nothing to launch for begin sign in");
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
                case 15545322:
                    if (stringExtra.equals("CREATE_PUBLIC_KEY_CREDENTIAL")) {
                        C0103u c0103u = (C0103u) getIntent().getParcelableExtra("REQUEST_TYPE");
                        int intExtra = getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1);
                        if (c0103u != null) {
                            int i14 = a.f451a;
                            d dVar = e.f9039l;
                            C0561a c0561a = new C0561a();
                            Looper mainLooper = getMainLooper();
                            K.k(mainLooper, "Looper must not be null.");
                            E3.a aVar = new E3.a(this, this, E3.a.f655a, dVar, new j(c0561a, mainLooper));
                            W3.d dVarA = AbstractC0584y.a();
                            dVarA.d = new b(aVar, c0103u);
                            dVarA.f5189c = 5407;
                            taskAddOnFailureListener = aVar.doRead(dVarA.a()).addOnSuccessListener(new C0080d(6, new c(this, intExtra, 2))).addOnFailureListener(new OnFailureListener(this) { // from class: W.b

                                /* renamed from: b, reason: collision with root package name */
                                public final /* synthetic */ HiddenActivity f5159b;

                                {
                                    this.f5159b = this;
                                }

                                @Override // com.google.android.gms.tasks.OnFailureListener
                                public final void onFailure(Exception exc) {
                                    String str = "CREATE_UNKNOWN";
                                    String str2 = "GET_NO_CREDENTIALS";
                                    HiddenActivity hiddenActivity = this.f5159b;
                                    switch (i13) {
                                        case 0:
                                            int i142 = HiddenActivity.f6417c;
                                            AbstractC1420h.f(hiddenActivity, "this$0");
                                            AbstractC1420h.f(exc, "e");
                                            if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver2 = hiddenActivity.f6418a;
                                            AbstractC1420h.c(resultReceiver2);
                                            hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                            break;
                                        case 1:
                                            int i15 = HiddenActivity.f6417c;
                                            AbstractC1420h.f(hiddenActivity, "this$0");
                                            AbstractC1420h.f(exc, "e");
                                            if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                                str = "CREATE_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver3 = hiddenActivity.f6418a;
                                            AbstractC1420h.c(resultReceiver3);
                                            hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                            break;
                                        case 2:
                                            int i16 = HiddenActivity.f6417c;
                                            AbstractC1420h.f(hiddenActivity, "this$0");
                                            AbstractC1420h.f(exc, "e");
                                            if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver4 = hiddenActivity.f6418a;
                                            AbstractC1420h.c(resultReceiver4);
                                            hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                            break;
                                        default:
                                            int i17 = HiddenActivity.f6417c;
                                            AbstractC1420h.f(hiddenActivity, "this$0");
                                            AbstractC1420h.f(exc, "e");
                                            if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                                str2 = "GET_INTERRUPTED";
                                            }
                                            ResultReceiver resultReceiver5 = hiddenActivity.f6418a;
                                            AbstractC1420h.c(resultReceiver5);
                                            hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                            break;
                                    }
                                }
                            });
                        }
                        if (taskAddOnFailureListener == null) {
                            Log.w("HiddenActivity", "During create public key credential, request is null, so nothing to launch for public key credentials");
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
                case 1246634622:
                    if (stringExtra.equals("CREATE_PASSWORD")) {
                        l lVar = (l) getIntent().getParcelableExtra("REQUEST_TYPE");
                        if ((lVar != null ? new zbaw((Activity) this, new r()).savePassword(lVar).addOnSuccessListener(new C0080d(7, new c(this, getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), 1))).addOnFailureListener(new OnFailureListener(this) { // from class: W.b

                            /* renamed from: b, reason: collision with root package name */
                            public final /* synthetic */ HiddenActivity f5159b;

                            {
                                this.f5159b = this;
                            }

                            @Override // com.google.android.gms.tasks.OnFailureListener
                            public final void onFailure(Exception exc) {
                                String str = "CREATE_UNKNOWN";
                                String str2 = "GET_NO_CREDENTIALS";
                                HiddenActivity hiddenActivity = this.f5159b;
                                switch (i12) {
                                    case 0:
                                        int i142 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str = "CREATE_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver2 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver2);
                                        hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                        break;
                                    case 1:
                                        int i15 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str = "CREATE_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver3 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver3);
                                        hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                        break;
                                    case 2:
                                        int i16 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str2 = "GET_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver4 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver4);
                                        hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                        break;
                                    default:
                                        int i17 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str2 = "GET_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver5 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver5);
                                        hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                        break;
                                }
                            }
                        }) : null) == null) {
                            Log.i("HiddenActivity", "During save password, params is null, nothing to launch for create password");
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
                case 1980564212:
                    if (stringExtra.equals("SIGN_IN_INTENT")) {
                        l3.j jVar = (l3.j) getIntent().getParcelableExtra("REQUEST_TYPE");
                        if ((jVar != null ? new zbbg((Activity) this, new t()).getSignInIntent(jVar).addOnSuccessListener(new C0080d(8, new c(this, getIntent().getIntExtra("ACTIVITY_REQUEST_CODE", 1), 3))).addOnFailureListener(new OnFailureListener(this) { // from class: W.b

                            /* renamed from: b, reason: collision with root package name */
                            public final /* synthetic */ HiddenActivity f5159b;

                            {
                                this.f5159b = this;
                            }

                            @Override // com.google.android.gms.tasks.OnFailureListener
                            public final void onFailure(Exception exc) {
                                String str = "CREATE_UNKNOWN";
                                String str2 = "GET_NO_CREDENTIALS";
                                HiddenActivity hiddenActivity = this.f5159b;
                                switch (i10) {
                                    case 0:
                                        int i142 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str = "CREATE_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver2 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver2);
                                        hiddenActivity.a(resultReceiver2, str, "During create public key credential, fido registration failure: " + exc.getMessage());
                                        break;
                                    case 1:
                                        int i15 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str = "CREATE_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver3 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver3);
                                        hiddenActivity.a(resultReceiver3, str, "During save password, found password failure response from one tap " + exc.getMessage());
                                        break;
                                    case 2:
                                        int i16 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str2 = "GET_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver4 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver4);
                                        hiddenActivity.a(resultReceiver4, str2, "During get sign-in intent, failure response from one tap: " + exc.getMessage());
                                        break;
                                    default:
                                        int i17 = HiddenActivity.f6417c;
                                        AbstractC1420h.f(hiddenActivity, "this$0");
                                        AbstractC1420h.f(exc, "e");
                                        if ((exc instanceof ApiException) && X.a.f5300a.contains(Integer.valueOf(((ApiException) exc).getStatusCode()))) {
                                            str2 = "GET_INTERRUPTED";
                                        }
                                        ResultReceiver resultReceiver5 = hiddenActivity.f6418a;
                                        AbstractC1420h.c(resultReceiver5);
                                        hiddenActivity.a(resultReceiver5, str2, "During begin sign in, failure response from one tap: " + exc.getMessage());
                                        break;
                                }
                            }
                        }) : null) == null) {
                            Log.i("HiddenActivity", "During get sign-in intent, params is null, nothing to launch for get sign-in intent");
                            finish();
                            return;
                        }
                        return;
                    }
                    break;
            }
        }
        Log.w("HiddenActivity", "Activity handed an unsupported type");
        finish();
    }

    @Override // android.app.Activity
    public final void onSaveInstanceState(Bundle bundle) {
        AbstractC1420h.f(bundle, "outState");
        bundle.putBoolean("androidx.credentials.playservices.AWAITING_RESULT", this.f6419b);
        super.onSaveInstanceState(bundle);
    }
}
