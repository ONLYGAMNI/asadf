package androidx.emoji2.text;

import android.util.SparseArray;
import f0.C0815a;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class l {

    /* renamed from: a, reason: collision with root package name */
    public int f6586a = 1;

    /* renamed from: b, reason: collision with root package name */
    public final o f6587b;

    /* renamed from: c, reason: collision with root package name */
    public o f6588c;
    public o d;

    /* renamed from: e, reason: collision with root package name */
    public int f6589e;

    /* renamed from: f, reason: collision with root package name */
    public int f6590f;

    public l(o oVar) {
        this.f6587b = oVar;
        this.f6588c = oVar;
    }

    public final int a(int i10) {
        SparseArray sparseArray = this.f6588c.f6601a;
        o oVar = sparseArray == null ? null : (o) sparseArray.get(i10);
        int i11 = 1;
        int i12 = 2;
        if (this.f6586a == 2) {
            if (oVar != null) {
                this.f6588c = oVar;
                this.f6590f++;
            } else if (i10 == 65038) {
                b();
            } else if (i10 != 65039) {
                o oVar2 = this.f6588c;
                if (oVar2.f6602b != null) {
                    i12 = 3;
                    if (this.f6590f != 1) {
                        this.d = oVar2;
                        b();
                    } else if (c()) {
                        this.d = this.f6588c;
                        b();
                    } else {
                        b();
                    }
                } else {
                    b();
                }
            }
            i11 = i12;
        } else if (oVar == null) {
            b();
        } else {
            this.f6586a = 2;
            this.f6588c = oVar;
            this.f6590f = 1;
            i11 = i12;
        }
        this.f6589e = i10;
        return i11;
    }

    public final void b() {
        this.f6586a = 1;
        this.f6588c = this.f6587b;
        this.f6590f = 0;
    }

    public final boolean c() {
        C0815a c0815aC = this.f6588c.f6602b.c();
        int iA = c0815aC.a(6);
        return !(iA == 0 || ((ByteBuffer) c0815aC.d).get(iA + c0815aC.f3952a) == 0) || this.f6589e == 65039;
    }
}
