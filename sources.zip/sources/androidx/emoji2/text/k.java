package androidx.emoji2.text;

import E5.E;
import f0.C0815a;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class k {
    public static final ThreadLocal d = new ThreadLocal();

    /* renamed from: a, reason: collision with root package name */
    public final int f6583a;

    /* renamed from: b, reason: collision with root package name */
    public final E f6584b;

    /* renamed from: c, reason: collision with root package name */
    public volatile int f6585c = 0;

    public k(E e4, int i10) {
        this.f6584b = e4;
        this.f6583a = i10;
    }

    public final int a(int i10) {
        C0815a c0815aC = c();
        int iA = c0815aC.a(16);
        if (iA == 0) {
            return 0;
        }
        ByteBuffer byteBuffer = (ByteBuffer) c0815aC.d;
        int i11 = iA + c0815aC.f3952a;
        return byteBuffer.getInt((i10 * 4) + byteBuffer.getInt(i11) + i11 + 4);
    }

    public final int b() {
        C0815a c0815aC = c();
        int iA = c0815aC.a(16);
        if (iA == 0) {
            return 0;
        }
        int i10 = iA + c0815aC.f3952a;
        return ((ByteBuffer) c0815aC.d).getInt(((ByteBuffer) c0815aC.d).getInt(i10) + i10);
    }

    public final C0815a c() {
        ThreadLocal threadLocal = d;
        C0815a c0815a = (C0815a) threadLocal.get();
        if (c0815a == null) {
            c0815a = new C0815a(2);
            threadLocal.set(c0815a);
        }
        f0.b bVar = (f0.b) this.f6584b.f698b;
        int iA = bVar.a(6);
        if (iA != 0) {
            int i10 = iA + bVar.f3952a;
            int i11 = (this.f6583a * 4) + ((ByteBuffer) bVar.d).getInt(i10) + i10 + 4;
            int i12 = ((ByteBuffer) bVar.d).getInt(i11) + i11;
            ByteBuffer byteBuffer = (ByteBuffer) bVar.d;
            c0815a.d = byteBuffer;
            if (byteBuffer != null) {
                c0815a.f3952a = i12;
                int i13 = i12 - byteBuffer.getInt(i12);
                c0815a.f3953b = i13;
                c0815a.f3954c = ((ByteBuffer) c0815a.d).getShort(i13);
            } else {
                c0815a.f3952a = 0;
                c0815a.f3953b = 0;
                c0815a.f3954c = 0;
            }
        }
        return c0815a;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", id:");
        C0815a c0815aC = c();
        int iA = c0815aC.a(4);
        sb.append(Integer.toHexString(iA != 0 ? ((ByteBuffer) c0815aC.d).getInt(iA + c0815aC.f3952a) : 0));
        sb.append(", codepoints:");
        int iB = b();
        for (int i10 = 0; i10 < iB; i10++) {
            sb.append(Integer.toHexString(a(i10)));
            sb.append(" ");
        }
        return sb.toString();
    }
}
