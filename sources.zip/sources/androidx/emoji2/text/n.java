package androidx.emoji2.text;

import K3.E;

/* loaded from: classes.dex */
public final class n {
    public static final E d = new E(28);

    /* renamed from: a, reason: collision with root package name */
    public final h f6598a;

    /* renamed from: b, reason: collision with root package name */
    public int f6599b = 0;

    /* renamed from: c, reason: collision with root package name */
    public final d f6600c = new d();

    public n(h hVar) {
        this.f6598a = hVar;
    }
}
