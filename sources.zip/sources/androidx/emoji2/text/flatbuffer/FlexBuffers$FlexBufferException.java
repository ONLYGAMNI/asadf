package androidx.emoji2.text.flatbuffer;

/* loaded from: classes.dex */
public class FlexBuffers$FlexBufferException extends RuntimeException {
}
