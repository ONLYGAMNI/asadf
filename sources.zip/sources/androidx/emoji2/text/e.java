package androidx.emoji2.text;

import E5.E;
import K3.D;
import a.AbstractC0338a;

/* loaded from: classes.dex */
public final class e extends AbstractC0338a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ V4.b f6572a;

    public e(V4.b bVar) {
        this.f6572a = bVar;
    }

    @Override // a.AbstractC0338a
    public final void K(Throwable th) {
        ((i) this.f6572a.f5096a).d(th);
    }

    @Override // a.AbstractC0338a
    public final void L(E e4) {
        V4.b bVar = this.f6572a;
        bVar.f5098c = e4;
        bVar.f5097b = new X0.m((E) bVar.f5098c, new D(28), ((i) bVar.f5096a).f6580h);
        ((i) bVar.f5096a).e();
    }
}
