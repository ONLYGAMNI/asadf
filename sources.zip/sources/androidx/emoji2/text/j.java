package androidx.emoji2.text;

import E5.E;
import a.AbstractC0338a;
import java.util.concurrent.ThreadPoolExecutor;

/* loaded from: classes.dex */
public final class j extends AbstractC0338a {

    /* renamed from: a */
    public final /* synthetic */ AbstractC0338a f6581a;

    /* renamed from: b */
    public final /* synthetic */ ThreadPoolExecutor f6582b;

    public j(AbstractC0338a abstractC0338a, ThreadPoolExecutor threadPoolExecutor) {
        this.f6581a = abstractC0338a;
        this.f6582b = threadPoolExecutor;
    }

    @Override // a.AbstractC0338a
    public final void K(Throwable th) {
        ThreadPoolExecutor threadPoolExecutor = this.f6582b;
        try {
            this.f6581a.K(th);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }

    @Override // a.AbstractC0338a
    public final void L(E e4) {
        ThreadPoolExecutor threadPoolExecutor = this.f6582b;
        try {
            this.f6581a.L(e4);
        } finally {
            threadPoolExecutor.shutdown();
        }
    }
}
