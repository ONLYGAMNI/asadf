package androidx.emoji2.text;

import E5.E;
import K3.D;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import r.C1329c;

/* loaded from: classes.dex */
public final class i {

    /* renamed from: i */
    public static final Object f6573i = new Object();

    /* renamed from: j */
    public static volatile i f6574j;

    /* renamed from: a */
    public final ReentrantReadWriteLock f6575a;

    /* renamed from: b */
    public final C1329c f6576b;

    /* renamed from: c */
    public volatile int f6577c;
    public final Handler d;

    /* renamed from: e */
    public final V4.b f6578e;

    /* renamed from: f */
    public final h f6579f;
    public final int g;

    /* renamed from: h */
    public final d f6580h;

    public i(n nVar) {
        ReentrantReadWriteLock reentrantReadWriteLock = new ReentrantReadWriteLock();
        this.f6575a = reentrantReadWriteLock;
        this.f6577c = 3;
        h hVar = nVar.f6598a;
        this.f6579f = hVar;
        int i10 = nVar.f6599b;
        this.g = i10;
        this.f6580h = nVar.f6600c;
        this.d = new Handler(Looper.getMainLooper());
        this.f6576b = new C1329c(0);
        V4.b bVar = new V4.b(this);
        this.f6578e = bVar;
        reentrantReadWriteLock.writeLock().lock();
        if (i10 == 0) {
            try {
                this.f6577c = 0;
            } catch (Throwable th) {
                this.f6575a.writeLock().unlock();
                throw th;
            }
        }
        reentrantReadWriteLock.writeLock().unlock();
        if (b() == 0) {
            try {
                hVar.c(new e(bVar));
            } catch (Throwable th2) {
                d(th2);
            }
        }
    }

    public static i a() {
        i iVar;
        synchronized (f6573i) {
            try {
                iVar = f6574j;
                if (!(iVar != null)) {
                    throw new IllegalStateException("EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
                }
            } finally {
            }
        }
        return iVar;
    }

    public final int b() {
        this.f6575a.readLock().lock();
        try {
            return this.f6577c;
        } finally {
            this.f6575a.readLock().unlock();
        }
    }

    public final void c() {
        if (!(this.g == 1)) {
            throw new IllegalStateException("Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        }
        if (b() == 1) {
            return;
        }
        this.f6575a.writeLock().lock();
        try {
            if (this.f6577c == 0) {
                return;
            }
            this.f6577c = 0;
            this.f6575a.writeLock().unlock();
            V4.b bVar = this.f6578e;
            i iVar = (i) bVar.f5096a;
            try {
                iVar.f6579f.c(new e(bVar));
            } catch (Throwable th) {
                iVar.d(th);
            }
        } finally {
            this.f6575a.writeLock().unlock();
        }
    }

    public final void d(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f6575a.writeLock().lock();
        try {
            this.f6577c = 2;
            arrayList.addAll(this.f6576b);
            this.f6576b.clear();
            this.f6575a.writeLock().unlock();
            this.d.post(new N.a(arrayList, this.f6577c, th));
        } catch (Throwable th2) {
            this.f6575a.writeLock().unlock();
            throw th2;
        }
    }

    public final void e() {
        ArrayList arrayList = new ArrayList();
        this.f6575a.writeLock().lock();
        try {
            this.f6577c = 1;
            arrayList.addAll(this.f6576b);
            this.f6576b.clear();
            this.f6575a.writeLock().unlock();
            this.d.post(new N.a(arrayList, this.f6577c, (Throwable) null));
        } catch (Throwable th) {
            this.f6575a.writeLock().unlock();
            throw th;
        }
    }

    public final CharSequence f(int i10, int i11, CharSequence charSequence) {
        int iCharCount;
        r[] rVarArr;
        if (!(b() == 1)) {
            throw new IllegalStateException("Not initialized yet");
        }
        if (i10 < 0) {
            throw new IllegalArgumentException("start cannot be negative");
        }
        if (i11 < 0) {
            throw new IllegalArgumentException("end cannot be negative");
        }
        com.bumptech.glide.c.e("start should be <= than end", i10 <= i11);
        t tVar = null;
        if (charSequence == null) {
            return null;
        }
        com.bumptech.glide.c.e("start should be < than charSequence length", i10 <= charSequence.length());
        com.bumptech.glide.c.e("end should be < than charSequence length", i11 <= charSequence.length());
        if (charSequence.length() == 0 || i10 == i11) {
            return charSequence;
        }
        X0.m mVar = (X0.m) this.f6578e.f5097b;
        mVar.getClass();
        boolean z3 = charSequence instanceof q;
        if (z3) {
            ((q) charSequence).a();
        }
        if (z3) {
            tVar = new t((Spannable) charSequence);
        } else {
            try {
                if (charSequence instanceof Spannable) {
                    tVar = new t((Spannable) charSequence);
                } else if ((charSequence instanceof Spanned) && ((Spanned) charSequence).nextSpanTransition(i10 - 1, i11 + 1, r.class) <= i11) {
                    tVar = new t(charSequence);
                }
            } finally {
                if (z3) {
                    ((q) charSequence).b();
                }
            }
        }
        if (tVar != null && (rVarArr = (r[]) tVar.f6611b.getSpans(i10, i11, r.class)) != null && rVarArr.length > 0) {
            for (r rVar : rVarArr) {
                int spanStart = tVar.f6611b.getSpanStart(rVar);
                int spanEnd = tVar.f6611b.getSpanEnd(rVar);
                if (spanStart != i11) {
                    tVar.removeSpan(rVar);
                }
                i10 = Math.min(spanStart, i10);
                i11 = Math.max(spanEnd, i11);
            }
        }
        if (i10 != i11 && i10 < charSequence.length()) {
            l lVar = new l((o) ((E) mVar.f5324c).d);
            int iCodePointAt = Character.codePointAt(charSequence, i10);
            int i12 = 0;
            t tVar2 = tVar;
            loop1: while (true) {
                iCharCount = i10;
                while (i10 < i11 && i12 < Integer.MAX_VALUE) {
                    int iA = lVar.a(iCodePointAt);
                    if (iA == 1) {
                        iCharCount += Character.charCount(Character.codePointAt(charSequence, iCharCount));
                        if (iCharCount < i11) {
                            iCodePointAt = Character.codePointAt(charSequence, iCharCount);
                        }
                        i10 = iCharCount;
                    } else if (iA == 2) {
                        i10 += Character.charCount(iCodePointAt);
                        if (i10 < i11) {
                            iCodePointAt = Character.codePointAt(charSequence, i10);
                        }
                    } else if (iA == 3) {
                        if (!mVar.A(charSequence, iCharCount, i10, lVar.d.f6602b)) {
                            if (tVar2 == null) {
                                tVar2 = new t((Spannable) new SpannableString(charSequence));
                            }
                            k kVar = lVar.d.f6602b;
                            ((D) mVar.f5323b).getClass();
                            tVar2.setSpan(new r(kVar), iCharCount, i10, 33);
                            i12++;
                        }
                    }
                }
                break loop1;
            }
            if (lVar.f6586a == 2 && lVar.f6588c.f6602b != null && ((lVar.f6590f > 1 || lVar.c()) && i12 < Integer.MAX_VALUE && !mVar.A(charSequence, iCharCount, i10, lVar.f6588c.f6602b))) {
                if (tVar2 == null) {
                    tVar2 = new t(charSequence);
                }
                k kVar2 = lVar.f6588c.f6602b;
                ((D) mVar.f5323b).getClass();
                tVar2.setSpan(new r(kVar2), iCharCount, i10, 33);
            }
            if (tVar2 != null) {
                Spannable spannable = tVar2.f6611b;
                if (z3) {
                    ((q) charSequence).b();
                }
                return spannable;
            }
            if (!z3) {
                return charSequence;
            }
        } else if (!z3) {
            return charSequence;
        }
        return charSequence;
    }

    public final void g(g gVar) {
        com.bumptech.glide.c.h(gVar, "initCallback cannot be null");
        this.f6575a.writeLock().lock();
        try {
            if (this.f6577c == 1 || this.f6577c == 2) {
                this.d.post(new N.a(Arrays.asList(gVar), this.f6577c, (Throwable) null));
            } else {
                this.f6576b.add(gVar);
            }
            this.f6575a.writeLock().unlock();
        } catch (Throwable th) {
            this.f6575a.writeLock().unlock();
            throw th;
        }
    }
}
