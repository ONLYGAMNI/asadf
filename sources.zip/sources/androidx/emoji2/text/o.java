package androidx.emoji2.text;

import android.util.SparseArray;

/* loaded from: classes.dex */
public final class o {

    /* renamed from: a, reason: collision with root package name */
    public final SparseArray f6601a;

    /* renamed from: b, reason: collision with root package name */
    public k f6602b;

    public o(int i10) {
        this.f6601a = new SparseArray(i10);
    }

    public final void a(k kVar, int i10, int i11) {
        int iA = kVar.a(i10);
        SparseArray sparseArray = this.f6601a;
        o oVar = sparseArray == null ? null : (o) sparseArray.get(iA);
        if (oVar == null) {
            oVar = new o(1);
            sparseArray.put(kVar.a(i10), oVar);
        }
        if (i11 > i10) {
            oVar.a(kVar, i10 + 1, i11);
        } else {
            oVar.f6602b = kVar;
        }
    }
}
