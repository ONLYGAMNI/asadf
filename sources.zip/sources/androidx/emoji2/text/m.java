package androidx.emoji2.text;

import D.RunnableC0050a;
import D6.C0052a;
import K3.E;
import a.AbstractC0338a;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public final class m implements h {

    /* renamed from: a */
    public final Context f6591a;

    /* renamed from: b */
    public final C0052a f6592b;

    /* renamed from: c */
    public final E f6593c;
    public final Object d;

    /* renamed from: e */
    public Handler f6594e;

    /* renamed from: f */
    public Executor f6595f;

    /* renamed from: n */
    public ThreadPoolExecutor f6596n;

    /* renamed from: o */
    public AbstractC0338a f6597o;

    public m(Context context, C0052a c0052a) {
        E e4 = n.d;
        this.d = new Object();
        com.bumptech.glide.c.h(context, "Context cannot be null");
        this.f6591a = context.getApplicationContext();
        this.f6592b = c0052a;
        this.f6593c = e4;
    }

    public final void a() {
        synchronized (this.d) {
            try {
                this.f6597o = null;
                Handler handler = this.f6594e;
                if (handler != null) {
                    handler.removeCallbacks(null);
                }
                this.f6594e = null;
                ThreadPoolExecutor threadPoolExecutor = this.f6596n;
                if (threadPoolExecutor != null) {
                    threadPoolExecutor.shutdown();
                }
                this.f6595f = null;
                this.f6596n = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b() {
        synchronized (this.d) {
            try {
                if (this.f6597o == null) {
                    return;
                }
                if (this.f6595f == null) {
                    ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 1, 15L, TimeUnit.SECONDS, new LinkedBlockingDeque(), new a("emojiCompat"));
                    threadPoolExecutor.allowCoreThreadTimeOut(true);
                    this.f6596n = threadPoolExecutor;
                    this.f6595f = threadPoolExecutor;
                }
                this.f6595f.execute(new RunnableC0050a(this, 19));
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // androidx.emoji2.text.h
    public final void c(AbstractC0338a abstractC0338a) {
        synchronized (this.d) {
            this.f6597o = abstractC0338a;
        }
        b();
    }

    public final N.i d() {
        try {
            E e4 = this.f6593c;
            Context context = this.f6591a;
            C0052a c0052a = this.f6592b;
            e4.getClass();
            G2.a aVarA = N.d.a(context, c0052a);
            int i10 = aVarA.f1386b;
            if (i10 != 0) {
                throw new RuntimeException(AbstractC1480a.j("fetchFonts failed (", i10, ")"));
            }
            N.i[] iVarArr = (N.i[]) aVarA.f1387c;
            if (iVarArr == null || iVarArr.length == 0) {
                throw new RuntimeException("fetchFonts failed (empty result)");
            }
            return iVarArr[0];
        } catch (PackageManager.NameNotFoundException e5) {
            throw new RuntimeException("provider not found", e5);
        }
    }
}
