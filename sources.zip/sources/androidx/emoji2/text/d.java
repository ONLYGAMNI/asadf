package androidx.emoji2.text;

import android.text.TextPaint;

/* loaded from: classes.dex */
public final class d implements f {

    /* renamed from: b, reason: collision with root package name */
    public static final ThreadLocal f6570b = new ThreadLocal();

    /* renamed from: a, reason: collision with root package name */
    public final TextPaint f6571a;

    public d() {
        TextPaint textPaint = new TextPaint();
        this.f6571a = textPaint;
        textPaint.setTextSize(10.0f);
    }
}
