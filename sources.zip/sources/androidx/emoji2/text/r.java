package androidx.emoji2.text;

import E5.E;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.style.ReplacementSpan;
import f0.C0815a;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class r extends ReplacementSpan {

    /* renamed from: b, reason: collision with root package name */
    public final k f6608b;

    /* renamed from: a, reason: collision with root package name */
    public final Paint.FontMetricsInt f6607a = new Paint.FontMetricsInt();

    /* renamed from: c, reason: collision with root package name */
    public float f6609c = 1.0f;

    public r(k kVar) {
        com.bumptech.glide.c.h(kVar, "metadata cannot be null");
        this.f6608b = kVar;
    }

    @Override // android.text.style.ReplacementSpan
    public final void draw(Canvas canvas, CharSequence charSequence, int i10, int i11, float f10, int i12, int i13, int i14, Paint paint) {
        i.a().getClass();
        k kVar = this.f6608b;
        E e4 = kVar.f6584b;
        Typeface typeface = (Typeface) e4.f700e;
        Typeface typeface2 = paint.getTypeface();
        paint.setTypeface(typeface);
        canvas.drawText((char[]) e4.f699c, kVar.f6583a * 2, 2, f10, i13, paint);
        paint.setTypeface(typeface2);
    }

    @Override // android.text.style.ReplacementSpan
    public final int getSize(Paint paint, CharSequence charSequence, int i10, int i11, Paint.FontMetricsInt fontMetricsInt) {
        Paint.FontMetricsInt fontMetricsInt2 = this.f6607a;
        paint.getFontMetricsInt(fontMetricsInt2);
        float fAbs = Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent) * 1.0f;
        k kVar = this.f6608b;
        this.f6609c = fAbs / (kVar.c().a(14) != 0 ? ((ByteBuffer) r8.d).getShort(r1 + r8.f3952a) : (short) 0);
        C0815a c0815aC = kVar.c();
        int iA = c0815aC.a(14);
        if (iA != 0) {
            ((ByteBuffer) c0815aC.d).getShort(iA + c0815aC.f3952a);
        }
        short s9 = (short) ((kVar.c().a(12) != 0 ? ((ByteBuffer) r5.d).getShort(r7 + r5.f3952a) : (short) 0) * this.f6609c);
        if (fontMetricsInt != null) {
            fontMetricsInt.ascent = fontMetricsInt2.ascent;
            fontMetricsInt.descent = fontMetricsInt2.descent;
            fontMetricsInt.top = fontMetricsInt2.top;
            fontMetricsInt.bottom = fontMetricsInt2.bottom;
        }
        return s9;
    }
}
