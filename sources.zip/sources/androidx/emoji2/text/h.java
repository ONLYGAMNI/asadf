package androidx.emoji2.text;

import a.AbstractC0338a;

/* loaded from: classes.dex */
public interface h {
    void c(AbstractC0338a abstractC0338a);
}
