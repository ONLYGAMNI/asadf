package androidx.emoji2.text;

import K3.D;
import R.AbstractC0249h;

/* loaded from: classes.dex */
public final class s extends D {
    @Override // K3.D
    public final boolean a(CharSequence charSequence) {
        return AbstractC0249h.o(charSequence) || (charSequence instanceof P.g);
    }
}
