package androidx.emoji2.text;

/* loaded from: classes.dex */
public abstract class g {
    public abstract void a();
}
