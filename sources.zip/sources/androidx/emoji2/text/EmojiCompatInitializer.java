package androidx.emoji2.text;

import K3.RunnableC0189y;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.D;
import androidx.lifecycle.F;
import androidx.lifecycle.InterfaceC0416m;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/* loaded from: classes.dex */
public class EmojiCompatInitializer implements G0.b {
    @Override // G0.b
    public final List a() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // G0.b
    public final /* bridge */ /* synthetic */ Object b(Context context) {
        c(context);
        return Boolean.TRUE;
    }

    public final void c(Context context) {
        n nVar = new n(new A3.b(context, 3));
        nVar.f6599b = 1;
        if (i.f6574j == null) {
            synchronized (i.f6573i) {
                try {
                    if (i.f6574j == null) {
                        i.f6574j = new i(nVar);
                    }
                } finally {
                }
            }
        }
        d(context);
    }

    public final void d(Context context) {
        Object objB;
        G0.a aVarC = G0.a.c(context);
        aVarC.getClass();
        synchronized (G0.a.f1381e) {
            try {
                objB = aVarC.f1382a.get(ProcessLifecycleInitializer.class);
                if (objB == null) {
                    objB = aVarC.b(ProcessLifecycleInitializer.class, new HashSet());
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        final F fH = ((D) objB).h();
        fH.a(new InterfaceC0416m() { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            @Override // androidx.lifecycle.InterfaceC0416m
            public final void a(D d) {
                EmojiCompatInitializer.this.getClass();
                (Build.VERSION.SDK_INT >= 28 ? b.a(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new RunnableC0189y(3), 500L);
                fH.b(this);
            }

            @Override // androidx.lifecycle.InterfaceC0416m
            public final void c(D d) {
            }

            @Override // androidx.lifecycle.InterfaceC0416m
            public final /* synthetic */ void e(D d) {
            }

            @Override // androidx.lifecycle.InterfaceC0416m
            public final /* synthetic */ void onDestroy(D d) {
            }

            @Override // androidx.lifecycle.InterfaceC0416m
            public final /* synthetic */ void onStart(D d) {
            }

            @Override // androidx.lifecycle.InterfaceC0416m
            public final /* synthetic */ void onStop(D d) {
            }
        });
    }
}
