package androidx.emoji2.text;

import K3.D;
import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

/* loaded from: classes.dex */
public final class t implements Spannable {

    /* renamed from: a, reason: collision with root package name */
    public boolean f6610a = false;

    /* renamed from: b, reason: collision with root package name */
    public Spannable f6611b;

    public t(Spannable spannable) {
        this.f6611b = spannable;
    }

    public final void a() {
        Spannable spannable = this.f6611b;
        if (!this.f6610a) {
            if ((Build.VERSION.SDK_INT < 28 ? new D(29) : new s(29)).a(spannable)) {
                this.f6611b = new SpannableString(spannable);
            }
        }
        this.f6610a = true;
    }

    @Override // java.lang.CharSequence
    public final char charAt(int i10) {
        return this.f6611b.charAt(i10);
    }

    @Override // java.lang.CharSequence
    public final IntStream chars() {
        return this.f6611b.chars();
    }

    @Override // java.lang.CharSequence
    public final IntStream codePoints() {
        return this.f6611b.codePoints();
    }

    @Override // android.text.Spanned
    public final int getSpanEnd(Object obj) {
        return this.f6611b.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public final int getSpanFlags(Object obj) {
        return this.f6611b.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public final int getSpanStart(Object obj) {
        return this.f6611b.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public final Object[] getSpans(int i10, int i11, Class cls) {
        return this.f6611b.getSpans(i10, i11, cls);
    }

    @Override // java.lang.CharSequence
    public final int length() {
        return this.f6611b.length();
    }

    @Override // android.text.Spanned
    public final int nextSpanTransition(int i10, int i11, Class cls) {
        return this.f6611b.nextSpanTransition(i10, i11, cls);
    }

    @Override // android.text.Spannable
    public final void removeSpan(Object obj) {
        a();
        this.f6611b.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public final void setSpan(Object obj, int i10, int i11, int i12) {
        a();
        this.f6611b.setSpan(obj, i10, i11, i12);
    }

    @Override // java.lang.CharSequence
    public final CharSequence subSequence(int i10, int i11) {
        return this.f6611b.subSequence(i10, i11);
    }

    @Override // java.lang.CharSequence
    public final String toString() {
        return this.f6611b.toString();
    }

    public t(CharSequence charSequence) {
        this.f6611b = new SpannableString(charSequence);
    }
}
