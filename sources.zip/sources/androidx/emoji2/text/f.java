package androidx.emoji2.text;

/* loaded from: classes.dex */
public interface f {
}
