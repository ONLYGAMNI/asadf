package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import java.util.HashMap;
import v.C1530a;
import v.C1534e;
import v.C1535f;
import v.C1539j;
import z.AbstractC1686b;
import z.i;
import z.j;
import z.o;
import z.s;

/* loaded from: classes.dex */
public class Barrier extends AbstractC1686b {

    /* renamed from: o */
    public int f6328o;

    /* renamed from: p */
    public int f6329p;

    /* renamed from: q */
    public C1530a f6330q;

    public Barrier(Context context) throws IllegalAccessException, Resources.NotFoundException, IllegalArgumentException {
        super(context);
        this.f16443a = new int[32];
        this.f16448n = new HashMap();
        this.f16445c = context;
        h(null);
        super.setVisibility(8);
    }

    public boolean getAllowsGoneWidget() {
        return this.f6330q.f15482y0;
    }

    public int getMargin() {
        return this.f6330q.f15483z0;
    }

    public int getType() {
        return this.f6328o;
    }

    @Override // z.AbstractC1686b
    public final void h(AttributeSet attributeSet) throws IllegalAccessException, Resources.NotFoundException, IllegalArgumentException {
        super.h(attributeSet);
        this.f6330q = new C1530a();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, s.f16647b);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 26) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == 25) {
                    this.f6330q.f15482y0 = typedArrayObtainStyledAttributes.getBoolean(index, true);
                } else if (index == 27) {
                    this.f6330q.f15483z0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.d = this.f6330q;
        k();
    }

    @Override // z.AbstractC1686b
    public final void i(i iVar, C1539j c1539j, o oVar, SparseArray sparseArray) {
        super.i(iVar, c1539j, oVar, sparseArray);
        if (c1539j instanceof C1530a) {
            C1530a c1530a = (C1530a) c1539j;
            boolean z3 = ((C1535f) c1539j.f15530V).f15579A0;
            j jVar = iVar.f16541e;
            l(c1530a, jVar.f16580g0, z3);
            c1530a.f15482y0 = jVar.f16596o0;
            c1530a.f15483z0 = jVar.f16582h0;
        }
    }

    @Override // z.AbstractC1686b
    public final void j(C1534e c1534e, boolean z3) {
        l(c1534e, this.f6328o, z3);
    }

    public final void l(C1534e c1534e, int i10, boolean z3) {
        this.f6329p = i10;
        if (z3) {
            int i11 = this.f6328o;
            if (i11 == 5) {
                this.f6329p = 1;
            } else if (i11 == 6) {
                this.f6329p = 0;
            }
        } else {
            int i12 = this.f6328o;
            if (i12 == 5) {
                this.f6329p = 0;
            } else if (i12 == 6) {
                this.f6329p = 1;
            }
        }
        if (c1534e instanceof C1530a) {
            ((C1530a) c1534e).f15481x0 = this.f6329p;
        }
    }

    public void setAllowsGoneWidget(boolean z3) {
        this.f6330q.f15482y0 = z3;
    }

    public void setDpMargin(int i10) {
        this.f6330q.f15483z0 = (int) ((i10 * getResources().getDisplayMetrics().density) + 0.5f);
    }

    public void setMargin(int i10) {
        this.f6330q.f15483z0 = i10;
    }

    public void setType(int i10) {
        this.f6328o = i10;
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }
}
