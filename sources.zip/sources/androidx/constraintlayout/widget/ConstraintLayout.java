package androidx.constraintlayout.widget;

import E5.x;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.common.api.f;
import com.google.android.gms.dynamite.descriptors.com.google.firebase.auth.ModuleDescriptor;
import d0.i;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParserException;
import v.C1534e;
import v.C1535f;
import v.C1538i;
import v.C1539j;
import z.AbstractC1686b;
import z.c;
import z.d;
import z.e;
import z.n;
import z.p;
import z.q;
import z.s;
import z.t;

/* loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {

    /* renamed from: y */
    public static t f6331y;

    /* renamed from: a */
    public final SparseArray f6332a;

    /* renamed from: b */
    public final ArrayList f6333b;

    /* renamed from: c */
    public final C1535f f6334c;
    public int d;

    /* renamed from: e */
    public int f6335e;

    /* renamed from: f */
    public int f6336f;

    /* renamed from: n */
    public int f6337n;

    /* renamed from: o */
    public boolean f6338o;

    /* renamed from: p */
    public int f6339p;

    /* renamed from: q */
    public n f6340q;

    /* renamed from: r */
    public x f6341r;

    /* renamed from: s */
    public int f6342s;

    /* renamed from: t */
    public HashMap f6343t;

    /* renamed from: u */
    public final SparseArray f6344u;

    /* renamed from: v */
    public final e f6345v;

    /* renamed from: w */
    public int f6346w;

    /* renamed from: x */
    public int f6347x;

    public ConstraintLayout(Context context, AttributeSet attributeSet) throws XmlPullParserException, IOException {
        super(context, attributeSet);
        this.f6332a = new SparseArray();
        this.f6333b = new ArrayList(4);
        this.f6334c = new C1535f();
        this.d = 0;
        this.f6335e = 0;
        this.f6336f = f.API_PRIORITY_OTHER;
        this.f6337n = f.API_PRIORITY_OTHER;
        this.f6338o = true;
        this.f6339p = 257;
        this.f6340q = null;
        this.f6341r = null;
        this.f6342s = -1;
        this.f6343t = new HashMap();
        this.f6344u = new SparseArray();
        this.f6345v = new e(this, this);
        this.f6346w = 0;
        this.f6347x = 0;
        i(attributeSet, 0);
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingRight()) + Math.max(0, getPaddingLeft());
        int iMax2 = Math.max(0, getPaddingEnd()) + Math.max(0, getPaddingStart());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    public static t getSharedValues() {
        if (f6331y == null) {
            t tVar = new t();
            new SparseIntArray();
            tVar.f16662a = new HashMap();
            f6331y = tVar;
        }
        return f6331y;
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof d;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList arrayList = this.f6333b;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i10 = 0; i10 < size; i10++) {
                ((AbstractC1686b) arrayList.get(i10)).getClass();
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            float width = getWidth();
            float height = getHeight();
            int childCount = getChildCount();
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i12 = Integer.parseInt(strArrSplit[0]);
                        int i13 = Integer.parseInt(strArrSplit[1]);
                        int i14 = Integer.parseInt(strArrSplit[2]);
                        int i15 = (int) ((i12 / 1080.0f) * width);
                        int i16 = (int) ((i13 / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f10 = i15;
                        float f11 = i16;
                        float f12 = i15 + ((int) ((i14 / 1080.0f) * width));
                        canvas.drawLine(f10, f11, f12, f11, paint);
                        float f13 = i16 + ((int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height));
                        canvas.drawLine(f12, f11, f12, f13, paint);
                        canvas.drawLine(f12, f13, f10, f13, paint);
                        canvas.drawLine(f10, f13, f10, f11, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f10, f11, f12, f13, paint);
                        canvas.drawLine(f10, f13, f12, f11, paint);
                    }
                }
            }
        }
    }

    @Override // android.view.View
    public final void forceLayout() {
        this.f6338o = true;
        super.forceLayout();
    }

    /* JADX WARN: Removed duplicated region for block: B:341:0x02b9  */
    /* JADX WARN: Removed duplicated region for block: B:344:0x02be  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:341:0x02b9 -> B:342:0x02ba). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void g(boolean r19, android.view.View r20, v.C1534e r21, z.d r22, android.util.SparseArray r23) {
        /*
            Method dump skipped, instructions count: 806
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.g(boolean, android.view.View, v.e, z.d, android.util.SparseArray):void");
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new d();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        d dVar = new d(context, attributeSet);
        dVar.f16475a = -1;
        dVar.f16477b = -1;
        dVar.f16479c = -1.0f;
        dVar.d = true;
        dVar.f16481e = -1;
        dVar.f16483f = -1;
        dVar.g = -1;
        dVar.f16486h = -1;
        dVar.f16488i = -1;
        dVar.f16490j = -1;
        dVar.f16492k = -1;
        dVar.f16494l = -1;
        dVar.f16496m = -1;
        dVar.f16498n = -1;
        dVar.f16500o = -1;
        dVar.f16502p = -1;
        dVar.f16504q = 0;
        dVar.f16505r = 0.0f;
        dVar.f16506s = -1;
        dVar.f16507t = -1;
        dVar.f16508u = -1;
        dVar.f16509v = -1;
        dVar.f16510w = Integer.MIN_VALUE;
        dVar.f16511x = Integer.MIN_VALUE;
        dVar.f16512y = Integer.MIN_VALUE;
        dVar.f16513z = Integer.MIN_VALUE;
        dVar.f16450A = Integer.MIN_VALUE;
        dVar.f16451B = Integer.MIN_VALUE;
        dVar.f16452C = Integer.MIN_VALUE;
        dVar.f16453D = 0;
        dVar.f16454E = 0.5f;
        dVar.f16455F = 0.5f;
        dVar.f16456G = null;
        dVar.f16457H = -1.0f;
        dVar.f16458I = -1.0f;
        dVar.f16459J = 0;
        dVar.K = 0;
        dVar.f16460L = 0;
        dVar.f16461M = 0;
        dVar.f16462N = 0;
        dVar.f16463O = 0;
        dVar.f16464P = 0;
        dVar.f16465Q = 0;
        dVar.f16466R = 1.0f;
        dVar.f16467S = 1.0f;
        dVar.f16468T = -1;
        dVar.f16469U = -1;
        dVar.f16470V = -1;
        dVar.f16471W = false;
        dVar.f16472X = false;
        dVar.f16473Y = null;
        dVar.f16474Z = 0;
        dVar.f16476a0 = true;
        dVar.f16478b0 = true;
        dVar.c0 = false;
        dVar.f16480d0 = false;
        dVar.f16482e0 = false;
        dVar.f16484f0 = -1;
        dVar.f16485g0 = -1;
        dVar.f16487h0 = -1;
        dVar.f16489i0 = -1;
        dVar.f16491j0 = Integer.MIN_VALUE;
        dVar.f16493k0 = Integer.MIN_VALUE;
        dVar.f16495l0 = 0.5f;
        dVar.f16503p0 = new C1534e();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, s.f16647b);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i10);
            int i11 = c.f16449a.get(index);
            switch (i11) {
                case 1:
                    dVar.f16470V = typedArrayObtainStyledAttributes.getInt(index, dVar.f16470V);
                    break;
                case 2:
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16502p);
                    dVar.f16502p = resourceId;
                    if (resourceId == -1) {
                        dVar.f16502p = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 3:
                    dVar.f16504q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16504q);
                    break;
                case 4:
                    float f10 = typedArrayObtainStyledAttributes.getFloat(index, dVar.f16505r) % 360.0f;
                    dVar.f16505r = f10;
                    if (f10 < 0.0f) {
                        dVar.f16505r = (360.0f - f10) % 360.0f;
                        break;
                    } else {
                        break;
                    }
                case 5:
                    dVar.f16475a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.f16475a);
                    break;
                case i.STRING_SET_FIELD_NUMBER /* 6 */:
                    dVar.f16477b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.f16477b);
                    break;
                case i.DOUBLE_FIELD_NUMBER /* 7 */:
                    dVar.f16479c = typedArrayObtainStyledAttributes.getFloat(index, dVar.f16479c);
                    break;
                case 8:
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16481e);
                    dVar.f16481e = resourceId2;
                    if (resourceId2 == -1) {
                        dVar.f16481e = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 9:
                    int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16483f);
                    dVar.f16483f = resourceId3;
                    if (resourceId3 == -1) {
                        dVar.f16483f = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 10:
                    int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.g);
                    dVar.g = resourceId4;
                    if (resourceId4 == -1) {
                        dVar.g = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case ModuleDescriptor.MODULE_VERSION /* 11 */:
                    int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16486h);
                    dVar.f16486h = resourceId5;
                    if (resourceId5 == -1) {
                        dVar.f16486h = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 12:
                    int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16488i);
                    dVar.f16488i = resourceId6;
                    if (resourceId6 == -1) {
                        dVar.f16488i = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 13:
                    int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16490j);
                    dVar.f16490j = resourceId7;
                    if (resourceId7 == -1) {
                        dVar.f16490j = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 14:
                    int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16492k);
                    dVar.f16492k = resourceId8;
                    if (resourceId8 == -1) {
                        dVar.f16492k = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 15:
                    int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16494l);
                    dVar.f16494l = resourceId9;
                    if (resourceId9 == -1) {
                        dVar.f16494l = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 16:
                    int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16496m);
                    dVar.f16496m = resourceId10;
                    if (resourceId10 == -1) {
                        dVar.f16496m = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 17:
                    int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16506s);
                    dVar.f16506s = resourceId11;
                    if (resourceId11 == -1) {
                        dVar.f16506s = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 18:
                    int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16507t);
                    dVar.f16507t = resourceId12;
                    if (resourceId12 == -1) {
                        dVar.f16507t = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 19:
                    int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16508u);
                    dVar.f16508u = resourceId13;
                    if (resourceId13 == -1) {
                        dVar.f16508u = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 20:
                    int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16509v);
                    dVar.f16509v = resourceId14;
                    if (resourceId14 == -1) {
                        dVar.f16509v = typedArrayObtainStyledAttributes.getInt(index, -1);
                        break;
                    } else {
                        break;
                    }
                case 21:
                    dVar.f16510w = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16510w);
                    break;
                case 22:
                    dVar.f16511x = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16511x);
                    break;
                case 23:
                    dVar.f16512y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16512y);
                    break;
                case 24:
                    dVar.f16513z = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16513z);
                    break;
                case 25:
                    dVar.f16450A = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16450A);
                    break;
                case 26:
                    dVar.f16451B = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16451B);
                    break;
                case 27:
                    dVar.f16471W = typedArrayObtainStyledAttributes.getBoolean(index, dVar.f16471W);
                    break;
                case 28:
                    dVar.f16472X = typedArrayObtainStyledAttributes.getBoolean(index, dVar.f16472X);
                    break;
                case 29:
                    dVar.f16454E = typedArrayObtainStyledAttributes.getFloat(index, dVar.f16454E);
                    break;
                case 30:
                    dVar.f16455F = typedArrayObtainStyledAttributes.getFloat(index, dVar.f16455F);
                    break;
                case 31:
                    int i12 = typedArrayObtainStyledAttributes.getInt(index, 0);
                    dVar.f16460L = i12;
                    if (i12 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        break;
                    } else {
                        break;
                    }
                case 32:
                    int i13 = typedArrayObtainStyledAttributes.getInt(index, 0);
                    dVar.f16461M = i13;
                    if (i13 == 1) {
                        Log.e("ConstraintLayout", "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        break;
                    } else {
                        break;
                    }
                case 33:
                    try {
                        dVar.f16462N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16462N);
                        break;
                    } catch (Exception unused) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.f16462N) == -2) {
                            dVar.f16462N = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 34:
                    try {
                        dVar.f16464P = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16464P);
                        break;
                    } catch (Exception unused2) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.f16464P) == -2) {
                            dVar.f16464P = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 35:
                    dVar.f16466R = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, dVar.f16466R));
                    dVar.f16460L = 2;
                    break;
                case 36:
                    try {
                        dVar.f16463O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16463O);
                        break;
                    } catch (Exception unused3) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.f16463O) == -2) {
                            dVar.f16463O = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 37:
                    try {
                        dVar.f16465Q = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16465Q);
                        break;
                    } catch (Exception unused4) {
                        if (typedArrayObtainStyledAttributes.getInt(index, dVar.f16465Q) == -2) {
                            dVar.f16465Q = -2;
                            break;
                        } else {
                            break;
                        }
                    }
                case 38:
                    dVar.f16467S = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, dVar.f16467S));
                    dVar.f16461M = 2;
                    break;
                default:
                    switch (i11) {
                        case 44:
                            n.n(dVar, typedArrayObtainStyledAttributes.getString(index));
                            break;
                        case 45:
                            dVar.f16457H = typedArrayObtainStyledAttributes.getFloat(index, dVar.f16457H);
                            break;
                        case 46:
                            dVar.f16458I = typedArrayObtainStyledAttributes.getFloat(index, dVar.f16458I);
                            break;
                        case 47:
                            dVar.f16459J = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 48:
                            dVar.K = typedArrayObtainStyledAttributes.getInt(index, 0);
                            break;
                        case 49:
                            dVar.f16468T = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.f16468T);
                            break;
                        case 50:
                            dVar.f16469U = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, dVar.f16469U);
                            break;
                        case 51:
                            dVar.f16473Y = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 52:
                            int resourceId15 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16498n);
                            dVar.f16498n = resourceId15;
                            if (resourceId15 == -1) {
                                dVar.f16498n = typedArrayObtainStyledAttributes.getInt(index, -1);
                                break;
                            } else {
                                break;
                            }
                        case 53:
                            int resourceId16 = typedArrayObtainStyledAttributes.getResourceId(index, dVar.f16500o);
                            dVar.f16500o = resourceId16;
                            if (resourceId16 == -1) {
                                dVar.f16500o = typedArrayObtainStyledAttributes.getInt(index, -1);
                                break;
                            } else {
                                break;
                            }
                        case 54:
                            dVar.f16453D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16453D);
                            break;
                        case 55:
                            dVar.f16452C = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, dVar.f16452C);
                            break;
                        default:
                            switch (i11) {
                                case 64:
                                    n.m(dVar, typedArrayObtainStyledAttributes, index, 0);
                                    break;
                                case 65:
                                    n.m(dVar, typedArrayObtainStyledAttributes, index, 1);
                                    break;
                                case 66:
                                    dVar.f16474Z = typedArrayObtainStyledAttributes.getInt(index, dVar.f16474Z);
                                    break;
                                case 67:
                                    dVar.d = typedArrayObtainStyledAttributes.getBoolean(index, dVar.d);
                                    break;
                            }
                    }
            }
        }
        typedArrayObtainStyledAttributes.recycle();
        dVar.a();
        return dVar;
    }

    public int getMaxHeight() {
        return this.f6337n;
    }

    public int getMaxWidth() {
        return this.f6336f;
    }

    public int getMinHeight() {
        return this.f6335e;
    }

    public int getMinWidth() {
        return this.d;
    }

    public int getOptimizationLevel() {
        return this.f6334c.f15586I0;
    }

    public String getSceneString() {
        int id;
        StringBuilder sb = new StringBuilder();
        C1535f c1535f = this.f6334c;
        if (c1535f.f15550j == null) {
            int id2 = getId();
            if (id2 != -1) {
                c1535f.f15550j = getContext().getResources().getResourceEntryName(id2);
            } else {
                c1535f.f15550j = "parent";
            }
        }
        if (c1535f.f15553k0 == null) {
            c1535f.f15553k0 = c1535f.f15550j;
            Log.v("ConstraintLayout", " setDebugName " + c1535f.f15553k0);
        }
        Iterator it = c1535f.f15595v0.iterator();
        while (it.hasNext()) {
            C1534e c1534e = (C1534e) it.next();
            View view = (View) c1534e.f15547h0;
            if (view != null) {
                if (c1534e.f15550j == null && (id = view.getId()) != -1) {
                    c1534e.f15550j = getContext().getResources().getResourceEntryName(id);
                }
                if (c1534e.f15553k0 == null) {
                    c1534e.f15553k0 = c1534e.f15550j;
                    Log.v("ConstraintLayout", " setDebugName " + c1534e.f15553k0);
                }
            }
        }
        c1535f.o(sb);
        return sb.toString();
    }

    public final C1534e h(View view) {
        if (view == this) {
            return this.f6334c;
        }
        if (view == null) {
            return null;
        }
        if (view.getLayoutParams() instanceof d) {
            return ((d) view.getLayoutParams()).f16503p0;
        }
        view.setLayoutParams(generateLayoutParams(view.getLayoutParams()));
        if (view.getLayoutParams() instanceof d) {
            return ((d) view.getLayoutParams()).f16503p0;
        }
        return null;
    }

    public final void i(AttributeSet attributeSet, int i10) throws XmlPullParserException, IOException {
        C1535f c1535f = this.f6334c;
        c1535f.f15547h0 = this;
        e eVar = this.f6345v;
        c1535f.f15599z0 = eVar;
        c1535f.f15597x0.f15857f = eVar;
        this.f6332a.put(getId(), this);
        this.f6340q = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, s.f16647b, i10, 0);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i11);
                if (index == 16) {
                    this.d = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.d);
                } else if (index == 17) {
                    this.f6335e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f6335e);
                } else if (index == 14) {
                    this.f6336f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f6336f);
                } else if (index == 15) {
                    this.f6337n = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f6337n);
                } else if (index == 113) {
                    this.f6339p = typedArrayObtainStyledAttributes.getInt(index, this.f6339p);
                } else if (index == 56) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            k(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.f6341r = null;
                        }
                    }
                } else if (index == 34) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        n nVar = new n();
                        this.f6340q = nVar;
                        nVar.j(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.f6340q = null;
                    }
                    this.f6342s = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        c1535f.f15586I0 = this.f6339p;
        t.c.f14993p = c1535f.X(512);
    }

    public final boolean j() {
        return (getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection();
    }

    /* JADX WARN: Removed duplicated region for block: B:92:0x0079  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void k(int r11) throws org.xmlpull.v1.XmlPullParserException, android.content.res.Resources.NotFoundException, java.io.IOException {
        /*
            r10 = this;
            E5.x r0 = new E5.x
            android.content.Context r1 = r10.getContext()
            r0.<init>()
            r2 = -1
            r0.f816a = r2
            r0.f817b = r2
            android.util.SparseArray r3 = new android.util.SparseArray
            r3.<init>()
            r0.d = r3
            android.util.SparseArray r3 = new android.util.SparseArray
            r3.<init>()
            r0.f819e = r3
            r0.f818c = r10
            android.content.res.Resources r3 = r1.getResources()
            android.content.res.XmlResourceParser r11 = r3.getXml(r11)
            int r3 = r11.getEventType()     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            r4 = 0
        L2b:
            r5 = 1
            if (r3 == r5) goto Lb0
            if (r3 == 0) goto La1
            r6 = 2
            if (r3 == r6) goto L35
            goto La4
        L35:
            java.lang.String r3 = r11.getName()     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            int r7 = r3.hashCode()     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            r8 = 4
            r9 = 3
            switch(r7) {
                case -1349929691: goto L6f;
                case 80204913: goto L65;
                case 1382829617: goto L5c;
                case 1657696882: goto L52;
                case 1901439077: goto L43;
                default: goto L42;
            }     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
        L42:
            goto L79
        L43:
            java.lang.String r5 = "Variant"
            boolean r3 = r3.equals(r5)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            if (r3 == 0) goto L79
            r5 = r9
            goto L7a
        L4d:
            r11 = move-exception
            goto La9
        L4f:
            r11 = move-exception
            goto Lad
        L52:
            java.lang.String r5 = "layoutDescription"
            boolean r3 = r3.equals(r5)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            if (r3 == 0) goto L79
            r5 = 0
            goto L7a
        L5c:
            java.lang.String r7 = "StateSet"
            boolean r3 = r3.equals(r7)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            if (r3 == 0) goto L79
            goto L7a
        L65:
            java.lang.String r5 = "State"
            boolean r3 = r3.equals(r5)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            if (r3 == 0) goto L79
            r5 = r6
            goto L7a
        L6f:
            java.lang.String r5 = "ConstraintSet"
            boolean r3 = r3.equals(r5)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            if (r3 == 0) goto L79
            r5 = r8
            goto L7a
        L79:
            r5 = r2
        L7a:
            if (r5 == r6) goto L92
            if (r5 == r9) goto L85
            if (r5 == r8) goto L81
            goto La4
        L81:
            r0.g(r1, r11)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            goto La4
        L85:
            z.g r3 = new z.g     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            r3.<init>(r1, r11)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            if (r4 == 0) goto La4
            java.util.ArrayList r5 = r4.f16521b     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            r5.add(r3)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            goto La4
        L92:
            z.f r4 = new z.f     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            r4.<init>(r1, r11)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            java.lang.Object r3 = r0.d     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            android.util.SparseArray r3 = (android.util.SparseArray) r3     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            int r5 = r4.f16520a     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            r3.put(r5, r4)     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            goto La4
        La1:
            r11.getName()     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
        La4:
            int r3 = r11.next()     // Catch: java.io.IOException -> L4d org.xmlpull.v1.XmlPullParserException -> L4f
            goto L2b
        La9:
            r11.printStackTrace()
            goto Lb0
        Lad:
            r11.printStackTrace()
        Lb0:
            r10.f6341r = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.k(int):void");
    }

    public final void l(int i10, int i11, int i12, int i13, boolean z3, boolean z9) {
        e eVar = this.f6345v;
        int i14 = eVar.f16517e;
        int iResolveSizeAndState = View.resolveSizeAndState(i12 + eVar.d, i10, 0);
        int iResolveSizeAndState2 = View.resolveSizeAndState(i13 + i14, i11, 0) & 16777215;
        int iMin = Math.min(this.f6336f, iResolveSizeAndState & 16777215);
        int iMin2 = Math.min(this.f6337n, iResolveSizeAndState2);
        if (z3) {
            iMin |= 16777216;
        }
        if (z9) {
            iMin2 |= 16777216;
        }
        setMeasuredDimension(iMin, iMin2);
    }

    /* JADX WARN: Removed duplicated region for block: B:458:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:467:0x00dc  */
    /* JADX WARN: Removed duplicated region for block: B:473:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:477:0x00fe  */
    /* JADX WARN: Removed duplicated region for block: B:480:0x012a  */
    /* JADX WARN: Removed duplicated region for block: B:481:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:484:0x0134  */
    /* JADX WARN: Removed duplicated region for block: B:485:0x0137  */
    /* JADX WARN: Removed duplicated region for block: B:488:0x015c  */
    /* JADX WARN: Removed duplicated region for block: B:492:0x0165  */
    /* JADX WARN: Removed duplicated region for block: B:495:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:531:0x01c6 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:532:0x01c8 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:537:0x01d0  */
    /* JADX WARN: Removed duplicated region for block: B:649:0x0449  */
    /* JADX WARN: Removed duplicated region for block: B:651:0x045b  */
    /* JADX WARN: Removed duplicated region for block: B:655:0x0462  */
    /* JADX WARN: Removed duplicated region for block: B:707:0x04f1 A[PHI: r13
  0x04f1: PHI (r13v22 boolean) = (r13v21 boolean), (r13v21 boolean), (r13v21 boolean), (r13v25 boolean) binds: [B:685:0x04c2, B:687:0x04c8, B:689:0x04cc, B:705:0x04ee] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:712:0x04fd  */
    /* JADX WARN: Removed duplicated region for block: B:713:0x0500  */
    /* JADX WARN: Removed duplicated region for block: B:723:0x0536  */
    /* JADX WARN: Removed duplicated region for block: B:726:0x054a  */
    /* JADX WARN: Removed duplicated region for block: B:728:0x054f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void m(v.C1535f r26, int r27, int r28, int r29) {
        /*
            Method dump skipped, instructions count: 1801
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.m(v.f, int, int, int):void");
    }

    public final void n(C1534e c1534e, d dVar, SparseArray sparseArray, int i10, int i11) {
        View view = (View) this.f6332a.get(i10);
        C1534e c1534e2 = (C1534e) sparseArray.get(i10);
        if (c1534e2 == null || view == null || !(view.getLayoutParams() instanceof d)) {
            return;
        }
        dVar.c0 = true;
        if (i11 == 6) {
            d dVar2 = (d) view.getLayoutParams();
            dVar2.c0 = true;
            dVar2.f16503p0.f15514E = true;
        }
        c1534e.j(6).b(c1534e2.j(i11), dVar.f16453D, dVar.f16452C, true);
        c1534e.f15514E = true;
        c1534e.j(3).j();
        c1534e.j(5).j();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            d dVar = (d) childAt.getLayoutParams();
            C1534e c1534e = dVar.f16503p0;
            if (childAt.getVisibility() != 8 || dVar.f16480d0 || dVar.f16482e0 || zIsInEditMode) {
                int iS = c1534e.s();
                int iT = c1534e.t();
                childAt.layout(iS, iT, c1534e.r() + iS, c1534e.l() + iT);
            }
        }
        ArrayList arrayList = this.f6333b;
        int size = arrayList.size();
        if (size > 0) {
            for (int i15 = 0; i15 < size; i15++) {
                ((AbstractC1686b) arrayList.get(i15)).getClass();
            }
        }
    }

    @Override // android.view.View
    public void onMeasure(int i10, int i11) {
        boolean z3;
        C1534e c1534e;
        if (this.f6346w == i10) {
            int i12 = this.f6347x;
        }
        int i13 = 0;
        if (!this.f6338o) {
            int childCount = getChildCount();
            int i14 = 0;
            while (true) {
                if (i14 >= childCount) {
                    break;
                }
                if (getChildAt(i14).isLayoutRequested()) {
                    this.f6338o = true;
                    break;
                }
                i14++;
            }
        }
        this.f6346w = i10;
        this.f6347x = i11;
        boolean zJ = j();
        C1535f c1535f = this.f6334c;
        c1535f.f15579A0 = zJ;
        if (this.f6338o) {
            this.f6338o = false;
            int childCount2 = getChildCount();
            int i15 = 0;
            while (true) {
                if (i15 >= childCount2) {
                    z3 = false;
                    break;
                } else {
                    if (getChildAt(i15).isLayoutRequested()) {
                        z3 = true;
                        break;
                    }
                    i15++;
                }
            }
            if (z3) {
                boolean zIsInEditMode = isInEditMode();
                int childCount3 = getChildCount();
                for (int i16 = 0; i16 < childCount3; i16++) {
                    C1534e c1534eH = h(getChildAt(i16));
                    if (c1534eH != null) {
                        c1534eH.D();
                    }
                }
                Object obj = null;
                if (zIsInEditMode) {
                    for (int i17 = 0; i17 < childCount3; i17++) {
                        View childAt = getChildAt(i17);
                        try {
                            String resourceName = getResources().getResourceName(childAt.getId());
                            Integer numValueOf = Integer.valueOf(childAt.getId());
                            if (resourceName instanceof String) {
                                if (this.f6343t == null) {
                                    this.f6343t = new HashMap();
                                }
                                int iIndexOf = resourceName.indexOf("/");
                                this.f6343t.put(iIndexOf != -1 ? resourceName.substring(iIndexOf + 1) : resourceName, numValueOf);
                            }
                            int iIndexOf2 = resourceName.indexOf(47);
                            if (iIndexOf2 != -1) {
                                resourceName = resourceName.substring(iIndexOf2 + 1);
                            }
                            int id = childAt.getId();
                            if (id != 0) {
                                View viewFindViewById = (View) this.f6332a.get(id);
                                if (viewFindViewById == null && (viewFindViewById = findViewById(id)) != null && viewFindViewById != this && viewFindViewById.getParent() == this) {
                                    onViewAdded(viewFindViewById);
                                }
                                if (viewFindViewById == this) {
                                    c1534e = c1535f;
                                    c1534e.f15553k0 = resourceName;
                                } else {
                                    c1534e = viewFindViewById == null ? null : ((d) viewFindViewById.getLayoutParams()).f16503p0;
                                    c1534e.f15553k0 = resourceName;
                                }
                            } else {
                                c1534e = c1535f;
                                c1534e.f15553k0 = resourceName;
                            }
                        } catch (Resources.NotFoundException unused) {
                        }
                    }
                }
                if (this.f6342s != -1) {
                    for (int i18 = 0; i18 < childCount3; i18++) {
                        getChildAt(i18).getId();
                    }
                }
                n nVar = this.f6340q;
                if (nVar != null) {
                    nVar.c(this);
                }
                c1535f.f15595v0.clear();
                ArrayList arrayList = this.f6333b;
                int size = arrayList.size();
                if (size > 0) {
                    int i19 = 0;
                    while (i19 < size) {
                        AbstractC1686b abstractC1686b = (AbstractC1686b) arrayList.get(i19);
                        if (abstractC1686b.isInEditMode()) {
                            abstractC1686b.setIds(abstractC1686b.f16446e);
                        }
                        C1539j c1539j = abstractC1686b.d;
                        if (c1539j != null) {
                            c1539j.f15647w0 = i13;
                            Arrays.fill(c1539j.f15646v0, obj);
                            for (int i20 = i13; i20 < abstractC1686b.f16444b; i20++) {
                                int i21 = abstractC1686b.f16443a[i20];
                                View view = (View) this.f6332a.get(i21);
                                if (view == null) {
                                    Integer numValueOf2 = Integer.valueOf(i21);
                                    HashMap map = abstractC1686b.f16448n;
                                    String str = (String) map.get(numValueOf2);
                                    int iF = abstractC1686b.f(this, str);
                                    if (iF != 0) {
                                        abstractC1686b.f16443a[i20] = iF;
                                        map.put(Integer.valueOf(iF), str);
                                        view = (View) this.f6332a.get(iF);
                                    }
                                }
                                if (view != null) {
                                    abstractC1686b.d.S(h(view));
                                }
                            }
                            abstractC1686b.d.U();
                        }
                        i19++;
                        obj = null;
                        i13 = 0;
                    }
                }
                for (int i22 = 0; i22 < childCount3; i22++) {
                    getChildAt(i22);
                }
                SparseArray sparseArray = this.f6344u;
                sparseArray.clear();
                sparseArray.put(0, c1535f);
                sparseArray.put(getId(), c1535f);
                for (int i23 = 0; i23 < childCount3; i23++) {
                    View childAt2 = getChildAt(i23);
                    sparseArray.put(childAt2.getId(), h(childAt2));
                }
                for (int i24 = 0; i24 < childCount3; i24++) {
                    View childAt3 = getChildAt(i24);
                    C1534e c1534eH2 = h(childAt3);
                    if (c1534eH2 != null) {
                        d dVar = (d) childAt3.getLayoutParams();
                        c1535f.f15595v0.add(c1534eH2);
                        C1534e c1534e2 = c1534eH2.f15530V;
                        if (c1534e2 != null) {
                            ((C1535f) c1534e2).f15595v0.remove(c1534eH2);
                            c1534eH2.D();
                        }
                        c1534eH2.f15530V = c1535f;
                        g(zIsInEditMode, childAt3, c1534eH2, dVar, sparseArray);
                    }
                }
            }
            if (z3) {
                c1535f.f15596w0.m(c1535f);
            }
        }
        m(c1535f, this.f6339p, i10, i11);
        l(i10, i11, c1535f.r(), c1535f.l(), c1535f.f15587J0, c1535f.f15588K0);
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        C1534e c1534eH = h(view);
        if ((view instanceof q) && !(c1534eH instanceof C1538i)) {
            d dVar = (d) view.getLayoutParams();
            C1538i c1538i = new C1538i();
            dVar.f16503p0 = c1538i;
            dVar.f16480d0 = true;
            c1538i.T(dVar.f16470V);
        }
        if (view instanceof AbstractC1686b) {
            AbstractC1686b abstractC1686b = (AbstractC1686b) view;
            abstractC1686b.k();
            ((d) view.getLayoutParams()).f16482e0 = true;
            ArrayList arrayList = this.f6333b;
            if (!arrayList.contains(abstractC1686b)) {
                arrayList.add(abstractC1686b);
            }
        }
        this.f6332a.put(view.getId(), view);
        this.f6338o = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f6332a.remove(view.getId());
        C1534e c1534eH = h(view);
        this.f6334c.f15595v0.remove(c1534eH);
        c1534eH.D();
        this.f6333b.remove(view);
        this.f6338o = true;
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        this.f6338o = true;
        super.requestLayout();
    }

    public void setConstraintSet(n nVar) {
        this.f6340q = nVar;
    }

    @Override // android.view.View
    public void setId(int i10) {
        int id = getId();
        SparseArray sparseArray = this.f6332a;
        sparseArray.remove(id);
        super.setId(i10);
        sparseArray.put(getId(), this);
    }

    public void setMaxHeight(int i10) {
        if (i10 == this.f6337n) {
            return;
        }
        this.f6337n = i10;
        requestLayout();
    }

    public void setMaxWidth(int i10) {
        if (i10 == this.f6336f) {
            return;
        }
        this.f6336f = i10;
        requestLayout();
    }

    public void setMinHeight(int i10) {
        if (i10 == this.f6335e) {
            return;
        }
        this.f6335e = i10;
        requestLayout();
    }

    public void setMinWidth(int i10) {
        if (i10 == this.d) {
            return;
        }
        this.d = i10;
        requestLayout();
    }

    public void setOnConstraintsChanged(p pVar) {
        x xVar = this.f6341r;
        if (xVar != null) {
            xVar.getClass();
        }
    }

    public void setOptimizationLevel(int i10) {
        this.f6339p = i10;
        C1535f c1535f = this.f6334c;
        c1535f.f15586I0 = i10;
        t.c.f14993p = c1535f.X(512);
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i10) throws XmlPullParserException, IOException {
        super(context, attributeSet, i10);
        this.f6332a = new SparseArray();
        this.f6333b = new ArrayList(4);
        this.f6334c = new C1535f();
        this.d = 0;
        this.f6335e = 0;
        this.f6336f = f.API_PRIORITY_OTHER;
        this.f6337n = f.API_PRIORITY_OTHER;
        this.f6338o = true;
        this.f6339p = 257;
        this.f6340q = null;
        this.f6341r = null;
        this.f6342s = -1;
        this.f6343t = new HashMap();
        this.f6344u = new SparseArray();
        this.f6345v = new e(this, this);
        this.f6346w = 0;
        this.f6347x = 0;
        i(attributeSet, i10);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        d dVar = new d(layoutParams);
        dVar.f16475a = -1;
        dVar.f16477b = -1;
        dVar.f16479c = -1.0f;
        dVar.d = true;
        dVar.f16481e = -1;
        dVar.f16483f = -1;
        dVar.g = -1;
        dVar.f16486h = -1;
        dVar.f16488i = -1;
        dVar.f16490j = -1;
        dVar.f16492k = -1;
        dVar.f16494l = -1;
        dVar.f16496m = -1;
        dVar.f16498n = -1;
        dVar.f16500o = -1;
        dVar.f16502p = -1;
        dVar.f16504q = 0;
        dVar.f16505r = 0.0f;
        dVar.f16506s = -1;
        dVar.f16507t = -1;
        dVar.f16508u = -1;
        dVar.f16509v = -1;
        dVar.f16510w = Integer.MIN_VALUE;
        dVar.f16511x = Integer.MIN_VALUE;
        dVar.f16512y = Integer.MIN_VALUE;
        dVar.f16513z = Integer.MIN_VALUE;
        dVar.f16450A = Integer.MIN_VALUE;
        dVar.f16451B = Integer.MIN_VALUE;
        dVar.f16452C = Integer.MIN_VALUE;
        dVar.f16453D = 0;
        dVar.f16454E = 0.5f;
        dVar.f16455F = 0.5f;
        dVar.f16456G = null;
        dVar.f16457H = -1.0f;
        dVar.f16458I = -1.0f;
        dVar.f16459J = 0;
        dVar.K = 0;
        dVar.f16460L = 0;
        dVar.f16461M = 0;
        dVar.f16462N = 0;
        dVar.f16463O = 0;
        dVar.f16464P = 0;
        dVar.f16465Q = 0;
        dVar.f16466R = 1.0f;
        dVar.f16467S = 1.0f;
        dVar.f16468T = -1;
        dVar.f16469U = -1;
        dVar.f16470V = -1;
        dVar.f16471W = false;
        dVar.f16472X = false;
        dVar.f16473Y = null;
        dVar.f16474Z = 0;
        dVar.f16476a0 = true;
        dVar.f16478b0 = true;
        dVar.c0 = false;
        dVar.f16480d0 = false;
        dVar.f16482e0 = false;
        dVar.f16484f0 = -1;
        dVar.f16485g0 = -1;
        dVar.f16487h0 = -1;
        dVar.f16489i0 = -1;
        dVar.f16491j0 = Integer.MIN_VALUE;
        dVar.f16493k0 = Integer.MIN_VALUE;
        dVar.f16495l0 = 0.5f;
        dVar.f16503p0 = new C1534e();
        return dVar;
    }
}
