package androidx.constraintlayout.core.parser;

/* loaded from: classes.dex */
public class CLParsingException extends Exception {
    @Override // java.lang.Throwable
    public final String toString() {
        return "CLParsingException (" + hashCode() + ") : null (null at line 0)";
    }
}
