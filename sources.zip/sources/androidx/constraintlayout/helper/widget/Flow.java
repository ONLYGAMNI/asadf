package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import v.AbstractC1542m;
import v.C1534e;
import v.C1537h;
import v.C1539j;
import z.i;
import z.o;
import z.s;
import z.w;

/* loaded from: classes.dex */
public class Flow extends w {

    /* renamed from: q, reason: collision with root package name */
    public C1537h f6272q;

    public Flow(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override // z.w, z.AbstractC1686b
    public final void h(AttributeSet attributeSet) throws IllegalAccessException, Resources.NotFoundException, IllegalArgumentException {
        super.h(attributeSet);
        this.f6272q = new C1537h();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, s.f16647b);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 0) {
                    this.f6272q.a1 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 1) {
                    C1537h c1537h = this.f6272q;
                    int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    c1537h.f15656x0 = dimensionPixelSize;
                    c1537h.f15657y0 = dimensionPixelSize;
                    c1537h.f15658z0 = dimensionPixelSize;
                    c1537h.f15649A0 = dimensionPixelSize;
                } else if (index == 18) {
                    C1537h c1537h2 = this.f6272q;
                    int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                    c1537h2.f15658z0 = dimensionPixelSize2;
                    c1537h2.f15650B0 = dimensionPixelSize2;
                    c1537h2.f15651C0 = dimensionPixelSize2;
                } else if (index == 19) {
                    this.f6272q.f15649A0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 2) {
                    this.f6272q.f15650B0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 3) {
                    this.f6272q.f15656x0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 4) {
                    this.f6272q.f15651C0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 5) {
                    this.f6272q.f15657y0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 54) {
                    this.f6272q.f15632Y0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 44) {
                    this.f6272q.f15616I0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 53) {
                    this.f6272q.f15617J0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 38) {
                    this.f6272q.f15618K0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 46) {
                    this.f6272q.f15620M0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 40) {
                    this.f6272q.f15619L0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 48) {
                    this.f6272q.f15621N0 = typedArrayObtainStyledAttributes.getInt(index, 0);
                } else if (index == 42) {
                    this.f6272q.f15622O0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 37) {
                    this.f6272q.f15624Q0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 45) {
                    this.f6272q.f15626S0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 39) {
                    this.f6272q.f15625R0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 47) {
                    this.f6272q.f15627T0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 51) {
                    this.f6272q.f15623P0 = typedArrayObtainStyledAttributes.getFloat(index, 0.5f);
                } else if (index == 41) {
                    this.f6272q.f15630W0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 50) {
                    this.f6272q.f15631X0 = typedArrayObtainStyledAttributes.getInt(index, 2);
                } else if (index == 43) {
                    this.f6272q.f15628U0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 52) {
                    this.f6272q.f15629V0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0);
                } else if (index == 49) {
                    this.f6272q.f15633Z0 = typedArrayObtainStyledAttributes.getInt(index, -1);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.d = this.f6272q;
        k();
    }

    @Override // z.AbstractC1686b
    public final void i(i iVar, C1539j c1539j, o oVar, SparseArray sparseArray) {
        super.i(iVar, c1539j, oVar, sparseArray);
        if (c1539j instanceof C1537h) {
            C1537h c1537h = (C1537h) c1539j;
            int i10 = oVar.f16470V;
            if (i10 != -1) {
                c1537h.a1 = i10;
            }
        }
    }

    @Override // z.AbstractC1686b
    public final void j(C1534e c1534e, boolean z3) {
        C1537h c1537h = this.f6272q;
        int i10 = c1537h.f15658z0;
        if (i10 > 0 || c1537h.f15649A0 > 0) {
            if (z3) {
                c1537h.f15650B0 = c1537h.f15649A0;
                c1537h.f15651C0 = i10;
            } else {
                c1537h.f15650B0 = i10;
                c1537h.f15651C0 = c1537h.f15649A0;
            }
        }
    }

    @Override // z.w
    public final void l(AbstractC1542m abstractC1542m, int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (abstractC1542m == null) {
            setMeasuredDimension(0, 0);
        } else {
            abstractC1542m.V(mode, size, mode2, size2);
            setMeasuredDimension(abstractC1542m.f15653E0, abstractC1542m.f15654F0);
        }
    }

    @Override // z.AbstractC1686b, android.view.View
    public final void onMeasure(int i10, int i11) {
        l(this.f6272q, i10, i11);
    }

    public void setFirstHorizontalBias(float f10) {
        this.f6272q.f15624Q0 = f10;
        requestLayout();
    }

    public void setFirstHorizontalStyle(int i10) {
        this.f6272q.f15618K0 = i10;
        requestLayout();
    }

    public void setFirstVerticalBias(float f10) {
        this.f6272q.f15625R0 = f10;
        requestLayout();
    }

    public void setFirstVerticalStyle(int i10) {
        this.f6272q.f15619L0 = i10;
        requestLayout();
    }

    public void setHorizontalAlign(int i10) {
        this.f6272q.f15630W0 = i10;
        requestLayout();
    }

    public void setHorizontalBias(float f10) {
        this.f6272q.f15622O0 = f10;
        requestLayout();
    }

    public void setHorizontalGap(int i10) {
        this.f6272q.f15628U0 = i10;
        requestLayout();
    }

    public void setHorizontalStyle(int i10) {
        this.f6272q.f15616I0 = i10;
        requestLayout();
    }

    public void setLastHorizontalBias(float f10) {
        this.f6272q.f15626S0 = f10;
        requestLayout();
    }

    public void setLastHorizontalStyle(int i10) {
        this.f6272q.f15620M0 = i10;
        requestLayout();
    }

    public void setLastVerticalBias(float f10) {
        this.f6272q.f15627T0 = f10;
        requestLayout();
    }

    public void setLastVerticalStyle(int i10) {
        this.f6272q.f15621N0 = i10;
        requestLayout();
    }

    public void setMaxElementsWrap(int i10) {
        this.f6272q.f15633Z0 = i10;
        requestLayout();
    }

    public void setOrientation(int i10) {
        this.f6272q.a1 = i10;
        requestLayout();
    }

    public void setPadding(int i10) {
        C1537h c1537h = this.f6272q;
        c1537h.f15656x0 = i10;
        c1537h.f15657y0 = i10;
        c1537h.f15658z0 = i10;
        c1537h.f15649A0 = i10;
        requestLayout();
    }

    public void setPaddingBottom(int i10) {
        this.f6272q.f15657y0 = i10;
        requestLayout();
    }

    public void setPaddingLeft(int i10) {
        this.f6272q.f15650B0 = i10;
        requestLayout();
    }

    public void setPaddingRight(int i10) {
        this.f6272q.f15651C0 = i10;
        requestLayout();
    }

    public void setPaddingTop(int i10) {
        this.f6272q.f15656x0 = i10;
        requestLayout();
    }

    public void setVerticalAlign(int i10) {
        this.f6272q.f15631X0 = i10;
        requestLayout();
    }

    public void setVerticalBias(float f10) {
        this.f6272q.f15623P0 = f10;
        requestLayout();
    }

    public void setVerticalGap(int i10) {
        this.f6272q.f15629V0 = i10;
        requestLayout();
    }

    public void setVerticalStyle(int i10) {
        this.f6272q.f15617J0 = i10;
        requestLayout();
    }

    public void setWrapMode(int i10) {
        this.f6272q.f15632Y0 = i10;
        requestLayout();
    }
}
