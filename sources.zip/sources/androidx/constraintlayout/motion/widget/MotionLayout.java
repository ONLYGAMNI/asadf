package androidx.constraintlayout.motion.widget;

import E5.x;
import R.InterfaceC0259s;
import T4.a;
import X0.f;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.widget.NestedScrollView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import s2.AbstractC1397b;
import u.C1474b;
import u.C1477e;
import u.l;
import v.C1534e;
import v.C1535f;
import x.C1619a;
import y.C1656a;
import y.h;
import y.j;
import y.k;
import y.m;
import y.n;
import y.p;
import y.q;
import y.r;
import y.t;
import y.u;
import y.v;
import y.w;
import z.g;
import z.s;

/* loaded from: classes.dex */
public class MotionLayout extends ConstraintLayout implements InterfaceC0259s {

    /* renamed from: G0 */
    public static boolean f6273G0;

    /* renamed from: A */
    public k f6274A;

    /* renamed from: A0 */
    public r f6275A0;

    /* renamed from: B */
    public Interpolator f6276B;

    /* renamed from: B0 */
    public final a f6277B0;

    /* renamed from: C */
    public float f6278C;

    /* renamed from: C0 */
    public boolean f6279C0;

    /* renamed from: D */
    public int f6280D;

    /* renamed from: D0 */
    public final RectF f6281D0;

    /* renamed from: E */
    public int f6282E;

    /* renamed from: E0 */
    public View f6283E0;

    /* renamed from: F */
    public int f6284F;

    /* renamed from: F0 */
    public Matrix f6285F0;

    /* renamed from: G */
    public int f6286G;

    /* renamed from: H */
    public int f6287H;

    /* renamed from: I */
    public boolean f6288I;

    /* renamed from: J */
    public final HashMap f6289J;
    public long K;

    /* renamed from: L */
    public float f6290L;

    /* renamed from: M */
    public float f6291M;

    /* renamed from: N */
    public float f6292N;

    /* renamed from: O */
    public long f6293O;

    /* renamed from: P */
    public float f6294P;

    /* renamed from: Q */
    public boolean f6295Q;

    /* renamed from: R */
    public boolean f6296R;

    /* renamed from: S */
    public int f6297S;

    /* renamed from: T */
    public n f6298T;

    /* renamed from: U */
    public boolean f6299U;

    /* renamed from: V */
    public final C1619a f6300V;

    /* renamed from: W */
    public final m f6301W;

    /* renamed from: a0 */
    public C1656a f6302a0;

    /* renamed from: b0 */
    public int f6303b0;
    public int c0;

    /* renamed from: d0 */
    public boolean f6304d0;

    /* renamed from: e0 */
    public float f6305e0;

    /* renamed from: f0 */
    public float f6306f0;

    /* renamed from: g0 */
    public long f6307g0;

    /* renamed from: h0 */
    public float f6308h0;

    /* renamed from: i0 */
    public boolean f6309i0;

    /* renamed from: j0 */
    public int f6310j0;

    /* renamed from: k0 */
    public long f6311k0;

    /* renamed from: l0 */
    public float f6312l0;

    /* renamed from: m0 */
    public boolean f6313m0;

    /* renamed from: n0 */
    public int f6314n0;

    /* renamed from: o0 */
    public int f6315o0;

    /* renamed from: p0 */
    public int f6316p0;

    /* renamed from: q0 */
    public int f6317q0;

    /* renamed from: r0 */
    public int f6318r0;

    /* renamed from: s0 */
    public int f6319s0;

    /* renamed from: t0 */
    public float f6320t0;

    /* renamed from: u0 */
    public final C1477e f6321u0;

    /* renamed from: v0 */
    public boolean f6322v0;

    /* renamed from: w0 */
    public p f6323w0;

    /* renamed from: x0 */
    public Runnable f6324x0;

    /* renamed from: y0 */
    public final Rect f6325y0;

    /* renamed from: z */
    public v f6326z;

    /* renamed from: z0 */
    public boolean f6327z0;

    public MotionLayout(Context context, AttributeSet attributeSet) {
        v vVar;
        super(context, attributeSet);
        this.f6276B = null;
        this.f6278C = 0.0f;
        this.f6280D = -1;
        this.f6282E = -1;
        this.f6284F = -1;
        this.f6286G = 0;
        this.f6287H = 0;
        this.f6288I = true;
        this.f6289J = new HashMap();
        this.K = 0L;
        this.f6290L = 1.0f;
        this.f6291M = 0.0f;
        this.f6292N = 0.0f;
        this.f6294P = 0.0f;
        this.f6296R = false;
        this.f6297S = 0;
        this.f6299U = false;
        C1619a c1619a = new C1619a();
        l lVar = new l();
        lVar.f15234k = false;
        c1619a.f15952a = lVar;
        c1619a.f15954c = lVar;
        this.f6300V = c1619a;
        this.f6301W = new m(this);
        this.f6304d0 = false;
        this.f6309i0 = false;
        this.f6310j0 = 0;
        this.f6311k0 = -1L;
        this.f6312l0 = 0.0f;
        this.f6313m0 = false;
        this.f6321u0 = new C1477e(1);
        this.f6322v0 = false;
        this.f6324x0 = null;
        new HashMap();
        this.f6325y0 = new Rect();
        this.f6327z0 = false;
        this.f6275A0 = r.f16161a;
        a aVar = new a();
        aVar.g = this;
        aVar.f4618c = new C1535f();
        aVar.d = new C1535f();
        aVar.f4619e = null;
        aVar.f4620f = null;
        this.f6277B0 = aVar;
        this.f6279C0 = false;
        this.f6281D0 = new RectF();
        this.f6283E0 = null;
        this.f6285F0 = null;
        new ArrayList();
        f6273G0 = isInEditMode();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, s.g);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            boolean z3 = true;
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == 2) {
                    this.f6326z = new v(getContext(), this, typedArrayObtainStyledAttributes.getResourceId(index, -1));
                } else if (index == 1) {
                    this.f6282E = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                } else if (index == 4) {
                    this.f6294P = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                    this.f6296R = true;
                } else if (index == 0) {
                    z3 = typedArrayObtainStyledAttributes.getBoolean(index, z3);
                } else if (index == 5) {
                    if (this.f6297S == 0) {
                        this.f6297S = typedArrayObtainStyledAttributes.getBoolean(index, false) ? 2 : 0;
                    }
                } else if (index == 3) {
                    this.f6297S = typedArrayObtainStyledAttributes.getInt(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            if (this.f6326z == null) {
                Log.e("MotionLayout", "WARNING NO app:layoutDescription tag");
            }
            if (!z3) {
                this.f6326z = null;
            }
        }
        if (this.f6297S != 0) {
            v vVar2 = this.f6326z;
            if (vVar2 == null) {
                Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
            } else {
                int iG = vVar2.g();
                v vVar3 = this.f6326z;
                z.n nVarB = vVar3.b(vVar3.g());
                String strO = f.o(getContext(), iG);
                int childCount = getChildCount();
                for (int i11 = 0; i11 < childCount; i11++) {
                    View childAt = getChildAt(i11);
                    int id = childAt.getId();
                    if (id == -1) {
                        StringBuilder sbQ = android.support.v4.media.session.a.q("CHECK: ", strO, " ALL VIEWS SHOULD HAVE ID's ");
                        sbQ.append(childAt.getClass().getName());
                        sbQ.append(" does not!");
                        Log.w("MotionLayout", sbQ.toString());
                    }
                    if (nVarB.i(id) == null) {
                        StringBuilder sbQ2 = android.support.v4.media.session.a.q("CHECK: ", strO, " NO CONSTRAINTS for ");
                        sbQ2.append(f.p(childAt));
                        Log.w("MotionLayout", sbQ2.toString());
                    }
                }
                Integer[] numArr = (Integer[]) nVarB.f16644f.keySet().toArray(new Integer[0]);
                int length = numArr.length;
                int[] iArr = new int[length];
                for (int i12 = 0; i12 < length; i12++) {
                    iArr[i12] = numArr[i12].intValue();
                }
                for (int i13 = 0; i13 < length; i13++) {
                    int i14 = iArr[i13];
                    String strO2 = f.o(getContext(), i14);
                    if (findViewById(iArr[i13]) == null) {
                        Log.w("MotionLayout", "CHECK: " + strO + " NO View matches id " + strO2);
                    }
                    if (nVarB.h(i14).f16541e.d == -1) {
                        Log.w("MotionLayout", AbstractC1397b.c("CHECK: ", strO, "(", strO2, ") no LAYOUT_HEIGHT"));
                    }
                    if (nVarB.h(i14).f16541e.f16574c == -1) {
                        Log.w("MotionLayout", AbstractC1397b.c("CHECK: ", strO, "(", strO2, ") no LAYOUT_HEIGHT"));
                    }
                }
                SparseIntArray sparseIntArray = new SparseIntArray();
                SparseIntArray sparseIntArray2 = new SparseIntArray();
                Iterator it = this.f6326z.d.iterator();
                while (it.hasNext()) {
                    u uVar = (u) it.next();
                    if (uVar == this.f6326z.f16202c) {
                        Log.v("MotionLayout", "CHECK: CURRENT");
                    }
                    if (uVar.d == uVar.f16186c) {
                        Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!");
                    }
                    int i15 = uVar.d;
                    int i16 = uVar.f16186c;
                    String strO3 = f.o(getContext(), i15);
                    String strO4 = f.o(getContext(), i16);
                    if (sparseIntArray.get(i15) == i16) {
                        Log.e("MotionLayout", "CHECK: two transitions with the same start and end " + strO3 + "->" + strO4);
                    }
                    if (sparseIntArray2.get(i16) == i15) {
                        Log.e("MotionLayout", "CHECK: you can't have reverse transitions" + strO3 + "->" + strO4);
                    }
                    sparseIntArray.put(i15, i16);
                    sparseIntArray2.put(i16, i15);
                    if (this.f6326z.b(i15) == null) {
                        Log.e("MotionLayout", " no such constraintSetStart " + strO3);
                    }
                    if (this.f6326z.b(i16) == null) {
                        Log.e("MotionLayout", " no such constraintSetEnd " + strO3);
                    }
                }
            }
        }
        if (this.f6282E != -1 || (vVar = this.f6326z) == null) {
            return;
        }
        this.f6282E = vVar.g();
        this.f6280D = this.f6326z.g();
        u uVar2 = this.f6326z.f16202c;
        this.f6284F = uVar2 != null ? uVar2.f16186c : -1;
    }

    public static Rect o(MotionLayout motionLayout, C1534e c1534e) {
        motionLayout.getClass();
        int iT = c1534e.t();
        Rect rect = motionLayout.f6325y0;
        rect.top = iT;
        rect.left = c1534e.s();
        rect.right = c1534e.r() + rect.left;
        rect.bottom = c1534e.l() + rect.top;
        return rect;
    }

    public final void A(int i10) {
        G2.a aVar;
        if (!super.isAttachedToWindow()) {
            if (this.f6323w0 == null) {
                this.f6323w0 = new p(this);
            }
            this.f6323w0.d = i10;
            return;
        }
        v vVar = this.f6326z;
        if (vVar != null && (aVar = vVar.f16201b) != null) {
            int i11 = this.f6282E;
            float f10 = -1;
            z.u uVar = (z.u) ((SparseArray) aVar.f1387c).get(i10);
            if (uVar == null) {
                i11 = i10;
            } else {
                ArrayList arrayList = uVar.f16664b;
                int i12 = uVar.f16665c;
                if (f10 != -1.0f && f10 != -1.0f) {
                    Iterator it = arrayList.iterator();
                    z.v vVar2 = null;
                    while (true) {
                        if (it.hasNext()) {
                            z.v vVar3 = (z.v) it.next();
                            if (vVar3.a(f10, f10)) {
                                if (i11 == vVar3.f16669e) {
                                    break;
                                } else {
                                    vVar2 = vVar3;
                                }
                            }
                        } else if (vVar2 != null) {
                            i11 = vVar2.f16669e;
                        }
                    }
                } else if (i12 != i11) {
                    Iterator it2 = arrayList.iterator();
                    while (it2.hasNext()) {
                        if (i11 == ((z.v) it2.next()).f16669e) {
                            break;
                        }
                    }
                    i11 = i12;
                }
            }
            if (i11 != -1) {
                i10 = i11;
            }
        }
        int i13 = this.f6282E;
        if (i13 == i10) {
            return;
        }
        if (this.f6280D == i10) {
            p(0.0f);
            return;
        }
        if (this.f6284F == i10) {
            p(1.0f);
            return;
        }
        this.f6284F = i10;
        if (i13 != -1) {
            y(i13, i10);
            p(1.0f);
            this.f6292N = 0.0f;
            p(1.0f);
            this.f6324x0 = null;
            return;
        }
        this.f6299U = false;
        this.f6294P = 1.0f;
        this.f6291M = 0.0f;
        this.f6292N = 0.0f;
        this.f6293O = getNanoTime();
        this.K = getNanoTime();
        this.f6295Q = false;
        this.f6274A = null;
        v vVar4 = this.f6326z;
        this.f6290L = (vVar4.f16202c != null ? r6.f16189h : vVar4.f16207j) / 1000.0f;
        this.f6280D = -1;
        vVar4.m(-1, this.f6284F);
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        HashMap map = this.f6289J;
        map.clear();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            map.put(childAt, new j(childAt));
            sparseArray.put(childAt.getId(), (j) map.get(childAt));
        }
        this.f6296R = true;
        z.n nVarB = this.f6326z.b(i10);
        a aVar2 = this.f6277B0;
        aVar2.g(null, nVarB);
        v();
        aVar2.c();
        int childCount2 = getChildCount();
        for (int i15 = 0; i15 < childCount2; i15++) {
            View childAt2 = getChildAt(i15);
            j jVar = (j) map.get(childAt2);
            if (jVar != null) {
                y.s sVar = jVar.f16118f;
                sVar.f16168c = 0.0f;
                sVar.d = 0.0f;
                sVar.d(childAt2.getX(), childAt2.getY(), childAt2.getWidth(), childAt2.getHeight());
                h hVar = jVar.f16119h;
                hVar.getClass();
                childAt2.getX();
                childAt2.getY();
                childAt2.getWidth();
                childAt2.getHeight();
                hVar.f16091c = childAt2.getVisibility();
                hVar.f16089a = childAt2.getVisibility() != 0 ? 0.0f : childAt2.getAlpha();
                hVar.d = childAt2.getElevation();
                hVar.f16092e = childAt2.getRotation();
                hVar.f16093f = childAt2.getRotationX();
                hVar.f16094n = childAt2.getRotationY();
                hVar.f16095o = childAt2.getScaleX();
                hVar.f16096p = childAt2.getScaleY();
                hVar.f16097q = childAt2.getPivotX();
                hVar.f16098r = childAt2.getPivotY();
                hVar.f16099s = childAt2.getTranslationX();
                hVar.f16100t = childAt2.getTranslationY();
                hVar.f16101u = childAt2.getTranslationZ();
            }
        }
        getWidth();
        getHeight();
        for (int i16 = 0; i16 < childCount; i16++) {
            j jVar2 = (j) map.get(getChildAt(i16));
            if (jVar2 != null) {
                this.f6326z.e(jVar2);
                jVar2.f(getNanoTime());
            }
        }
        u uVar2 = this.f6326z.f16202c;
        float f11 = uVar2 != null ? uVar2.f16190i : 0.0f;
        if (f11 != 0.0f) {
            float fMin = Float.MAX_VALUE;
            float fMax = -3.4028235E38f;
            for (int i17 = 0; i17 < childCount; i17++) {
                y.s sVar2 = ((j) map.get(getChildAt(i17))).g;
                float f12 = sVar2.f16170f + sVar2.f16169e;
                fMin = Math.min(fMin, f12);
                fMax = Math.max(fMax, f12);
            }
            for (int i18 = 0; i18 < childCount; i18++) {
                j jVar3 = (j) map.get(getChildAt(i18));
                y.s sVar3 = jVar3.g;
                float f13 = sVar3.f16169e;
                float f14 = sVar3.f16170f;
                jVar3.f16125n = 1.0f / (1.0f - f11);
                jVar3.f16124m = f11 - ((((f13 + f14) - fMin) * f11) / (fMax - fMin));
            }
        }
        this.f6291M = 0.0f;
        this.f6292N = 0.0f;
        this.f6296R = true;
        invalidate();
    }

    public final void B(int i10, z.n nVar) {
        v vVar = this.f6326z;
        if (vVar != null) {
            vVar.g.put(i10, nVar);
        }
        this.f6277B0.g(this.f6326z.b(this.f6280D), this.f6326z.b(this.f6284F));
        v();
        if (this.f6282E == i10) {
            nVar.b(this);
        }
    }

    @Override // R.r
    public final void a(View view, View view2, int i10, int i11) {
        this.f6307g0 = getNanoTime();
        this.f6308h0 = 0.0f;
        this.f6305e0 = 0.0f;
        this.f6306f0 = 0.0f;
    }

    @Override // R.r
    public final void b(View view, int i10) {
        w wVar;
        v vVar = this.f6326z;
        if (vVar != null) {
            float f10 = this.f6308h0;
            if (f10 == 0.0f) {
                return;
            }
            float f11 = this.f6305e0 / f10;
            float f12 = this.f6306f0 / f10;
            u uVar = vVar.f16202c;
            if (uVar == null || (wVar = uVar.f16193l) == null) {
                return;
            }
            wVar.f16233m = false;
            MotionLayout motionLayout = wVar.f16238r;
            float progress = motionLayout.getProgress();
            wVar.f16238r.s(wVar.d, progress, wVar.f16228h, wVar.g, wVar.f16234n);
            float f13 = wVar.f16231k;
            float[] fArr = wVar.f16234n;
            float f14 = f13 != 0.0f ? (f11 * f13) / fArr[0] : (f12 * wVar.f16232l) / fArr[1];
            if (!Float.isNaN(f14)) {
                progress += f14 / 3.0f;
            }
            if (progress != 0.0f) {
                boolean z3 = progress != 1.0f;
                int i11 = wVar.f16225c;
                if ((i11 != 3) && z3) {
                    motionLayout.z(((double) progress) >= 0.5d ? 1.0f : 0.0f, f14, i11);
                }
            }
        }
    }

    /* JADX WARN: Type inference failed for: r1v3 */
    /* JADX WARN: Type inference failed for: r1v4, types: [boolean] */
    /* JADX WARN: Type inference failed for: r1v5 */
    @Override // R.r
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
        u uVar;
        boolean z3;
        ?? r12;
        w wVar;
        float f10;
        w wVar2;
        w wVar3;
        w wVar4;
        int i13;
        v vVar = this.f6326z;
        if (vVar == null || (uVar = vVar.f16202c) == null || !(!uVar.f16196o)) {
            return;
        }
        int i14 = -1;
        if (!z3 || (wVar4 = uVar.f16193l) == null || (i13 = wVar4.f16226e) == -1 || view.getId() == i13) {
            u uVar2 = vVar.f16202c;
            if ((uVar2 == null || (wVar3 = uVar2.f16193l) == null) ? false : wVar3.f16241u) {
                w wVar5 = uVar.f16193l;
                if (wVar5 != null && (wVar5.f16243w & 4) != 0) {
                    i14 = i11;
                }
                float f11 = this.f6291M;
                if ((f11 == 1.0f || f11 == 0.0f) && view.canScrollVertically(i14)) {
                    return;
                }
            }
            w wVar6 = uVar.f16193l;
            if (wVar6 != null && (wVar6.f16243w & 1) != 0) {
                float f12 = i10;
                float f13 = i11;
                u uVar3 = vVar.f16202c;
                if (uVar3 == null || (wVar2 = uVar3.f16193l) == null) {
                    f10 = 0.0f;
                } else {
                    wVar2.f16238r.s(wVar2.d, wVar2.f16238r.getProgress(), wVar2.f16228h, wVar2.g, wVar2.f16234n);
                    float f14 = wVar2.f16231k;
                    float[] fArr = wVar2.f16234n;
                    if (f14 != 0.0f) {
                        if (fArr[0] == 0.0f) {
                            fArr[0] = 1.0E-7f;
                        }
                        f10 = (f12 * f14) / fArr[0];
                    } else {
                        if (fArr[1] == 0.0f) {
                            fArr[1] = 1.0E-7f;
                        }
                        f10 = (f13 * wVar2.f16232l) / fArr[1];
                    }
                }
                float f15 = this.f6292N;
                if ((f15 <= 0.0f && f10 < 0.0f) || (f15 >= 1.0f && f10 > 0.0f)) {
                    view.setNestedScrollingEnabled(false);
                    view.post(new y.l(view, 0));
                    return;
                }
            }
            float f16 = this.f6291M;
            long nanoTime = getNanoTime();
            float f17 = i10;
            this.f6305e0 = f17;
            float f18 = i11;
            this.f6306f0 = f18;
            this.f6308h0 = (float) ((nanoTime - this.f6307g0) * 1.0E-9d);
            this.f6307g0 = nanoTime;
            u uVar4 = vVar.f16202c;
            if (uVar4 != null && (wVar = uVar4.f16193l) != null) {
                MotionLayout motionLayout = wVar.f16238r;
                float progress = motionLayout.getProgress();
                if (!wVar.f16233m) {
                    wVar.f16233m = true;
                    motionLayout.setProgress(progress);
                }
                wVar.f16238r.s(wVar.d, progress, wVar.f16228h, wVar.g, wVar.f16234n);
                float f19 = wVar.f16231k;
                float[] fArr2 = wVar.f16234n;
                if (Math.abs((wVar.f16232l * fArr2[1]) + (f19 * fArr2[0])) < 0.01d) {
                    fArr2[0] = 0.01f;
                    fArr2[1] = 0.01f;
                }
                float f20 = wVar.f16231k;
                float fMax = Math.max(Math.min(progress + (f20 != 0.0f ? (f17 * f20) / fArr2[0] : (f18 * wVar.f16232l) / fArr2[1]), 1.0f), 0.0f);
                if (fMax != motionLayout.getProgress()) {
                    motionLayout.setProgress(fMax);
                }
            }
            if (f16 != this.f6291M) {
                iArr[0] = i10;
                r12 = 1;
                iArr[1] = i11;
            } else {
                r12 = 1;
            }
            r(false);
            if (iArr[0] == 0 && iArr[r12] == 0) {
                return;
            }
            this.f6304d0 = r12;
        }
    }

    @Override // R.InterfaceC0259s
    public final void d(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        if (this.f6304d0 || i10 != 0 || i11 != 0) {
            iArr[0] = iArr[0] + i12;
            iArr[1] = iArr[1] + i13;
        }
        this.f6304d0 = false;
    }

    /*  JADX ERROR: NullPointerException in pass: LoopRegionVisitor
        java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.SSAVar.use(jadx.core.dex.instructions.args.RegisterArg)" because "ssaVar" is null
        	at jadx.core.dex.nodes.InsnNode.rebindArgs(InsnNode.java:493)
        	at jadx.core.dex.nodes.InsnNode.rebindArgs(InsnNode.java:496)
        */
    /* JADX WARN: Removed duplicated region for block: B:337:0x0301  */
    /* JADX WARN: Removed duplicated region for block: B:348:0x032c  */
    /* JADX WARN: Removed duplicated region for block: B:353:0x0349  */
    /* JADX WARN: Removed duplicated region for block: B:356:0x0359  */
    /* JADX WARN: Removed duplicated region for block: B:361:0x037c  */
    /* JADX WARN: Removed duplicated region for block: B:362:0x0386  */
    /* JADX WARN: Removed duplicated region for block: B:365:0x0393  */
    /* JADX WARN: Removed duplicated region for block: B:366:0x03a1  */
    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void dispatchDraw(android.graphics.Canvas r37) {
        /*
            Method dump skipped, instructions count: 1278
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.dispatchDraw(android.graphics.Canvas):void");
    }

    @Override // R.r
    public final void e(View view, int i10, int i11, int i12, int i13, int i14) {
    }

    @Override // R.r
    public final boolean f(View view, View view2, int i10, int i11) {
        u uVar;
        w wVar;
        v vVar = this.f6326z;
        return (vVar == null || (uVar = vVar.f16202c) == null || (wVar = uVar.f16193l) == null || (wVar.f16243w & 2) != 0) ? false : true;
    }

    public int[] getConstraintSetIds() {
        v vVar = this.f6326z;
        if (vVar == null) {
            return null;
        }
        SparseArray sparseArray = vVar.g;
        int size = sparseArray.size();
        int[] iArr = new int[size];
        for (int i10 = 0; i10 < size; i10++) {
            iArr[i10] = sparseArray.keyAt(i10);
        }
        return iArr;
    }

    public int getCurrentState() {
        return this.f6282E;
    }

    public ArrayList<u> getDefinedTransitions() {
        v vVar = this.f6326z;
        if (vVar == null) {
            return null;
        }
        return vVar.d;
    }

    public C1656a getDesignTool() {
        if (this.f6302a0 == null) {
            this.f6302a0 = new C1656a();
        }
        return this.f6302a0;
    }

    public int getEndState() {
        return this.f6284F;
    }

    public long getNanoTime() {
        return System.nanoTime();
    }

    public float getProgress() {
        return this.f6292N;
    }

    public v getScene() {
        return this.f6326z;
    }

    public int getStartState() {
        return this.f6280D;
    }

    public float getTargetPosition() {
        return this.f6294P;
    }

    public Bundle getTransitionState() {
        if (this.f6323w0 == null) {
            this.f6323w0 = new p(this);
        }
        p pVar = this.f6323w0;
        MotionLayout motionLayout = pVar.f16160e;
        pVar.d = motionLayout.f6284F;
        pVar.f16159c = motionLayout.f6280D;
        pVar.f16158b = motionLayout.getVelocity();
        pVar.f16157a = motionLayout.getProgress();
        p pVar2 = this.f6323w0;
        pVar2.getClass();
        Bundle bundle = new Bundle();
        bundle.putFloat("motion.progress", pVar2.f16157a);
        bundle.putFloat("motion.velocity", pVar2.f16158b);
        bundle.putInt("motion.StartState", pVar2.f16159c);
        bundle.putInt("motion.EndState", pVar2.d);
        return bundle;
    }

    public long getTransitionTimeMs() {
        v vVar = this.f6326z;
        if (vVar != null) {
            this.f6290L = (vVar.f16202c != null ? r2.f16189h : vVar.f16207j) / 1000.0f;
        }
        return (long) (this.f6290L * 1000.0f);
    }

    public float getVelocity() {
        return this.f6278C;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public final void k(int i10) {
        this.f6341r = null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        u uVar;
        int i10;
        super.onAttachedToWindow();
        Display display = getDisplay();
        if (display != null) {
            display.getRotation();
        }
        v vVar = this.f6326z;
        if (vVar != null && (i10 = this.f6282E) != -1) {
            z.n nVarB = vVar.b(i10);
            v vVar2 = this.f6326z;
            int i11 = 0;
            loop0: while (true) {
                SparseArray sparseArray = vVar2.g;
                if (i11 >= sparseArray.size()) {
                    break;
                }
                int iKeyAt = sparseArray.keyAt(i11);
                SparseIntArray sparseIntArray = vVar2.f16206i;
                int i12 = sparseIntArray.get(iKeyAt);
                int size = sparseIntArray.size();
                while (i12 > 0) {
                    if (i12 == iKeyAt) {
                        break loop0;
                    }
                    int i13 = size - 1;
                    if (size < 0) {
                        break loop0;
                    }
                    i12 = sparseIntArray.get(i12);
                    size = i13;
                }
                vVar2.l(iKeyAt, this);
                i11++;
            }
            Log.e("MotionScene", "Cannot be derived from yourself");
            if (nVarB != null) {
                nVarB.b(this);
            }
            this.f6280D = this.f6282E;
        }
        u();
        p pVar = this.f6323w0;
        if (pVar != null) {
            if (this.f6327z0) {
                post(new y.l(this, 1));
                return;
            } else {
                pVar.a();
                return;
            }
        }
        v vVar3 = this.f6326z;
        if (vVar3 == null || (uVar = vVar3.f16202c) == null || uVar.f16195n != 4) {
            return;
        }
        p(1.0f);
        this.f6324x0 = null;
        setState(r.f16162b);
        setState(r.f16163c);
    }

    /* JADX WARN: Removed duplicated region for block: B:286:0x00f2  */
    /* JADX WARN: Removed duplicated region for block: B:381:0x03eb  */
    @Override // android.view.ViewGroup
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onInterceptTouchEvent(android.view.MotionEvent r25) throws android.content.res.Resources.NotFoundException {
        /*
            Method dump skipped, instructions count: 1219
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        this.f6322v0 = true;
        try {
            if (this.f6326z == null) {
                super.onLayout(z3, i10, i11, i12, i13);
                return;
            }
            int i14 = i12 - i10;
            int i15 = i13 - i11;
            if (this.f6303b0 != i14 || this.c0 != i15) {
                v();
                r(true);
            }
            this.f6303b0 = i14;
            this.c0 = i15;
        } finally {
            this.f6322v0 = false;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        boolean z3;
        if (this.f6326z == null) {
            super.onMeasure(i10, i11);
            return;
        }
        boolean z9 = true;
        boolean z10 = (this.f6286G == i10 && this.f6287H == i11) ? false : true;
        if (this.f6279C0) {
            this.f6279C0 = false;
            u();
            z10 = true;
        }
        if (this.f6338o) {
            z10 = true;
        }
        this.f6286G = i10;
        this.f6287H = i11;
        int iG = this.f6326z.g();
        u uVar = this.f6326z.f16202c;
        int i12 = uVar == null ? -1 : uVar.f16186c;
        C1535f c1535f = this.f6334c;
        a aVar = this.f6277B0;
        if ((!z10 && iG == aVar.f4616a && i12 == aVar.f4617b) || this.f6280D == -1) {
            if (z10) {
                super.onMeasure(i10, i11);
            }
            z3 = true;
        } else {
            super.onMeasure(i10, i11);
            aVar.g(this.f6326z.b(iG), this.f6326z.b(i12));
            aVar.h();
            aVar.f4616a = iG;
            aVar.f4617b = i12;
            z3 = false;
        }
        if (this.f6313m0 || z3) {
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int iR = c1535f.r() + getPaddingRight() + getPaddingLeft();
            int iL = c1535f.l() + paddingBottom;
            int i13 = this.f6318r0;
            if (i13 == Integer.MIN_VALUE || i13 == 0) {
                iR = (int) ((this.f6320t0 * (this.f6316p0 - r1)) + this.f6314n0);
                requestLayout();
            }
            int i14 = this.f6319s0;
            if (i14 == Integer.MIN_VALUE || i14 == 0) {
                iL = (int) ((this.f6320t0 * (this.f6317q0 - r2)) + this.f6315o0);
                requestLayout();
            }
            setMeasuredDimension(iR, iL);
        }
        float fSignum = Math.signum(this.f6294P - this.f6292N);
        long nanoTime = getNanoTime();
        k kVar = this.f6274A;
        float interpolation = this.f6292N + (!(kVar instanceof C1619a) ? (((nanoTime - this.f6293O) * fSignum) * 1.0E-9f) / this.f6290L : 0.0f);
        if (this.f6295Q) {
            interpolation = this.f6294P;
        }
        if ((fSignum <= 0.0f || interpolation < this.f6294P) && (fSignum > 0.0f || interpolation > this.f6294P)) {
            z9 = false;
        } else {
            interpolation = this.f6294P;
        }
        if (kVar != null && !z9) {
            interpolation = this.f6299U ? kVar.getInterpolation((nanoTime - this.K) * 1.0E-9f) : kVar.getInterpolation(interpolation);
        }
        if ((fSignum > 0.0f && interpolation >= this.f6294P) || (fSignum <= 0.0f && interpolation <= this.f6294P)) {
            interpolation = this.f6294P;
        }
        this.f6320t0 = interpolation;
        int childCount = getChildCount();
        long nanoTime2 = getNanoTime();
        Interpolator interpolator = this.f6276B;
        if (interpolator != null) {
            interpolation = interpolator.getInterpolation(interpolation);
        }
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt = getChildAt(i15);
            j jVar = (j) this.f6289J.get(childAt);
            if (jVar != null) {
                jVar.c(interpolation, nanoTime2, childAt, this.f6321u0);
            }
        }
        if (this.f6313m0) {
            requestLayout();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i10) {
        w wVar;
        v vVar = this.f6326z;
        if (vVar != null) {
            boolean zJ = j();
            vVar.f16213p = zJ;
            u uVar = vVar.f16202c;
            if (uVar == null || (wVar = uVar.f16193l) == null) {
                return;
            }
            wVar.c(zJ);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:500:0x022c  */
    /* JADX WARN: Removed duplicated region for block: B:503:0x0232  */
    /* JADX WARN: Removed duplicated region for block: B:520:0x0263  */
    /* JADX WARN: Removed duplicated region for block: B:588:0x04be  */
    /* JADX WARN: Removed duplicated region for block: B:589:0x04e1  */
    /* JADX WARN: Removed duplicated region for block: B:592:0x04fb  */
    /* JADX WARN: Removed duplicated region for block: B:594:0x0509  */
    /* JADX WARN: Removed duplicated region for block: B:622:0x0567  */
    /* JADX WARN: Removed duplicated region for block: B:626:0x0572  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean onTouchEvent(android.view.MotionEvent r35) {
        /*
            Method dump skipped, instructions count: 2014
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final void p(float f10) {
        v vVar = this.f6326z;
        if (vVar == null) {
            return;
        }
        float f11 = this.f6292N;
        float f12 = this.f6291M;
        if (f11 != f12 && this.f6295Q) {
            this.f6292N = f12;
        }
        float f13 = this.f6292N;
        if (f13 == f10) {
            return;
        }
        this.f6299U = false;
        this.f6294P = f10;
        this.f6290L = (vVar.f16202c != null ? r3.f16189h : vVar.f16207j) / 1000.0f;
        setProgress(f10);
        this.f6274A = null;
        this.f6276B = this.f6326z.d();
        this.f6295Q = false;
        this.K = getNanoTime();
        this.f6296R = true;
        this.f6291M = f13;
        this.f6292N = f13;
        invalidate();
    }

    public final void q() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            j jVar = (j) this.f6289J.get(getChildAt(i10));
            if (jVar != null) {
                "button".equals(f.p(jVar.f16115b));
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:245:0x00e2 A[PHI: r3
  0x00e2: PHI (r3v16 float) = (r3v15 float), (r3v17 float), (r3v17 float) binds: [B:230:0x00ad, B:241:0x00d6, B:243:0x00da] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:255:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:258:0x0118  */
    /* JADX WARN: Removed duplicated region for block: B:273:0x014d  */
    /* JADX WARN: Removed duplicated region for block: B:274:0x014f  */
    /* JADX WARN: Removed duplicated region for block: B:277:0x0157  */
    /* JADX WARN: Removed duplicated region for block: B:280:0x016e  */
    /* JADX WARN: Removed duplicated region for block: B:295:0x01ae  */
    /* JADX WARN: Removed duplicated region for block: B:301:0x01bb  */
    /* JADX WARN: Removed duplicated region for block: B:304:0x01c8  */
    /* JADX WARN: Removed duplicated region for block: B:309:0x01e1  */
    /* JADX WARN: Removed duplicated region for block: B:312:0x01e9  */
    /* JADX WARN: Removed duplicated region for block: B:328:0x021b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void r(boolean r23) {
        /*
            Method dump skipped, instructions count: 623
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.r(boolean):void");
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View, android.view.ViewParent
    public final void requestLayout() {
        v vVar;
        u uVar;
        if (!this.f6313m0 && this.f6282E == -1 && (vVar = this.f6326z) != null && (uVar = vVar.f16202c) != null) {
            int i10 = uVar.f16198q;
            if (i10 == 0) {
                return;
            }
            if (i10 == 2) {
                int childCount = getChildCount();
                for (int i11 = 0; i11 < childCount; i11++) {
                    ((j) this.f6289J.get(getChildAt(i11))).d = true;
                }
                return;
            }
        }
        super.requestLayout();
    }

    public final void s(int i10, float f10, float f11, float f12, float[] fArr) {
        double[] dArr;
        HashMap map = this.f6289J;
        View view = (View) this.f6332a.get(i10);
        j jVar = (j) map.get(view);
        if (jVar == null) {
            Log.w("MotionLayout", "WARNING could not find view id " + (view == null ? android.support.v4.media.session.a.h(i10, "") : view.getContext().getResources().getResourceName(i10)));
            return;
        }
        float[] fArr2 = jVar.f16133v;
        float fA = jVar.a(f10, fArr2);
        O0.w[] wVarArr = jVar.f16121j;
        int i11 = 0;
        if (wVarArr != null) {
            double d = fA;
            wVarArr[0].q(d, jVar.f16128q);
            jVar.f16121j[0].n(d, jVar.f16127p);
            float f13 = fArr2[0];
            while (true) {
                dArr = jVar.f16128q;
                if (i11 >= dArr.length) {
                    break;
                }
                dArr[i11] = dArr[i11] * f13;
                i11++;
            }
            C1474b c1474b = jVar.f16122k;
            if (c1474b != null) {
                double[] dArr2 = jVar.f16127p;
                if (dArr2.length > 0) {
                    c1474b.n(d, dArr2);
                    jVar.f16122k.q(d, jVar.f16128q);
                    int[] iArr = jVar.f16126o;
                    double[] dArr3 = jVar.f16128q;
                    double[] dArr4 = jVar.f16127p;
                    jVar.f16118f.getClass();
                    y.s.e(f11, f12, fArr, iArr, dArr3, dArr4);
                }
            } else {
                int[] iArr2 = jVar.f16126o;
                double[] dArr5 = jVar.f16127p;
                jVar.f16118f.getClass();
                y.s.e(f11, f12, fArr, iArr2, dArr, dArr5);
            }
        } else {
            y.s sVar = jVar.g;
            float f14 = sVar.f16169e;
            y.s sVar2 = jVar.f16118f;
            float f15 = f14 - sVar2.f16169e;
            float f16 = sVar.f16170f - sVar2.f16170f;
            float f17 = sVar.f16171n - sVar2.f16171n;
            float f18 = (sVar.f16172o - sVar2.f16172o) + f16;
            fArr[0] = ((f17 + f15) * f11) + ((1.0f - f11) * f15);
            fArr[1] = (f18 * f12) + ((1.0f - f12) * f16);
        }
        view.getY();
    }

    public void setDebugMode(int i10) {
        this.f6297S = i10;
        invalidate();
    }

    public void setDelayedApplicationOfInitialState(boolean z3) {
        this.f6327z0 = z3;
    }

    public void setInteractionEnabled(boolean z3) {
        this.f6288I = z3;
    }

    public void setInterpolatedProgress(float f10) {
        if (this.f6326z != null) {
            setState(r.f16163c);
            Interpolator interpolatorD = this.f6326z.d();
            if (interpolatorD != null) {
                setProgress(interpolatorD.getInterpolation(f10));
                return;
            }
        }
        setProgress(f10);
    }

    public void setOnHide(float f10) {
    }

    public void setOnShow(float f10) {
    }

    public void setProgress(float f10) {
        if (f10 < 0.0f || f10 > 1.0f) {
            Log.w("MotionLayout", "Warning! Progress is defined for values between 0.0 and 1.0 inclusive");
        }
        if (!super.isAttachedToWindow()) {
            if (this.f6323w0 == null) {
                this.f6323w0 = new p(this);
            }
            this.f6323w0.f16157a = f10;
            return;
        }
        r rVar = r.d;
        r rVar2 = r.f16163c;
        if (f10 <= 0.0f) {
            if (this.f6292N == 1.0f && this.f6282E == this.f6284F) {
                setState(rVar2);
            }
            this.f6282E = this.f6280D;
            if (this.f6292N == 0.0f) {
                setState(rVar);
            }
        } else if (f10 >= 1.0f) {
            if (this.f6292N == 0.0f && this.f6282E == this.f6280D) {
                setState(rVar2);
            }
            this.f6282E = this.f6284F;
            if (this.f6292N == 1.0f) {
                setState(rVar);
            }
        } else {
            this.f6282E = -1;
            setState(rVar2);
        }
        if (this.f6326z == null) {
            return;
        }
        this.f6295Q = true;
        this.f6294P = f10;
        this.f6291M = f10;
        this.f6293O = -1L;
        this.K = -1L;
        this.f6274A = null;
        this.f6296R = true;
        invalidate();
    }

    public void setScene(v vVar) {
        w wVar;
        this.f6326z = vVar;
        boolean zJ = j();
        vVar.f16213p = zJ;
        u uVar = vVar.f16202c;
        if (uVar != null && (wVar = uVar.f16193l) != null) {
            wVar.c(zJ);
        }
        v();
    }

    public void setStartState(int i10) {
        if (super.isAttachedToWindow()) {
            this.f6282E = i10;
            return;
        }
        if (this.f6323w0 == null) {
            this.f6323w0 = new p(this);
        }
        p pVar = this.f6323w0;
        pVar.f16159c = i10;
        pVar.d = i10;
    }

    public void setState(r rVar) {
        Runnable runnable;
        Runnable runnable2;
        r rVar2 = r.d;
        if (rVar == rVar2 && this.f6282E == -1) {
            return;
        }
        r rVar3 = this.f6275A0;
        this.f6275A0 = rVar;
        int iOrdinal = rVar3.ordinal();
        if (iOrdinal == 0 || iOrdinal == 1) {
            if (rVar != rVar2 || (runnable = this.f6324x0) == null) {
                return;
            }
            runnable.run();
            return;
        }
        if (iOrdinal == 2 && rVar == rVar2 && (runnable2 = this.f6324x0) != null) {
            runnable2.run();
        }
    }

    public void setTransition(int i10) {
        u uVar;
        v vVar = this.f6326z;
        if (vVar != null) {
            Iterator it = vVar.d.iterator();
            while (true) {
                if (!it.hasNext()) {
                    uVar = null;
                    break;
                } else {
                    uVar = (u) it.next();
                    if (uVar.f16184a == i10) {
                        break;
                    }
                }
            }
            this.f6280D = uVar.d;
            this.f6284F = uVar.f16186c;
            if (!super.isAttachedToWindow()) {
                if (this.f6323w0 == null) {
                    this.f6323w0 = new p(this);
                }
                p pVar = this.f6323w0;
                pVar.f16159c = this.f6280D;
                pVar.d = this.f6284F;
                return;
            }
            int i11 = this.f6282E;
            float f10 = i11 == this.f6280D ? 0.0f : i11 == this.f6284F ? 1.0f : Float.NaN;
            v vVar2 = this.f6326z;
            vVar2.f16202c = uVar;
            w wVar = uVar.f16193l;
            if (wVar != null) {
                wVar.c(vVar2.f16213p);
            }
            this.f6277B0.g(this.f6326z.b(this.f6280D), this.f6326z.b(this.f6284F));
            v();
            if (this.f6292N != f10) {
                if (f10 == 0.0f) {
                    q();
                    this.f6326z.b(this.f6280D).b(this);
                } else if (f10 == 1.0f) {
                    q();
                    this.f6326z.b(this.f6284F).b(this);
                }
            }
            this.f6292N = Float.isNaN(f10) ? 0.0f : f10;
            if (!Float.isNaN(f10)) {
                setProgress(f10);
                return;
            }
            Log.v("MotionLayout", f.n() + " transitionToStart ");
            p(0.0f);
        }
    }

    public void setTransitionDuration(int i10) {
        v vVar = this.f6326z;
        if (vVar == null) {
            Log.e("MotionLayout", "MotionScene not defined");
            return;
        }
        u uVar = vVar.f16202c;
        if (uVar != null) {
            uVar.f16189h = Math.max(i10, 8);
        } else {
            vVar.f16207j = i10;
        }
    }

    public void setTransitionState(Bundle bundle) {
        if (this.f6323w0 == null) {
            this.f6323w0 = new p(this);
        }
        p pVar = this.f6323w0;
        pVar.getClass();
        pVar.f16157a = bundle.getFloat("motion.progress");
        pVar.f16158b = bundle.getFloat("motion.velocity");
        pVar.f16159c = bundle.getInt("motion.StartState");
        pVar.d = bundle.getInt("motion.EndState");
        if (super.isAttachedToWindow()) {
            this.f6323w0.a();
        }
    }

    public final boolean t(float f10, float f11, View view, MotionEvent motionEvent) {
        boolean z3;
        boolean zOnTouchEvent;
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                if (t((r3.getLeft() + f10) - view.getScrollX(), (r3.getTop() + f11) - view.getScrollY(), viewGroup.getChildAt(childCount), motionEvent)) {
                    z3 = true;
                    break;
                }
            }
            z3 = false;
        } else {
            z3 = false;
        }
        if (!z3) {
            RectF rectF = this.f6281D0;
            rectF.set(f10, f11, (view.getRight() + f10) - view.getLeft(), (view.getBottom() + f11) - view.getTop());
            if (motionEvent.getAction() != 0 || rectF.contains(motionEvent.getX(), motionEvent.getY())) {
                float f12 = -f10;
                float f13 = -f11;
                Matrix matrix = view.getMatrix();
                if (matrix.isIdentity()) {
                    motionEvent.offsetLocation(f12, f13);
                    zOnTouchEvent = view.onTouchEvent(motionEvent);
                    motionEvent.offsetLocation(-f12, -f13);
                } else {
                    MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                    motionEventObtain.offsetLocation(f12, f13);
                    if (this.f6285F0 == null) {
                        this.f6285F0 = new Matrix();
                    }
                    matrix.invert(this.f6285F0);
                    motionEventObtain.transform(this.f6285F0);
                    zOnTouchEvent = view.onTouchEvent(motionEventObtain);
                    motionEventObtain.recycle();
                }
                if (zOnTouchEvent) {
                    return true;
                }
            }
        }
        return z3;
    }

    @Override // android.view.View
    public final String toString() {
        Context context = getContext();
        return f.o(context, this.f6280D) + "->" + f.o(context, this.f6284F) + " (pos:" + this.f6292N + " Dpos/Dt:" + this.f6278C;
    }

    public final void u() {
        u uVar;
        w wVar;
        View viewFindViewById;
        v vVar = this.f6326z;
        if (vVar == null) {
            return;
        }
        if (vVar.a(this.f6282E, this)) {
            requestLayout();
            return;
        }
        int i10 = this.f6282E;
        if (i10 != -1) {
            v vVar2 = this.f6326z;
            ArrayList arrayList = vVar2.d;
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                u uVar2 = (u) it.next();
                if (uVar2.f16194m.size() > 0) {
                    Iterator it2 = uVar2.f16194m.iterator();
                    while (it2.hasNext()) {
                        ((t) it2.next()).b(this);
                    }
                }
            }
            ArrayList arrayList2 = vVar2.f16204f;
            Iterator it3 = arrayList2.iterator();
            while (it3.hasNext()) {
                u uVar3 = (u) it3.next();
                if (uVar3.f16194m.size() > 0) {
                    Iterator it4 = uVar3.f16194m.iterator();
                    while (it4.hasNext()) {
                        ((t) it4.next()).b(this);
                    }
                }
            }
            Iterator it5 = arrayList.iterator();
            while (it5.hasNext()) {
                u uVar4 = (u) it5.next();
                if (uVar4.f16194m.size() > 0) {
                    Iterator it6 = uVar4.f16194m.iterator();
                    while (it6.hasNext()) {
                        ((t) it6.next()).a(this, i10, uVar4);
                    }
                }
            }
            Iterator it7 = arrayList2.iterator();
            while (it7.hasNext()) {
                u uVar5 = (u) it7.next();
                if (uVar5.f16194m.size() > 0) {
                    Iterator it8 = uVar5.f16194m.iterator();
                    while (it8.hasNext()) {
                        ((t) it8.next()).a(this, i10, uVar5);
                    }
                }
            }
        }
        if (!this.f6326z.n() || (uVar = this.f6326z.f16202c) == null || (wVar = uVar.f16193l) == null) {
            return;
        }
        int i11 = wVar.d;
        if (i11 != -1) {
            MotionLayout motionLayout = wVar.f16238r;
            viewFindViewById = motionLayout.findViewById(i11);
            if (viewFindViewById == null) {
                Log.e("TouchResponse", "cannot find TouchAnchorId @id/" + f.o(motionLayout.getContext(), wVar.d));
            }
        } else {
            viewFindViewById = null;
        }
        if (viewFindViewById instanceof NestedScrollView) {
            NestedScrollView nestedScrollView = (NestedScrollView) viewFindViewById;
            nestedScrollView.setOnTouchListener(new W3.f(2));
            nestedScrollView.setOnScrollChangeListener(new b3.f(27));
        }
    }

    public final void v() {
        this.f6277B0.h();
        invalidate();
    }

    public final void w(float f10, float f11) {
        if (!super.isAttachedToWindow()) {
            if (this.f6323w0 == null) {
                this.f6323w0 = new p(this);
            }
            p pVar = this.f6323w0;
            pVar.f16157a = f10;
            pVar.f16158b = f11;
            return;
        }
        setProgress(f10);
        setState(r.f16163c);
        this.f6278C = f11;
        if (f11 != 0.0f) {
            p(f11 > 0.0f ? 1.0f : 0.0f);
        } else {
            if (f10 == 0.0f || f10 == 1.0f) {
                return;
            }
            p(f10 > 0.5f ? 1.0f : 0.0f);
        }
    }

    public final void x(int i10) {
        setState(r.f16162b);
        this.f6282E = i10;
        this.f6280D = -1;
        this.f6284F = -1;
        x xVar = this.f6341r;
        if (xVar == null) {
            v vVar = this.f6326z;
            if (vVar != null) {
                vVar.b(i10).b(this);
                return;
            }
            return;
        }
        float f10 = -1;
        int i11 = xVar.f816a;
        SparseArray sparseArray = (SparseArray) xVar.d;
        int i12 = 0;
        ConstraintLayout constraintLayout = (ConstraintLayout) xVar.f818c;
        if (i11 != i10) {
            xVar.f816a = i10;
            z.f fVar = (z.f) sparseArray.get(i10);
            while (true) {
                ArrayList arrayList = fVar.f16521b;
                if (i12 >= arrayList.size()) {
                    i12 = -1;
                    break;
                } else if (((g) arrayList.get(i12)).a(f10, f10)) {
                    break;
                } else {
                    i12++;
                }
            }
            ArrayList arrayList2 = fVar.f16521b;
            z.n nVar = i12 == -1 ? fVar.d : ((g) arrayList2.get(i12)).f16527f;
            if (i12 != -1) {
                int i13 = ((g) arrayList2.get(i12)).f16526e;
            }
            if (nVar != null) {
                xVar.f817b = i12;
                nVar.b(constraintLayout);
                return;
            } else {
                Log.v("ConstraintLayoutStates", "NO Constraint set found ! id=" + i10 + ", dim =-1.0, -1.0");
                return;
            }
        }
        z.f fVar2 = i10 == -1 ? (z.f) sparseArray.valueAt(0) : (z.f) sparseArray.get(i11);
        int i14 = xVar.f817b;
        if (i14 == -1 || !((g) fVar2.f16521b.get(i14)).a(f10, f10)) {
            while (true) {
                ArrayList arrayList3 = fVar2.f16521b;
                if (i12 >= arrayList3.size()) {
                    i12 = -1;
                    break;
                } else if (((g) arrayList3.get(i12)).a(f10, f10)) {
                    break;
                } else {
                    i12++;
                }
            }
            if (xVar.f817b == i12) {
                return;
            }
            ArrayList arrayList4 = fVar2.f16521b;
            z.n nVar2 = i12 == -1 ? null : ((g) arrayList4.get(i12)).f16527f;
            if (i12 != -1) {
                int i15 = ((g) arrayList4.get(i12)).f16526e;
            }
            if (nVar2 == null) {
                return;
            }
            xVar.f817b = i12;
            nVar2.b(constraintLayout);
        }
    }

    public final void y(int i10, int i11) {
        if (!super.isAttachedToWindow()) {
            if (this.f6323w0 == null) {
                this.f6323w0 = new p(this);
            }
            p pVar = this.f6323w0;
            pVar.f16159c = i10;
            pVar.d = i11;
            return;
        }
        v vVar = this.f6326z;
        if (vVar != null) {
            this.f6280D = i10;
            this.f6284F = i11;
            vVar.m(i10, i11);
            this.f6277B0.g(this.f6326z.b(i10), this.f6326z.b(i11));
            v();
            this.f6292N = 0.0f;
            p(0.0f);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:121:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x0087  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x00c3  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void z(float r17, float r18, int r19) {
        /*
            Method dump skipped, instructions count: 365
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.motion.widget.MotionLayout.z(float, float, int):void");
    }

    public void setTransition(u uVar) {
        w wVar;
        v vVar = this.f6326z;
        vVar.f16202c = uVar;
        if (uVar != null && (wVar = uVar.f16193l) != null) {
            wVar.c(vVar.f16213p);
        }
        setState(r.f16162b);
        int i10 = this.f6282E;
        u uVar2 = this.f6326z.f16202c;
        if (i10 == (uVar2 == null ? -1 : uVar2.f16186c)) {
            this.f6292N = 1.0f;
            this.f6291M = 1.0f;
            this.f6294P = 1.0f;
        } else {
            this.f6292N = 0.0f;
            this.f6291M = 0.0f;
            this.f6294P = 0.0f;
        }
        this.f6293O = (uVar.f16199r & 1) != 0 ? -1L : getNanoTime();
        int iG = this.f6326z.g();
        v vVar2 = this.f6326z;
        u uVar3 = vVar2.f16202c;
        int i11 = uVar3 != null ? uVar3.f16186c : -1;
        if (iG == this.f6280D && i11 == this.f6284F) {
            return;
        }
        this.f6280D = iG;
        this.f6284F = i11;
        vVar2.m(iG, i11);
        z.n nVarB = this.f6326z.b(this.f6280D);
        z.n nVarB2 = this.f6326z.b(this.f6284F);
        a aVar = this.f6277B0;
        aVar.g(nVarB, nVarB2);
        int i12 = this.f6280D;
        int i13 = this.f6284F;
        aVar.f4616a = i12;
        aVar.f4617b = i13;
        aVar.h();
        v();
    }

    public void setTransitionListener(q qVar) {
    }
}
