package androidx.cardview.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import b0.C0477g;
import l1.d;
import p.AbstractC1274a;
import q.C1285a;

/* loaded from: classes.dex */
public class CardView extends FrameLayout {

    /* renamed from: f, reason: collision with root package name */
    public static final int[] f6266f = {R.attr.colorBackground};

    /* renamed from: n, reason: collision with root package name */
    public static final C0477g f6267n = new C0477g(19);

    /* renamed from: a, reason: collision with root package name */
    public boolean f6268a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f6269b;

    /* renamed from: c, reason: collision with root package name */
    public final Rect f6270c;
    public final Rect d;

    /* renamed from: e, reason: collision with root package name */
    public final d f6271e;

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, com.tajir.tajir.R.attr.cardViewStyle);
    }

    public ColorStateList getCardBackgroundColor() {
        return ((C1285a) ((Drawable) this.f6271e.f12857b)).f14336h;
    }

    public float getCardElevation() {
        return ((CardView) this.f6271e.f12858c).getElevation();
    }

    public int getContentPaddingBottom() {
        return this.f6270c.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f6270c.left;
    }

    public int getContentPaddingRight() {
        return this.f6270c.right;
    }

    public int getContentPaddingTop() {
        return this.f6270c.top;
    }

    public float getMaxCardElevation() {
        return ((C1285a) ((Drawable) this.f6271e.f12857b)).f14334e;
    }

    public boolean getPreventCornerOverlap() {
        return this.f6269b;
    }

    public float getRadius() {
        return ((C1285a) ((Drawable) this.f6271e.f12857b)).f14331a;
    }

    public boolean getUseCompatPadding() {
        return this.f6268a;
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i10, int i11) {
        super.onMeasure(i10, i11);
    }

    public void setCardBackgroundColor(int i10) {
        ColorStateList colorStateListValueOf = ColorStateList.valueOf(i10);
        C1285a c1285a = (C1285a) ((Drawable) this.f6271e.f12857b);
        if (colorStateListValueOf == null) {
            c1285a.getClass();
            colorStateListValueOf = ColorStateList.valueOf(0);
        }
        c1285a.f14336h = colorStateListValueOf;
        c1285a.f14332b.setColor(colorStateListValueOf.getColorForState(c1285a.getState(), c1285a.f14336h.getDefaultColor()));
        c1285a.invalidateSelf();
    }

    public void setCardElevation(float f10) {
        ((CardView) this.f6271e.f12858c).setElevation(f10);
    }

    public void setMaxCardElevation(float f10) {
        f6267n.t(this.f6271e, f10);
    }

    @Override // android.view.View
    public void setMinimumHeight(int i10) {
        super.setMinimumHeight(i10);
    }

    @Override // android.view.View
    public void setMinimumWidth(int i10) {
        super.setMinimumWidth(i10);
    }

    @Override // android.view.View
    public final void setPadding(int i10, int i11, int i12, int i13) {
    }

    @Override // android.view.View
    public final void setPaddingRelative(int i10, int i11, int i12, int i13) {
    }

    public void setPreventCornerOverlap(boolean z3) {
        if (z3 != this.f6269b) {
            this.f6269b = z3;
            C0477g c0477g = f6267n;
            d dVar = this.f6271e;
            c0477g.t(dVar, ((C1285a) ((Drawable) dVar.f12857b)).f14334e);
        }
    }

    public void setRadius(float f10) {
        C1285a c1285a = (C1285a) ((Drawable) this.f6271e.f12857b);
        if (f10 == c1285a.f14331a) {
            return;
        }
        c1285a.f14331a = f10;
        c1285a.b(null);
        c1285a.invalidateSelf();
    }

    public void setUseCompatPadding(boolean z3) {
        if (this.f6268a != z3) {
            this.f6268a = z3;
            C0477g c0477g = f6267n;
            d dVar = this.f6271e;
            c0477g.t(dVar, ((C1285a) ((Drawable) dVar.f12857b)).f14334e);
        }
    }

    public CardView(Context context, AttributeSet attributeSet, int i10) {
        ColorStateList colorStateListValueOf;
        super(context, attributeSet, i10);
        Rect rect = new Rect();
        this.f6270c = rect;
        this.d = new Rect();
        d dVar = new d(this, 20);
        this.f6271e = dVar;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC1274a.f14101a, i10, com.tajir.tajir.R.style.CardView);
        if (typedArrayObtainStyledAttributes.hasValue(2)) {
            colorStateListValueOf = typedArrayObtainStyledAttributes.getColorStateList(2);
        } else {
            TypedArray typedArrayObtainStyledAttributes2 = getContext().obtainStyledAttributes(f6266f);
            int color = typedArrayObtainStyledAttributes2.getColor(0, 0);
            typedArrayObtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            colorStateListValueOf = ColorStateList.valueOf(fArr[2] > 0.5f ? getResources().getColor(com.tajir.tajir.R.color.cardview_light_background) : getResources().getColor(com.tajir.tajir.R.color.cardview_dark_background));
        }
        float dimension = typedArrayObtainStyledAttributes.getDimension(3, 0.0f);
        float dimension2 = typedArrayObtainStyledAttributes.getDimension(4, 0.0f);
        float dimension3 = typedArrayObtainStyledAttributes.getDimension(5, 0.0f);
        this.f6268a = typedArrayObtainStyledAttributes.getBoolean(7, false);
        this.f6269b = typedArrayObtainStyledAttributes.getBoolean(6, true);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(8, 0);
        rect.left = typedArrayObtainStyledAttributes.getDimensionPixelSize(10, dimensionPixelSize);
        rect.top = typedArrayObtainStyledAttributes.getDimensionPixelSize(12, dimensionPixelSize);
        rect.right = typedArrayObtainStyledAttributes.getDimensionPixelSize(11, dimensionPixelSize);
        rect.bottom = typedArrayObtainStyledAttributes.getDimensionPixelSize(9, dimensionPixelSize);
        dimension3 = dimension2 > dimension3 ? dimension2 : dimension3;
        typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.getDimensionPixelSize(1, 0);
        typedArrayObtainStyledAttributes.recycle();
        C0477g c0477g = f6267n;
        C1285a c1285a = new C1285a(colorStateListValueOf, dimension);
        dVar.f12857b = c1285a;
        setBackgroundDrawable(c1285a);
        setClipToOutline(true);
        setElevation(dimension2);
        c0477g.t(dVar, dimension3);
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        C1285a c1285a = (C1285a) ((Drawable) this.f6271e.f12857b);
        if (colorStateList == null) {
            c1285a.getClass();
            colorStateList = ColorStateList.valueOf(0);
        }
        c1285a.f14336h = colorStateList;
        c1285a.f14332b.setColor(colorStateList.getColorForState(c1285a.getState(), c1285a.f14336h.getDefaultColor()));
        c1285a.invalidateSelf();
    }
}
