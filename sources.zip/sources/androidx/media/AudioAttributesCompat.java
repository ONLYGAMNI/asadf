package androidx.media;

import K0.c;
import android.util.SparseIntArray;

/* loaded from: classes.dex */
public class AudioAttributesCompat implements c {

    /* renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f7011b = 0;

    /* renamed from: a, reason: collision with root package name */
    public AudioAttributesImpl f7012a;

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        sparseIntArray.put(5, 1);
        sparseIntArray.put(6, 2);
        sparseIntArray.put(7, 2);
        sparseIntArray.put(8, 1);
        sparseIntArray.put(9, 1);
        sparseIntArray.put(10, 1);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesCompat)) {
            return false;
        }
        AudioAttributesCompat audioAttributesCompat = (AudioAttributesCompat) obj;
        AudioAttributesImpl audioAttributesImpl = this.f7012a;
        return audioAttributesImpl == null ? audioAttributesCompat.f7012a == null : audioAttributesImpl.equals(audioAttributesCompat.f7012a);
    }

    public final int hashCode() {
        return this.f7012a.hashCode();
    }

    public final String toString() {
        return this.f7012a.toString();
    }
}
