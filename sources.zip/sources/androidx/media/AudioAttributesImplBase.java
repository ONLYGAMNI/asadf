package androidx.media;

import android.support.v4.media.session.a;
import com.google.android.gms.dynamite.descriptors.com.google.firebase.auth.ModuleDescriptor;
import d0.i;
import java.util.Arrays;

/* loaded from: classes.dex */
class AudioAttributesImplBase implements AudioAttributesImpl {

    /* renamed from: a, reason: collision with root package name */
    public int f7015a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f7016b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f7017c = 0;
    public int d = -1;

    public final boolean equals(Object obj) {
        int i10;
        if (!(obj instanceof AudioAttributesImplBase)) {
            return false;
        }
        AudioAttributesImplBase audioAttributesImplBase = (AudioAttributesImplBase) obj;
        if (this.f7016b == audioAttributesImplBase.f7016b) {
            int i11 = this.f7017c;
            int i12 = audioAttributesImplBase.f7017c;
            int i13 = audioAttributesImplBase.d;
            if (i13 == -1) {
                int i14 = audioAttributesImplBase.f7015a;
                int i15 = AudioAttributesCompat.f7011b;
                if ((i12 & 1) != 1) {
                    if ((i12 & 4) != 4) {
                        switch (i14) {
                            case 2:
                                i10 = 0;
                                break;
                            case 3:
                                i10 = 8;
                                break;
                            case 4:
                                i10 = 4;
                                break;
                            case 5:
                            case i.DOUBLE_FIELD_NUMBER /* 7 */:
                            case 8:
                            case 9:
                            case 10:
                                i10 = 5;
                                break;
                            case i.STRING_SET_FIELD_NUMBER /* 6 */:
                                i10 = 2;
                                break;
                            case ModuleDescriptor.MODULE_VERSION /* 11 */:
                                i10 = 10;
                                break;
                            case 12:
                            default:
                                i10 = 3;
                                break;
                            case 13:
                                i10 = 1;
                                break;
                        }
                    } else {
                        i10 = 6;
                    }
                } else {
                    i10 = 7;
                }
            } else {
                i10 = i13;
            }
            if (i10 == 6) {
                i12 |= 4;
            } else if (i10 == 7) {
                i12 |= 1;
            }
            if (i11 == (i12 & 273) && this.f7015a == audioAttributesImplBase.f7015a && this.d == i13) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f7016b), Integer.valueOf(this.f7017c), Integer.valueOf(this.f7015a), Integer.valueOf(this.d)});
    }

    public final String toString() {
        String strH;
        StringBuilder sb = new StringBuilder("AudioAttributesCompat:");
        if (this.d != -1) {
            sb.append(" stream=");
            sb.append(this.d);
            sb.append(" derived");
        }
        sb.append(" usage=");
        int i10 = this.f7015a;
        int i11 = AudioAttributesCompat.f7011b;
        switch (i10) {
            case 0:
                strH = "USAGE_UNKNOWN";
                break;
            case 1:
                strH = "USAGE_MEDIA";
                break;
            case 2:
                strH = "USAGE_VOICE_COMMUNICATION";
                break;
            case 3:
                strH = "USAGE_VOICE_COMMUNICATION_SIGNALLING";
                break;
            case 4:
                strH = "USAGE_ALARM";
                break;
            case 5:
                strH = "USAGE_NOTIFICATION";
                break;
            case i.STRING_SET_FIELD_NUMBER /* 6 */:
                strH = "USAGE_NOTIFICATION_RINGTONE";
                break;
            case i.DOUBLE_FIELD_NUMBER /* 7 */:
                strH = "USAGE_NOTIFICATION_COMMUNICATION_REQUEST";
                break;
            case 8:
                strH = "USAGE_NOTIFICATION_COMMUNICATION_INSTANT";
                break;
            case 9:
                strH = "USAGE_NOTIFICATION_COMMUNICATION_DELAYED";
                break;
            case 10:
                strH = "USAGE_NOTIFICATION_EVENT";
                break;
            case ModuleDescriptor.MODULE_VERSION /* 11 */:
                strH = "USAGE_ASSISTANCE_ACCESSIBILITY";
                break;
            case 12:
                strH = "USAGE_ASSISTANCE_NAVIGATION_GUIDANCE";
                break;
            case 13:
                strH = "USAGE_ASSISTANCE_SONIFICATION";
                break;
            case 14:
                strH = "USAGE_GAME";
                break;
            case 15:
            default:
                strH = a.h(i10, "unknown usage ");
                break;
            case 16:
                strH = "USAGE_ASSISTANT";
                break;
        }
        sb.append(strH);
        sb.append(" content=");
        sb.append(this.f7016b);
        sb.append(" flags=0x");
        sb.append(Integer.toHexString(this.f7017c).toUpperCase());
        return sb.toString();
    }
}
