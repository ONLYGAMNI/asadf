package androidx.media;

import K0.a;

/* loaded from: classes.dex */
public final class AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(a aVar) {
        AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
        audioAttributesImplBase.f7015a = aVar.f(audioAttributesImplBase.f7015a, 1);
        audioAttributesImplBase.f7016b = aVar.f(audioAttributesImplBase.f7016b, 2);
        audioAttributesImplBase.f7017c = aVar.f(audioAttributesImplBase.f7017c, 3);
        audioAttributesImplBase.d = aVar.f(audioAttributesImplBase.d, 4);
        return audioAttributesImplBase;
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, a aVar) {
        aVar.getClass();
        aVar.j(audioAttributesImplBase.f7015a, 1);
        aVar.j(audioAttributesImplBase.f7016b, 2);
        aVar.j(audioAttributesImplBase.f7017c, 3);
        aVar.j(audioAttributesImplBase.d, 4);
    }
}
