package androidx.media;

import K0.c;

/* loaded from: classes.dex */
interface AudioAttributesImpl extends c {
}
