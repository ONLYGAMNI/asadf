package androidx.core.app;

import android.app.AppComponentFactory;

/* loaded from: classes.dex */
public class CoreComponentFactory extends AppComponentFactory {
}
