package androidx.core.app;

import K0.c;
import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements c {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f6371a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f6372b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f6373c;
    public PendingIntent d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f6374e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f6375f;
}
