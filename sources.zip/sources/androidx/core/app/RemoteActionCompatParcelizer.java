package androidx.core.app;

import K0.a;
import K0.b;
import K0.c;
import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import java.lang.reflect.InvocationTargetException;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        c cVarH = remoteActionCompat.f6371a;
        if (aVar.e(1)) {
            cVarH = aVar.h();
        }
        remoteActionCompat.f6371a = (IconCompat) cVarH;
        CharSequence charSequence = remoteActionCompat.f6372b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f2091e);
        }
        remoteActionCompat.f6372b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f6373c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f2091e);
        }
        remoteActionCompat.f6373c = charSequence2;
        remoteActionCompat.d = (PendingIntent) aVar.g(remoteActionCompat.d, 4);
        boolean z3 = remoteActionCompat.f6374e;
        if (aVar.e(5)) {
            z3 = ((b) aVar).f2091e.readInt() != 0;
        }
        remoteActionCompat.f6374e = z3;
        boolean z9 = remoteActionCompat.f6375f;
        if (aVar.e(6)) {
            z9 = ((b) aVar).f2091e.readInt() != 0;
        }
        remoteActionCompat.f6375f = z9;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f6371a;
        aVar.i(1);
        aVar.k(iconCompat);
        CharSequence charSequence = remoteActionCompat.f6372b;
        aVar.i(2);
        Parcel parcel = ((b) aVar).f2091e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f6373c;
        aVar.i(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.d;
        aVar.i(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z3 = remoteActionCompat.f6374e;
        aVar.i(5);
        parcel.writeInt(z3 ? 1 : 0);
        boolean z9 = remoteActionCompat.f6375f;
        aVar.i(6);
        parcel.writeInt(z9 ? 1 : 0);
    }
}
