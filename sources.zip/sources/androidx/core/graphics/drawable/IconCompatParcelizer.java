package androidx.core.graphics.drawable;

import K0.a;
import K0.b;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import d0.i;
import java.nio.charset.Charset;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f6380a = aVar.f(iconCompat.f6380a, 1);
        byte[] bArr = iconCompat.f6382c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f2091e;
            int i10 = parcel.readInt();
            if (i10 < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[i10];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f6382c = bArr;
        iconCompat.d = aVar.g(iconCompat.d, 3);
        iconCompat.f6383e = aVar.f(iconCompat.f6383e, 4);
        iconCompat.f6384f = aVar.f(iconCompat.f6384f, 5);
        iconCompat.g = (ColorStateList) aVar.g(iconCompat.g, 6);
        String string = iconCompat.f6386i;
        if (aVar.e(7)) {
            string = ((b) aVar).f2091e.readString();
        }
        iconCompat.f6386i = string;
        String string2 = iconCompat.f6387j;
        if (aVar.e(8)) {
            string2 = ((b) aVar).f2091e.readString();
        }
        iconCompat.f6387j = string2;
        iconCompat.f6385h = PorterDuff.Mode.valueOf(iconCompat.f6386i);
        switch (iconCompat.f6380a) {
            case -1:
                Parcelable parcelable = iconCompat.d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f6381b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case 5:
                Parcelable parcelable2 = iconCompat.d;
                if (parcelable2 != null) {
                    iconCompat.f6381b = parcelable2;
                } else {
                    byte[] bArr3 = iconCompat.f6382c;
                    iconCompat.f6381b = bArr3;
                    iconCompat.f6380a = 3;
                    iconCompat.f6383e = 0;
                    iconCompat.f6384f = bArr3.length;
                }
                return iconCompat;
            case 2:
            case 4:
            case i.STRING_SET_FIELD_NUMBER /* 6 */:
                String str = new String(iconCompat.f6382c, Charset.forName("UTF-16"));
                iconCompat.f6381b = str;
                if (iconCompat.f6380a == 2 && iconCompat.f6387j == null) {
                    iconCompat.f6387j = str.split(":", -1)[0];
                }
                return iconCompat;
            case 3:
                iconCompat.f6381b = iconCompat.f6382c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f6386i = iconCompat.f6385h.name();
        switch (iconCompat.f6380a) {
            case -1:
                iconCompat.d = (Parcelable) iconCompat.f6381b;
                break;
            case 1:
            case 5:
                iconCompat.d = (Parcelable) iconCompat.f6381b;
                break;
            case 2:
                iconCompat.f6382c = ((String) iconCompat.f6381b).getBytes(Charset.forName("UTF-16"));
                break;
            case 3:
                iconCompat.f6382c = (byte[]) iconCompat.f6381b;
                break;
            case 4:
            case i.STRING_SET_FIELD_NUMBER /* 6 */:
                iconCompat.f6382c = iconCompat.f6381b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i10 = iconCompat.f6380a;
        if (-1 != i10) {
            aVar.j(i10, 1);
        }
        byte[] bArr = iconCompat.f6382c;
        if (bArr != null) {
            aVar.i(2);
            int length = bArr.length;
            Parcel parcel = ((b) aVar).f2091e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.d;
        if (parcelable != null) {
            aVar.i(3);
            ((b) aVar).f2091e.writeParcelable(parcelable, 0);
        }
        int i11 = iconCompat.f6383e;
        if (i11 != 0) {
            aVar.j(i11, 4);
        }
        int i12 = iconCompat.f6384f;
        if (i12 != 0) {
            aVar.j(i12, 5);
        }
        ColorStateList colorStateList = iconCompat.g;
        if (colorStateList != null) {
            aVar.i(6);
            ((b) aVar).f2091e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f6386i;
        if (str != null) {
            aVar.i(7);
            ((b) aVar).f2091e.writeString(str);
        }
        String str2 = iconCompat.f6387j;
        if (str2 != null) {
            aVar.i(8);
            ((b) aVar).f2091e.writeString(str2);
        }
    }
}
