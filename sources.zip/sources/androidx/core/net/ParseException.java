package androidx.core.net;

/* loaded from: classes.dex */
public class ParseException extends RuntimeException {
}
