package androidx.appcompat.view.menu;

import R.E;
import R.X;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import com.tajir.tajir.R;
import e.AbstractC0764a;
import java.util.WeakHashMap;
import k.n;
import k.z;

/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements z, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a, reason: collision with root package name */
    public n f6081a;

    /* renamed from: b, reason: collision with root package name */
    public ImageView f6082b;

    /* renamed from: c, reason: collision with root package name */
    public RadioButton f6083c;
    public TextView d;

    /* renamed from: e, reason: collision with root package name */
    public CheckBox f6084e;

    /* renamed from: f, reason: collision with root package name */
    public TextView f6085f;

    /* renamed from: n, reason: collision with root package name */
    public ImageView f6086n;

    /* renamed from: o, reason: collision with root package name */
    public ImageView f6087o;

    /* renamed from: p, reason: collision with root package name */
    public LinearLayout f6088p;

    /* renamed from: q, reason: collision with root package name */
    public final Drawable f6089q;

    /* renamed from: r, reason: collision with root package name */
    public final int f6090r;

    /* renamed from: s, reason: collision with root package name */
    public final Context f6091s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f6092t;

    /* renamed from: u, reason: collision with root package name */
    public final Drawable f6093u;

    /* renamed from: v, reason: collision with root package name */
    public final boolean f6094v;

    /* renamed from: w, reason: collision with root package name */
    public LayoutInflater f6095w;

    /* renamed from: x, reason: collision with root package name */
    public boolean f6096x;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        k6.z zVarJ = k6.z.j(getContext(), attributeSet, AbstractC0764a.f10137r, R.attr.listMenuViewStyle, 0);
        this.f6089q = zVarJ.f(5);
        TypedArray typedArray = (TypedArray) zVarJ.f12479c;
        this.f6090r = typedArray.getResourceId(1, -1);
        this.f6092t = typedArray.getBoolean(7, false);
        this.f6091s = context;
        this.f6093u = zVarJ.f(8);
        TypedArray typedArrayObtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{android.R.attr.divider}, R.attr.dropDownListViewStyle, 0);
        this.f6094v = typedArrayObtainStyledAttributes.hasValue(0);
        zVarJ.k();
        typedArrayObtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f6095w == null) {
            this.f6095w = LayoutInflater.from(getContext());
        }
        return this.f6095w;
    }

    private void setSubMenuArrowVisible(boolean z3) {
        ImageView imageView = this.f6086n;
        if (imageView != null) {
            imageView.setVisibility(z3 ? 0 : 8);
        }
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public final void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f6087o;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f6087o.getLayoutParams();
        rect.top = this.f6087o.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0037  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x005e  */
    @Override // k.z
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void c(k.n r11) {
        /*
            Method dump skipped, instructions count: 325
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ListMenuItemView.c(k.n):void");
    }

    @Override // k.z
    public n getItemData() {
        return this.f6081a;
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        WeakHashMap weakHashMap = X.f3966a;
        E.q(this, this.f6089q);
        TextView textView = (TextView) findViewById(R.id.title);
        this.d = textView;
        int i10 = this.f6090r;
        if (i10 != -1) {
            textView.setTextAppearance(this.f6091s, i10);
        }
        this.f6085f = (TextView) findViewById(R.id.shortcut);
        ImageView imageView = (ImageView) findViewById(R.id.submenuarrow);
        this.f6086n = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f6093u);
        }
        this.f6087o = (ImageView) findViewById(R.id.group_divider);
        this.f6088p = (LinearLayout) findViewById(R.id.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        if (this.f6082b != null && this.f6092t) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f6082b.getLayoutParams();
            int i12 = layoutParams.height;
            if (i12 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i12;
            }
        }
        super.onMeasure(i10, i11);
    }

    public void setCheckable(boolean z3) {
        CompoundButton compoundButton;
        View view;
        if (!z3 && this.f6083c == null && this.f6084e == null) {
            return;
        }
        if ((this.f6081a.f11980E & 4) != 0) {
            if (this.f6083c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f6083c = radioButton;
                LinearLayout linearLayout = this.f6088p;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f6083c;
            view = this.f6084e;
        } else {
            if (this.f6084e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f6084e = checkBox;
                LinearLayout linearLayout2 = this.f6088p;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f6084e;
            view = this.f6083c;
        }
        if (z3) {
            compoundButton.setChecked(this.f6081a.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (view == null || view.getVisibility() == 8) {
                return;
            }
            view.setVisibility(8);
            return;
        }
        CheckBox checkBox2 = this.f6084e;
        if (checkBox2 != null) {
            checkBox2.setVisibility(8);
        }
        RadioButton radioButton2 = this.f6083c;
        if (radioButton2 != null) {
            radioButton2.setVisibility(8);
        }
    }

    public void setChecked(boolean z3) {
        CompoundButton compoundButton;
        if ((this.f6081a.f11980E & 4) != 0) {
            if (this.f6083c == null) {
                RadioButton radioButton = (RadioButton) getInflater().inflate(R.layout.abc_list_menu_item_radio, (ViewGroup) this, false);
                this.f6083c = radioButton;
                LinearLayout linearLayout = this.f6088p;
                if (linearLayout != null) {
                    linearLayout.addView(radioButton, -1);
                } else {
                    addView(radioButton, -1);
                }
            }
            compoundButton = this.f6083c;
        } else {
            if (this.f6084e == null) {
                CheckBox checkBox = (CheckBox) getInflater().inflate(R.layout.abc_list_menu_item_checkbox, (ViewGroup) this, false);
                this.f6084e = checkBox;
                LinearLayout linearLayout2 = this.f6088p;
                if (linearLayout2 != null) {
                    linearLayout2.addView(checkBox, -1);
                } else {
                    addView(checkBox, -1);
                }
            }
            compoundButton = this.f6084e;
        }
        compoundButton.setChecked(z3);
    }

    public void setForceShowIcon(boolean z3) {
        this.f6096x = z3;
        this.f6092t = z3;
    }

    public void setGroupDividerEnabled(boolean z3) {
        ImageView imageView = this.f6087o;
        if (imageView != null) {
            imageView.setVisibility((this.f6094v || !z3) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        this.f6081a.f11998u.getClass();
        boolean z3 = this.f6096x;
        if (z3 || this.f6092t) {
            ImageView imageView = this.f6082b;
            if (imageView == null && drawable == null && !this.f6092t) {
                return;
            }
            if (imageView == null) {
                ImageView imageView2 = (ImageView) getInflater().inflate(R.layout.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f6082b = imageView2;
                LinearLayout linearLayout = this.f6088p;
                if (linearLayout != null) {
                    linearLayout.addView(imageView2, 0);
                } else {
                    addView(imageView2, 0);
                }
            }
            if (drawable == null && !this.f6092t) {
                this.f6082b.setVisibility(8);
                return;
            }
            ImageView imageView3 = this.f6082b;
            if (!z3) {
                drawable = null;
            }
            imageView3.setImageDrawable(drawable);
            if (this.f6082b.getVisibility() != 0) {
                this.f6082b.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (charSequence == null) {
            if (this.d.getVisibility() != 8) {
                this.d.setVisibility(8);
            }
        } else {
            this.d.setText(charSequence);
            if (this.d.getVisibility() != 0) {
                this.d.setVisibility(0);
            }
        }
    }
}
