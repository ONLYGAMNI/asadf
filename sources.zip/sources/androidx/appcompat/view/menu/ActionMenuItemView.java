package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import e.AbstractC0764a;
import f9.d;
import k.AbstractC1080c;
import k.C1079b;
import k.k;
import k.l;
import k.n;
import k.z;
import l.C1122d0;
import l.InterfaceC1135k;

/* loaded from: classes.dex */
public class ActionMenuItemView extends C1122d0 implements z, View.OnClickListener, InterfaceC1135k {

    /* renamed from: o */
    public n f6068o;

    /* renamed from: p */
    public CharSequence f6069p;

    /* renamed from: q */
    public Drawable f6070q;

    /* renamed from: r */
    public k f6071r;

    /* renamed from: s */
    public C1079b f6072s;

    /* renamed from: t */
    public AbstractC1080c f6073t;

    /* renamed from: u */
    public boolean f6074u;

    /* renamed from: v */
    public boolean f6075v;

    /* renamed from: w */
    public final int f6076w;

    /* renamed from: x */
    public int f6077x;

    /* renamed from: y */
    public final int f6078y;

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        this.f6074u = g();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0764a.f10124c, 0, 0);
        this.f6076w = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        this.f6078y = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f6077x = -1;
        setSaveEnabled(false);
    }

    @Override // l.InterfaceC1135k
    public final boolean a() {
        return !TextUtils.isEmpty(getText());
    }

    @Override // l.InterfaceC1135k
    public final boolean b() {
        return (TextUtils.isEmpty(getText()) ^ true) && this.f6068o.getIcon() == null;
    }

    @Override // k.z
    public final void c(n nVar) {
        this.f6068o = nVar;
        setIcon(nVar.getIcon());
        setTitle(nVar.getTitleCondensed());
        setId(nVar.f11986a);
        setVisibility(nVar.isVisible() ? 0 : 8);
        setEnabled(nVar.isEnabled());
        if (nVar.hasSubMenu() && this.f6072s == null) {
            this.f6072s = new C1079b(this);
        }
    }

    public final boolean g() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i10 = configuration.screenWidthDp;
        return i10 >= 480 || (i10 >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    @Override // android.widget.TextView, android.view.View
    public CharSequence getAccessibilityClassName() {
        return Button.class.getName();
    }

    @Override // k.z
    public n getItemData() {
        return this.f6068o;
    }

    public final void h() {
        boolean z3 = true;
        boolean z9 = !TextUtils.isEmpty(this.f6069p);
        if (this.f6070q != null && ((this.f6068o.f11981F & 4) != 4 || (!this.f6074u && !this.f6075v))) {
            z3 = false;
        }
        boolean z10 = z9 & z3;
        setText(z10 ? this.f6069p : null);
        CharSequence charSequence = this.f6068o.f12001x;
        if (TextUtils.isEmpty(charSequence)) {
            setContentDescription(z10 ? null : this.f6068o.f11989e);
        } else {
            setContentDescription(charSequence);
        }
        CharSequence charSequence2 = this.f6068o.f12002y;
        if (TextUtils.isEmpty(charSequence2)) {
            d.t(this, z10 ? null : this.f6068o.f11989e);
        } else {
            d.t(this, charSequence2);
        }
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        k kVar = this.f6071r;
        if (kVar != null) {
            kVar.a(this.f6068o);
        }
    }

    @Override // android.widget.TextView, android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f6074u = g();
        h();
    }

    @Override // l.C1122d0, android.widget.TextView, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        boolean z3 = !TextUtils.isEmpty(getText());
        if (z3 && (i12 = this.f6077x) >= 0) {
            super.setPadding(i12, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i10, i11);
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int measuredWidth = getMeasuredWidth();
        int i13 = this.f6076w;
        int iMin = mode == Integer.MIN_VALUE ? Math.min(size, i13) : i13;
        if (mode != 1073741824 && i13 > 0 && measuredWidth < iMin) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(iMin, 1073741824), i11);
        }
        if (z3 || this.f6070q == null) {
            return;
        }
        super.setPadding((getMeasuredWidth() - this.f6070q.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
    }

    @Override // android.widget.TextView, android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(null);
    }

    @Override // android.widget.TextView, android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        C1079b c1079b;
        if (this.f6068o.hasSubMenu() && (c1079b = this.f6072s) != null && c1079b.onTouch(this, motionEvent)) {
            return true;
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setCheckable(boolean z3) {
    }

    public void setChecked(boolean z3) {
    }

    public void setExpandedFormat(boolean z3) {
        if (this.f6075v != z3) {
            this.f6075v = z3;
            n nVar = this.f6068o;
            if (nVar != null) {
                l lVar = nVar.f11998u;
                lVar.f11964r = true;
                lVar.p(true);
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f6070q = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i10 = this.f6078y;
            if (intrinsicWidth > i10) {
                intrinsicHeight = (int) (intrinsicHeight * (i10 / intrinsicWidth));
                intrinsicWidth = i10;
            }
            if (intrinsicHeight > i10) {
                intrinsicWidth = (int) (intrinsicWidth * (i10 / intrinsicHeight));
            } else {
                i10 = intrinsicHeight;
            }
            drawable.setBounds(0, 0, intrinsicWidth, i10);
        }
        setCompoundDrawables(drawable, null, null, null);
        h();
    }

    public void setItemInvoker(k kVar) {
        this.f6071r = kVar;
    }

    @Override // android.widget.TextView, android.view.View
    public final void setPadding(int i10, int i11, int i12, int i13) {
        this.f6077x = i10;
        super.setPadding(i10, i11, i12, i13);
    }

    public void setPopupCallback(AbstractC1080c abstractC1080c) {
        this.f6073t = abstractC1080c;
    }

    public void setTitle(CharSequence charSequence) {
        this.f6069p = charSequence;
        h();
    }
}
