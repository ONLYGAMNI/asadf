package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import k.A;
import k.k;
import k.l;
import k.n;
import k6.z;

/* loaded from: classes.dex */
public final class ExpandedMenuView extends ListView implements k, A, AdapterView.OnItemClickListener {

    /* renamed from: b */
    public static final int[] f6079b = {R.attr.background, R.attr.divider};

    /* renamed from: a */
    public l f6080a;

    public ExpandedMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setOnItemClickListener(this);
        z zVarJ = z.j(context, attributeSet, f6079b, R.attr.listViewStyle, 0);
        TypedArray typedArray = (TypedArray) zVarJ.f12479c;
        if (typedArray.hasValue(0)) {
            setBackgroundDrawable(zVarJ.f(0));
        }
        if (typedArray.hasValue(1)) {
            setDivider(zVarJ.f(1));
        }
        zVarJ.k();
    }

    @Override // k.k
    public final boolean a(n nVar) {
        return this.f6080a.q(nVar, null, 0);
    }

    @Override // k.A
    public final void d(l lVar) {
        this.f6080a = lVar;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.widget.AdapterView, android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setChildrenDrawingCacheEnabled(false);
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public final void onItemClick(AdapterView adapterView, View view, int i10, long j10) {
        a((n) getAdapter().getItem(i10));
    }
}
