package androidx.appcompat.widget;

import R.C0243d0;
import R.E;
import R.X;
import U8.s;
import W3.e;
import a.AbstractC0338a;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.tajir.tajir.R;
import e.AbstractC0764a;
import java.util.WeakHashMap;
import k.A;
import k.l;
import l.C1123e;
import l.C1133j;
import l.x1;

/* loaded from: classes.dex */
public class ActionBarContextView extends ViewGroup {

    /* renamed from: A */
    public final int f6105A;

    /* renamed from: a */
    public final s f6106a;

    /* renamed from: b */
    public final Context f6107b;

    /* renamed from: c */
    public ActionMenuView f6108c;
    public C1133j d;

    /* renamed from: e */
    public int f6109e;

    /* renamed from: f */
    public C0243d0 f6110f;

    /* renamed from: n */
    public boolean f6111n;

    /* renamed from: o */
    public boolean f6112o;

    /* renamed from: p */
    public CharSequence f6113p;

    /* renamed from: q */
    public CharSequence f6114q;

    /* renamed from: r */
    public View f6115r;

    /* renamed from: s */
    public View f6116s;

    /* renamed from: t */
    public View f6117t;

    /* renamed from: u */
    public LinearLayout f6118u;

    /* renamed from: v */
    public TextView f6119v;

    /* renamed from: w */
    public TextView f6120w;

    /* renamed from: x */
    public final int f6121x;

    /* renamed from: y */
    public final int f6122y;

    /* renamed from: z */
    public boolean f6123z;

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        int resourceId;
        super(context, attributeSet, R.attr.actionModeStyle);
        this.f6106a = new s(this);
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f6107b = context;
        } else {
            this.f6107b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0764a.d, R.attr.actionModeStyle, 0);
        Drawable drawable = (!typedArrayObtainStyledAttributes.hasValue(0) || (resourceId = typedArrayObtainStyledAttributes.getResourceId(0, 0)) == 0) ? typedArrayObtainStyledAttributes.getDrawable(0) : AbstractC0338a.s(context, resourceId);
        WeakHashMap weakHashMap = X.f3966a;
        E.q(this, drawable);
        this.f6121x = typedArrayObtainStyledAttributes.getResourceId(5, 0);
        this.f6122y = typedArrayObtainStyledAttributes.getResourceId(4, 0);
        this.f6109e = typedArrayObtainStyledAttributes.getLayoutDimension(3, 0);
        this.f6105A = typedArrayObtainStyledAttributes.getResourceId(2, R.layout.abc_action_mode_close_item_material);
        typedArrayObtainStyledAttributes.recycle();
    }

    public static int f(View view, int i10, int i11) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i10, Integer.MIN_VALUE), i11);
        return Math.max(0, i10 - view.getMeasuredWidth());
    }

    public static int g(int i10, int i11, int i12, View view, boolean z3) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i13 = ((i12 - measuredHeight) / 2) + i11;
        if (z3) {
            view.layout(i10 - measuredWidth, i13, i10, measuredHeight + i13);
        } else {
            view.layout(i10, i13, i10 + measuredWidth, measuredHeight + i13);
        }
        return z3 ? -measuredWidth : measuredWidth;
    }

    public final void c(j.b bVar) {
        View view = this.f6115r;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f6105A, (ViewGroup) this, false);
            this.f6115r = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f6115r);
        }
        View viewFindViewById = this.f6115r.findViewById(R.id.action_mode_close_button);
        this.f6116s = viewFindViewById;
        viewFindViewById.setOnClickListener(new e(bVar, 4));
        l lVarK = bVar.k();
        C1133j c1133j = this.d;
        if (c1133j != null) {
            c1133j.e();
            C1123e c1123e = c1133j.f12696B;
            if (c1123e != null && c1123e.b()) {
                c1123e.f12022j.dismiss();
            }
        }
        C1133j c1133j2 = new C1133j(getContext());
        this.d = c1133j2;
        c1133j2.f12712t = true;
        c1133j2.f12713u = true;
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        lVarK.b(this.d, this.f6107b);
        C1133j c1133j3 = this.d;
        A a6 = c1133j3.f12707o;
        if (a6 == null) {
            A a9 = (A) c1133j3.d.inflate(c1133j3.f12705f, (ViewGroup) this, false);
            c1133j3.f12707o = a9;
            a9.d(c1133j3.f12703c);
            c1133j3.j(true);
        }
        A a10 = c1133j3.f12707o;
        if (a6 != a10) {
            ((ActionMenuView) a10).setPresenter(c1133j3);
        }
        ActionMenuView actionMenuView = (ActionMenuView) a10;
        this.f6108c = actionMenuView;
        WeakHashMap weakHashMap = X.f3966a;
        E.q(actionMenuView, null);
        addView(this.f6108c, layoutParams);
    }

    public final void d() {
        if (this.f6118u == null) {
            LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f6118u = linearLayout;
            this.f6119v = (TextView) linearLayout.findViewById(R.id.action_bar_title);
            this.f6120w = (TextView) this.f6118u.findViewById(R.id.action_bar_subtitle);
            int i10 = this.f6121x;
            if (i10 != 0) {
                this.f6119v.setTextAppearance(getContext(), i10);
            }
            int i11 = this.f6122y;
            if (i11 != 0) {
                this.f6120w.setTextAppearance(getContext(), i11);
            }
        }
        this.f6119v.setText(this.f6113p);
        this.f6120w.setText(this.f6114q);
        boolean z3 = !TextUtils.isEmpty(this.f6113p);
        boolean z9 = !TextUtils.isEmpty(this.f6114q);
        this.f6120w.setVisibility(z9 ? 0 : 8);
        this.f6118u.setVisibility((z3 || z9) ? 0 : 8);
        if (this.f6118u.getParent() == null) {
            addView(this.f6118u);
        }
    }

    public final void e() {
        removeAllViews();
        this.f6117t = null;
        this.f6108c = null;
        this.d = null;
        View view = this.f6116s;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public int getAnimatedVisibility() {
        return this.f6110f != null ? this.f6106a.f5007b : getVisibility();
    }

    public int getContentHeight() {
        return this.f6109e;
    }

    public CharSequence getSubtitle() {
        return this.f6114q;
    }

    public CharSequence getTitle() {
        return this.f6113p;
    }

    @Override // android.view.View
    /* renamed from: h */
    public final void setVisibility(int i10) {
        if (i10 != getVisibility()) {
            C0243d0 c0243d0 = this.f6110f;
            if (c0243d0 != null) {
                c0243d0.b();
            }
            super.setVisibility(i10);
        }
    }

    public final C0243d0 i(int i10, long j10) {
        C0243d0 c0243d0 = this.f6110f;
        if (c0243d0 != null) {
            c0243d0.b();
        }
        s sVar = this.f6106a;
        if (i10 != 0) {
            C0243d0 c0243d0A = X.a(this);
            c0243d0A.a(0.0f);
            c0243d0A.c(j10);
            ((ActionBarContextView) sVar.f5008c).f6110f = c0243d0A;
            sVar.f5007b = i10;
            c0243d0A.d(sVar);
            return c0243d0A;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        C0243d0 c0243d0A2 = X.a(this);
        c0243d0A2.a(1.0f);
        c0243d0A2.c(j10);
        ((ActionBarContextView) sVar.f5008c).f6110f = c0243d0A2;
        sVar.f5007b = i10;
        c0243d0A2.d(sVar);
        return c0243d0A2;
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, AbstractC0764a.f10122a, R.attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(13, 0));
        typedArrayObtainStyledAttributes.recycle();
        C1133j c1133j = this.d;
        if (c1133j != null) {
            Configuration configuration2 = c1133j.f12702b.getResources().getConfiguration();
            int i10 = configuration2.screenWidthDp;
            int i11 = configuration2.screenHeightDp;
            c1133j.f12716x = (configuration2.smallestScreenWidthDp > 600 || i10 > 600 || (i10 > 960 && i11 > 720) || (i10 > 720 && i11 > 960)) ? 5 : (i10 >= 500 || (i10 > 640 && i11 > 480) || (i10 > 480 && i11 > 640)) ? 4 : i10 >= 360 ? 3 : 2;
            l lVar = c1133j.f12703c;
            if (lVar != null) {
                lVar.p(true);
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C1133j c1133j = this.d;
        if (c1133j != null) {
            c1133j.e();
            C1123e c1123e = this.d.f12696B;
            if (c1123e == null || !c1123e.b()) {
                return;
            }
            c1123e.f12022j.dismiss();
        }
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f6112o = false;
        }
        if (!this.f6112o) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f6112o = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f6112o = false;
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        boolean zA = x1.a(this);
        int paddingRight = zA ? (i12 - i10) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i13 - i11) - getPaddingTop()) - getPaddingBottom();
        View view = this.f6115r;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f6115r.getLayoutParams();
            int i14 = zA ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i15 = zA ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i16 = zA ? paddingRight - i14 : paddingRight + i14;
            int iG = g(i16, paddingTop, paddingTop2, this.f6115r, zA) + i16;
            paddingRight = zA ? iG - i15 : iG + i15;
        }
        LinearLayout linearLayout = this.f6118u;
        if (linearLayout != null && this.f6117t == null && linearLayout.getVisibility() != 8) {
            paddingRight += g(paddingRight, paddingTop, paddingTop2, this.f6118u, zA);
        }
        View view2 = this.f6117t;
        if (view2 != null) {
            g(paddingRight, paddingTop, paddingTop2, view2, zA);
        }
        int paddingLeft = zA ? getPaddingLeft() : (i12 - i10) - getPaddingRight();
        ActionMenuView actionMenuView = this.f6108c;
        if (actionMenuView != null) {
            g(paddingLeft, paddingTop, paddingTop2, actionMenuView, !zA);
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        if (View.MeasureSpec.getMode(i10) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_width=\"match_parent\" (or fill_parent)"));
        }
        if (View.MeasureSpec.getMode(i11) == 0) {
            throw new IllegalStateException(getClass().getSimpleName().concat(" can only be used with android:layout_height=\"wrap_content\""));
        }
        int size = View.MeasureSpec.getSize(i10);
        int size2 = this.f6109e;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i11);
        }
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingBottom;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f6115r;
        if (view != null) {
            int iF = f(view, paddingLeft, iMakeMeasureSpec);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f6115r.getLayoutParams();
            paddingLeft = iF - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f6108c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = f(this.f6108c, paddingLeft, iMakeMeasureSpec);
        }
        LinearLayout linearLayout = this.f6118u;
        if (linearLayout != null && this.f6117t == null) {
            if (this.f6123z) {
                this.f6118u.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f6118u.getMeasuredWidth();
                boolean z3 = measuredWidth <= paddingLeft;
                if (z3) {
                    paddingLeft -= measuredWidth;
                }
                this.f6118u.setVisibility(z3 ? 0 : 8);
            } else {
                paddingLeft = f(linearLayout, paddingLeft, iMakeMeasureSpec);
            }
        }
        View view2 = this.f6117t;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i12 = layoutParams.width;
            int i13 = i12 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i12 >= 0) {
                paddingLeft = Math.min(i12, paddingLeft);
            }
            int i14 = layoutParams.height;
            int i15 = i14 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i14 >= 0) {
                iMin = Math.min(i14, iMin);
            }
            this.f6117t.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i13), View.MeasureSpec.makeMeasureSpec(iMin, i15));
        }
        if (this.f6109e > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i16 = 0;
        for (int i17 = 0; i17 < childCount; i17++) {
            int measuredHeight = getChildAt(i17).getMeasuredHeight() + paddingBottom;
            if (measuredHeight > i16) {
                i16 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i16);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f6111n = false;
        }
        if (!this.f6111n) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f6111n = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f6111n = false;
        }
        return true;
    }

    public void setContentHeight(int i10) {
        this.f6109e = i10;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f6117t;
        if (view2 != null) {
            removeView(view2);
        }
        this.f6117t = view;
        if (view != null && (linearLayout = this.f6118u) != null) {
            removeView(linearLayout);
            this.f6118u = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f6114q = charSequence;
        d();
    }

    public void setTitle(CharSequence charSequence) {
        this.f6113p = charSequence;
        d();
        X.o(this, charSequence);
    }

    public void setTitleOptional(boolean z3) {
        if (z3 != this.f6123z) {
            requestLayout();
        }
        this.f6123z = z3;
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }
}
