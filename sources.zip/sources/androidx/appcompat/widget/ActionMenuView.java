package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import androidx.appcompat.view.menu.ActionMenuItemView;
import b3.f;
import k.A;
import k.j;
import k.k;
import k.l;
import k.n;
import k.x;
import l.A0;
import l.C1123e;
import l.C1129h;
import l.C1133j;
import l.C1137l;
import l.C1165z0;
import l.InterfaceC1135k;
import l.InterfaceC1139m;
import l.x1;
import p3.i;

/* loaded from: classes.dex */
public class ActionMenuView extends A0 implements k, A {

    /* renamed from: A */
    public C1133j f6151A;

    /* renamed from: B */
    public x f6152B;

    /* renamed from: C */
    public j f6153C;

    /* renamed from: D */
    public boolean f6154D;

    /* renamed from: E */
    public int f6155E;

    /* renamed from: F */
    public final int f6156F;

    /* renamed from: G */
    public final int f6157G;

    /* renamed from: H */
    public InterfaceC1139m f6158H;

    /* renamed from: w */
    public l f6159w;

    /* renamed from: x */
    public Context f6160x;

    /* renamed from: y */
    public int f6161y;

    /* renamed from: z */
    public boolean f6162z;

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setBaselineAligned(false);
        float f10 = context.getResources().getDisplayMetrics().density;
        this.f6156F = (int) (56.0f * f10);
        this.f6157G = (int) (f10 * 4.0f);
        this.f6160x = context;
        this.f6161y = 0;
    }

    public static C1137l l() {
        C1137l c1137l = new C1137l(-2, -2);
        c1137l.f12732a = false;
        ((LinearLayout.LayoutParams) c1137l).gravity = 16;
        return c1137l;
    }

    public static C1137l m(ViewGroup.LayoutParams layoutParams) {
        C1137l c1137l;
        if (layoutParams == null) {
            return l();
        }
        if (layoutParams instanceof C1137l) {
            C1137l c1137l2 = (C1137l) layoutParams;
            c1137l = new C1137l(c1137l2);
            c1137l.f12732a = c1137l2.f12732a;
        } else {
            c1137l = new C1137l(layoutParams);
        }
        if (((LinearLayout.LayoutParams) c1137l).gravity <= 0) {
            ((LinearLayout.LayoutParams) c1137l).gravity = 16;
        }
        return c1137l;
    }

    @Override // k.k
    public final boolean a(n nVar) {
        return this.f6159w.q(nVar, null, 0);
    }

    @Override // l.A0, android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C1137l;
    }

    @Override // k.A
    public final void d(l lVar) {
        this.f6159w = lVar;
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    @Override // l.A0, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return l();
    }

    @Override // l.A0, android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return m(layoutParams);
    }

    public Menu getMenu() {
        if (this.f6159w == null) {
            Context context = getContext();
            l lVar = new l(context);
            this.f6159w = lVar;
            lVar.f11958e = new i(this, 25);
            C1133j c1133j = new C1133j(context);
            this.f6151A = c1133j;
            c1133j.f12712t = true;
            c1133j.f12713u = true;
            x fVar = this.f6152B;
            if (fVar == null) {
                fVar = new f(16);
            }
            c1133j.f12704e = fVar;
            this.f6159w.b(c1133j, this.f6160x);
            C1133j c1133j2 = this.f6151A;
            c1133j2.f12707o = this;
            this.f6159w = c1133j2.f12703c;
        }
        return this.f6159w;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C1133j c1133j = this.f6151A;
        C1129h c1129h = c1133j.f12709q;
        if (c1129h != null) {
            return c1129h.getDrawable();
        }
        if (c1133j.f12711s) {
            return c1133j.f12710r;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f6161y;
    }

    public int getWindowAnimations() {
        return 0;
    }

    @Override // l.A0
    /* renamed from: h */
    public final /* bridge */ /* synthetic */ C1165z0 generateDefaultLayoutParams() {
        return l();
    }

    @Override // l.A0
    /* renamed from: i */
    public final C1165z0 generateLayoutParams(AttributeSet attributeSet) {
        return new C1137l(getContext(), attributeSet);
    }

    @Override // l.A0
    /* renamed from: j */
    public final /* bridge */ /* synthetic */ C1165z0 generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return m(layoutParams);
    }

    public final boolean n(int i10) {
        boolean zA = false;
        if (i10 == 0) {
            return false;
        }
        KeyEvent.Callback childAt = getChildAt(i10 - 1);
        KeyEvent.Callback childAt2 = getChildAt(i10);
        if (i10 < getChildCount() && (childAt instanceof InterfaceC1135k)) {
            zA = ((InterfaceC1135k) childAt).a();
        }
        return (i10 <= 0 || !(childAt2 instanceof InterfaceC1135k)) ? zA : zA | ((InterfaceC1135k) childAt2).b();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C1133j c1133j = this.f6151A;
        if (c1133j != null) {
            c1133j.j(false);
            if (this.f6151A.h()) {
                this.f6151A.e();
                this.f6151A.n();
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C1133j c1133j = this.f6151A;
        if (c1133j != null) {
            c1133j.e();
            C1123e c1123e = c1133j.f12696B;
            if (c1123e == null || !c1123e.b()) {
                return;
            }
            c1123e.f12022j.dismiss();
        }
    }

    @Override // l.A0, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int width;
        int paddingLeft;
        if (!this.f6154D) {
            super.onLayout(z3, i10, i11, i12, i13);
            return;
        }
        int childCount = getChildCount();
        int i14 = (i13 - i11) / 2;
        int dividerWidth = getDividerWidth();
        int i15 = i12 - i10;
        int paddingRight = (i15 - getPaddingRight()) - getPaddingLeft();
        boolean zA = x1.a(this);
        int i16 = 0;
        int i17 = 0;
        for (int i18 = 0; i18 < childCount; i18++) {
            View childAt = getChildAt(i18);
            if (childAt.getVisibility() != 8) {
                C1137l c1137l = (C1137l) childAt.getLayoutParams();
                if (c1137l.f12732a) {
                    int measuredWidth = childAt.getMeasuredWidth();
                    if (n(i18)) {
                        measuredWidth += dividerWidth;
                    }
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (zA) {
                        paddingLeft = getPaddingLeft() + ((LinearLayout.LayoutParams) c1137l).leftMargin;
                        width = paddingLeft + measuredWidth;
                    } else {
                        width = (getWidth() - getPaddingRight()) - ((LinearLayout.LayoutParams) c1137l).rightMargin;
                        paddingLeft = width - measuredWidth;
                    }
                    int i19 = i14 - (measuredHeight / 2);
                    childAt.layout(paddingLeft, i19, width, measuredHeight + i19);
                    paddingRight -= measuredWidth;
                    i16 = 1;
                } else {
                    paddingRight -= (childAt.getMeasuredWidth() + ((LinearLayout.LayoutParams) c1137l).leftMargin) + ((LinearLayout.LayoutParams) c1137l).rightMargin;
                    n(i18);
                    i17++;
                }
            }
        }
        if (childCount == 1 && i16 == 0) {
            View childAt2 = getChildAt(0);
            int measuredWidth2 = childAt2.getMeasuredWidth();
            int measuredHeight2 = childAt2.getMeasuredHeight();
            int i20 = (i15 / 2) - (measuredWidth2 / 2);
            int i21 = i14 - (measuredHeight2 / 2);
            childAt2.layout(i20, i21, measuredWidth2 + i20, measuredHeight2 + i21);
            return;
        }
        int i22 = i17 - (i16 ^ 1);
        int iMax = Math.max(0, i22 > 0 ? paddingRight / i22 : 0);
        if (zA) {
            int width2 = getWidth() - getPaddingRight();
            for (int i23 = 0; i23 < childCount; i23++) {
                View childAt3 = getChildAt(i23);
                C1137l c1137l2 = (C1137l) childAt3.getLayoutParams();
                if (childAt3.getVisibility() != 8 && !c1137l2.f12732a) {
                    int i24 = width2 - ((LinearLayout.LayoutParams) c1137l2).rightMargin;
                    int measuredWidth3 = childAt3.getMeasuredWidth();
                    int measuredHeight3 = childAt3.getMeasuredHeight();
                    int i25 = i14 - (measuredHeight3 / 2);
                    childAt3.layout(i24 - measuredWidth3, i25, i24, measuredHeight3 + i25);
                    width2 = i24 - ((measuredWidth3 + ((LinearLayout.LayoutParams) c1137l2).leftMargin) + iMax);
                }
            }
            return;
        }
        int paddingLeft2 = getPaddingLeft();
        for (int i26 = 0; i26 < childCount; i26++) {
            View childAt4 = getChildAt(i26);
            C1137l c1137l3 = (C1137l) childAt4.getLayoutParams();
            if (childAt4.getVisibility() != 8 && !c1137l3.f12732a) {
                int i27 = paddingLeft2 + ((LinearLayout.LayoutParams) c1137l3).leftMargin;
                int measuredWidth4 = childAt4.getMeasuredWidth();
                int measuredHeight4 = childAt4.getMeasuredHeight();
                int i28 = i14 - (measuredHeight4 / 2);
                childAt4.layout(i27, i28, i27 + measuredWidth4, measuredHeight4 + i28);
                paddingLeft2 = measuredWidth4 + ((LinearLayout.LayoutParams) c1137l3).rightMargin + iMax + i27;
            }
        }
    }

    /* JADX WARN: Type inference failed for: r1v20 */
    /* JADX WARN: Type inference failed for: r1v21, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r1v23 */
    /* JADX WARN: Type inference failed for: r1v26 */
    @Override // l.A0, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        int i13;
        int i14;
        boolean z3;
        int i15;
        int i16;
        int i17;
        int i18;
        ?? r12;
        int i19;
        int i20;
        int i21;
        l lVar;
        boolean z9 = this.f6154D;
        boolean z10 = View.MeasureSpec.getMode(i10) == 1073741824;
        this.f6154D = z10;
        if (z9 != z10) {
            this.f6155E = 0;
        }
        int size = View.MeasureSpec.getSize(i10);
        if (this.f6154D && (lVar = this.f6159w) != null && size != this.f6155E) {
            this.f6155E = size;
            lVar.p(true);
        }
        int childCount = getChildCount();
        if (!this.f6154D || childCount <= 0) {
            for (int i22 = 0; i22 < childCount; i22++) {
                C1137l c1137l = (C1137l) getChildAt(i22).getLayoutParams();
                ((LinearLayout.LayoutParams) c1137l).rightMargin = 0;
                ((LinearLayout.LayoutParams) c1137l).leftMargin = 0;
            }
            super.onMeasure(i10, i11);
            return;
        }
        int mode = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i10);
        int size3 = View.MeasureSpec.getSize(i11);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i11, paddingBottom, -2);
        int i23 = size2 - paddingRight;
        int i24 = this.f6156F;
        int i25 = i23 / i24;
        int i26 = i23 % i24;
        if (i25 == 0) {
            setMeasuredDimension(i23, 0);
            return;
        }
        int i27 = (i26 / i25) + i24;
        int childCount2 = getChildCount();
        int i28 = 0;
        int iMax = 0;
        int i29 = 0;
        boolean z11 = false;
        int i30 = 0;
        int iMax2 = 0;
        long j10 = 0;
        while (true) {
            i12 = this.f6157G;
            if (i29 >= childCount2) {
                break;
            }
            View childAt = getChildAt(i29);
            int i31 = size3;
            if (childAt.getVisibility() == 8) {
                i19 = i23;
                i20 = paddingBottom;
            } else {
                boolean z12 = childAt instanceof ActionMenuItemView;
                int i32 = i28 + 1;
                if (z12) {
                    childAt.setPadding(i12, 0, i12, 0);
                }
                C1137l c1137l2 = (C1137l) childAt.getLayoutParams();
                c1137l2.f12736f = false;
                c1137l2.f12734c = 0;
                c1137l2.f12733b = 0;
                c1137l2.d = false;
                ((LinearLayout.LayoutParams) c1137l2).leftMargin = 0;
                ((LinearLayout.LayoutParams) c1137l2).rightMargin = 0;
                c1137l2.f12735e = z12 && (TextUtils.isEmpty(((ActionMenuItemView) childAt).getText()) ^ true);
                int i33 = c1137l2.f12732a ? 1 : i25;
                C1137l c1137l3 = (C1137l) childAt.getLayoutParams();
                i19 = i23;
                i20 = paddingBottom;
                int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(childMeasureSpec) - paddingBottom, View.MeasureSpec.getMode(childMeasureSpec));
                ActionMenuItemView actionMenuItemView = z12 ? (ActionMenuItemView) childAt : null;
                boolean z13 = actionMenuItemView != null && (TextUtils.isEmpty(actionMenuItemView.getText()) ^ true);
                if (i33 <= 0 || (z13 && i33 < 2)) {
                    i21 = 0;
                } else {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec(i33 * i27, Integer.MIN_VALUE), iMakeMeasureSpec);
                    int measuredWidth = childAt.getMeasuredWidth();
                    i21 = measuredWidth / i27;
                    if (measuredWidth % i27 != 0) {
                        i21++;
                    }
                    if (z13 && i21 < 2) {
                        i21 = 2;
                    }
                }
                c1137l3.d = !c1137l3.f12732a && z13;
                c1137l3.f12733b = i21;
                childAt.measure(View.MeasureSpec.makeMeasureSpec(i21 * i27, 1073741824), iMakeMeasureSpec);
                iMax = Math.max(iMax, i21);
                if (c1137l2.d) {
                    i30++;
                }
                if (c1137l2.f12732a) {
                    z11 = true;
                }
                i25 -= i21;
                iMax2 = Math.max(iMax2, childAt.getMeasuredHeight());
                if (i21 == 1) {
                    j10 |= 1 << i29;
                }
                i28 = i32;
            }
            i29++;
            size3 = i31;
            paddingBottom = i20;
            i23 = i19;
        }
        int i34 = i23;
        int i35 = size3;
        int i36 = iMax2;
        boolean z14 = z11 && i28 == 2;
        boolean z15 = false;
        while (i30 > 0 && i25 > 0) {
            int i37 = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
            int i38 = 0;
            int i39 = 0;
            long j11 = 0;
            while (i39 < childCount2) {
                int i40 = i36;
                C1137l c1137l4 = (C1137l) getChildAt(i39).getLayoutParams();
                boolean z16 = z15;
                if (c1137l4.d) {
                    int i41 = c1137l4.f12733b;
                    if (i41 < i37) {
                        j11 = 1 << i39;
                        i37 = i41;
                        i38 = 1;
                    } else if (i41 == i37) {
                        i38++;
                        j11 |= 1 << i39;
                    }
                }
                i39++;
                z15 = z16;
                i36 = i40;
            }
            i14 = i36;
            z3 = z15;
            j10 |= j11;
            if (i38 > i25) {
                i13 = mode;
                break;
            }
            int i42 = i37 + 1;
            int i43 = 0;
            while (i43 < childCount2) {
                View childAt2 = getChildAt(i43);
                C1137l c1137l5 = (C1137l) childAt2.getLayoutParams();
                int i44 = mode;
                int i45 = childMeasureSpec;
                int i46 = childCount2;
                long j12 = 1 << i43;
                if ((j11 & j12) != 0) {
                    if (z14 && c1137l5.f12735e) {
                        r12 = 1;
                        r12 = 1;
                        if (i25 == 1) {
                            childAt2.setPadding(i12 + i27, 0, i12, 0);
                        }
                    } else {
                        r12 = 1;
                    }
                    c1137l5.f12733b += r12;
                    c1137l5.f12736f = r12;
                    i25--;
                } else if (c1137l5.f12733b == i42) {
                    j10 |= j12;
                }
                i43++;
                childMeasureSpec = i45;
                mode = i44;
                childCount2 = i46;
            }
            i36 = i14;
            z15 = true;
        }
        i13 = mode;
        i14 = i36;
        z3 = z15;
        int i47 = childMeasureSpec;
        int i48 = childCount2;
        boolean z17 = !z11 && i28 == 1;
        if (i25 <= 0 || j10 == 0 || (i25 >= i28 - 1 && !z17 && iMax <= 1)) {
            i15 = i48;
        } else {
            float fBitCount = Long.bitCount(j10);
            if (!z17) {
                if ((j10 & 1) != 0 && !((C1137l) getChildAt(0).getLayoutParams()).f12735e) {
                    fBitCount -= 0.5f;
                }
                int i49 = i48 - 1;
                if ((j10 & (1 << i49)) != 0 && !((C1137l) getChildAt(i49).getLayoutParams()).f12735e) {
                    fBitCount -= 0.5f;
                }
            }
            int i50 = fBitCount > 0.0f ? (int) ((i25 * i27) / fBitCount) : 0;
            i15 = i48;
            for (int i51 = 0; i51 < i15; i51++) {
                if ((j10 & (1 << i51)) != 0) {
                    View childAt3 = getChildAt(i51);
                    C1137l c1137l6 = (C1137l) childAt3.getLayoutParams();
                    if (childAt3 instanceof ActionMenuItemView) {
                        c1137l6.f12734c = i50;
                        c1137l6.f12736f = true;
                        if (i51 == 0 && !c1137l6.f12735e) {
                            ((LinearLayout.LayoutParams) c1137l6).leftMargin = (-i50) / 2;
                        }
                        z3 = true;
                    } else if (c1137l6.f12732a) {
                        c1137l6.f12734c = i50;
                        c1137l6.f12736f = true;
                        ((LinearLayout.LayoutParams) c1137l6).rightMargin = (-i50) / 2;
                        z3 = true;
                    } else {
                        if (i51 != 0) {
                            ((LinearLayout.LayoutParams) c1137l6).leftMargin = i50 / 2;
                        }
                        if (i51 != i15 - 1) {
                            ((LinearLayout.LayoutParams) c1137l6).rightMargin = i50 / 2;
                        }
                    }
                }
            }
        }
        if (z3) {
            int i52 = 0;
            while (i52 < i15) {
                View childAt4 = getChildAt(i52);
                C1137l c1137l7 = (C1137l) childAt4.getLayoutParams();
                if (c1137l7.f12736f) {
                    i18 = i47;
                    childAt4.measure(View.MeasureSpec.makeMeasureSpec((c1137l7.f12733b * i27) + c1137l7.f12734c, 1073741824), i18);
                } else {
                    i18 = i47;
                }
                i52++;
                i47 = i18;
            }
        }
        if (i13 != 1073741824) {
            i17 = i34;
            i16 = i14;
        } else {
            i16 = i35;
            i17 = i34;
        }
        setMeasuredDimension(i17, i16);
    }

    public void setExpandedActionViewsExclusive(boolean z3) {
        this.f6151A.f12717y = z3;
    }

    public void setOnMenuItemClickListener(InterfaceC1139m interfaceC1139m) {
        this.f6158H = interfaceC1139m;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C1133j c1133j = this.f6151A;
        C1129h c1129h = c1133j.f12709q;
        if (c1129h != null) {
            c1129h.setImageDrawable(drawable);
        } else {
            c1133j.f12711s = true;
            c1133j.f12710r = drawable;
        }
    }

    public void setOverflowReserved(boolean z3) {
        this.f6162z = z3;
    }

    public void setPopupTheme(int i10) {
        if (this.f6161y != i10) {
            this.f6161y = i10;
            if (i10 == 0) {
                this.f6160x = getContext();
            } else {
                this.f6160x = new ContextThemeWrapper(getContext(), i10);
            }
        }
    }

    public void setPresenter(C1133j c1133j) {
        this.f6151A = c1133j;
        c1133j.f12707o = this;
        this.f6159w = c1133j.f12703c;
    }

    @Override // l.A0, android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C1137l(getContext(), attributeSet);
    }
}
