package androidx.appcompat.widget;

import D6.G;
import R.AbstractC0254m;
import R.F;
import R.InterfaceC0255n;
import R.X;
import W3.e;
import X0.m;
import a.AbstractC0338a;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.fragment.app.A;
import com.tajir.tajir.R;
import e.AbstractC0764a;
import j.j;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.WeakHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import k.l;
import k.n;
import k6.C1101A;
import k6.z;
import l.C1122d0;
import l.C1133j;
import l.C1158w;
import l.C1160x;
import l.InterfaceC1144o0;
import l.S0;
import l.i1;
import l.j1;
import l.l1;
import l.m1;
import l.n1;
import l.o1;
import l.p1;
import l.q1;
import l.x1;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup implements InterfaceC0255n {

    /* renamed from: A */
    public S0 f6217A;

    /* renamed from: B */
    public int f6218B;

    /* renamed from: C */
    public int f6219C;

    /* renamed from: D */
    public final int f6220D;

    /* renamed from: E */
    public CharSequence f6221E;

    /* renamed from: F */
    public CharSequence f6222F;

    /* renamed from: G */
    public ColorStateList f6223G;

    /* renamed from: H */
    public ColorStateList f6224H;

    /* renamed from: I */
    public boolean f6225I;

    /* renamed from: J */
    public boolean f6226J;
    public final ArrayList K;

    /* renamed from: L */
    public final ArrayList f6227L;

    /* renamed from: M */
    public final int[] f6228M;

    /* renamed from: N */
    public final m f6229N;

    /* renamed from: O */
    public ArrayList f6230O;

    /* renamed from: P */
    public final C1101A f6231P;

    /* renamed from: Q */
    public q1 f6232Q;

    /* renamed from: R */
    public C1133j f6233R;

    /* renamed from: S */
    public l1 f6234S;

    /* renamed from: T */
    public boolean f6235T;

    /* renamed from: U */
    public OnBackInvokedCallback f6236U;

    /* renamed from: V */
    public OnBackInvokedDispatcher f6237V;

    /* renamed from: W */
    public boolean f6238W;

    /* renamed from: a */
    public ActionMenuView f6239a;

    /* renamed from: a0 */
    public final G f6240a0;

    /* renamed from: b */
    public C1122d0 f6241b;

    /* renamed from: c */
    public C1122d0 f6242c;
    public C1158w d;

    /* renamed from: e */
    public C1160x f6243e;

    /* renamed from: f */
    public final Drawable f6244f;

    /* renamed from: n */
    public final CharSequence f6245n;

    /* renamed from: o */
    public C1158w f6246o;

    /* renamed from: p */
    public View f6247p;

    /* renamed from: q */
    public Context f6248q;

    /* renamed from: r */
    public int f6249r;

    /* renamed from: s */
    public int f6250s;

    /* renamed from: t */
    public int f6251t;

    /* renamed from: u */
    public final int f6252u;

    /* renamed from: v */
    public final int f6253v;

    /* renamed from: w */
    public int f6254w;

    /* renamed from: x */
    public int f6255x;

    /* renamed from: y */
    public int f6256y;

    /* renamed from: z */
    public int f6257z;

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    private ArrayList<MenuItem> getCurrentMenuItems() {
        ArrayList<MenuItem> arrayList = new ArrayList<>();
        Menu menu = getMenu();
        for (int i10 = 0; i10 < menu.size(); i10++) {
            arrayList.add(menu.getItem(i10));
        }
        return arrayList;
    }

    private MenuInflater getMenuInflater() {
        return new j(getContext());
    }

    public static m1 h() {
        m1 m1Var = new m1(-2, -2);
        m1Var.f12744b = 0;
        m1Var.f12743a = 8388627;
        return m1Var;
    }

    public static m1 i(ViewGroup.LayoutParams layoutParams) {
        boolean z3 = layoutParams instanceof m1;
        if (z3) {
            m1 m1Var = (m1) layoutParams;
            m1 m1Var2 = new m1(m1Var);
            m1Var2.f12744b = 0;
            m1Var2.f12744b = m1Var.f12744b;
            return m1Var2;
        }
        if (z3) {
            m1 m1Var3 = new m1((m1) layoutParams);
            m1Var3.f12744b = 0;
            return m1Var3;
        }
        if (!(layoutParams instanceof ViewGroup.MarginLayoutParams)) {
            m1 m1Var4 = new m1(layoutParams);
            m1Var4.f12744b = 0;
            return m1Var4;
        }
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams;
        m1 m1Var5 = new m1(marginLayoutParams);
        m1Var5.f12744b = 0;
        ((ViewGroup.MarginLayoutParams) m1Var5).leftMargin = marginLayoutParams.leftMargin;
        ((ViewGroup.MarginLayoutParams) m1Var5).topMargin = marginLayoutParams.topMargin;
        ((ViewGroup.MarginLayoutParams) m1Var5).rightMargin = marginLayoutParams.rightMargin;
        ((ViewGroup.MarginLayoutParams) m1Var5).bottomMargin = marginLayoutParams.bottomMargin;
        return m1Var5;
    }

    public static int l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return AbstractC0254m.b(marginLayoutParams) + AbstractC0254m.c(marginLayoutParams);
    }

    public static int m(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final void a(int i10, ArrayList arrayList) {
        WeakHashMap weakHashMap = X.f3966a;
        boolean z3 = F.d(this) == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, F.d(this));
        arrayList.clear();
        if (!z3) {
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                m1 m1Var = (m1) childAt.getLayoutParams();
                if (m1Var.f12744b == 0 && u(childAt) && j(m1Var.f12743a) == absoluteGravity) {
                    arrayList.add(childAt);
                }
            }
            return;
        }
        for (int i12 = childCount - 1; i12 >= 0; i12--) {
            View childAt2 = getChildAt(i12);
            m1 m1Var2 = (m1) childAt2.getLayoutParams();
            if (m1Var2.f12744b == 0 && u(childAt2) && j(m1Var2.f12743a) == absoluteGravity) {
                arrayList.add(childAt2);
            }
        }
    }

    public final void b(View view, boolean z3) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        m1 m1VarH = layoutParams == null ? h() : !checkLayoutParams(layoutParams) ? i(layoutParams) : (m1) layoutParams;
        m1VarH.f12744b = 1;
        if (!z3 || this.f6247p == null) {
            addView(view, m1VarH);
        } else {
            view.setLayoutParams(m1VarH);
            this.f6227L.add(view);
        }
    }

    public final void c() {
        if (this.f6246o == null) {
            C1158w c1158w = new C1158w(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            this.f6246o = c1158w;
            c1158w.setImageDrawable(this.f6244f);
            this.f6246o.setContentDescription(this.f6245n);
            m1 m1VarH = h();
            m1VarH.f12743a = (this.f6252u & 112) | 8388611;
            m1VarH.f12744b = 2;
            this.f6246o.setLayoutParams(m1VarH);
            this.f6246o.setOnClickListener(new e(this, 5));
        }
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof m1);
    }

    public final void d() {
        if (this.f6217A == null) {
            S0 s02 = new S0();
            s02.f12616a = 0;
            s02.f12617b = 0;
            s02.f12618c = Integer.MIN_VALUE;
            s02.d = Integer.MIN_VALUE;
            s02.f12619e = 0;
            s02.f12620f = 0;
            s02.g = false;
            s02.f12621h = false;
            this.f6217A = s02;
        }
    }

    public final void e() {
        f();
        ActionMenuView actionMenuView = this.f6239a;
        if (actionMenuView.f6159w == null) {
            l lVar = (l) actionMenuView.getMenu();
            if (this.f6234S == null) {
                this.f6234S = new l1(this);
            }
            this.f6239a.setExpandedActionViewsExclusive(true);
            lVar.b(this.f6234S, this.f6248q);
            v();
        }
    }

    public final void f() {
        if (this.f6239a == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), null);
            this.f6239a = actionMenuView;
            actionMenuView.setPopupTheme(this.f6249r);
            this.f6239a.setOnMenuItemClickListener(this.f6231P);
            ActionMenuView actionMenuView2 = this.f6239a;
            j1 j1Var = new j1(this, 0);
            actionMenuView2.f6152B = null;
            actionMenuView2.f6153C = j1Var;
            m1 m1VarH = h();
            m1VarH.f12743a = (this.f6252u & 112) | 8388613;
            this.f6239a.setLayoutParams(m1VarH);
            b(this.f6239a, false);
        }
    }

    public final void g() {
        if (this.d == null) {
            this.d = new C1158w(getContext(), null, R.attr.toolbarNavigationButtonStyle);
            m1 m1VarH = h();
            m1VarH.f12743a = (this.f6252u & 112) | 8388611;
            this.d.setLayoutParams(m1VarH);
        }
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return h();
    }

    @Override // android.view.ViewGroup
    public final /* bridge */ /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return i(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        C1158w c1158w = this.f6246o;
        if (c1158w != null) {
            return c1158w.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        C1158w c1158w = this.f6246o;
        if (c1158w != null) {
            return c1158w.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        S0 s02 = this.f6217A;
        if (s02 != null) {
            return s02.g ? s02.f12616a : s02.f12617b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i10 = this.f6219C;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        S0 s02 = this.f6217A;
        if (s02 != null) {
            return s02.f12616a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        S0 s02 = this.f6217A;
        if (s02 != null) {
            return s02.f12617b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        S0 s02 = this.f6217A;
        if (s02 != null) {
            return s02.g ? s02.f12617b : s02.f12616a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i10 = this.f6218B;
        return i10 != Integer.MIN_VALUE ? i10 : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        l lVar;
        ActionMenuView actionMenuView = this.f6239a;
        return (actionMenuView == null || (lVar = actionMenuView.f6159w) == null || !lVar.hasVisibleItems()) ? getContentInsetEnd() : Math.max(getContentInsetEnd(), Math.max(this.f6219C, 0));
    }

    public int getCurrentContentInsetLeft() {
        WeakHashMap weakHashMap = X.f3966a;
        return F.d(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        WeakHashMap weakHashMap = X.f3966a;
        return F.d(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f6218B, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        C1160x c1160x = this.f6243e;
        if (c1160x != null) {
            return c1160x.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        C1160x c1160x = this.f6243e;
        if (c1160x != null) {
            return c1160x.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        e();
        return this.f6239a.getMenu();
    }

    public View getNavButtonView() {
        return this.d;
    }

    public CharSequence getNavigationContentDescription() {
        C1158w c1158w = this.d;
        if (c1158w != null) {
            return c1158w.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        C1158w c1158w = this.d;
        if (c1158w != null) {
            return c1158w.getDrawable();
        }
        return null;
    }

    public C1133j getOuterActionMenuPresenter() {
        return this.f6233R;
    }

    public Drawable getOverflowIcon() {
        e();
        return this.f6239a.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f6248q;
    }

    public int getPopupTheme() {
        return this.f6249r;
    }

    public CharSequence getSubtitle() {
        return this.f6222F;
    }

    public final TextView getSubtitleTextView() {
        return this.f6242c;
    }

    public CharSequence getTitle() {
        return this.f6221E;
    }

    public int getTitleMarginBottom() {
        return this.f6257z;
    }

    public int getTitleMarginEnd() {
        return this.f6255x;
    }

    public int getTitleMarginStart() {
        return this.f6254w;
    }

    public int getTitleMarginTop() {
        return this.f6256y;
    }

    public final TextView getTitleTextView() {
        return this.f6241b;
    }

    public InterfaceC1144o0 getWrapper() {
        Drawable drawable;
        if (this.f6232Q == null) {
            q1 q1Var = new q1();
            q1Var.f12773n = 0;
            q1Var.f12762a = this;
            q1Var.f12767h = getTitle();
            q1Var.f12768i = getSubtitle();
            q1Var.g = q1Var.f12767h != null;
            q1Var.f12766f = getNavigationIcon();
            z zVarJ = z.j(getContext(), null, AbstractC0764a.f10122a, R.attr.actionBarStyle, 0);
            q1Var.f12774o = zVarJ.f(15);
            TypedArray typedArray = (TypedArray) zVarJ.f12479c;
            CharSequence text = typedArray.getText(27);
            if (!TextUtils.isEmpty(text)) {
                q1Var.g = true;
                q1Var.f12767h = text;
                if ((q1Var.f12763b & 8) != 0) {
                    Toolbar toolbar = q1Var.f12762a;
                    toolbar.setTitle(text);
                    if (q1Var.g) {
                        X.o(toolbar.getRootView(), text);
                    }
                }
            }
            CharSequence text2 = typedArray.getText(25);
            if (!TextUtils.isEmpty(text2)) {
                q1Var.f12768i = text2;
                if ((q1Var.f12763b & 8) != 0) {
                    setSubtitle(text2);
                }
            }
            Drawable drawableF = zVarJ.f(20);
            if (drawableF != null) {
                q1Var.f12765e = drawableF;
                q1Var.c();
            }
            Drawable drawableF2 = zVarJ.f(17);
            if (drawableF2 != null) {
                q1Var.d = drawableF2;
                q1Var.c();
            }
            if (q1Var.f12766f == null && (drawable = q1Var.f12774o) != null) {
                q1Var.f12766f = drawable;
                int i10 = q1Var.f12763b & 4;
                Toolbar toolbar2 = q1Var.f12762a;
                if (i10 != 0) {
                    toolbar2.setNavigationIcon(drawable);
                } else {
                    toolbar2.setNavigationIcon((Drawable) null);
                }
            }
            q1Var.a(typedArray.getInt(10, 0));
            int resourceId = typedArray.getResourceId(9, 0);
            if (resourceId != 0) {
                View viewInflate = LayoutInflater.from(getContext()).inflate(resourceId, (ViewGroup) this, false);
                View view = q1Var.f12764c;
                if (view != null && (q1Var.f12763b & 16) != 0) {
                    removeView(view);
                }
                q1Var.f12764c = viewInflate;
                if (viewInflate != null && (q1Var.f12763b & 16) != 0) {
                    addView(viewInflate);
                }
                q1Var.a(q1Var.f12763b | 16);
            }
            int layoutDimension = typedArray.getLayoutDimension(13, 0);
            if (layoutDimension > 0) {
                ViewGroup.LayoutParams layoutParams = getLayoutParams();
                layoutParams.height = layoutDimension;
                setLayoutParams(layoutParams);
            }
            int dimensionPixelOffset = typedArray.getDimensionPixelOffset(7, -1);
            int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(3, -1);
            if (dimensionPixelOffset >= 0 || dimensionPixelOffset2 >= 0) {
                int iMax = Math.max(dimensionPixelOffset, 0);
                int iMax2 = Math.max(dimensionPixelOffset2, 0);
                d();
                this.f6217A.a(iMax, iMax2);
            }
            int resourceId2 = typedArray.getResourceId(28, 0);
            if (resourceId2 != 0) {
                Context context = getContext();
                this.f6250s = resourceId2;
                C1122d0 c1122d0 = this.f6241b;
                if (c1122d0 != null) {
                    c1122d0.setTextAppearance(context, resourceId2);
                }
            }
            int resourceId3 = typedArray.getResourceId(26, 0);
            if (resourceId3 != 0) {
                Context context2 = getContext();
                this.f6251t = resourceId3;
                C1122d0 c1122d02 = this.f6242c;
                if (c1122d02 != null) {
                    c1122d02.setTextAppearance(context2, resourceId3);
                }
            }
            int resourceId4 = typedArray.getResourceId(22, 0);
            if (resourceId4 != 0) {
                setPopupTheme(resourceId4);
            }
            zVarJ.k();
            if (R.string.abc_action_bar_up_description != q1Var.f12773n) {
                q1Var.f12773n = R.string.abc_action_bar_up_description;
                if (TextUtils.isEmpty(getNavigationContentDescription())) {
                    int i11 = q1Var.f12773n;
                    q1Var.f12769j = i11 != 0 ? getContext().getString(i11) : null;
                    q1Var.b();
                }
            }
            q1Var.f12769j = getNavigationContentDescription();
            setNavigationOnClickListener(new p1(q1Var));
            this.f6232Q = q1Var;
        }
        return this.f6232Q;
    }

    public final int j(int i10) {
        WeakHashMap weakHashMap = X.f3966a;
        int iD = F.d(this);
        int absoluteGravity = Gravity.getAbsoluteGravity(i10, iD) & 7;
        return (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) ? absoluteGravity : iD == 1 ? 5 : 3;
    }

    public final int k(View view, int i10) {
        m1 m1Var = (m1) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i11 = i10 > 0 ? (measuredHeight - i10) / 2 : 0;
        int i12 = m1Var.f12743a & 112;
        if (i12 != 16 && i12 != 48 && i12 != 80) {
            i12 = this.f6220D & 112;
        }
        if (i12 == 48) {
            return getPaddingTop() - i11;
        }
        if (i12 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) m1Var).bottomMargin) - i11;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int iMax = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i13 = ((ViewGroup.MarginLayoutParams) m1Var).topMargin;
        if (iMax < i13) {
            iMax = i13;
        } else {
            int i14 = (((height - paddingBottom) - measuredHeight) - iMax) - paddingTop;
            int i15 = ((ViewGroup.MarginLayoutParams) m1Var).bottomMargin;
            if (i14 < i15) {
                iMax = Math.max(0, iMax - (i15 - i14));
            }
        }
        return paddingTop + iMax;
    }

    public void n(int i10) {
        getMenuInflater().inflate(i10, getMenu());
    }

    public final void o() {
        Iterator it = this.f6230O.iterator();
        while (it.hasNext()) {
            getMenu().removeItem(((MenuItem) it.next()).getItemId());
        }
        getMenu();
        ArrayList<MenuItem> currentMenuItems = getCurrentMenuItems();
        getMenuInflater();
        Iterator it2 = ((CopyOnWriteArrayList) this.f6229N.f5324c).iterator();
        while (it2.hasNext()) {
            ((A) it2.next()).f6612a.j();
        }
        ArrayList<MenuItem> currentMenuItems2 = getCurrentMenuItems();
        currentMenuItems2.removeAll(currentMenuItems);
        this.f6230O = currentMenuItems2;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        v();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f6240a0);
        v();
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f6226J = false;
        }
        if (!this.f6226J) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f6226J = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f6226J = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:148:0x0062  */
    /* JADX WARN: Removed duplicated region for block: B:153:0x0079  */
    /* JADX WARN: Removed duplicated region for block: B:158:0x00b6  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x00cd  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x00ea  */
    /* JADX WARN: Removed duplicated region for block: B:169:0x0101  */
    /* JADX WARN: Removed duplicated region for block: B:171:0x0106  */
    /* JADX WARN: Removed duplicated region for block: B:172:0x011e  */
    /* JADX WARN: Removed duplicated region for block: B:177:0x012b  */
    /* JADX WARN: Removed duplicated region for block: B:178:0x012d  */
    /* JADX WARN: Removed duplicated region for block: B:179:0x0130  */
    /* JADX WARN: Removed duplicated region for block: B:181:0x0134  */
    /* JADX WARN: Removed duplicated region for block: B:182:0x0137  */
    /* JADX WARN: Removed duplicated region for block: B:194:0x016a  */
    /* JADX WARN: Removed duplicated region for block: B:204:0x01a2  */
    /* JADX WARN: Removed duplicated region for block: B:206:0x01b1  */
    /* JADX WARN: Removed duplicated region for block: B:220:0x0222  */
    /* JADX WARN: Removed duplicated region for block: B:236:0x029b A[LOOP:0: B:235:0x0299->B:236:0x029b, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:239:0x02b8 A[LOOP:1: B:238:0x02b6->B:239:0x02b8, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:242:0x02d6 A[LOOP:2: B:241:0x02d4->B:242:0x02d6, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:246:0x0317  */
    /* JADX WARN: Removed duplicated region for block: B:251:0x0325 A[LOOP:3: B:250:0x0323->B:251:0x0325, LOOP_END] */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public void onLayout(boolean r19, int r20, int r21, int r22, int r23) {
        /*
            Method dump skipped, instructions count: 822
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        int iL;
        int iMax;
        int iCombineMeasuredStates;
        int iL2;
        int iM;
        int iCombineMeasuredStates2;
        int iMax2;
        boolean zA = x1.a(this);
        int i12 = !zA ? 1 : 0;
        int i13 = 0;
        if (u(this.d)) {
            t(this.d, i10, 0, i11, this.f6253v);
            iL = l(this.d) + this.d.getMeasuredWidth();
            iMax = Math.max(0, m(this.d) + this.d.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(0, this.d.getMeasuredState());
        } else {
            iL = 0;
            iMax = 0;
            iCombineMeasuredStates = 0;
        }
        if (u(this.f6246o)) {
            t(this.f6246o, i10, 0, i11, this.f6253v);
            iL = l(this.f6246o) + this.f6246o.getMeasuredWidth();
            iMax = Math.max(iMax, m(this.f6246o) + this.f6246o.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f6246o.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int iMax3 = Math.max(currentContentInsetStart, iL);
        int iMax4 = Math.max(0, currentContentInsetStart - iL);
        int[] iArr = this.f6228M;
        iArr[zA ? 1 : 0] = iMax4;
        if (u(this.f6239a)) {
            t(this.f6239a, i10, iMax3, i11, this.f6253v);
            iL2 = l(this.f6239a) + this.f6239a.getMeasuredWidth();
            iMax = Math.max(iMax, m(this.f6239a) + this.f6239a.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f6239a.getMeasuredState());
        } else {
            iL2 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int iMax5 = iMax3 + Math.max(currentContentInsetEnd, iL2);
        iArr[i12] = Math.max(0, currentContentInsetEnd - iL2);
        if (u(this.f6247p)) {
            iMax5 += s(this.f6247p, i10, iMax5, i11, 0, iArr);
            iMax = Math.max(iMax, m(this.f6247p) + this.f6247p.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f6247p.getMeasuredState());
        }
        if (u(this.f6243e)) {
            iMax5 += s(this.f6243e, i10, iMax5, i11, 0, iArr);
            iMax = Math.max(iMax, m(this.f6243e) + this.f6243e.getMeasuredHeight());
            iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, this.f6243e.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (((m1) childAt.getLayoutParams()).f12744b == 0 && u(childAt)) {
                iMax5 += s(childAt, i10, iMax5, i11, 0, iArr);
                iMax = Math.max(iMax, m(childAt) + childAt.getMeasuredHeight());
                iCombineMeasuredStates = View.combineMeasuredStates(iCombineMeasuredStates, childAt.getMeasuredState());
            }
        }
        int i15 = this.f6256y + this.f6257z;
        int i16 = this.f6254w + this.f6255x;
        if (u(this.f6241b)) {
            s(this.f6241b, i10, iMax5 + i16, i11, i15, iArr);
            int iL3 = l(this.f6241b) + this.f6241b.getMeasuredWidth();
            iM = m(this.f6241b) + this.f6241b.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f6241b.getMeasuredState());
            iMax2 = iL3;
        } else {
            iM = 0;
            iCombineMeasuredStates2 = iCombineMeasuredStates;
            iMax2 = 0;
        }
        if (u(this.f6242c)) {
            iMax2 = Math.max(iMax2, s(this.f6242c, i10, iMax5 + i16, i11, iM + i15, iArr));
            iM += m(this.f6242c) + this.f6242c.getMeasuredHeight();
            iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates2, this.f6242c.getMeasuredState());
        }
        int iMax6 = Math.max(iMax, iM);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + iMax6;
        int iResolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + iMax5 + iMax2, getSuggestedMinimumWidth()), i10, (-16777216) & iCombineMeasuredStates2);
        int iResolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i11, iCombineMeasuredStates2 << 16);
        if (!this.f6235T) {
            i13 = iResolveSizeAndState2;
            break;
        }
        int childCount2 = getChildCount();
        for (int i17 = 0; i17 < childCount2; i17++) {
            View childAt2 = getChildAt(i17);
            if (u(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                i13 = iResolveSizeAndState2;
                break;
            }
        }
        setMeasuredDimension(iResolveSizeAndState, i13);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem menuItemFindItem;
        if (!(parcelable instanceof o1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        o1 o1Var = (o1) parcelable;
        super.onRestoreInstanceState(o1Var.f5637a);
        ActionMenuView actionMenuView = this.f6239a;
        l lVar = actionMenuView != null ? actionMenuView.f6159w : null;
        int i10 = o1Var.f12751c;
        if (i10 != 0 && this.f6234S != null && lVar != null && (menuItemFindItem = lVar.findItem(i10)) != null) {
            menuItemFindItem.expandActionView();
        }
        if (o1Var.d) {
            G g = this.f6240a0;
            removeCallbacks(g);
            post(g);
        }
    }

    @Override // android.view.View
    public final void onRtlPropertiesChanged(int i10) {
        super.onRtlPropertiesChanged(i10);
        d();
        S0 s02 = this.f6217A;
        boolean z3 = i10 == 1;
        if (z3 == s02.g) {
            return;
        }
        s02.g = z3;
        if (!s02.f12621h) {
            s02.f12616a = s02.f12619e;
            s02.f12617b = s02.f12620f;
            return;
        }
        if (z3) {
            int i11 = s02.d;
            if (i11 == Integer.MIN_VALUE) {
                i11 = s02.f12619e;
            }
            s02.f12616a = i11;
            int i12 = s02.f12618c;
            if (i12 == Integer.MIN_VALUE) {
                i12 = s02.f12620f;
            }
            s02.f12617b = i12;
            return;
        }
        int i13 = s02.f12618c;
        if (i13 == Integer.MIN_VALUE) {
            i13 = s02.f12619e;
        }
        s02.f12616a = i13;
        int i14 = s02.d;
        if (i14 == Integer.MIN_VALUE) {
            i14 = s02.f12620f;
        }
        s02.f12617b = i14;
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        C1133j c1133j;
        n nVar;
        o1 o1Var = new o1(super.onSaveInstanceState());
        l1 l1Var = this.f6234S;
        if (l1Var != null && (nVar = l1Var.f12741b) != null) {
            o1Var.f12751c = nVar.f11986a;
        }
        ActionMenuView actionMenuView = this.f6239a;
        o1Var.d = (actionMenuView == null || (c1133j = actionMenuView.f6151A) == null || !c1133j.h()) ? false : true;
        return o1Var;
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f6225I = false;
        }
        if (!this.f6225I) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f6225I = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f6225I = false;
        }
        return true;
    }

    public final boolean p(View view) {
        return view.getParent() == this || this.f6227L.contains(view);
    }

    public final int q(View view, int i10, int i11, int[] iArr) {
        m1 m1Var = (m1) view.getLayoutParams();
        int i12 = ((ViewGroup.MarginLayoutParams) m1Var).leftMargin - iArr[0];
        int iMax = Math.max(0, i12) + i10;
        iArr[0] = Math.max(0, -i12);
        int iK = k(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax, iK, iMax + measuredWidth, view.getMeasuredHeight() + iK);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) m1Var).rightMargin + iMax;
    }

    public final int r(View view, int i10, int i11, int[] iArr) {
        m1 m1Var = (m1) view.getLayoutParams();
        int i12 = ((ViewGroup.MarginLayoutParams) m1Var).rightMargin - iArr[1];
        int iMax = i10 - Math.max(0, i12);
        iArr[1] = Math.max(0, -i12);
        int iK = k(view, i11);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(iMax - measuredWidth, iK, iMax, view.getMeasuredHeight() + iK);
        return iMax - (measuredWidth + ((ViewGroup.MarginLayoutParams) m1Var).leftMargin);
    }

    public final int s(View view, int i10, int i11, int i12, int i13, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i14 = marginLayoutParams.leftMargin - iArr[0];
        int i15 = marginLayoutParams.rightMargin - iArr[1];
        int iMax = Math.max(0, i15) + Math.max(0, i14);
        iArr[0] = Math.max(0, -i14);
        iArr[1] = Math.max(0, -i15);
        view.measure(ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + iMax + i11, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i12, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i13, marginLayoutParams.height));
        return view.getMeasuredWidth() + iMax;
    }

    public void setBackInvokedCallbackEnabled(boolean z3) {
        if (this.f6238W != z3) {
            this.f6238W = z3;
            v();
        }
    }

    public void setCollapseContentDescription(int i10) {
        setCollapseContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setCollapseIcon(int i10) {
        setCollapseIcon(AbstractC0338a.s(getContext(), i10));
    }

    public void setCollapsible(boolean z3) {
        this.f6235T = z3;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f6219C) {
            this.f6219C = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i10) {
        if (i10 < 0) {
            i10 = Integer.MIN_VALUE;
        }
        if (i10 != this.f6218B) {
            this.f6218B = i10;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i10) {
        setLogo(AbstractC0338a.s(getContext(), i10));
    }

    public void setLogoDescription(int i10) {
        setLogoDescription(getContext().getText(i10));
    }

    public void setNavigationContentDescription(int i10) {
        setNavigationContentDescription(i10 != 0 ? getContext().getText(i10) : null);
    }

    public void setNavigationIcon(int i10) {
        setNavigationIcon(AbstractC0338a.s(getContext(), i10));
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        g();
        this.d.setOnClickListener(onClickListener);
    }

    public void setOverflowIcon(Drawable drawable) {
        e();
        this.f6239a.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i10) {
        if (this.f6249r != i10) {
            this.f6249r = i10;
            if (i10 == 0) {
                this.f6248q = getContext();
            } else {
                this.f6248q = new ContextThemeWrapper(getContext(), i10);
            }
        }
    }

    public void setSubtitle(int i10) {
        setSubtitle(getContext().getText(i10));
    }

    public void setSubtitleTextColor(int i10) {
        setSubtitleTextColor(ColorStateList.valueOf(i10));
    }

    public void setTitle(int i10) {
        setTitle(getContext().getText(i10));
    }

    public void setTitleMarginBottom(int i10) {
        this.f6257z = i10;
        requestLayout();
    }

    public void setTitleMarginEnd(int i10) {
        this.f6255x = i10;
        requestLayout();
    }

    public void setTitleMarginStart(int i10) {
        this.f6254w = i10;
        requestLayout();
    }

    public void setTitleMarginTop(int i10) {
        this.f6256y = i10;
        requestLayout();
    }

    public void setTitleTextColor(int i10) {
        setTitleTextColor(ColorStateList.valueOf(i10));
    }

    public final void t(View view, int i10, int i11, int i12, int i13) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i10, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i11, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i12, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i13 >= 0) {
            if (mode != 0) {
                i13 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i13);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i13, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final boolean u(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    /* JADX WARN: Removed duplicated region for block: B:45:0x0023  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void v() {
        /*
            r4 = this;
            r0 = 0
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 33
            if (r1 < r2) goto L4f
            android.window.OnBackInvokedDispatcher r1 = l.k1.a(r4)
            l.l1 r2 = r4.f6234S
            if (r2 == 0) goto L23
            k.n r2 = r2.f12741b
            if (r2 == 0) goto L23
            if (r1 == 0) goto L23
            java.util.WeakHashMap r2 = R.X.f3966a
            boolean r2 = R.H.b(r4)
            if (r2 == 0) goto L23
            boolean r2 = r4.f6238W
            if (r2 == 0) goto L23
            r2 = 1
            goto L24
        L23:
            r2 = r0
        L24:
            if (r2 == 0) goto L41
            android.window.OnBackInvokedDispatcher r3 = r4.f6237V
            if (r3 != 0) goto L41
            android.window.OnBackInvokedCallback r2 = r4.f6236U
            if (r2 != 0) goto L39
            l.i1 r2 = new l.i1
            r2.<init>(r4, r0)
            android.window.OnBackInvokedCallback r0 = l.k1.b(r2)
            r4.f6236U = r0
        L39:
            android.window.OnBackInvokedCallback r0 = r4.f6236U
            l.k1.c(r1, r0)
            r4.f6237V = r1
            goto L4f
        L41:
            if (r2 != 0) goto L4f
            android.window.OnBackInvokedDispatcher r0 = r4.f6237V
            if (r0 == 0) goto L4f
            android.window.OnBackInvokedCallback r1 = r4.f6236U
            l.k1.d(r0, r1)
            r0 = 0
            r4.f6237V = r0
        L4f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.v():void");
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, R.attr.toolbarStyle);
        this.f6220D = 8388627;
        this.K = new ArrayList();
        this.f6227L = new ArrayList();
        this.f6228M = new int[2];
        this.f6229N = new m(new i1(this, 1));
        this.f6230O = new ArrayList();
        this.f6231P = new C1101A(this);
        this.f6240a0 = new G(this, 24);
        Context context2 = getContext();
        int[] iArr = AbstractC0764a.f10143x;
        z zVarJ = z.j(context2, attributeSet, iArr, R.attr.toolbarStyle, 0);
        X.m(this, context, iArr, attributeSet, (TypedArray) zVarJ.f12479c, R.attr.toolbarStyle);
        TypedArray typedArray = (TypedArray) zVarJ.f12479c;
        this.f6250s = typedArray.getResourceId(28, 0);
        this.f6251t = typedArray.getResourceId(19, 0);
        this.f6220D = typedArray.getInteger(0, 8388627);
        this.f6252u = typedArray.getInteger(2, 48);
        int dimensionPixelOffset = typedArray.getDimensionPixelOffset(22, 0);
        dimensionPixelOffset = typedArray.hasValue(27) ? typedArray.getDimensionPixelOffset(27, dimensionPixelOffset) : dimensionPixelOffset;
        this.f6257z = dimensionPixelOffset;
        this.f6256y = dimensionPixelOffset;
        this.f6255x = dimensionPixelOffset;
        this.f6254w = dimensionPixelOffset;
        int dimensionPixelOffset2 = typedArray.getDimensionPixelOffset(25, -1);
        if (dimensionPixelOffset2 >= 0) {
            this.f6254w = dimensionPixelOffset2;
        }
        int dimensionPixelOffset3 = typedArray.getDimensionPixelOffset(24, -1);
        if (dimensionPixelOffset3 >= 0) {
            this.f6255x = dimensionPixelOffset3;
        }
        int dimensionPixelOffset4 = typedArray.getDimensionPixelOffset(26, -1);
        if (dimensionPixelOffset4 >= 0) {
            this.f6256y = dimensionPixelOffset4;
        }
        int dimensionPixelOffset5 = typedArray.getDimensionPixelOffset(23, -1);
        if (dimensionPixelOffset5 >= 0) {
            this.f6257z = dimensionPixelOffset5;
        }
        this.f6253v = typedArray.getDimensionPixelSize(13, -1);
        int dimensionPixelOffset6 = typedArray.getDimensionPixelOffset(9, Integer.MIN_VALUE);
        int dimensionPixelOffset7 = typedArray.getDimensionPixelOffset(5, Integer.MIN_VALUE);
        int dimensionPixelSize = typedArray.getDimensionPixelSize(7, 0);
        int dimensionPixelSize2 = typedArray.getDimensionPixelSize(8, 0);
        d();
        S0 s02 = this.f6217A;
        s02.f12621h = false;
        if (dimensionPixelSize != Integer.MIN_VALUE) {
            s02.f12619e = dimensionPixelSize;
            s02.f12616a = dimensionPixelSize;
        }
        if (dimensionPixelSize2 != Integer.MIN_VALUE) {
            s02.f12620f = dimensionPixelSize2;
            s02.f12617b = dimensionPixelSize2;
        }
        if (dimensionPixelOffset6 != Integer.MIN_VALUE || dimensionPixelOffset7 != Integer.MIN_VALUE) {
            s02.a(dimensionPixelOffset6, dimensionPixelOffset7);
        }
        this.f6218B = typedArray.getDimensionPixelOffset(10, Integer.MIN_VALUE);
        this.f6219C = typedArray.getDimensionPixelOffset(6, Integer.MIN_VALUE);
        this.f6244f = zVarJ.f(4);
        this.f6245n = typedArray.getText(3);
        CharSequence text = typedArray.getText(21);
        if (!TextUtils.isEmpty(text)) {
            setTitle(text);
        }
        CharSequence text2 = typedArray.getText(18);
        if (!TextUtils.isEmpty(text2)) {
            setSubtitle(text2);
        }
        this.f6248q = getContext();
        setPopupTheme(typedArray.getResourceId(17, 0));
        Drawable drawableF = zVarJ.f(16);
        if (drawableF != null) {
            setNavigationIcon(drawableF);
        }
        CharSequence text3 = typedArray.getText(15);
        if (!TextUtils.isEmpty(text3)) {
            setNavigationContentDescription(text3);
        }
        Drawable drawableF2 = zVarJ.f(11);
        if (drawableF2 != null) {
            setLogo(drawableF2);
        }
        CharSequence text4 = typedArray.getText(12);
        if (!TextUtils.isEmpty(text4)) {
            setLogoDescription(text4);
        }
        if (typedArray.hasValue(29)) {
            setTitleTextColor(zVarJ.e(29));
        }
        if (typedArray.hasValue(20)) {
            setSubtitleTextColor(zVarJ.e(20));
        }
        if (typedArray.hasValue(14)) {
            n(typedArray.getResourceId(14, 0));
        }
        zVarJ.k();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        Context context = getContext();
        m1 m1Var = new m1(context, attributeSet);
        m1Var.f12743a = 0;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0764a.f10123b);
        m1Var.f12743a = typedArrayObtainStyledAttributes.getInt(0, 0);
        typedArrayObtainStyledAttributes.recycle();
        m1Var.f12744b = 0;
        return m1Var;
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            c();
        }
        C1158w c1158w = this.f6246o;
        if (c1158w != null) {
            c1158w.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            c();
            this.f6246o.setImageDrawable(drawable);
        } else {
            C1158w c1158w = this.f6246o;
            if (c1158w != null) {
                c1158w.setImageDrawable(this.f6244f);
            }
        }
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f6243e == null) {
                this.f6243e = new C1160x(getContext(), null, 0);
            }
            if (!p(this.f6243e)) {
                b(this.f6243e, true);
            }
        } else {
            C1160x c1160x = this.f6243e;
            if (c1160x != null && p(c1160x)) {
                removeView(this.f6243e);
                this.f6227L.remove(this.f6243e);
            }
        }
        C1160x c1160x2 = this.f6243e;
        if (c1160x2 != null) {
            c1160x2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f6243e == null) {
            this.f6243e = new C1160x(getContext(), null, 0);
        }
        C1160x c1160x = this.f6243e;
        if (c1160x != null) {
            c1160x.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            g();
        }
        C1158w c1158w = this.d;
        if (c1158w != null) {
            c1158w.setContentDescription(charSequence);
            f9.d.t(this.d, charSequence);
        }
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            g();
            if (!p(this.d)) {
                b(this.d, true);
            }
        } else {
            C1158w c1158w = this.d;
            if (c1158w != null && p(c1158w)) {
                removeView(this.d);
                this.f6227L.remove(this.d);
            }
        }
        C1158w c1158w2 = this.d;
        if (c1158w2 != null) {
            c1158w2.setImageDrawable(drawable);
        }
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C1122d0 c1122d0 = this.f6242c;
            if (c1122d0 != null && p(c1122d0)) {
                removeView(this.f6242c);
                this.f6227L.remove(this.f6242c);
            }
        } else {
            if (this.f6242c == null) {
                Context context = getContext();
                C1122d0 c1122d02 = new C1122d0(context, null);
                this.f6242c = c1122d02;
                c1122d02.setSingleLine();
                this.f6242c.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f6251t;
                if (i10 != 0) {
                    this.f6242c.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.f6224H;
                if (colorStateList != null) {
                    this.f6242c.setTextColor(colorStateList);
                }
            }
            if (!p(this.f6242c)) {
                b(this.f6242c, true);
            }
        }
        C1122d0 c1122d03 = this.f6242c;
        if (c1122d03 != null) {
            c1122d03.setText(charSequence);
        }
        this.f6222F = charSequence;
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f6224H = colorStateList;
        C1122d0 c1122d0 = this.f6242c;
        if (c1122d0 != null) {
            c1122d0.setTextColor(colorStateList);
        }
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            C1122d0 c1122d0 = this.f6241b;
            if (c1122d0 != null && p(c1122d0)) {
                removeView(this.f6241b);
                this.f6227L.remove(this.f6241b);
            }
        } else {
            if (this.f6241b == null) {
                Context context = getContext();
                C1122d0 c1122d02 = new C1122d0(context, null);
                this.f6241b = c1122d02;
                c1122d02.setSingleLine();
                this.f6241b.setEllipsize(TextUtils.TruncateAt.END);
                int i10 = this.f6250s;
                if (i10 != 0) {
                    this.f6241b.setTextAppearance(context, i10);
                }
                ColorStateList colorStateList = this.f6223G;
                if (colorStateList != null) {
                    this.f6241b.setTextColor(colorStateList);
                }
            }
            if (!p(this.f6241b)) {
                b(this.f6241b, true);
            }
        }
        C1122d0 c1122d03 = this.f6241b;
        if (c1122d03 != null) {
            c1122d03.setText(charSequence);
        }
        this.f6221E = charSequence;
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f6223G = colorStateList;
        C1122d0 c1122d0 = this.f6241b;
        if (c1122d0 != null) {
            c1122d0.setTextColor(colorStateList);
        }
    }

    public void setOnMenuItemClickListener(n1 n1Var) {
    }
}
