package androidx.appcompat.widget;

import R.E;
import R.X;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import com.tajir.tajir.R;
import e.AbstractC0764a;
import java.util.WeakHashMap;
import l.C1115a;
import l.T0;

/* loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* renamed from: a, reason: collision with root package name */
    public boolean f6097a;

    /* renamed from: b, reason: collision with root package name */
    public View f6098b;

    /* renamed from: c, reason: collision with root package name */
    public View f6099c;
    public Drawable d;

    /* renamed from: e, reason: collision with root package name */
    public Drawable f6100e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f6101f;

    /* renamed from: n, reason: collision with root package name */
    public final boolean f6102n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f6103o;

    /* renamed from: p, reason: collision with root package name */
    public final int f6104p;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C1115a c1115a = new C1115a(this);
        WeakHashMap weakHashMap = X.f3966a;
        E.q(this, c1115a);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0764a.f10122a);
        boolean z3 = false;
        this.d = typedArrayObtainStyledAttributes.getDrawable(0);
        this.f6100e = typedArrayObtainStyledAttributes.getDrawable(2);
        this.f6104p = typedArrayObtainStyledAttributes.getDimensionPixelSize(13, -1);
        if (getId() == R.id.split_action_bar) {
            this.f6102n = true;
            this.f6101f = typedArrayObtainStyledAttributes.getDrawable(1);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f6102n ? !(this.d != null || this.f6100e != null) : this.f6101f == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.d;
        if (drawable != null && drawable.isStateful()) {
            this.d.setState(getDrawableState());
        }
        Drawable drawable2 = this.f6100e;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f6100e.setState(getDrawableState());
        }
        Drawable drawable3 = this.f6101f;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f6101f.setState(getDrawableState());
    }

    public View getTabContainer() {
        return null;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.d;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f6100e;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f6101f;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public final void onFinishInflate() {
        super.onFinishInflate();
        this.f6098b = findViewById(R.id.action_bar);
        this.f6099c = findViewById(R.id.action_context_bar);
    }

    @Override // android.view.View
    public final boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f6097a || super.onInterceptTouchEvent(motionEvent);
    }

    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        super.onLayout(z3, i10, i11, i12, i13);
        boolean z9 = true;
        if (this.f6102n) {
            Drawable drawable = this.f6101f;
            if (drawable != null) {
                drawable.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z9 = false;
            }
        } else {
            if (this.d == null) {
                z9 = false;
            } else if (this.f6098b.getVisibility() == 0) {
                this.d.setBounds(this.f6098b.getLeft(), this.f6098b.getTop(), this.f6098b.getRight(), this.f6098b.getBottom());
            } else {
                View view = this.f6099c;
                if (view == null || view.getVisibility() != 0) {
                    this.d.setBounds(0, 0, 0, 0);
                } else {
                    this.d.setBounds(this.f6099c.getLeft(), this.f6099c.getTop(), this.f6099c.getRight(), this.f6099c.getBottom());
                }
            }
            this.f6103o = false;
        }
        if (z9) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        if (this.f6098b == null && View.MeasureSpec.getMode(i11) == Integer.MIN_VALUE && (i12 = this.f6104p) >= 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(Math.min(i12, View.MeasureSpec.getSize(i11)), Integer.MIN_VALUE);
        }
        super.onMeasure(i10, i11);
        if (this.f6098b == null) {
            return;
        }
        View.MeasureSpec.getMode(i11);
    }

    @Override // android.view.View
    public final boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.d;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.d);
        }
        this.d = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f6098b;
            if (view != null) {
                this.d.setBounds(view.getLeft(), this.f6098b.getTop(), this.f6098b.getRight(), this.f6098b.getBottom());
            }
        }
        boolean z3 = false;
        if (!this.f6102n ? !(this.d != null || this.f6100e != null) : this.f6101f == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f6101f;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f6101f);
        }
        this.f6101f = drawable;
        boolean z3 = this.f6102n;
        boolean z9 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (z3 && (drawable2 = this.f6101f) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!z3 ? !(this.d != null || this.f6100e != null) : this.f6101f == null) {
            z9 = true;
        }
        setWillNotDraw(z9);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2 = this.f6100e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f6100e);
        }
        this.f6100e = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f6103o && this.f6100e != null) {
                throw null;
            }
        }
        boolean z3 = false;
        if (!this.f6102n ? !(this.d != null || this.f6100e != null) : this.f6101f == null) {
            z3 = true;
        }
        setWillNotDraw(z3);
        invalidate();
        invalidateOutline();
    }

    public void setTransitioning(boolean z3) {
        this.f6097a = z3;
        setDescendantFocusability(z3 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z3 = i10 == 0;
        Drawable drawable = this.d;
        if (drawable != null) {
            drawable.setVisible(z3, false);
        }
        Drawable drawable2 = this.f6100e;
        if (drawable2 != null) {
            drawable2.setVisible(z3, false);
        }
        Drawable drawable3 = this.f6101f;
        if (drawable3 != null) {
            drawable3.setVisible(z3, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    public final boolean verifyDrawable(Drawable drawable) {
        Drawable drawable2 = this.d;
        boolean z3 = this.f6102n;
        return (drawable == drawable2 && !z3) || (drawable == this.f6100e && this.f6103o) || ((drawable == this.f6101f && z3) || super.verifyDrawable(drawable));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i10) {
        if (i10 != 0) {
            return super.startActionModeForChild(view, callback, i10);
        }
        return null;
    }

    public void setTabContainer(T0 t02) {
    }
}
