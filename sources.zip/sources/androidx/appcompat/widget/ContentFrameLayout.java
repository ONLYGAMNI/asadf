package androidx.appcompat.widget;

import R.C0243d0;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import f.v;
import k.l;
import l.C1123e;
import l.C1133j;
import l.InterfaceC1140m0;
import l.InterfaceC1142n0;
import l.q1;

/* loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* renamed from: a */
    public TypedValue f6167a;

    /* renamed from: b */
    public TypedValue f6168b;

    /* renamed from: c */
    public TypedValue f6169c;
    public TypedValue d;

    /* renamed from: e */
    public TypedValue f6170e;

    /* renamed from: f */
    public TypedValue f6171f;

    /* renamed from: n */
    public final Rect f6172n;

    /* renamed from: o */
    public InterfaceC1140m0 f6173o;

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f6172n = new Rect();
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f6170e == null) {
            this.f6170e = new TypedValue();
        }
        return this.f6170e;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.f6171f == null) {
            this.f6171f = new TypedValue();
        }
        return this.f6171f;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f6169c == null) {
            this.f6169c = new TypedValue();
        }
        return this.f6169c;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.d == null) {
            this.d = new TypedValue();
        }
        return this.d;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f6167a == null) {
            this.f6167a = new TypedValue();
        }
        return this.f6167a;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f6168b == null) {
            this.f6168b = new TypedValue();
        }
        return this.f6168b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onAttachedToWindow() {
        super.onAttachedToWindow();
        InterfaceC1140m0 interfaceC1140m0 = this.f6173o;
        if (interfaceC1140m0 != null) {
            interfaceC1140m0.getClass();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        C1133j c1133j;
        super.onDetachedFromWindow();
        InterfaceC1140m0 interfaceC1140m0 = this.f6173o;
        if (interfaceC1140m0 != null) {
            v vVar = (v) ((B.b) interfaceC1140m0).f65b;
            InterfaceC1142n0 interfaceC1142n0 = vVar.f10495y;
            if (interfaceC1142n0 != null) {
                ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) interfaceC1142n0;
                actionBarOverlayLayout.k();
                ActionMenuView actionMenuView = ((q1) actionBarOverlayLayout.f6136e).f12762a.f6239a;
                if (actionMenuView != null && (c1133j = actionMenuView.f6151A) != null) {
                    c1133j.e();
                    C1123e c1123e = c1133j.f12696B;
                    if (c1123e != null && c1123e.b()) {
                        c1123e.f12022j.dismiss();
                    }
                }
            }
            if (vVar.f10451D != null) {
                vVar.f10489s.getDecorView().removeCallbacks(vVar.f10452E);
                if (vVar.f10451D.isShowing()) {
                    try {
                        vVar.f10451D.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                vVar.f10451D = null;
            }
            C0243d0 c0243d0 = vVar.f10453F;
            if (c0243d0 != null) {
                c0243d0.b();
            }
            l lVar = vVar.z(0).f10435h;
            if (lVar != null) {
                lVar.c(true);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:100:0x008a  */
    /* JADX WARN: Removed duplicated region for block: B:101:0x009d  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x00d1  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x0062  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void onMeasure(int r17, int r18) {
        /*
            Method dump skipped, instructions count: 229
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(InterfaceC1140m0 interfaceC1140m0) {
        this.f6173o = interfaceC1140m0;
    }
}
