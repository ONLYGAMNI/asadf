package androidx.appcompat.widget;

import R.E;
import R.X;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import com.tajir.tajir.R;
import e.AbstractC0764a;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import k6.z;
import k8.C1109f;
import l.A0;
import l.B0;
import l.C1141n;
import l.M;
import l.U0;
import l.V0;
import l.W0;
import l.X0;
import l.Y0;
import l.Z0;
import l.a1;
import l.b1;
import l.d1;

/* loaded from: classes.dex */
public class SearchView extends A0 implements j.c {

    /* renamed from: n0, reason: collision with root package name */
    public static final C1109f f6174n0;

    /* renamed from: A, reason: collision with root package name */
    public final ImageView f6175A;

    /* renamed from: B, reason: collision with root package name */
    public final ImageView f6176B;

    /* renamed from: C, reason: collision with root package name */
    public final ImageView f6177C;

    /* renamed from: D, reason: collision with root package name */
    public final ImageView f6178D;

    /* renamed from: E, reason: collision with root package name */
    public final View f6179E;

    /* renamed from: F, reason: collision with root package name */
    public b1 f6180F;

    /* renamed from: G, reason: collision with root package name */
    public final Rect f6181G;

    /* renamed from: H, reason: collision with root package name */
    public final Rect f6182H;

    /* renamed from: I, reason: collision with root package name */
    public final int[] f6183I;

    /* renamed from: J, reason: collision with root package name */
    public final int[] f6184J;
    public final ImageView K;

    /* renamed from: L, reason: collision with root package name */
    public final Drawable f6185L;

    /* renamed from: M, reason: collision with root package name */
    public final int f6186M;

    /* renamed from: N, reason: collision with root package name */
    public final int f6187N;

    /* renamed from: O, reason: collision with root package name */
    public final Intent f6188O;

    /* renamed from: P, reason: collision with root package name */
    public final Intent f6189P;

    /* renamed from: Q, reason: collision with root package name */
    public final CharSequence f6190Q;

    /* renamed from: R, reason: collision with root package name */
    public View.OnFocusChangeListener f6191R;

    /* renamed from: S, reason: collision with root package name */
    public View.OnClickListener f6192S;

    /* renamed from: T, reason: collision with root package name */
    public boolean f6193T;

    /* renamed from: U, reason: collision with root package name */
    public boolean f6194U;

    /* renamed from: V, reason: collision with root package name */
    public Y.b f6195V;

    /* renamed from: W, reason: collision with root package name */
    public boolean f6196W;

    /* renamed from: a0, reason: collision with root package name */
    public CharSequence f6197a0;

    /* renamed from: b0, reason: collision with root package name */
    public boolean f6198b0;
    public boolean c0;

    /* renamed from: d0, reason: collision with root package name */
    public int f6199d0;

    /* renamed from: e0, reason: collision with root package name */
    public boolean f6200e0;

    /* renamed from: f0, reason: collision with root package name */
    public CharSequence f6201f0;

    /* renamed from: g0, reason: collision with root package name */
    public boolean f6202g0;

    /* renamed from: h0, reason: collision with root package name */
    public int f6203h0;

    /* renamed from: i0, reason: collision with root package name */
    public SearchableInfo f6204i0;

    /* renamed from: j0, reason: collision with root package name */
    public Bundle f6205j0;

    /* renamed from: k0, reason: collision with root package name */
    public final U0 f6206k0;

    /* renamed from: l0, reason: collision with root package name */
    public final U0 f6207l0;

    /* renamed from: m0, reason: collision with root package name */
    public final WeakHashMap f6208m0;

    /* renamed from: w, reason: collision with root package name */
    public final SearchAutoComplete f6209w;

    /* renamed from: x, reason: collision with root package name */
    public final View f6210x;

    /* renamed from: y, reason: collision with root package name */
    public final View f6211y;

    /* renamed from: z, reason: collision with root package name */
    public final View f6212z;

    public static class SearchAutoComplete extends C1141n {

        /* renamed from: e, reason: collision with root package name */
        public int f6213e;

        /* renamed from: f, reason: collision with root package name */
        public SearchView f6214f;

        /* renamed from: n, reason: collision with root package name */
        public boolean f6215n;

        /* renamed from: o, reason: collision with root package name */
        public final d f6216o;

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f6216o = new d(this);
            this.f6213e = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i10 = configuration.screenWidthDp;
            int i11 = configuration.screenHeightDp;
            if (i10 >= 960 && i11 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i10 < 600) {
                return (i10 < 640 || i11 < 480) ? 160 : 192;
            }
            return 192;
        }

        public final void a() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            if (Build.VERSION.SDK_INT >= 29) {
                c.b(this, 1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            C1109f c1109f = SearchView.f6174n0;
            c1109f.getClass();
            C1109f.a();
            Method method = c1109f.f12505c;
            if (method != null) {
                try {
                    method.invoke(this, Boolean.TRUE);
                } catch (Exception unused) {
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final boolean enoughToFilter() {
            return this.f6213e <= 0 || super.enoughToFilter();
        }

        @Override // l.C1141n, android.widget.TextView, android.view.View
        public final InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection inputConnectionOnCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f6215n) {
                d dVar = this.f6216o;
                removeCallbacks(dVar);
                post(dVar);
            }
            return inputConnectionOnCreateInputConnection;
        }

        @Override // android.view.View
        public final void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onFocusChanged(boolean z3, int i10, Rect rect) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            super.onFocusChanged(z3, i10, rect);
            SearchView searchView = this.f6214f;
            searchView.y(searchView.f6194U);
            searchView.post(searchView.f6206k0);
            if (searchView.f6209w.hasFocus()) {
                searchView.n();
            }
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final boolean onKeyPreIme(int i10, KeyEvent keyEvent) {
            if (i10 == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                }
                if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f6214f.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i10, keyEvent);
        }

        @Override // android.widget.AutoCompleteTextView, android.widget.TextView, android.view.View
        public final void onWindowFocusChanged(boolean z3) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
            super.onWindowFocusChanged(z3);
            if (z3 && this.f6214f.hasFocus() && getVisibility() == 0) {
                this.f6215n = true;
                Context context = getContext();
                C1109f c1109f = SearchView.f6174n0;
                if (context.getResources().getConfiguration().orientation == 2) {
                    a();
                }
            }
        }

        @Override // android.widget.AutoCompleteTextView
        public final void performCompletion() {
        }

        @Override // android.widget.AutoCompleteTextView
        public final void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z3) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            d dVar = this.f6216o;
            if (!z3) {
                this.f6215n = false;
                removeCallbacks(dVar);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else {
                if (!inputMethodManager.isActive(this)) {
                    this.f6215n = true;
                    return;
                }
                this.f6215n = false;
                removeCallbacks(dVar);
                inputMethodManager.showSoftInput(this, 0);
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f6214f = searchView;
        }

        @Override // android.widget.AutoCompleteTextView
        public void setThreshold(int i10) {
            super.setThreshold(i10);
            this.f6213e = i10;
        }
    }

    static {
        C1109f c1109f = null;
        if (Build.VERSION.SDK_INT < 29) {
            C1109f c1109f2 = new C1109f();
            c1109f2.f12503a = null;
            c1109f2.f12504b = null;
            c1109f2.f12505c = null;
            C1109f.a();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", null);
                c1109f2.f12503a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", null);
                c1109f2.f12504b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            try {
                Method method = AutoCompleteTextView.class.getMethod("ensureImeVisible", Boolean.TYPE);
                c1109f2.f12505c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
            c1109f = c1109f2;
        }
        f6174n0 = c1109f;
    }

    public SearchView(Context context) {
        this(context, null);
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        SearchAutoComplete searchAutoComplete = this.f6209w;
        searchAutoComplete.setText(charSequence);
        searchAutoComplete.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    @Override // j.c
    public final void b() {
        if (this.f6202g0) {
            return;
        }
        this.f6202g0 = true;
        SearchAutoComplete searchAutoComplete = this.f6209w;
        int imeOptions = searchAutoComplete.getImeOptions();
        this.f6203h0 = imeOptions;
        searchAutoComplete.setImeOptions(imeOptions | 33554432);
        searchAutoComplete.setText("");
        setIconified(false);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void clearFocus() {
        this.c0 = true;
        super.clearFocus();
        SearchAutoComplete searchAutoComplete = this.f6209w;
        searchAutoComplete.clearFocus();
        searchAutoComplete.setImeVisibility(false);
        this.c0 = false;
    }

    @Override // j.c
    public final void e() {
        SearchAutoComplete searchAutoComplete = this.f6209w;
        searchAutoComplete.setText("");
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.f6201f0 = "";
        clearFocus();
        y(true);
        searchAutoComplete.setImeOptions(this.f6203h0);
        this.f6202g0 = false;
    }

    public int getImeOptions() {
        return this.f6209w.getImeOptions();
    }

    public int getInputType() {
        return this.f6209w.getInputType();
    }

    public int getMaxWidth() {
        return this.f6199d0;
    }

    public CharSequence getQuery() {
        return this.f6209w.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f6197a0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f6204i0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f6190Q : getContext().getText(this.f6204i0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.f6187N;
    }

    public int getSuggestionRowLayout() {
        return this.f6186M;
    }

    public Y.b getSuggestionsAdapter() {
        return this.f6195V;
    }

    public final Intent l(Uri uri, String str, String str2, String str3) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f6201f0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f6205j0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        intent.setComponent(this.f6204i0.getSearchActivity());
        return intent;
    }

    public final Intent m(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1107296256);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f6205j0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        int voiceMaxResults = searchableInfo.getVoiceMaxResults() != 0 ? searchableInfo.getVoiceMaxResults() : 1;
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", voiceMaxResults);
        intent3.putExtra("calling_package", searchActivity != null ? searchActivity.flattenToShortString() : null);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    public final void n() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        int i10 = Build.VERSION.SDK_INT;
        SearchAutoComplete searchAutoComplete = this.f6209w;
        if (i10 >= 29) {
            c.a(searchAutoComplete);
            return;
        }
        C1109f c1109f = f6174n0;
        c1109f.getClass();
        C1109f.a();
        Method method = c1109f.f12503a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, null);
            } catch (Exception unused) {
            }
        }
        c1109f.getClass();
        C1109f.a();
        Method method2 = c1109f.f12504b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete, null);
            } catch (Exception unused2) {
            }
        }
    }

    public final void o() {
        SearchAutoComplete searchAutoComplete = this.f6209w;
        if (!TextUtils.isEmpty(searchAutoComplete.getText())) {
            searchAutoComplete.setText("");
            searchAutoComplete.requestFocus();
            searchAutoComplete.setImeVisibility(true);
        } else if (this.f6193T) {
            clearFocus();
            y(true);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        removeCallbacks(this.f6206k0);
        post(this.f6207l0);
        super.onDetachedFromWindow();
    }

    @Override // l.A0, android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        super.onLayout(z3, i10, i11, i12, i13);
        if (z3) {
            int[] iArr = this.f6183I;
            SearchAutoComplete searchAutoComplete = this.f6209w;
            searchAutoComplete.getLocationInWindow(iArr);
            int[] iArr2 = this.f6184J;
            getLocationInWindow(iArr2);
            int i14 = iArr[1] - iArr2[1];
            int i15 = iArr[0] - iArr2[0];
            int width = searchAutoComplete.getWidth() + i15;
            int height = searchAutoComplete.getHeight() + i14;
            Rect rect = this.f6181G;
            rect.set(i15, i14, width, height);
            int i16 = rect.left;
            int i17 = rect.right;
            int i18 = i13 - i11;
            Rect rect2 = this.f6182H;
            rect2.set(i16, 0, i17, i18);
            b1 b1Var = this.f6180F;
            if (b1Var == null) {
                b1 b1Var2 = new b1(rect2, rect, searchAutoComplete);
                this.f6180F = b1Var2;
                setTouchDelegate(b1Var2);
            } else {
                b1Var.f12646b.set(rect2);
                Rect rect3 = b1Var.d;
                rect3.set(rect2);
                int i19 = -b1Var.f12648e;
                rect3.inset(i19, i19);
                b1Var.f12647c.set(rect);
            }
        }
    }

    @Override // l.A0, android.view.View
    public final void onMeasure(int i10, int i11) {
        int i12;
        if (this.f6194U) {
            super.onMeasure(i10, i11);
            return;
        }
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        if (mode == Integer.MIN_VALUE) {
            int i13 = this.f6199d0;
            size = i13 > 0 ? Math.min(i13, size) : Math.min(getPreferredWidth(), size);
        } else if (mode == 0) {
            size = this.f6199d0;
            if (size <= 0) {
                size = getPreferredWidth();
            }
        } else if (mode == 1073741824 && (i12 = this.f6199d0) > 0) {
            size = Math.min(i12, size);
        }
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        if (mode2 == Integer.MIN_VALUE) {
            size2 = Math.min(getPreferredHeight(), size2);
        } else if (mode2 == 0) {
            size2 = getPreferredHeight();
        }
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(size, 1073741824), View.MeasureSpec.makeMeasureSpec(size2, 1073741824));
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof a1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        a1 a1Var = (a1) parcelable;
        super.onRestoreInstanceState(a1Var.f5637a);
        y(a1Var.f12642c);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        a1 a1Var = new a1(super.onSaveInstanceState());
        a1Var.f12642c = this.f6194U;
        return a1Var;
    }

    @Override // android.view.View
    public final void onWindowFocusChanged(boolean z3) {
        super.onWindowFocusChanged(z3);
        post(this.f6206k0);
    }

    public final void p(int i10) {
        int position;
        String strH;
        Cursor cursor = this.f6195V.f5474c;
        if (cursor != null && cursor.moveToPosition(i10)) {
            Intent intentL = null;
            try {
                int i11 = d1.f12661E;
                String strH2 = d1.h(cursor, cursor.getColumnIndex("suggest_intent_action"));
                if (strH2 == null) {
                    strH2 = this.f6204i0.getSuggestIntentAction();
                }
                if (strH2 == null) {
                    strH2 = "android.intent.action.SEARCH";
                }
                String strH3 = d1.h(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (strH3 == null) {
                    strH3 = this.f6204i0.getSuggestIntentData();
                }
                if (strH3 != null && (strH = d1.h(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) != null) {
                    strH3 = strH3 + "/" + Uri.encode(strH);
                }
                intentL = l(strH3 == null ? null : Uri.parse(strH3), strH2, d1.h(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), d1.h(cursor, cursor.getColumnIndex("suggest_intent_query")));
            } catch (RuntimeException e4) {
                try {
                    position = cursor.getPosition();
                } catch (RuntimeException unused) {
                    position = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + position + " returned exception.", e4);
            }
            if (intentL != null) {
                try {
                    getContext().startActivity(intentL);
                } catch (RuntimeException e5) {
                    Log.e("SearchView", "Failed launch activity: " + intentL, e5);
                }
            }
        }
        SearchAutoComplete searchAutoComplete = this.f6209w;
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public final void q(int i10) {
        Editable text = this.f6209w.getText();
        Cursor cursor = this.f6195V.f5474c;
        if (cursor == null) {
            return;
        }
        if (!cursor.moveToPosition(i10)) {
            setQuery(text);
            return;
        }
        String strC = this.f6195V.c(cursor);
        if (strC != null) {
            setQuery(strC);
        } else {
            setQuery(text);
        }
    }

    public final void r(CharSequence charSequence) {
        setQuery(charSequence);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final boolean requestFocus(int i10, Rect rect) {
        if (this.c0 || !isFocusable()) {
            return false;
        }
        if (this.f6194U) {
            return super.requestFocus(i10, rect);
        }
        boolean zRequestFocus = this.f6209w.requestFocus(i10, rect);
        if (zRequestFocus) {
            y(false);
        }
        return zRequestFocus;
    }

    public final void s() {
        SearchAutoComplete searchAutoComplete = this.f6209w;
        Editable text = searchAutoComplete.getText();
        if (text == null || TextUtils.getTrimmedLength(text) <= 0) {
            return;
        }
        if (this.f6204i0 != null) {
            getContext().startActivity(l(null, "android.intent.action.SEARCH", null, text.toString()));
        }
        searchAutoComplete.setImeVisibility(false);
        searchAutoComplete.dismissDropDown();
    }

    public void setAppSearchData(Bundle bundle) {
        this.f6205j0 = bundle;
    }

    public void setIconified(boolean z3) {
        if (z3) {
            o();
            return;
        }
        y(false);
        SearchAutoComplete searchAutoComplete = this.f6209w;
        searchAutoComplete.requestFocus();
        searchAutoComplete.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f6192S;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    public void setIconifiedByDefault(boolean z3) {
        if (this.f6193T == z3) {
            return;
        }
        this.f6193T = z3;
        y(z3);
        v();
    }

    public void setImeOptions(int i10) {
        this.f6209w.setImeOptions(i10);
    }

    public void setInputType(int i10) {
        this.f6209w.setInputType(i10);
    }

    public void setMaxWidth(int i10) {
        this.f6199d0 = i10;
        requestLayout();
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f6191R = onFocusChangeListener;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f6192S = onClickListener;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f6197a0 = charSequence;
        v();
    }

    public void setQueryRefinementEnabled(boolean z3) {
        this.f6198b0 = z3;
        Y.b bVar = this.f6195V;
        if (bVar instanceof d1) {
            ((d1) bVar).f12674w = z3 ? 2 : 1;
        }
    }

    public void setSearchableInfo(SearchableInfo searchableInfo) {
        this.f6204i0 = searchableInfo;
        Intent intent = null;
        SearchAutoComplete searchAutoComplete = this.f6209w;
        if (searchableInfo != null) {
            searchAutoComplete.setThreshold(searchableInfo.getSuggestThreshold());
            searchAutoComplete.setImeOptions(this.f6204i0.getImeOptions());
            int inputType = this.f6204i0.getInputType();
            if ((inputType & 15) == 1) {
                inputType &= -65537;
                if (this.f6204i0.getSuggestAuthority() != null) {
                    inputType |= 589824;
                }
            }
            searchAutoComplete.setInputType(inputType);
            Y.b bVar = this.f6195V;
            if (bVar != null) {
                bVar.b(null);
            }
            if (this.f6204i0.getSuggestAuthority() != null) {
                d1 d1Var = new d1(getContext(), this, this.f6204i0, this.f6208m0);
                this.f6195V = d1Var;
                searchAutoComplete.setAdapter(d1Var);
                ((d1) this.f6195V).f12674w = this.f6198b0 ? 2 : 1;
            }
            v();
        }
        SearchableInfo searchableInfo2 = this.f6204i0;
        boolean z3 = false;
        if (searchableInfo2 != null && searchableInfo2.getVoiceSearchEnabled()) {
            if (this.f6204i0.getVoiceSearchLaunchWebSearch()) {
                intent = this.f6188O;
            } else if (this.f6204i0.getVoiceSearchLaunchRecognizer()) {
                intent = this.f6189P;
            }
            if (intent != null) {
                z3 = getContext().getPackageManager().resolveActivity(intent, 65536) != null;
            }
        }
        this.f6200e0 = z3;
        if (z3) {
            searchAutoComplete.setPrivateImeOptions("nm");
        }
        y(this.f6194U);
    }

    public void setSubmitButtonEnabled(boolean z3) {
        this.f6196W = z3;
        y(this.f6194U);
    }

    public void setSuggestionsAdapter(Y.b bVar) {
        this.f6195V = bVar;
        this.f6209w.setAdapter(bVar);
    }

    public final void t() {
        boolean z3 = true;
        boolean z9 = !TextUtils.isEmpty(this.f6209w.getText());
        if (!z9 && (!this.f6193T || this.f6202g0)) {
            z3 = false;
        }
        int i10 = z3 ? 0 : 8;
        ImageView imageView = this.f6177C;
        imageView.setVisibility(i10);
        Drawable drawable = imageView.getDrawable();
        if (drawable != null) {
            drawable.setState(z9 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    public final void u() {
        int[] iArr = this.f6209w.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f6211y.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f6212z.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public final void v() {
        Drawable drawable;
        CharSequence queryHint = getQueryHint();
        if (queryHint == null) {
            queryHint = "";
        }
        boolean z3 = this.f6193T;
        SearchAutoComplete searchAutoComplete = this.f6209w;
        if (z3 && (drawable = this.f6185L) != null) {
            int textSize = (int) (searchAutoComplete.getTextSize() * 1.25d);
            drawable.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(drawable), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    public final void w() {
        this.f6212z.setVisibility(((this.f6196W || this.f6200e0) && !this.f6194U && (this.f6176B.getVisibility() == 0 || this.f6178D.getVisibility() == 0)) ? 0 : 8);
    }

    public final void x(boolean z3) {
        boolean z9 = this.f6196W;
        this.f6176B.setVisibility((!z9 || !(z9 || this.f6200e0) || this.f6194U || !hasFocus() || (!z3 && this.f6200e0)) ? 8 : 0);
    }

    public final void y(boolean z3) {
        this.f6194U = z3;
        int i10 = 8;
        int i11 = z3 ? 0 : 8;
        boolean zIsEmpty = TextUtils.isEmpty(this.f6209w.getText());
        this.f6175A.setVisibility(i11);
        x(!zIsEmpty);
        this.f6210x.setVisibility(z3 ? 8 : 0);
        ImageView imageView = this.K;
        imageView.setVisibility((imageView.getDrawable() == null || this.f6193T) ? 8 : 0);
        t();
        if (this.f6200e0 && !this.f6194U && zIsEmpty) {
            this.f6176B.setVisibility(8);
            i10 = 0;
        }
        this.f6178D.setVisibility(i10);
        w();
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f6181G = new Rect();
        this.f6182H = new Rect();
        this.f6183I = new int[2];
        this.f6184J = new int[2];
        this.f6206k0 = new U0(this, 0);
        this.f6207l0 = new U0(this, 1);
        this.f6208m0 = new WeakHashMap();
        a aVar = new a(this);
        b bVar = new b(this);
        W0 w02 = new W0(this);
        M m9 = new M(this, 1);
        B0 b02 = new B0(this, 1);
        L6.d dVar = new L6.d(this, 7);
        int[] iArr = AbstractC0764a.f10140u;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i10, 0);
        z zVar = new z(context, typedArrayObtainStyledAttributes);
        X.m(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i10);
        LayoutInflater.from(context).inflate(typedArrayObtainStyledAttributes.getResourceId(19, R.layout.abc_search_view), (ViewGroup) this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(R.id.search_src_text);
        this.f6209w = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f6210x = findViewById(R.id.search_edit_frame);
        View viewFindViewById = findViewById(R.id.search_plate);
        this.f6211y = viewFindViewById;
        View viewFindViewById2 = findViewById(R.id.submit_area);
        this.f6212z = viewFindViewById2;
        ImageView imageView = (ImageView) findViewById(R.id.search_button);
        this.f6175A = imageView;
        ImageView imageView2 = (ImageView) findViewById(R.id.search_go_btn);
        this.f6176B = imageView2;
        ImageView imageView3 = (ImageView) findViewById(R.id.search_close_btn);
        this.f6177C = imageView3;
        ImageView imageView4 = (ImageView) findViewById(R.id.search_voice_btn);
        this.f6178D = imageView4;
        ImageView imageView5 = (ImageView) findViewById(R.id.search_mag_icon);
        this.K = imageView5;
        E.q(viewFindViewById, zVar.f(20));
        E.q(viewFindViewById2, zVar.f(25));
        imageView.setImageDrawable(zVar.f(23));
        imageView2.setImageDrawable(zVar.f(15));
        imageView3.setImageDrawable(zVar.f(12));
        imageView4.setImageDrawable(zVar.f(28));
        imageView5.setImageDrawable(zVar.f(23));
        this.f6185L = zVar.f(22);
        f9.d.t(imageView, getResources().getString(R.string.abc_searchview_description_search));
        this.f6186M = typedArrayObtainStyledAttributes.getResourceId(26, R.layout.abc_search_dropdown_item_icons_2line);
        this.f6187N = typedArrayObtainStyledAttributes.getResourceId(13, 0);
        imageView.setOnClickListener(aVar);
        imageView3.setOnClickListener(aVar);
        imageView2.setOnClickListener(aVar);
        imageView4.setOnClickListener(aVar);
        searchAutoComplete.setOnClickListener(aVar);
        searchAutoComplete.addTextChangedListener(dVar);
        searchAutoComplete.setOnEditorActionListener(w02);
        searchAutoComplete.setOnItemClickListener(m9);
        searchAutoComplete.setOnItemSelectedListener(b02);
        searchAutoComplete.setOnKeyListener(bVar);
        searchAutoComplete.setOnFocusChangeListener(new V0(this));
        setIconifiedByDefault(typedArrayObtainStyledAttributes.getBoolean(18, true));
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(2, -1);
        if (dimensionPixelSize != -1) {
            setMaxWidth(dimensionPixelSize);
        }
        this.f6190Q = typedArrayObtainStyledAttributes.getText(14);
        this.f6197a0 = typedArrayObtainStyledAttributes.getText(21);
        int i11 = typedArrayObtainStyledAttributes.getInt(6, -1);
        if (i11 != -1) {
            setImeOptions(i11);
        }
        int i12 = typedArrayObtainStyledAttributes.getInt(5, -1);
        if (i12 != -1) {
            setInputType(i12);
        }
        setFocusable(typedArrayObtainStyledAttributes.getBoolean(1, true));
        zVar.k();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f6188O = intent;
        intent.addFlags(268435456);
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f6189P = intent2;
        intent2.addFlags(268435456);
        View viewFindViewById3 = findViewById(searchAutoComplete.getDropDownAnchor());
        this.f6179E = viewFindViewById3;
        if (viewFindViewById3 != null) {
            viewFindViewById3.addOnLayoutChangeListener(new U3.a(this, 2));
        }
        y(this.f6193T);
        v();
    }

    public void setOnCloseListener(X0 x02) {
    }

    public void setOnQueryTextListener(Y0 y02) {
    }

    public void setOnSuggestionListener(Z0 z02) {
    }
}
