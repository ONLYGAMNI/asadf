package androidx.appcompat.widget;

import I0.k;
import R.B0;
import R.C0260t;
import R.E;
import R.I;
import R.InterfaceC0259s;
import R.K;
import R.X;
import R.p0;
import R.q0;
import R.r;
import R.r0;
import R.s0;
import R.z0;
import a.AbstractC0338a;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import com.google.android.gms.common.api.f;
import com.tajir.tajir.R;
import java.util.WeakHashMap;
import k.l;
import k.x;
import l.C1121d;
import l.C1133j;
import l.InterfaceC1119c;
import l.InterfaceC1142n0;
import l.InterfaceC1144o0;
import l.RunnableC1117b;
import l.l1;
import l.q1;

/* loaded from: classes.dex */
public class ActionBarOverlayLayout extends ViewGroup implements InterfaceC1142n0, r, InterfaceC0259s {

    /* renamed from: I, reason: collision with root package name */
    public static final int[] f6124I = {R.attr.actionBarSize, android.R.attr.windowContentOverlay};

    /* renamed from: A, reason: collision with root package name */
    public B0 f6125A;

    /* renamed from: B, reason: collision with root package name */
    public InterfaceC1119c f6126B;

    /* renamed from: C, reason: collision with root package name */
    public OverScroller f6127C;

    /* renamed from: D, reason: collision with root package name */
    public ViewPropertyAnimator f6128D;

    /* renamed from: E, reason: collision with root package name */
    public final k f6129E;

    /* renamed from: F, reason: collision with root package name */
    public final RunnableC1117b f6130F;

    /* renamed from: G, reason: collision with root package name */
    public final RunnableC1117b f6131G;

    /* renamed from: H, reason: collision with root package name */
    public final C0260t f6132H;

    /* renamed from: a, reason: collision with root package name */
    public int f6133a;

    /* renamed from: b, reason: collision with root package name */
    public int f6134b;

    /* renamed from: c, reason: collision with root package name */
    public ContentFrameLayout f6135c;
    public ActionBarContainer d;

    /* renamed from: e, reason: collision with root package name */
    public InterfaceC1144o0 f6136e;

    /* renamed from: f, reason: collision with root package name */
    public Drawable f6137f;

    /* renamed from: n, reason: collision with root package name */
    public boolean f6138n;

    /* renamed from: o, reason: collision with root package name */
    public boolean f6139o;

    /* renamed from: p, reason: collision with root package name */
    public boolean f6140p;

    /* renamed from: q, reason: collision with root package name */
    public boolean f6141q;

    /* renamed from: r, reason: collision with root package name */
    public boolean f6142r;

    /* renamed from: s, reason: collision with root package name */
    public int f6143s;

    /* renamed from: t, reason: collision with root package name */
    public int f6144t;

    /* renamed from: u, reason: collision with root package name */
    public final Rect f6145u;

    /* renamed from: v, reason: collision with root package name */
    public final Rect f6146v;

    /* renamed from: w, reason: collision with root package name */
    public final Rect f6147w;

    /* renamed from: x, reason: collision with root package name */
    public B0 f6148x;

    /* renamed from: y, reason: collision with root package name */
    public B0 f6149y;

    /* renamed from: z, reason: collision with root package name */
    public B0 f6150z;

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f6134b = 0;
        this.f6145u = new Rect();
        this.f6146v = new Rect();
        this.f6147w = new Rect();
        new Rect();
        new Rect();
        new Rect();
        new Rect();
        B0 b02 = B0.f3950b;
        this.f6148x = b02;
        this.f6149y = b02;
        this.f6150z = b02;
        this.f6125A = b02;
        this.f6129E = new k(this, 7);
        this.f6130F = new RunnableC1117b(this, 0);
        this.f6131G = new RunnableC1117b(this, 1);
        i(context);
        this.f6132H = new C0260t();
    }

    public static boolean g(View view, Rect rect, boolean z3) {
        boolean z9;
        C1121d c1121d = (C1121d) view.getLayoutParams();
        int i10 = ((ViewGroup.MarginLayoutParams) c1121d).leftMargin;
        int i11 = rect.left;
        if (i10 != i11) {
            ((ViewGroup.MarginLayoutParams) c1121d).leftMargin = i11;
            z9 = true;
        } else {
            z9 = false;
        }
        int i12 = ((ViewGroup.MarginLayoutParams) c1121d).topMargin;
        int i13 = rect.top;
        if (i12 != i13) {
            ((ViewGroup.MarginLayoutParams) c1121d).topMargin = i13;
            z9 = true;
        }
        int i14 = ((ViewGroup.MarginLayoutParams) c1121d).rightMargin;
        int i15 = rect.right;
        if (i14 != i15) {
            ((ViewGroup.MarginLayoutParams) c1121d).rightMargin = i15;
            z9 = true;
        }
        if (z3) {
            int i16 = ((ViewGroup.MarginLayoutParams) c1121d).bottomMargin;
            int i17 = rect.bottom;
            if (i16 != i17) {
                ((ViewGroup.MarginLayoutParams) c1121d).bottomMargin = i17;
                return true;
            }
        }
        return z9;
    }

    @Override // R.r
    public final void a(View view, View view2, int i10, int i11) {
        if (i11 == 0) {
            onNestedScrollAccepted(view, view2, i10);
        }
    }

    @Override // R.r
    public final void b(View view, int i10) {
        if (i10 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // R.r
    public final void c(View view, int i10, int i11, int[] iArr, int i12) {
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C1121d;
    }

    @Override // R.InterfaceC0259s
    public final void d(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        e(view, i10, i11, i12, i13, i14);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        int translationY;
        super.draw(canvas);
        if (this.f6137f == null || this.f6138n) {
            return;
        }
        if (this.d.getVisibility() == 0) {
            translationY = (int) (this.d.getTranslationY() + this.d.getBottom() + 0.5f);
        } else {
            translationY = 0;
        }
        this.f6137f.setBounds(0, translationY, getWidth(), this.f6137f.getIntrinsicHeight() + translationY);
        this.f6137f.draw(canvas);
    }

    @Override // R.r
    public final void e(View view, int i10, int i11, int i12, int i13, int i14) {
        if (i14 == 0) {
            onNestedScroll(view, i10, i11, i12, i13);
        }
    }

    @Override // R.r
    public final boolean f(View view, View view2, int i10, int i11) {
        return i11 == 0 && onStartNestedScroll(view, view2, i10);
    }

    @Override // android.view.View
    public final boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C1121d(-1, -1);
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C1121d(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.d;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        C0260t c0260t = this.f6132H;
        return c0260t.f4013b | c0260t.f4012a;
    }

    public CharSequence getTitle() {
        k();
        return ((q1) this.f6136e).f12762a.getTitle();
    }

    public final void h() {
        removeCallbacks(this.f6130F);
        removeCallbacks(this.f6131G);
        ViewPropertyAnimator viewPropertyAnimator = this.f6128D;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public final void i(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f6124I);
        this.f6133a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f6137f = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f6138n = context.getApplicationInfo().targetSdkVersion < 19;
        this.f6127C = new OverScroller(context);
    }

    public final void j(int i10) {
        k();
        if (i10 == 2) {
            ((q1) this.f6136e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else if (i10 == 5) {
            ((q1) this.f6136e).getClass();
            Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
        } else {
            if (i10 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    public final void k() {
        InterfaceC1144o0 wrapper;
        if (this.f6135c == null) {
            this.f6135c = (ContentFrameLayout) findViewById(R.id.action_bar_activity_content);
            this.d = (ActionBarContainer) findViewById(R.id.action_bar_container);
            KeyEvent.Callback callbackFindViewById = findViewById(R.id.action_bar);
            if (callbackFindViewById instanceof InterfaceC1144o0) {
                wrapper = (InterfaceC1144o0) callbackFindViewById;
            } else {
                if (!(callbackFindViewById instanceof Toolbar)) {
                    throw new IllegalStateException("Can't make a decor toolbar out of ".concat(callbackFindViewById.getClass().getSimpleName()));
                }
                wrapper = ((Toolbar) callbackFindViewById).getWrapper();
            }
            this.f6136e = wrapper;
        }
    }

    public final void l(Menu menu, x xVar) {
        k();
        q1 q1Var = (q1) this.f6136e;
        C1133j c1133j = q1Var.f12772m;
        Toolbar toolbar = q1Var.f12762a;
        if (c1133j == null) {
            C1133j c1133j2 = new C1133j(toolbar.getContext());
            q1Var.f12772m = c1133j2;
            c1133j2.f12708p = R.id.action_menu_presenter;
        }
        C1133j c1133j3 = q1Var.f12772m;
        c1133j3.f12704e = xVar;
        l lVar = (l) menu;
        if (lVar == null && toolbar.f6239a == null) {
            return;
        }
        toolbar.f();
        l lVar2 = toolbar.f6239a.f6159w;
        if (lVar2 == lVar) {
            return;
        }
        if (lVar2 != null) {
            lVar2.r(toolbar.f6233R);
            lVar2.r(toolbar.f6234S);
        }
        if (toolbar.f6234S == null) {
            toolbar.f6234S = new l1(toolbar);
        }
        c1133j3.f12717y = true;
        if (lVar != null) {
            lVar.b(c1133j3, toolbar.f6248q);
            lVar.b(toolbar.f6234S, toolbar.f6248q);
        } else {
            c1133j3.k(toolbar.f6248q, null);
            toolbar.f6234S.k(toolbar.f6248q, null);
            c1133j3.j(true);
            toolbar.f6234S.j(true);
        }
        toolbar.f6239a.setPopupTheme(toolbar.f6249r);
        toolbar.f6239a.setPresenter(c1133j3);
        toolbar.f6233R = c1133j3;
        toolbar.v();
    }

    @Override // android.view.View
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        k();
        B0 b0H = B0.h(this, windowInsets);
        boolean zG = g(this.d, new Rect(b0H.b(), b0H.d(), b0H.c(), b0H.a()), false);
        WeakHashMap weakHashMap = X.f3966a;
        Rect rect = this.f6145u;
        K.b(this, b0H, rect);
        int i10 = rect.left;
        int i11 = rect.top;
        int i12 = rect.right;
        int i13 = rect.bottom;
        z0 z0Var = b0H.f3951a;
        B0 b0L = z0Var.l(i10, i11, i12, i13);
        this.f6148x = b0L;
        boolean z3 = true;
        if (!this.f6149y.equals(b0L)) {
            this.f6149y = this.f6148x;
            zG = true;
        }
        Rect rect2 = this.f6146v;
        if (rect2.equals(rect)) {
            z3 = zG;
        } else {
            rect2.set(rect);
        }
        if (z3) {
            requestLayout();
        }
        return z0Var.a().f3951a.c().f3951a.b().g();
    }

    @Override // android.view.View
    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        i(getContext());
        WeakHashMap weakHashMap = X.f3966a;
        I.c(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h();
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z3, int i10, int i11, int i12, int i13) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                C1121d c1121d = (C1121d) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i15 = ((ViewGroup.MarginLayoutParams) c1121d).leftMargin + paddingLeft;
                int i16 = ((ViewGroup.MarginLayoutParams) c1121d).topMargin + paddingTop;
                childAt.layout(i15, i16, measuredWidth + i15, measuredHeight + i16);
            }
        }
    }

    @Override // android.view.View
    public final void onMeasure(int i10, int i11) {
        int measuredHeight;
        k();
        measureChildWithMargins(this.d, i10, 0, i11, 0);
        C1121d c1121d = (C1121d) this.d.getLayoutParams();
        int iMax = Math.max(0, this.d.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c1121d).leftMargin + ((ViewGroup.MarginLayoutParams) c1121d).rightMargin);
        int iMax2 = Math.max(0, this.d.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c1121d).topMargin + ((ViewGroup.MarginLayoutParams) c1121d).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.d.getMeasuredState());
        WeakHashMap weakHashMap = X.f3966a;
        boolean z3 = (E.g(this) & 256) != 0;
        if (z3) {
            measuredHeight = this.f6133a;
            if (this.f6140p && this.d.getTabContainer() != null) {
                measuredHeight += this.f6133a;
            }
        } else {
            measuredHeight = this.d.getVisibility() != 8 ? this.d.getMeasuredHeight() : 0;
        }
        Rect rect = this.f6145u;
        Rect rect2 = this.f6147w;
        rect2.set(rect);
        B0 b02 = this.f6148x;
        this.f6150z = b02;
        if (this.f6139o || z3) {
            H.c cVarB = H.c.b(b02.b(), this.f6150z.d() + measuredHeight, this.f6150z.c(), this.f6150z.a());
            B0 b03 = this.f6150z;
            int i12 = Build.VERSION.SDK_INT;
            s0 r0Var = i12 >= 30 ? new r0(b03) : i12 >= 29 ? new q0(b03) : new p0(b03);
            r0Var.g(cVarB);
            this.f6150z = r0Var.b();
        } else {
            rect2.top += measuredHeight;
            rect2.bottom = rect2.bottom;
            this.f6150z = b02.f3951a.l(0, measuredHeight, 0, 0);
        }
        g(this.f6135c, rect2, true);
        if (!this.f6125A.equals(this.f6150z)) {
            B0 b04 = this.f6150z;
            this.f6125A = b04;
            X.b(this.f6135c, b04);
        }
        measureChildWithMargins(this.f6135c, i10, 0, i11, 0);
        C1121d c1121d2 = (C1121d) this.f6135c.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f6135c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) c1121d2).leftMargin + ((ViewGroup.MarginLayoutParams) c1121d2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f6135c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) c1121d2).topMargin + ((ViewGroup.MarginLayoutParams) c1121d2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f6135c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + iMax3, getSuggestedMinimumWidth()), i10, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + iMax4, getSuggestedMinimumHeight()), i11, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedFling(View view, float f10, float f11, boolean z3) {
        if (!this.f6141q || !z3) {
            return false;
        }
        this.f6127C.fling(0, 0, 0, (int) f11, 0, 0, Integer.MIN_VALUE, f.API_PRIORITY_OTHER);
        if (this.f6127C.getFinalY() > this.d.getHeight()) {
            h();
            this.f6131G.run();
        } else {
            h();
            this.f6130F.run();
        }
        this.f6142r = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        int i14 = this.f6143s + i11;
        this.f6143s = i14;
        setActionBarHideOffset(i14);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onNestedScrollAccepted(View view, View view2, int i10) {
        f.I i11;
        j.l lVar;
        this.f6132H.f4012a = i10;
        this.f6143s = getActionBarHideOffset();
        h();
        InterfaceC1119c interfaceC1119c = this.f6126B;
        if (interfaceC1119c == null || (lVar = (i11 = (f.I) interfaceC1119c).f10367v) == null) {
            return;
        }
        lVar.a();
        i11.f10367v = null;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean onStartNestedScroll(View view, View view2, int i10) {
        if ((i10 & 2) == 0 || this.d.getVisibility() != 0) {
            return false;
        }
        return this.f6141q;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void onStopNestedScroll(View view) {
        if (!this.f6141q || this.f6142r) {
            return;
        }
        if (this.f6143s <= this.d.getHeight()) {
            h();
            postDelayed(this.f6130F, 600L);
        } else {
            h();
            postDelayed(this.f6131G, 600L);
        }
    }

    @Override // android.view.View
    public final void onWindowSystemUiVisibilityChanged(int i10) {
        super.onWindowSystemUiVisibilityChanged(i10);
        k();
        int i11 = this.f6144t ^ i10;
        this.f6144t = i10;
        boolean z3 = (i10 & 4) == 0;
        boolean z9 = (i10 & 256) != 0;
        InterfaceC1119c interfaceC1119c = this.f6126B;
        if (interfaceC1119c != null) {
            ((f.I) interfaceC1119c).f10363r = !z9;
            if (z3 || !z9) {
                f.I i12 = (f.I) interfaceC1119c;
                if (i12.f10364s) {
                    i12.f10364s = false;
                    i12.D(true);
                }
            } else {
                f.I i13 = (f.I) interfaceC1119c;
                if (!i13.f10364s) {
                    i13.f10364s = true;
                    i13.D(true);
                }
            }
        }
        if ((i11 & 256) == 0 || this.f6126B == null) {
            return;
        }
        WeakHashMap weakHashMap = X.f3966a;
        I.c(this);
    }

    @Override // android.view.View
    public final void onWindowVisibilityChanged(int i10) {
        super.onWindowVisibilityChanged(i10);
        this.f6134b = i10;
        InterfaceC1119c interfaceC1119c = this.f6126B;
        if (interfaceC1119c != null) {
            ((f.I) interfaceC1119c).f10362q = i10;
        }
    }

    public void setActionBarHideOffset(int i10) {
        h();
        this.d.setTranslationY(-Math.max(0, Math.min(i10, this.d.getHeight())));
    }

    public void setActionBarVisibilityCallback(InterfaceC1119c interfaceC1119c) {
        this.f6126B = interfaceC1119c;
        if (getWindowToken() != null) {
            ((f.I) this.f6126B).f10362q = this.f6134b;
            int i10 = this.f6144t;
            if (i10 != 0) {
                onWindowSystemUiVisibilityChanged(i10);
                WeakHashMap weakHashMap = X.f3966a;
                I.c(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z3) {
        this.f6140p = z3;
    }

    public void setHideOnContentScrollEnabled(boolean z3) {
        if (z3 != this.f6141q) {
            this.f6141q = z3;
            if (z3) {
                return;
            }
            h();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i10) {
        k();
        q1 q1Var = (q1) this.f6136e;
        q1Var.d = i10 != 0 ? AbstractC0338a.s(q1Var.f12762a.getContext(), i10) : null;
        q1Var.c();
    }

    public void setLogo(int i10) {
        k();
        q1 q1Var = (q1) this.f6136e;
        q1Var.f12765e = i10 != 0 ? AbstractC0338a.s(q1Var.f12762a.getContext(), i10) : null;
        q1Var.c();
    }

    public void setOverlayMode(boolean z3) {
        this.f6139o = z3;
        this.f6138n = z3 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z3) {
    }

    public void setUiOptions(int i10) {
    }

    @Override // l.InterfaceC1142n0
    public void setWindowCallback(Window.Callback callback) {
        k();
        ((q1) this.f6136e).f12770k = callback;
    }

    @Override // l.InterfaceC1142n0
    public void setWindowTitle(CharSequence charSequence) {
        k();
        q1 q1Var = (q1) this.f6136e;
        if (q1Var.g) {
            return;
        }
        q1Var.f12767h = charSequence;
        if ((q1Var.f12763b & 8) != 0) {
            Toolbar toolbar = q1Var.f12762a;
            toolbar.setTitle(charSequence);
            if (q1Var.g) {
                X.o(toolbar.getRootView(), charSequence);
            }
        }
    }

    @Override // android.view.ViewGroup
    public final boolean shouldDelayChildPressedState() {
        return false;
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C1121d(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        k();
        q1 q1Var = (q1) this.f6136e;
        q1Var.d = drawable;
        q1Var.c();
    }
}
