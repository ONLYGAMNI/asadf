package androidx.appcompat.app;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ListView;
import e.AbstractC0764a;

/* loaded from: classes.dex */
public class AlertController$RecycleListView extends ListView {

    /* renamed from: a, reason: collision with root package name */
    public final int f6066a;

    /* renamed from: b, reason: collision with root package name */
    public final int f6067b;

    public AlertController$RecycleListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, AbstractC0764a.f10139t);
        this.f6067b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(0, -1);
        this.f6066a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(1, -1);
    }
}
