package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class a0 implements Application.ActivityLifecycleCallbacks {
    public static final Z Companion = new Z();

    public static final void registerIn(Activity activity) {
        Companion.getClass();
        AbstractC1420h.f(activity, "activity");
        activity.registerActivityLifecycleCallbacks(new a0());
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        AbstractC1420h.f(activity, "activity");
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityDestroyed(Activity activity) {
        AbstractC1420h.f(activity, "activity");
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        AbstractC1420h.f(activity, "activity");
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPostCreated(Activity activity, Bundle bundle) {
        AbstractC1420h.f(activity, "activity");
        int i10 = b0.f6944b;
        e0.f(activity, EnumC0424v.ON_CREATE);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPostResumed(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        int i10 = b0.f6944b;
        e0.f(activity, EnumC0424v.ON_RESUME);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPostStarted(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        int i10 = b0.f6944b;
        e0.f(activity, EnumC0424v.ON_START);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreDestroyed(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        int i10 = b0.f6944b;
        e0.f(activity, EnumC0424v.ON_DESTROY);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPrePaused(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        int i10 = b0.f6944b;
        e0.f(activity, EnumC0424v.ON_PAUSE);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreStopped(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        int i10 = b0.f6944b;
        e0.f(activity, EnumC0424v.ON_STOP);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityResumed(Activity activity) {
        AbstractC1420h.f(activity, "activity");
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
        AbstractC1420h.f(activity, "activity");
        AbstractC1420h.f(bundle, "bundle");
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStarted(Activity activity) {
        AbstractC1420h.f(activity, "activity");
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        AbstractC1420h.f(activity, "activity");
    }
}
