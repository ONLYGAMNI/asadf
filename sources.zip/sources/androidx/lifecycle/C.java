package androidx.lifecycle;

/* loaded from: classes.dex */
public interface C {
}
