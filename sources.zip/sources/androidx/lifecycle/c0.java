package androidx.lifecycle;

import android.os.Binder;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Size;
import android.util.SizeF;
import android.util.SparseArray;
import e8.C0795g;
import f8.AbstractC0857y;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class c0 {

    /* renamed from: f, reason: collision with root package name */
    public static final Class[] f6946f = {Boolean.TYPE, boolean[].class, Double.TYPE, double[].class, Integer.TYPE, int[].class, Long.TYPE, long[].class, String.class, String[].class, Binder.class, Bundle.class, Byte.TYPE, byte[].class, Character.TYPE, char[].class, CharSequence.class, CharSequence[].class, ArrayList.class, Float.TYPE, float[].class, Parcelable.class, Parcelable[].class, Serializable.class, Short.TYPE, short[].class, SparseArray.class, Size.class, SizeF.class};

    /* renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f6947a;

    /* renamed from: b, reason: collision with root package name */
    public final LinkedHashMap f6948b;

    /* renamed from: c, reason: collision with root package name */
    public final LinkedHashMap f6949c;
    public final LinkedHashMap d;

    /* renamed from: e, reason: collision with root package name */
    public final C0.d f6950e;

    public c0(HashMap map) {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        this.f6947a = linkedHashMap;
        this.f6948b = new LinkedHashMap();
        this.f6949c = new LinkedHashMap();
        this.d = new LinkedHashMap();
        this.f6950e = new androidx.activity.d(this, 3);
        linkedHashMap.putAll(map);
    }

    public static Bundle a(c0 c0Var) {
        AbstractC1420h.f(c0Var, "this$0");
        Iterator it = AbstractC0857y.G(c0Var.f6948b).entrySet().iterator();
        while (true) {
            boolean zHasNext = it.hasNext();
            LinkedHashMap linkedHashMap = c0Var.f6947a;
            if (!zHasNext) {
                Set<String> setKeySet = linkedHashMap.keySet();
                ArrayList arrayList = new ArrayList(setKeySet.size());
                ArrayList arrayList2 = new ArrayList(arrayList.size());
                for (String str : setKeySet) {
                    arrayList.add(str);
                    arrayList2.add(linkedHashMap.get(str));
                }
                return android.support.v4.media.session.b.e(new C0795g("keys", arrayList), new C0795g("values", arrayList2));
            }
            Map.Entry entry = (Map.Entry) it.next();
            String str2 = (String) entry.getKey();
            Bundle bundleA = ((C0.d) entry.getValue()).a();
            AbstractC1420h.f(str2, "key");
            if (bundleA != null) {
                Class[] clsArr = f6946f;
                for (int i10 = 0; i10 < 29; i10++) {
                    Class cls = clsArr[i10];
                    AbstractC1420h.c(cls);
                    if (!cls.isInstance(bundleA)) {
                    }
                }
                throw new IllegalArgumentException("Can't put value with type " + bundleA.getClass() + " into saved state");
            }
            Object obj = c0Var.f6949c.get(str2);
            N n9 = obj instanceof N ? (N) obj : null;
            if (n9 != null) {
                n9.k(bundleA);
            } else {
                linkedHashMap.put(str2, bundleA);
            }
            F8.t tVar = (F8.t) c0Var.d.get(str2);
            if (tVar != null) {
                ((F8.D) tVar).f(bundleA);
            }
        }
    }

    public c0() {
        this.f6947a = new LinkedHashMap();
        this.f6948b = new LinkedHashMap();
        this.f6949c = new LinkedHashMap();
        this.d = new LinkedHashMap();
        this.f6950e = new androidx.activity.d(this, 3);
    }
}
