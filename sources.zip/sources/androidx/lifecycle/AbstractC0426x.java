package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicReference;

/* renamed from: androidx.lifecycle.x, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0426x {

    /* renamed from: a, reason: collision with root package name */
    public AtomicReference f7008a;

    public abstract void a(C c4);

    public abstract void b(C c4);
}
