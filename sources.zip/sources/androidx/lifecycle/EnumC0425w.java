package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* renamed from: androidx.lifecycle.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0425w {

    /* renamed from: a, reason: collision with root package name */
    public static final EnumC0425w f7003a;

    /* renamed from: b, reason: collision with root package name */
    public static final EnumC0425w f7004b;

    /* renamed from: c, reason: collision with root package name */
    public static final EnumC0425w f7005c;
    public static final EnumC0425w d;

    /* renamed from: e, reason: collision with root package name */
    public static final EnumC0425w f7006e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ EnumC0425w[] f7007f;

    static {
        EnumC0425w enumC0425w = new EnumC0425w("DESTROYED", 0);
        f7003a = enumC0425w;
        EnumC0425w enumC0425w2 = new EnumC0425w("INITIALIZED", 1);
        f7004b = enumC0425w2;
        EnumC0425w enumC0425w3 = new EnumC0425w("CREATED", 2);
        f7005c = enumC0425w3;
        EnumC0425w enumC0425w4 = new EnumC0425w("STARTED", 3);
        d = enumC0425w4;
        EnumC0425w enumC0425w5 = new EnumC0425w("RESUMED", 4);
        f7006e = enumC0425w5;
        f7007f = new EnumC0425w[]{enumC0425w, enumC0425w2, enumC0425w3, enumC0425w4, enumC0425w5};
    }

    public static EnumC0425w valueOf(String str) {
        return (EnumC0425w) Enum.valueOf(EnumC0425w.class, str);
    }

    public static EnumC0425w[] values() {
        return (EnumC0425w[]) f7007f.clone();
    }

    public final boolean a(EnumC0425w enumC0425w) {
        return compareTo(enumC0425w) >= 0;
    }
}
