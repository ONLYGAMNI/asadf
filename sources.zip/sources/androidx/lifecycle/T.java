package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class T extends AbstractC0418o {
    final /* synthetic */ U this$0;

    public T(U u7) {
        this.this$0 = u7;
    }

    @Override // androidx.lifecycle.AbstractC0418o, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        AbstractC1420h.f(activity, "activity");
        if (Build.VERSION.SDK_INT < 29) {
            int i10 = b0.f6944b;
            Fragment fragmentFindFragmentByTag = activity.getFragmentManager().findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag");
            AbstractC1420h.d(fragmentFindFragmentByTag, "null cannot be cast to non-null type androidx.lifecycle.ReportFragment");
            ((b0) fragmentFindFragmentByTag).f6945a = this.this$0.f6926o;
        }
    }

    @Override // androidx.lifecycle.AbstractC0418o, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        U u7 = this.this$0;
        int i10 = u7.f6921b - 1;
        u7.f6921b = i10;
        if (i10 == 0) {
            Handler handler = u7.f6923e;
            AbstractC1420h.c(handler);
            handler.postDelayed(u7.f6925n, 700L);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPreCreated(Activity activity, Bundle bundle) {
        AbstractC1420h.f(activity, "activity");
        Q.a(activity, new S(this.this$0));
    }

    @Override // androidx.lifecycle.AbstractC0418o, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        U u7 = this.this$0;
        int i10 = u7.f6920a - 1;
        u7.f6920a = i10;
        if (i10 == 0 && u7.f6922c) {
            u7.f6924f.e(EnumC0424v.ON_STOP);
            u7.d = true;
        }
    }
}
