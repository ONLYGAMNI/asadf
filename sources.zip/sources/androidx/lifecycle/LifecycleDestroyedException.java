package androidx.lifecycle;

import java.util.concurrent.CancellationException;

/* loaded from: classes.dex */
public final class LifecycleDestroyedException extends CancellationException {
}
