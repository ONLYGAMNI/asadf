package androidx.lifecycle;

import m0.InterfaceC1193b;

/* loaded from: classes.dex */
public final class l0 implements InterfaceC1193b {

    /* renamed from: a, reason: collision with root package name */
    public static final l0 f6992a = new l0();

    /* renamed from: b, reason: collision with root package name */
    public static final l0 f6993b = new l0();
}
