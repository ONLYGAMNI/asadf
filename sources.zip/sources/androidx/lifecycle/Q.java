package androidx.lifecycle;

import android.app.Activity;
import android.app.Application;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class Q {
    public static final void a(Activity activity, Application.ActivityLifecycleCallbacks activityLifecycleCallbacks) {
        AbstractC1420h.f(activity, "activity");
        AbstractC1420h.f(activityLifecycleCallbacks, "callback");
        activity.registerActivityLifecycleCallbacks(activityLifecycleCallbacks);
    }
}
