package androidx.lifecycle;

import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* loaded from: classes.dex */
public final class Y extends AbstractC1113j implements r8.p {

    /* renamed from: a, reason: collision with root package name */
    public int f6940a;

    /* renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f6941b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ AbstractC0426x f6942c;
    public final /* synthetic */ EnumC0425w d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ r8.p f6943e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Y(AbstractC0426x abstractC0426x, E6.t tVar, i8.d dVar) {
        super(2, dVar);
        EnumC0425w enumC0425w = EnumC0425w.d;
        this.f6942c = abstractC0426x;
        this.d = enumC0425w;
        this.f6943e = tVar;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        Y y9 = new Y(this.f6942c, (E6.t) this.f6943e, dVar);
        y9.f6941b = obj;
        return y9;
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((Y) create((C8.G) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        int i10 = this.f6940a;
        if (i10 == 0) {
            f9.d.x(obj);
            C8.G g = (C8.G) this.f6941b;
            J8.d dVar = C8.Q.f295a;
            D8.e eVar = H8.m.f1642a.f604f;
            X x9 = new X(this.f6942c, this.d, g, this.f6943e, null);
            this.f6940a = 1;
            if (C8.I.D(this, eVar, x9) == enumC1073a) {
                return enumC1073a;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            f9.d.x(obj);
        }
        return C0803o.f10326a;
    }
}
