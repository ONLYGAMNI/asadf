package androidx.lifecycle;

import android.app.Application;
import android.os.Bundle;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.LinkedHashMap;
import m0.AbstractC1194c;
import m0.C1196e;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class h0 extends p0 implements n0 {

    /* renamed from: a, reason: collision with root package name */
    public final Application f6973a;

    /* renamed from: b, reason: collision with root package name */
    public final m0 f6974b;

    /* renamed from: c, reason: collision with root package name */
    public final Bundle f6975c;
    public final AbstractC0426x d;

    /* renamed from: e, reason: collision with root package name */
    public final C0.e f6976e;

    public h0(Application application, C0.f fVar, Bundle bundle) {
        m0 m0Var;
        AbstractC1420h.f(fVar, "owner");
        this.f6976e = fVar.b();
        this.d = fVar.h();
        this.f6975c = bundle;
        this.f6973a = application;
        if (application != null) {
            if (m0.f6994c == null) {
                m0.f6994c = new m0(application);
            }
            m0Var = m0.f6994c;
            AbstractC1420h.c(m0Var);
        } else {
            m0Var = new m0(null);
        }
        this.f6974b = m0Var;
    }

    public final j0 a(Class cls, String str) throws NoSuchMethodException, SecurityException, IOException {
        AbstractC0426x abstractC0426x = this.d;
        if (abstractC0426x == null) {
            throw new UnsupportedOperationException("SavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
        }
        boolean zIsAssignableFrom = AbstractC0406c.class.isAssignableFrom(cls);
        Application application = this.f6973a;
        Constructor constructorA = (!zIsAssignableFrom || application == null) ? i0.a(i0.f6981b, cls) : i0.a(i0.f6980a, cls);
        if (constructorA == null) {
            if (application != null) {
                return this.f6974b.create(cls);
            }
            if (o0.f6997a == null) {
                o0.f6997a = new o0();
            }
            o0 o0Var = o0.f6997a;
            AbstractC1420h.c(o0Var);
            return o0Var.create(cls);
        }
        C0.e eVar = this.f6976e;
        AbstractC1420h.c(eVar);
        SavedStateHandleController savedStateHandleControllerC = e0.c(eVar, abstractC0426x, str, this.f6975c);
        c0 c0Var = savedStateHandleControllerC.f6917b;
        j0 j0VarB = (!zIsAssignableFrom || application == null) ? i0.b(cls, constructorA, c0Var) : i0.b(cls, constructorA, application, c0Var);
        j0VarB.setTagIfAbsent(AbstractC0405b.TAG_SAVED_STATE_HANDLE_CONTROLLER, savedStateHandleControllerC);
        return j0VarB;
    }

    @Override // androidx.lifecycle.n0
    public final j0 create(Class cls, AbstractC1194c abstractC1194c) {
        l0 l0Var = l0.f6993b;
        LinkedHashMap linkedHashMap = ((C1196e) abstractC1194c).f12974a;
        String str = (String) linkedHashMap.get(l0Var);
        if (str == null) {
            throw new IllegalStateException("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
        }
        if (linkedHashMap.get(e0.f6957a) == null || linkedHashMap.get(e0.f6958b) == null) {
            if (this.d != null) {
                return a(cls, str);
            }
            throw new IllegalStateException("SAVED_STATE_REGISTRY_OWNER_KEY andVIEW_MODEL_STORE_OWNER_KEY must be provided in the creation extras tosuccessfully create a ViewModel.");
        }
        Application application = (Application) linkedHashMap.get(l0.f6992a);
        boolean zIsAssignableFrom = AbstractC0406c.class.isAssignableFrom(cls);
        Constructor constructorA = (!zIsAssignableFrom || application == null) ? i0.a(i0.f6981b, cls) : i0.a(i0.f6980a, cls);
        return constructorA == null ? this.f6974b.create(cls, abstractC1194c) : (!zIsAssignableFrom || application == null) ? i0.b(cls, constructorA, e0.e(abstractC1194c)) : i0.b(cls, constructorA, application, e0.e(abstractC1194c));
    }

    @Override // androidx.lifecycle.p0
    public final void onRequery(j0 j0Var) throws NoSuchMethodException, SecurityException {
        AbstractC0426x abstractC0426x = this.d;
        if (abstractC0426x != null) {
            C0.e eVar = this.f6976e;
            AbstractC1420h.c(eVar);
            e0.b(j0Var, eVar, abstractC0426x);
        }
    }

    @Override // androidx.lifecycle.n0
    public final j0 create(Class cls) {
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            return a(cls, canonicalName);
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }
}
