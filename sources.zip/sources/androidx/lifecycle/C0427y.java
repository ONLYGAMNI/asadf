package androidx.lifecycle;

import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* renamed from: androidx.lifecycle.y, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0427y extends AbstractC1113j implements r8.p {

    /* renamed from: a, reason: collision with root package name */
    public /* synthetic */ Object f7009a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ LifecycleCoroutineScopeImpl f7010b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0427y(LifecycleCoroutineScopeImpl lifecycleCoroutineScopeImpl, i8.d dVar) {
        super(2, dVar);
        this.f7010b = lifecycleCoroutineScopeImpl;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        C0427y c0427y = new C0427y(this.f7010b, dVar);
        c0427y.f7009a = obj;
        return c0427y;
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        C0427y c0427y = (C0427y) create((C8.G) obj, (i8.d) obj2);
        C0803o c0803o = C0803o.f10326a;
        c0427y.invokeSuspend(c0803o);
        return c0803o;
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        f9.d.x(obj);
        C8.G g = (C8.G) this.f7009a;
        LifecycleCoroutineScopeImpl lifecycleCoroutineScopeImpl = this.f7010b;
        if (((F) lifecycleCoroutineScopeImpl.f6901a).d.compareTo(EnumC0425w.f7004b) >= 0) {
            lifecycleCoroutineScopeImpl.f6901a.a(lifecycleCoroutineScopeImpl);
        } else {
            C8.I.g(g.b(), null);
        }
        return C0803o.f10326a;
    }
}
