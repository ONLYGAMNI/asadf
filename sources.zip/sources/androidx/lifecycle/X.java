package androidx.lifecycle;

import e8.C0803o;
import k8.AbstractC1113j;
import s8.C1431s;

/* loaded from: classes.dex */
public final class X extends AbstractC1113j implements r8.p {

    /* renamed from: a, reason: collision with root package name */
    public C1431s f6934a;

    /* renamed from: b, reason: collision with root package name */
    public C1431s f6935b;

    /* renamed from: c, reason: collision with root package name */
    public int f6936c;
    public final /* synthetic */ AbstractC0426x d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ EnumC0425w f6937e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ C8.G f6938f;

    /* renamed from: n, reason: collision with root package name */
    public final /* synthetic */ r8.p f6939n;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public X(AbstractC0426x abstractC0426x, EnumC0425w enumC0425w, C8.G g, r8.p pVar, i8.d dVar) {
        super(2, dVar);
        this.d = abstractC0426x;
        this.f6937e = enumC0425w;
        this.f6938f = g;
        this.f6939n = pVar;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        return new X(this.d, this.f6937e, this.f6938f, this.f6939n, dVar);
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((X) create((C8.G) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x008c  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0099  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00a3  */
    @Override // k8.AbstractC1104a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r18) throws java.lang.Throwable {
        /*
            r17 = this;
            r1 = r17
            j8.a r0 = j8.EnumC1073a.f11857a
            int r2 = r1.f6936c
            e8.o r3 = e8.C0803o.f10326a
            androidx.lifecycle.x r5 = r1.d
            r6 = 1
            if (r2 == 0) goto L22
            if (r2 != r6) goto L1a
            s8.s r2 = r1.f6935b
            s8.s r6 = r1.f6934a
            f9.d.x(r18)     // Catch: java.lang.Throwable -> L17
            goto L7c
        L17:
            r0 = move-exception
            goto L93
        L1a:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
            r0.<init>(r2)
            throw r0
        L22:
            f9.d.x(r18)
            r2 = r5
            androidx.lifecycle.F r2 = (androidx.lifecycle.F) r2
            androidx.lifecycle.w r2 = r2.d
            androidx.lifecycle.w r7 = androidx.lifecycle.EnumC0425w.f7003a
            if (r2 != r7) goto L2f
            return r3
        L2f:
            s8.s r2 = new s8.s
            r2.<init>()
            s8.s r7 = new s8.s
            r7.<init>()
            androidx.lifecycle.w r8 = r1.f6937e     // Catch: java.lang.Throwable -> L90
            C8.G r11 = r1.f6938f     // Catch: java.lang.Throwable -> L90
            r8.p r15 = r1.f6939n     // Catch: java.lang.Throwable -> L90
            r1.f6934a = r2     // Catch: java.lang.Throwable -> L90
            r1.f6935b = r7     // Catch: java.lang.Throwable -> L90
            r1.f6936c = r6     // Catch: java.lang.Throwable -> L90
            C8.m r14 = new C8.m     // Catch: java.lang.Throwable -> L90
            i8.d r9 = c5.v0.n(r17)     // Catch: java.lang.Throwable -> L90
            r14.<init>(r6, r9)     // Catch: java.lang.Throwable -> L90
            r14.t()     // Catch: java.lang.Throwable -> L90
            androidx.lifecycle.t r6 = androidx.lifecycle.EnumC0424v.Companion     // Catch: java.lang.Throwable -> L90
            r6.getClass()     // Catch: java.lang.Throwable -> L90
            androidx.lifecycle.v r9 = androidx.lifecycle.C0422t.c(r8)     // Catch: java.lang.Throwable -> L90
            androidx.lifecycle.v r12 = androidx.lifecycle.C0422t.a(r8)     // Catch: java.lang.Throwable -> L90
            M8.d r6 = M8.e.a()     // Catch: java.lang.Throwable -> L90
            androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1 r13 = new androidx.lifecycle.RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1     // Catch: java.lang.Throwable -> L90
            r8 = r13
            r10 = r2
            r4 = r13
            r13 = r14
            r16 = r14
            r14 = r6
            r8.<init>()     // Catch: java.lang.Throwable -> L90
            r7.f14976a = r4     // Catch: java.lang.Throwable -> L90
            r5.a(r4)     // Catch: java.lang.Throwable -> L90
            java.lang.Object r4 = r16.s()     // Catch: java.lang.Throwable -> L90
            if (r4 != r0) goto L7a
            return r0
        L7a:
            r6 = r2
            r2 = r7
        L7c:
            java.lang.Object r0 = r6.f14976a
            C8.j0 r0 = (C8.InterfaceC0033j0) r0
            if (r0 == 0) goto L86
            r4 = 0
            r0.cancel(r4)
        L86:
            java.lang.Object r0 = r2.f14976a
            androidx.lifecycle.B r0 = (androidx.lifecycle.B) r0
            if (r0 == 0) goto L8f
            r5.b(r0)
        L8f:
            return r3
        L90:
            r0 = move-exception
            r6 = r2
            r2 = r7
        L93:
            java.lang.Object r3 = r6.f14976a
            C8.j0 r3 = (C8.InterfaceC0033j0) r3
            if (r3 == 0) goto L9d
            r4 = 0
            r3.cancel(r4)
        L9d:
            java.lang.Object r2 = r2.f14976a
            androidx.lifecycle.B r2 = (androidx.lifecycle.B) r2
            if (r2 == 0) goto La6
            r5.b(r2)
        La6:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.X.invokeSuspend(java.lang.Object):java.lang.Object");
    }
}
