package androidx.lifecycle;

import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class LifecycleCoroutineScopeImpl implements B, C8.G {

    /* renamed from: a */
    public final AbstractC0426x f6901a;

    /* renamed from: b */
    public final i8.i f6902b;

    public LifecycleCoroutineScopeImpl(AbstractC0426x abstractC0426x, i8.i iVar) {
        AbstractC1420h.f(iVar, "coroutineContext");
        this.f6901a = abstractC0426x;
        this.f6902b = iVar;
        if (((F) abstractC0426x).d == EnumC0425w.f7003a) {
            C8.I.g(iVar, null);
        }
    }

    @Override // C8.G
    public final i8.i b() {
        return this.f6902b;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        AbstractC0426x abstractC0426x = this.f6901a;
        if (((F) abstractC0426x).d.compareTo(EnumC0425w.f7003a) <= 0) {
            abstractC0426x.b(this);
            C8.I.g(this.f6902b, null);
        }
    }
}
