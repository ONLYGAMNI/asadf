package androidx.lifecycle;

import java.util.Map;
import m.C1189b;
import n.C1239c;
import n.C1240d;
import n.C1242f;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public abstract class K {

    /* renamed from: k */
    public static final Object f6887k = new Object();

    /* renamed from: a */
    public final Object f6888a;

    /* renamed from: b */
    public final C1242f f6889b;

    /* renamed from: c */
    public int f6890c;
    public boolean d;

    /* renamed from: e */
    public volatile Object f6891e;

    /* renamed from: f */
    public volatile Object f6892f;
    public int g;

    /* renamed from: h */
    public boolean f6893h;

    /* renamed from: i */
    public boolean f6894i;

    /* renamed from: j */
    public final D6.G f6895j;

    public K(Object obj) {
        this.f6888a = new Object();
        this.f6889b = new C1242f();
        this.f6890c = 0;
        this.f6892f = f6887k;
        this.f6895j = new D6.G(this, 17);
        this.f6891e = obj;
        this.g = 0;
    }

    public static void a(String str) {
        if (!C1189b.A().B()) {
            throw new IllegalStateException(AbstractC1480a.k("Cannot invoke ", str, " on a background thread"));
        }
    }

    public final void b(J j10) {
        if (j10.f6885b) {
            if (!j10.h()) {
                j10.b(false);
                return;
            }
            int i10 = j10.f6886c;
            int i11 = this.g;
            if (i10 >= i11) {
                return;
            }
            j10.f6886c = i11;
            j10.f6884a.a(this.f6891e);
        }
    }

    public final void c(J j10) {
        if (this.f6893h) {
            this.f6894i = true;
            return;
        }
        this.f6893h = true;
        do {
            this.f6894i = false;
            if (j10 != null) {
                b(j10);
                j10 = null;
            } else {
                C1242f c1242f = this.f6889b;
                c1242f.getClass();
                C1240d c1240d = new C1240d(c1242f);
                c1242f.f13215c.put(c1240d, Boolean.FALSE);
                while (c1240d.hasNext()) {
                    b((J) ((Map.Entry) c1240d.next()).getValue());
                    if (this.f6894i) {
                        break;
                    }
                }
            }
        } while (this.f6894i);
        this.f6893h = false;
    }

    public final Object d() {
        Object obj = this.f6891e;
        if (obj != f6887k) {
            return obj;
        }
        return null;
    }

    public void e(D d, O o9) {
        Object obj;
        a("observe");
        if (d.h().d == EnumC0425w.f7003a) {
            return;
        }
        LiveData$LifecycleBoundObserver liveData$LifecycleBoundObserver = new LiveData$LifecycleBoundObserver(this, d, o9);
        C1242f c1242f = this.f6889b;
        C1239c c1239cB = c1242f.b(o9);
        if (c1239cB != null) {
            obj = c1239cB.f13208b;
        } else {
            C1239c c1239c = new C1239c(o9, liveData$LifecycleBoundObserver);
            c1242f.d++;
            C1239c c1239c2 = c1242f.f13214b;
            if (c1239c2 == null) {
                c1242f.f13213a = c1239c;
                c1242f.f13214b = c1239c;
            } else {
                c1239c2.f13209c = c1239c;
                c1239c.d = c1239c2;
                c1242f.f13214b = c1239c;
            }
            obj = null;
        }
        J j10 = (J) obj;
        if (j10 != null && !j10.g(d)) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (j10 != null) {
            return;
        }
        d.h().a(liveData$LifecycleBoundObserver);
    }

    public void f(O o9) {
        Object obj;
        a("observeForever");
        I i10 = new I(this, o9);
        C1242f c1242f = this.f6889b;
        C1239c c1239cB = c1242f.b(o9);
        if (c1239cB != null) {
            obj = c1239cB.f13208b;
        } else {
            C1239c c1239c = new C1239c(o9, i10);
            c1242f.d++;
            C1239c c1239c2 = c1242f.f13214b;
            if (c1239c2 == null) {
                c1242f.f13213a = c1239c;
                c1242f.f13214b = c1239c;
            } else {
                c1239c2.f13209c = c1239c;
                c1239c.d = c1239c2;
                c1242f.f13214b = c1239c;
            }
            obj = null;
        }
        J j10 = (J) obj;
        if (j10 instanceof LiveData$LifecycleBoundObserver) {
            throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
        }
        if (j10 != null) {
            return;
        }
        i10.b(true);
    }

    public void g() {
    }

    public void h() {
    }

    public void i(Object obj) {
        boolean z3;
        synchronized (this.f6888a) {
            z3 = this.f6892f == f6887k;
            this.f6892f = obj;
        }
        if (z3) {
            C1189b.A().C(this.f6895j);
        }
    }

    public void j(O o9) {
        a("removeObserver");
        J j10 = (J) this.f6889b.c(o9);
        if (j10 == null) {
            return;
        }
        j10.f();
        j10.b(false);
    }

    public void k(Object obj) {
        a("setValue");
        this.g++;
        this.f6891e = obj;
        c(null);
    }

    public K() {
        this.f6888a = new Object();
        this.f6889b = new C1242f();
        this.f6890c = 0;
        Object obj = f6887k;
        this.f6892f = obj;
        this.f6895j = new D6.G(this, 17);
        this.f6891e = obj;
        this.g = -1;
    }
}
