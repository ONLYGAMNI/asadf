package androidx.lifecycle;

/* loaded from: classes.dex */
public abstract class p0 {
    public abstract void onRequery(j0 j0Var);
}
