package androidx.lifecycle;

/* loaded from: classes.dex */
public interface D {
    F h();
}
