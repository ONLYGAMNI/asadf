package androidx.lifecycle;

/* loaded from: classes.dex */
public final class I extends J {
    @Override // androidx.lifecycle.J
    public final boolean h() {
        return true;
    }
}
