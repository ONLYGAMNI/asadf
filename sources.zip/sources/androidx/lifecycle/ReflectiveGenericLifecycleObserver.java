package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;

@Deprecated
/* loaded from: classes.dex */
class ReflectiveGenericLifecycleObserver implements B {

    /* renamed from: a, reason: collision with root package name */
    public final Object f6907a;

    /* renamed from: b, reason: collision with root package name */
    public final C0410g f6908b;

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f6907a = obj;
        C0412i c0412i = C0412i.f6977c;
        Class<?> cls = obj.getClass();
        C0410g c0410g = (C0410g) c0412i.f6978a.get(cls);
        this.f6908b = c0410g == null ? c0412i.a(cls, null) : c0410g;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        HashMap map = this.f6908b.f6968a;
        List list = (List) map.get(enumC0424v);
        Object obj = this.f6907a;
        C0410g.a(list, d, enumC0424v, obj);
        C0410g.a((List) map.get(EnumC0424v.ON_ANY), d, enumC0424v, obj);
    }
}
