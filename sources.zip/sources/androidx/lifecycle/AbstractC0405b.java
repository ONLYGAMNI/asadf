package androidx.lifecycle;

import android.os.Bundle;
import java.io.IOException;
import m0.AbstractC1194c;
import s8.AbstractC1420h;

/* renamed from: androidx.lifecycle.b, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0405b extends p0 implements n0 {
    public static final C0404a Companion = new C0404a();
    public static final String TAG_SAVED_STATE_HANDLE_CONTROLLER = "androidx.lifecycle.savedstate.vm.tag";
    private Bundle defaultArgs;
    private AbstractC0426x lifecycle;
    private C0.e savedStateRegistry;

    public AbstractC0405b(C0.f fVar) {
        AbstractC1420h.f(fVar, "owner");
        this.savedStateRegistry = fVar.b();
        this.lifecycle = fVar.h();
        this.defaultArgs = null;
    }

    @Override // androidx.lifecycle.n0
    public <T extends j0> T create(Class<T> cls, AbstractC1194c abstractC1194c) throws NoSuchMethodException, SecurityException, IOException {
        AbstractC1420h.f(cls, "modelClass");
        AbstractC1420h.f(abstractC1194c, "extras");
        String str = (String) abstractC1194c.a(l0.f6993b);
        if (str == null) {
            throw new IllegalStateException("VIEW_MODEL_KEY must always be provided by ViewModelProvider");
        }
        C0.e eVar = this.savedStateRegistry;
        if (eVar == null) {
            return (T) create(str, cls, e0.e(abstractC1194c));
        }
        AbstractC1420h.c(eVar);
        AbstractC0426x abstractC0426x = this.lifecycle;
        AbstractC1420h.c(abstractC0426x);
        SavedStateHandleController savedStateHandleControllerC = e0.c(eVar, abstractC0426x, str, this.defaultArgs);
        T t9 = (T) create(str, cls, savedStateHandleControllerC.f6917b);
        t9.setTagIfAbsent(TAG_SAVED_STATE_HANDLE_CONTROLLER, savedStateHandleControllerC);
        return t9;
    }

    public abstract j0 create(String str, Class cls, c0 c0Var);

    @Override // androidx.lifecycle.p0
    public void onRequery(j0 j0Var) throws NoSuchMethodException, SecurityException {
        AbstractC1420h.f(j0Var, "viewModel");
        C0.e eVar = this.savedStateRegistry;
        if (eVar != null) {
            AbstractC1420h.c(eVar);
            AbstractC0426x abstractC0426x = this.lifecycle;
            AbstractC1420h.c(abstractC0426x);
            e0.b(j0Var, eVar, abstractC0426x);
        }
    }

    @Override // androidx.lifecycle.n0
    public <T extends j0> T create(Class<T> cls) throws NoSuchMethodException, SecurityException, IOException {
        AbstractC1420h.f(cls, "modelClass");
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            if (this.lifecycle != null) {
                C0.e eVar = this.savedStateRegistry;
                AbstractC1420h.c(eVar);
                AbstractC0426x abstractC0426x = this.lifecycle;
                AbstractC1420h.c(abstractC0426x);
                SavedStateHandleController savedStateHandleControllerC = e0.c(eVar, abstractC0426x, canonicalName, this.defaultArgs);
                T t9 = (T) create(canonicalName, cls, savedStateHandleControllerC.f6917b);
                t9.setTagIfAbsent(TAG_SAVED_STATE_HANDLE_CONTROLLER, savedStateHandleControllerC);
                return t9;
            }
            throw new UnsupportedOperationException("AbstractSavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras).");
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }
}
