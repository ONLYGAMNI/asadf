package androidx.lifecycle;

/* loaded from: classes.dex */
public interface O {
    void a(Object obj);
}
