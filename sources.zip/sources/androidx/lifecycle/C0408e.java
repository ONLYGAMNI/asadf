package androidx.lifecycle;

import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* renamed from: androidx.lifecycle.e */
/* loaded from: classes.dex */
public final class C0408e extends AbstractC1113j implements r8.p {

    /* renamed from: a */
    public int f6954a;

    /* renamed from: b */
    public /* synthetic */ Object f6955b;

    /* renamed from: c */
    public final /* synthetic */ C0409f f6956c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0408e(C0409f c0409f, i8.d dVar) {
        super(2, dVar);
        this.f6956c = c0409f;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        C0408e c0408e = new C0408e(this.f6956c, dVar);
        c0408e.f6955b = obj;
        return c0408e;
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C0408e) create((C8.G) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        int i10 = this.f6954a;
        C0409f c0409f = this.f6956c;
        if (i10 == 0) {
            f9.d.x(obj);
            M m9 = new M(c0409f.f6960a, ((C8.G) this.f6955b).b());
            r8.p pVar = c0409f.f6961b;
            this.f6954a = 1;
            if (pVar.invoke(m9, this) == enumC1073a) {
                return enumC1073a;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            f9.d.x(obj);
        }
        c0409f.f6963e.invoke();
        return C0803o.f10326a;
    }
}
