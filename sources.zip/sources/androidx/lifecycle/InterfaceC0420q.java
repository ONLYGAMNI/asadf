package androidx.lifecycle;

/* renamed from: androidx.lifecycle.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0420q {
}
