package androidx.lifecycle;

import e8.C0803o;
import k8.AbstractC1106c;

/* renamed from: androidx.lifecycle.k */
/* loaded from: classes.dex */
public final class C0414k extends AbstractC1106c {

    /* renamed from: a */
    public /* synthetic */ Object f6983a;

    /* renamed from: b */
    public final /* synthetic */ C0415l f6984b;

    /* renamed from: c */
    public int f6985c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0414k(C0415l c0415l, i8.d dVar) {
        super(dVar);
        this.f6984b = c0415l;
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        this.f6983a = obj;
        this.f6985c |= Integer.MIN_VALUE;
        this.f6984b.l(this);
        return C0803o.f10326a;
    }
}
