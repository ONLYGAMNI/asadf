package androidx.lifecycle;

import java.lang.reflect.Method;

/* renamed from: androidx.lifecycle.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0411h {

    /* renamed from: a, reason: collision with root package name */
    public final int f6971a;

    /* renamed from: b, reason: collision with root package name */
    public final Method f6972b;

    public C0411h(int i10, Method method) throws SecurityException {
        this.f6971a = i10;
        this.f6972b = method;
        method.setAccessible(true);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0411h)) {
            return false;
        }
        C0411h c0411h = (C0411h) obj;
        return this.f6971a == c0411h.f6971a && this.f6972b.getName().equals(c0411h.f6972b.getName());
    }

    public final int hashCode() {
        return this.f6972b.getName().hashCode() + (this.f6971a * 31);
    }
}
