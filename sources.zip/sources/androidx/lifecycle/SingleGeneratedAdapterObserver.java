package androidx.lifecycle;

/* loaded from: classes.dex */
public final class SingleGeneratedAdapterObserver implements B {
    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        throw null;
    }
}
