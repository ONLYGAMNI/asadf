package androidx.lifecycle;

/* loaded from: classes.dex */
public class N extends K {
}
