package androidx.lifecycle;

import java.io.Closeable;
import s8.AbstractC1420h;

/* renamed from: androidx.lifecycle.j, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0413j implements Closeable, C8.G {

    /* renamed from: a, reason: collision with root package name */
    public final i8.i f6982a;

    public C0413j(i8.i iVar) {
        AbstractC1420h.f(iVar, "context");
        this.f6982a = iVar;
    }

    @Override // C8.G
    public final i8.i b() {
        return this.f6982a;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        C8.I.g(this.f6982a, null);
    }
}
