package androidx.lifecycle;

import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* loaded from: classes.dex */
public final class W extends AbstractC1113j implements r8.p {

    /* renamed from: a, reason: collision with root package name */
    public M8.a f6930a;

    /* renamed from: b, reason: collision with root package name */
    public r8.p f6931b;

    /* renamed from: c, reason: collision with root package name */
    public int f6932c;
    public final /* synthetic */ M8.a d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ r8.p f6933e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public W(M8.a aVar, r8.p pVar, i8.d dVar) {
        super(2, dVar);
        this.d = aVar;
        this.f6933e = pVar;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        return new W(this.d, this.f6933e, dVar);
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((W) create((C8.G) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) throws Throwable {
        M8.a aVar;
        r8.p pVar;
        M8.a aVar2;
        Throwable th;
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        int i10 = this.f6932c;
        try {
            if (i10 == 0) {
                f9.d.x(obj);
                aVar = this.d;
                this.f6930a = aVar;
                pVar = this.f6933e;
                this.f6931b = pVar;
                this.f6932c = 1;
                if (aVar.b(this) == enumC1073a) {
                    return enumC1073a;
                }
            } else {
                if (i10 != 1) {
                    if (i10 != 2) {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    aVar2 = this.f6930a;
                    try {
                        f9.d.x(obj);
                        aVar2.a(null);
                        return C0803o.f10326a;
                    } catch (Throwable th2) {
                        th = th2;
                        aVar2.a(null);
                        throw th;
                    }
                }
                pVar = this.f6931b;
                M8.a aVar3 = this.f6930a;
                f9.d.x(obj);
                aVar = aVar3;
            }
            V v9 = new V(pVar, null);
            this.f6930a = aVar;
            this.f6931b = null;
            this.f6932c = 2;
            if (C8.I.h(v9, this) == enumC1073a) {
                return enumC1073a;
            }
            aVar2 = aVar;
            aVar2.a(null);
            return C0803o.f10326a;
        } catch (Throwable th3) {
            aVar2 = aVar;
            th = th3;
            aVar2.a(null);
            throw th;
        }
    }
}
