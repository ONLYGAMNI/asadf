package androidx.lifecycle;

import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class M {

    /* renamed from: a, reason: collision with root package name */
    public final C0415l f6905a;

    /* renamed from: b, reason: collision with root package name */
    public final i8.i f6906b;

    public M(C0415l c0415l, i8.i iVar) {
        AbstractC1420h.f(iVar, "context");
        this.f6905a = c0415l;
        J8.d dVar = C8.Q.f295a;
        this.f6906b = iVar.plus(H8.m.f1642a.f604f);
    }
}
