package androidx.lifecycle;

import java.util.HashMap;

/* loaded from: classes.dex */
public final class CompositeGeneratedAdaptersObserver implements B {

    /* renamed from: a, reason: collision with root package name */
    public final InterfaceC0420q[] f6870a;

    public CompositeGeneratedAdaptersObserver(InterfaceC0420q[] interfaceC0420qArr) {
        this.f6870a = interfaceC0420qArr;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        new HashMap();
        InterfaceC0420q[] interfaceC0420qArr = this.f6870a;
        if (interfaceC0420qArr.length > 0) {
            InterfaceC0420q interfaceC0420q = interfaceC0420qArr[0];
            throw null;
        }
        if (interfaceC0420qArr.length <= 0) {
            return;
        }
        InterfaceC0420q interfaceC0420q2 = interfaceC0420qArr[0];
        throw null;
    }
}
