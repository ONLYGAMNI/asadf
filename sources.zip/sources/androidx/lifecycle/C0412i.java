package androidx.lifecycle;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/* renamed from: androidx.lifecycle.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0412i {

    /* renamed from: c, reason: collision with root package name */
    public static final C0412i f6977c = new C0412i();

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f6978a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final HashMap f6979b = new HashMap();

    public static void b(HashMap map, C0411h c0411h, EnumC0424v enumC0424v, Class cls) {
        EnumC0424v enumC0424v2 = (EnumC0424v) map.get(c0411h);
        if (enumC0424v2 == null || enumC0424v == enumC0424v2) {
            if (enumC0424v2 == null) {
                map.put(c0411h, enumC0424v);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Method " + c0411h.f6972b.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + enumC0424v2 + ", new value " + enumC0424v);
    }

    public final C0410g a(Class cls, Method[] methodArr) throws SecurityException {
        int i10;
        Class superclass = cls.getSuperclass();
        HashMap map = new HashMap();
        HashMap map2 = this.f6978a;
        if (superclass != null) {
            C0410g c0410gA = (C0410g) map2.get(superclass);
            if (c0410gA == null) {
                c0410gA = a(superclass, null);
            }
            map.putAll(c0410gA.f6969b);
        }
        for (Class<?> cls2 : cls.getInterfaces()) {
            C0410g c0410gA2 = (C0410g) map2.get(cls2);
            if (c0410gA2 == null) {
                c0410gA2 = a(cls2, null);
            }
            for (Map.Entry entry : c0410gA2.f6969b.entrySet()) {
                b(map, (C0411h) entry.getKey(), (EnumC0424v) entry.getValue(), cls);
            }
        }
        if (methodArr == null) {
            try {
                methodArr = cls.getDeclaredMethods();
            } catch (NoClassDefFoundError e4) {
                throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", e4);
            }
        }
        boolean z3 = false;
        for (Method method : methodArr) {
            P p9 = (P) method.getAnnotation(P.class);
            if (p9 != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i10 = 0;
                } else {
                    if (!D.class.isAssignableFrom(parameterTypes[0])) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i10 = 1;
                }
                EnumC0424v enumC0424vValue = p9.value();
                if (parameterTypes.length > 1) {
                    if (!EnumC0424v.class.isAssignableFrom(parameterTypes[1])) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (enumC0424vValue != EnumC0424v.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i10 = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                b(map, new C0411h(i10, method), enumC0424vValue, cls);
                z3 = true;
            }
        }
        C0410g c0410g = new C0410g(map);
        map2.put(cls, c0410g);
        this.f6979b.put(cls, Boolean.valueOf(z3));
        return c0410g;
    }
}
