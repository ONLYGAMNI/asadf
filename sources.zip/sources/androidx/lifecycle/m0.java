package androidx.lifecycle;

import android.app.Application;
import java.lang.reflect.InvocationTargetException;
import m0.AbstractC1194c;
import m0.C1196e;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class m0 extends o0 {

    /* renamed from: c, reason: collision with root package name */
    public static m0 f6994c;

    /* renamed from: b, reason: collision with root package name */
    public final Application f6995b;

    public m0(Application application) {
        this.f6995b = application;
    }

    public final j0 a(Class cls, Application application) {
        if (!AbstractC0406c.class.isAssignableFrom(cls)) {
            return super.create(cls);
        }
        try {
            j0 j0Var = (j0) cls.getConstructor(Application.class).newInstance(application);
            AbstractC1420h.e(j0Var, "{\n                try {\n…          }\n            }");
            return j0Var;
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("Cannot create an instance of " + cls, e4);
        } catch (InstantiationException e5) {
            throw new RuntimeException("Cannot create an instance of " + cls, e5);
        } catch (NoSuchMethodException e10) {
            throw new RuntimeException("Cannot create an instance of " + cls, e10);
        } catch (InvocationTargetException e11) {
            throw new RuntimeException("Cannot create an instance of " + cls, e11);
        }
    }

    @Override // androidx.lifecycle.o0, androidx.lifecycle.n0
    public final j0 create(Class cls, AbstractC1194c abstractC1194c) {
        if (this.f6995b != null) {
            return create(cls);
        }
        Application application = (Application) ((C1196e) abstractC1194c).f12974a.get(l0.f6992a);
        if (application != null) {
            return a(cls, application);
        }
        if (AbstractC0406c.class.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("CreationExtras must have an application by `APPLICATION_KEY`");
        }
        return super.create(cls);
    }

    @Override // androidx.lifecycle.o0, androidx.lifecycle.n0
    public final j0 create(Class cls) {
        Application application = this.f6995b;
        if (application != null) {
            return a(cls, application);
        }
        throw new UnsupportedOperationException("AndroidViewModelFactory constructed with empty constructor works only with create(modelClass: Class<T>, extras: CreationExtras).");
    }
}
