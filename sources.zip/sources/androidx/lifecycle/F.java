package androidx.lifecycle;

import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;
import m.C1189b;
import n.C1237a;
import n.C1239c;
import s8.AbstractC1420h;
import u0.AbstractC1480a;

/* loaded from: classes.dex */
public final class F extends AbstractC0426x {

    /* renamed from: b */
    public final boolean f6875b;

    /* renamed from: c */
    public C1237a f6876c;
    public EnumC0425w d;

    /* renamed from: e */
    public final WeakReference f6877e;

    /* renamed from: f */
    public int f6878f;
    public boolean g;

    /* renamed from: h */
    public boolean f6879h;

    /* renamed from: i */
    public final ArrayList f6880i;

    public F(D d) {
        AbstractC1420h.f(d, "provider");
        this.f7008a = new AtomicReference();
        this.f6875b = true;
        this.f6876c = new C1237a();
        this.d = EnumC0425w.f7004b;
        this.f6880i = new ArrayList();
        this.f6877e = new WeakReference(d);
    }

    @Override // androidx.lifecycle.AbstractC0426x
    public final void a(C c4) {
        B reflectiveGenericLifecycleObserver;
        D d;
        ArrayList arrayList = this.f6880i;
        AbstractC1420h.f(c4, "observer");
        d("addObserver");
        EnumC0425w enumC0425w = this.d;
        EnumC0425w enumC0425w2 = EnumC0425w.f7003a;
        if (enumC0425w != enumC0425w2) {
            enumC0425w2 = EnumC0425w.f7004b;
        }
        E e4 = new E();
        HashMap map = H.f6882a;
        boolean z3 = c4 instanceof B;
        boolean z9 = c4 instanceof InterfaceC0416m;
        if (z3 && z9) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((InterfaceC0416m) c4, (B) c4);
        } else if (z9) {
            reflectiveGenericLifecycleObserver = new DefaultLifecycleObserverAdapter((InterfaceC0416m) c4, null);
        } else if (z3) {
            reflectiveGenericLifecycleObserver = (B) c4;
        } else {
            Class<?> cls = c4.getClass();
            if (H.b(cls) == 2) {
                Object obj = H.f6883b.get(cls);
                AbstractC1420h.c(obj);
                List list = (List) obj;
                if (list.size() == 1) {
                    H.a((Constructor) list.get(0), c4);
                    throw null;
                }
                int size = list.size();
                InterfaceC0420q[] interfaceC0420qArr = new InterfaceC0420q[size];
                if (size > 0) {
                    H.a((Constructor) list.get(0), c4);
                    throw null;
                }
                reflectiveGenericLifecycleObserver = new CompositeGeneratedAdaptersObserver(interfaceC0420qArr);
            } else {
                reflectiveGenericLifecycleObserver = new ReflectiveGenericLifecycleObserver(c4);
            }
        }
        e4.f6874b = reflectiveGenericLifecycleObserver;
        e4.f6873a = enumC0425w2;
        if (((E) this.f6876c.e(c4, e4)) == null && (d = (D) this.f6877e.get()) != null) {
            boolean z10 = this.f6878f != 0 || this.g;
            EnumC0425w enumC0425wC = c(c4);
            this.f6878f++;
            while (e4.f6873a.compareTo(enumC0425wC) < 0 && this.f6876c.f13203e.containsKey(c4)) {
                arrayList.add(e4.f6873a);
                C0422t c0422t = EnumC0424v.Companion;
                EnumC0425w enumC0425w3 = e4.f6873a;
                c0422t.getClass();
                EnumC0424v enumC0424vB = C0422t.b(enumC0425w3);
                if (enumC0424vB == null) {
                    throw new IllegalStateException("no event up from " + e4.f6873a);
                }
                e4.a(d, enumC0424vB);
                arrayList.remove(arrayList.size() - 1);
                enumC0425wC = c(c4);
            }
            if (!z10) {
                h();
            }
            this.f6878f--;
        }
    }

    @Override // androidx.lifecycle.AbstractC0426x
    public final void b(C c4) {
        AbstractC1420h.f(c4, "observer");
        d("removeObserver");
        this.f6876c.c(c4);
    }

    public final EnumC0425w c(C c4) {
        E e4;
        HashMap map = this.f6876c.f13203e;
        C1239c c1239c = map.containsKey(c4) ? ((C1239c) map.get(c4)).d : null;
        EnumC0425w enumC0425w = (c1239c == null || (e4 = (E) c1239c.f13208b) == null) ? null : e4.f6873a;
        ArrayList arrayList = this.f6880i;
        EnumC0425w enumC0425w2 = arrayList.isEmpty() ^ true ? (EnumC0425w) arrayList.get(arrayList.size() - 1) : null;
        EnumC0425w enumC0425w3 = this.d;
        AbstractC1420h.f(enumC0425w3, "state1");
        if (enumC0425w == null || enumC0425w.compareTo(enumC0425w3) >= 0) {
            enumC0425w = enumC0425w3;
        }
        return (enumC0425w2 == null || enumC0425w2.compareTo(enumC0425w) >= 0) ? enumC0425w : enumC0425w2;
    }

    public final void d(String str) {
        if (this.f6875b && !C1189b.A().B()) {
            throw new IllegalStateException(AbstractC1480a.k("Method ", str, " must be called on the main thread").toString());
        }
    }

    public final void e(EnumC0424v enumC0424v) {
        AbstractC1420h.f(enumC0424v, "event");
        d("handleLifecycleEvent");
        f(enumC0424v.a());
    }

    public final void f(EnumC0425w enumC0425w) {
        EnumC0425w enumC0425w2 = this.d;
        if (enumC0425w2 == enumC0425w) {
            return;
        }
        EnumC0425w enumC0425w3 = EnumC0425w.f7004b;
        EnumC0425w enumC0425w4 = EnumC0425w.f7003a;
        if (enumC0425w2 == enumC0425w3 && enumC0425w == enumC0425w4) {
            throw new IllegalStateException(("no event down from " + this.d + " in component " + this.f6877e.get()).toString());
        }
        this.d = enumC0425w;
        if (this.g || this.f6878f != 0) {
            this.f6879h = true;
            return;
        }
        this.g = true;
        h();
        this.g = false;
        if (this.d == enumC0425w4) {
            this.f6876c = new C1237a();
        }
    }

    public final void g(EnumC0425w enumC0425w) {
        AbstractC1420h.f(enumC0425w, "state");
        d("setCurrentState");
        f(enumC0425w);
    }

    /* JADX WARN: Code restructure failed: missing block: B:90:0x0030, code lost:
    
        r7.f6879h = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:91:0x0032, code lost:
    
        return;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void h() {
        /*
            Method dump skipped, instructions count: 367
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.F.h():void");
    }
}
