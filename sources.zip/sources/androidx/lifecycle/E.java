package androidx.lifecycle;

import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class E {

    /* renamed from: a, reason: collision with root package name */
    public EnumC0425w f6873a;

    /* renamed from: b, reason: collision with root package name */
    public B f6874b;

    public final void a(D d, EnumC0424v enumC0424v) {
        EnumC0425w enumC0425wA = enumC0424v.a();
        EnumC0425w enumC0425w = this.f6873a;
        AbstractC1420h.f(enumC0425w, "state1");
        if (enumC0425wA.compareTo(enumC0425w) < 0) {
            enumC0425w = enumC0425wA;
        }
        this.f6873a = enumC0425w;
        this.f6874b.d(d, enumC0424v);
        this.f6873a = enumC0425wA;
    }
}
