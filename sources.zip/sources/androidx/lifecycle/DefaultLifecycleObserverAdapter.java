package androidx.lifecycle;

import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class DefaultLifecycleObserverAdapter implements B {

    /* renamed from: a, reason: collision with root package name */
    public final InterfaceC0416m f6871a;

    /* renamed from: b, reason: collision with root package name */
    public final B f6872b;

    public DefaultLifecycleObserverAdapter(InterfaceC0416m interfaceC0416m, B b7) {
        AbstractC1420h.f(interfaceC0416m, "defaultLifecycleObserver");
        this.f6871a = interfaceC0416m;
        this.f6872b = b7;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        int i10 = AbstractC0417n.f6996a[enumC0424v.ordinal()];
        InterfaceC0416m interfaceC0416m = this.f6871a;
        switch (i10) {
            case 1:
                interfaceC0416m.c(d);
                break;
            case 2:
                interfaceC0416m.onStart(d);
                break;
            case 3:
                interfaceC0416m.a(d);
                break;
            case 4:
                interfaceC0416m.e(d);
                break;
            case 5:
                interfaceC0416m.onStop(d);
                break;
            case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                interfaceC0416m.onDestroy(d);
                break;
            case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        B b7 = this.f6872b;
        if (b7 != null) {
            b7.d(d, enumC0424v);
        }
    }
}
