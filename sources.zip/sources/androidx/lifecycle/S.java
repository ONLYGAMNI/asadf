package androidx.lifecycle;

import android.app.Activity;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class S extends AbstractC0418o {
    final /* synthetic */ U this$0;

    public S(U u7) {
        this.this$0 = u7;
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPostResumed(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        this.this$0.a();
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPostStarted(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        U u7 = this.this$0;
        int i10 = u7.f6920a + 1;
        u7.f6920a = i10;
        if (i10 == 1 && u7.d) {
            u7.f6924f.e(EnumC0424v.ON_START);
            u7.d = false;
        }
    }
}
