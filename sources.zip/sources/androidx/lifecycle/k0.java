package androidx.lifecycle;

import e8.InterfaceC0793e;
import m0.AbstractC1194c;
import r8.InterfaceC1379a;
import s8.AbstractC1420h;
import s8.C1416d;
import x8.InterfaceC1650b;

/* loaded from: classes.dex */
public final class k0 implements InterfaceC0793e {

    /* renamed from: a, reason: collision with root package name */
    public final InterfaceC1650b f6986a;

    /* renamed from: b, reason: collision with root package name */
    public final InterfaceC1379a f6987b;

    /* renamed from: c, reason: collision with root package name */
    public final InterfaceC1379a f6988c;
    public final InterfaceC1379a d;

    /* renamed from: e, reason: collision with root package name */
    public j0 f6989e;

    public k0(C1416d c1416d, InterfaceC1379a interfaceC1379a, InterfaceC1379a interfaceC1379a2, InterfaceC1379a interfaceC1379a3) {
        AbstractC1420h.f(interfaceC1379a3, "extrasProducer");
        this.f6986a = c1416d;
        this.f6987b = interfaceC1379a;
        this.f6988c = interfaceC1379a2;
        this.d = interfaceC1379a3;
    }

    @Override // e8.InterfaceC0793e
    public final boolean a() {
        return this.f6989e != null;
    }

    @Override // e8.InterfaceC0793e
    public final Object getValue() {
        j0 j0Var = this.f6989e;
        if (j0Var != null) {
            return j0Var;
        }
        j0 j0VarV = new X0.m((q0) this.f6987b.invoke(), (n0) this.f6988c.invoke(), (AbstractC1194c) this.d.invoke()).v(D4.b.v(this.f6986a));
        this.f6989e = j0VarV;
        return j0VarV;
    }
}
