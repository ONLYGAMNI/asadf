package androidx.lifecycle;

import m0.C1196e;

/* loaded from: classes.dex */
public interface r {
    n0 c();

    C1196e d();
}
