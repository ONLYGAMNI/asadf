package androidx.lifecycle;

import s8.AbstractC1420h;

/* renamed from: androidx.lifecycle.t */
/* loaded from: classes.dex */
public final class C0422t {
    public static EnumC0424v a(EnumC0425w enumC0425w) {
        AbstractC1420h.f(enumC0425w, "state");
        int iOrdinal = enumC0425w.ordinal();
        if (iOrdinal == 2) {
            return EnumC0424v.ON_DESTROY;
        }
        if (iOrdinal == 3) {
            return EnumC0424v.ON_STOP;
        }
        if (iOrdinal != 4) {
            return null;
        }
        return EnumC0424v.ON_PAUSE;
    }

    public static EnumC0424v b(EnumC0425w enumC0425w) {
        AbstractC1420h.f(enumC0425w, "state");
        int iOrdinal = enumC0425w.ordinal();
        if (iOrdinal == 1) {
            return EnumC0424v.ON_CREATE;
        }
        if (iOrdinal == 2) {
            return EnumC0424v.ON_START;
        }
        if (iOrdinal != 3) {
            return null;
        }
        return EnumC0424v.ON_RESUME;
    }

    public static EnumC0424v c(EnumC0425w enumC0425w) {
        AbstractC1420h.f(enumC0425w, "state");
        int iOrdinal = enumC0425w.ordinal();
        if (iOrdinal == 2) {
            return EnumC0424v.ON_CREATE;
        }
        if (iOrdinal == 3) {
            return EnumC0424v.ON_START;
        }
        if (iOrdinal != 4) {
            return null;
        }
        return EnumC0424v.ON_RESUME;
    }
}
