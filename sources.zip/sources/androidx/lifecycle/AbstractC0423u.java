package androidx.lifecycle;

/* renamed from: androidx.lifecycle.u */
/* loaded from: classes.dex */
public abstract /* synthetic */ class AbstractC0423u {

    /* renamed from: a */
    public static final /* synthetic */ int[] f7002a;

    static {
        int[] iArr = new int[EnumC0424v.values().length];
        try {
            iArr[EnumC0424v.ON_CREATE.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr[EnumC0424v.ON_STOP.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr[EnumC0424v.ON_START.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr[EnumC0424v.ON_PAUSE.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr[EnumC0424v.ON_RESUME.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            iArr[EnumC0424v.ON_DESTROY.ordinal()] = 6;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            iArr[EnumC0424v.ON_ANY.ordinal()] = 7;
        } catch (NoSuchFieldError unused7) {
        }
        f7002a = iArr;
    }
}
