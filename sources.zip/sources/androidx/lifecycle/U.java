package androidx.lifecycle;

import D.RunnableC0050a;
import android.os.Handler;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class U implements D {

    /* renamed from: p, reason: collision with root package name */
    public static final U f6919p = new U();

    /* renamed from: a, reason: collision with root package name */
    public int f6920a;

    /* renamed from: b, reason: collision with root package name */
    public int f6921b;

    /* renamed from: e, reason: collision with root package name */
    public Handler f6923e;

    /* renamed from: c, reason: collision with root package name */
    public boolean f6922c = true;
    public boolean d = true;

    /* renamed from: f, reason: collision with root package name */
    public final F f6924f = new F(this);

    /* renamed from: n, reason: collision with root package name */
    public final RunnableC0050a f6925n = new RunnableC0050a(this, 21);

    /* renamed from: o, reason: collision with root package name */
    public final B.b f6926o = new B.b(this, 19);

    public final void a() {
        int i10 = this.f6921b + 1;
        this.f6921b = i10;
        if (i10 == 1) {
            if (this.f6922c) {
                this.f6924f.e(EnumC0424v.ON_RESUME);
                this.f6922c = false;
            } else {
                Handler handler = this.f6923e;
                AbstractC1420h.c(handler);
                handler.removeCallbacks(this.f6925n);
            }
        }
    }

    @Override // androidx.lifecycle.D
    public final F h() {
        return this.f6924f;
    }
}
