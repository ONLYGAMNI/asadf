package androidx.lifecycle;

/* loaded from: classes.dex */
public abstract class J {

    /* renamed from: a, reason: collision with root package name */
    public final O f6884a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f6885b;

    /* renamed from: c, reason: collision with root package name */
    public int f6886c = -1;
    public final /* synthetic */ K d;

    public J(K k10, O o9) {
        this.d = k10;
        this.f6884a = o9;
    }

    public final void b(boolean z3) {
        if (z3 == this.f6885b) {
            return;
        }
        this.f6885b = z3;
        int i10 = z3 ? 1 : -1;
        K k10 = this.d;
        int i11 = k10.f6890c;
        k10.f6890c = i10 + i11;
        if (!k10.d) {
            k10.d = true;
            while (true) {
                try {
                    int i12 = k10.f6890c;
                    if (i11 == i12) {
                        break;
                    }
                    boolean z9 = i11 == 0 && i12 > 0;
                    boolean z10 = i11 > 0 && i12 == 0;
                    if (z9) {
                        k10.g();
                    } else if (z10) {
                        k10.h();
                    }
                    i11 = i12;
                } catch (Throwable th) {
                    k10.d = false;
                    throw th;
                }
            }
            k10.d = false;
        }
        if (this.f6885b) {
            k10.c(this);
        }
    }

    public void f() {
    }

    public boolean g(D d) {
        return false;
    }

    public abstract boolean h();
}
