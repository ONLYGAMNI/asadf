package androidx.lifecycle;

import android.os.Bundle;
import e8.C0799k;
import java.util.Map;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class f0 implements C0.d {

    /* renamed from: a, reason: collision with root package name */
    public final C0.e f6965a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f6966b;

    /* renamed from: c, reason: collision with root package name */
    public Bundle f6967c;
    public final C0799k d;

    public f0(C0.e eVar, r0 r0Var) {
        AbstractC1420h.f(eVar, "savedStateRegistry");
        AbstractC1420h.f(r0Var, "viewModelStoreOwner");
        this.f6965a = eVar;
        this.d = com.bumptech.glide.d.u(new E0.g(r0Var, 5));
    }

    @Override // C0.d
    public final Bundle a() {
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f6967c;
        if (bundle2 != null) {
            bundle.putAll(bundle2);
        }
        for (Map.Entry entry : ((g0) this.d.getValue()).f6970a.entrySet()) {
            String str = (String) entry.getKey();
            Bundle bundleA = ((c0) entry.getValue()).f6950e.a();
            if (!AbstractC1420h.a(bundleA, Bundle.EMPTY)) {
                bundle.putBundle(str, bundleA);
            }
        }
        this.f6966b = false;
        return bundle;
    }
}
