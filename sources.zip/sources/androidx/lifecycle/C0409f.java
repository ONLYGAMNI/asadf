package androidx.lifecycle;

import C8.C0;
import C8.InterfaceC0033j0;
import r8.InterfaceC1379a;

/* renamed from: androidx.lifecycle.f */
/* loaded from: classes.dex */
public final class C0409f {

    /* renamed from: a */
    public final C0415l f6960a;

    /* renamed from: b */
    public final r8.p f6961b;

    /* renamed from: c */
    public final long f6962c;
    public final C8.G d;

    /* renamed from: e */
    public final InterfaceC1379a f6963e;

    /* renamed from: f */
    public InterfaceC0033j0 f6964f;
    public C0 g;

    public C0409f(C0415l c0415l, C0419p c0419p, long j10, B1.a aVar, E0.g gVar) {
        this.f6960a = c0415l;
        this.f6961b = c0419p;
        this.f6962c = j10;
        this.d = aVar;
        this.f6963e = gVar;
    }
}
