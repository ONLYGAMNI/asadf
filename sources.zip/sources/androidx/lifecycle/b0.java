package androidx.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class b0 extends Fragment {

    /* renamed from: b */
    public static final /* synthetic */ int f6944b = 0;

    /* renamed from: a */
    public B.b f6945a;

    public final void a(EnumC0424v enumC0424v) {
        if (Build.VERSION.SDK_INT < 29) {
            Activity activity = getActivity();
            AbstractC1420h.e(activity, "activity");
            e0.f(activity, enumC0424v);
        }
    }

    @Override // android.app.Fragment
    public final void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        a(EnumC0424v.ON_CREATE);
    }

    @Override // android.app.Fragment
    public final void onDestroy() {
        super.onDestroy();
        a(EnumC0424v.ON_DESTROY);
        this.f6945a = null;
    }

    @Override // android.app.Fragment
    public final void onPause() {
        super.onPause();
        a(EnumC0424v.ON_PAUSE);
    }

    @Override // android.app.Fragment
    public final void onResume() {
        super.onResume();
        B.b bVar = this.f6945a;
        if (bVar != null) {
            ((U) bVar.f65b).a();
        }
        a(EnumC0424v.ON_RESUME);
    }

    @Override // android.app.Fragment
    public final void onStart() {
        super.onStart();
        B.b bVar = this.f6945a;
        if (bVar != null) {
            U u7 = (U) bVar.f65b;
            int i10 = u7.f6920a + 1;
            u7.f6920a = i10;
            if (i10 == 1 && u7.d) {
                u7.f6924f.e(EnumC0424v.ON_START);
                u7.d = false;
            }
        }
        a(EnumC0424v.ON_START);
    }

    @Override // android.app.Fragment
    public final void onStop() {
        super.onStop();
        a(EnumC0424v.ON_STOP);
    }
}
