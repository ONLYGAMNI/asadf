package androidx.lifecycle;

/* renamed from: androidx.lifecycle.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0416m extends C {
    void a(D d);

    void c(D d);

    void e(D d);

    void onDestroy(D d);

    void onStart(D d);

    void onStop(D d);
}
