package androidx.lifecycle;

import m0.AbstractC1194c;

/* loaded from: classes.dex */
public interface n0 {
    j0 create(Class cls);

    j0 create(Class cls, AbstractC1194c abstractC1194c);
}
