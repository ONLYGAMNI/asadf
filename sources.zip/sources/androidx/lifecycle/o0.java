package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import m0.AbstractC1194c;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public class o0 implements n0 {

    /* renamed from: a, reason: collision with root package name */
    public static o0 f6997a;

    @Override // androidx.lifecycle.n0
    public j0 create(Class cls, AbstractC1194c abstractC1194c) {
        return create(cls);
    }

    @Override // androidx.lifecycle.n0
    public j0 create(Class cls) throws IllegalAccessException, InstantiationException, IllegalArgumentException, InvocationTargetException {
        try {
            Object objNewInstance = cls.getDeclaredConstructor(null).newInstance(null);
            AbstractC1420h.e(objNewInstance, "{\n                modelC…wInstance()\n            }");
            return (j0) objNewInstance;
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("Cannot create an instance of " + cls, e4);
        } catch (InstantiationException e5) {
            throw new RuntimeException("Cannot create an instance of " + cls, e5);
        } catch (NoSuchMethodException e10) {
            throw new RuntimeException("Cannot create an instance of " + cls, e10);
        }
    }
}
