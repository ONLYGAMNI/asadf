package androidx.lifecycle;

/* loaded from: classes.dex */
public interface B extends C {
    void d(D d, EnumC0424v enumC0424v);
}
