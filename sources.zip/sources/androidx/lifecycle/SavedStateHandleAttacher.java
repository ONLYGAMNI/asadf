package androidx.lifecycle;

/* loaded from: classes.dex */
public final class SavedStateHandleAttacher implements B {

    /* renamed from: a, reason: collision with root package name */
    public final f0 f6915a;

    public SavedStateHandleAttacher(f0 f0Var) {
        this.f6915a = f0Var;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        if (enumC0424v != EnumC0424v.ON_CREATE) {
            throw new IllegalStateException(("Next event must be ON_CREATE, it was " + enumC0424v).toString());
        }
        d.h().b(this);
        f0 f0Var = this.f6915a;
        if (f0Var.f6966b) {
            return;
        }
        f0Var.f6967c = f0Var.f6965a.a("androidx.lifecycle.internal.SavedStateHandlesProvider");
        f0Var.f6966b = true;
    }
}
