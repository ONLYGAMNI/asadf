package androidx.lifecycle;

import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class SavedStateHandleController implements B {

    /* renamed from: a */
    public final String f6916a;

    /* renamed from: b */
    public final c0 f6917b;

    /* renamed from: c */
    public boolean f6918c;

    public SavedStateHandleController(String str, c0 c0Var) {
        this.f6916a = str;
        this.f6917b = c0Var;
    }

    public final void b(C0.e eVar, AbstractC0426x abstractC0426x) {
        AbstractC1420h.f(eVar, "registry");
        AbstractC1420h.f(abstractC0426x, "lifecycle");
        if (!(!this.f6918c)) {
            throw new IllegalStateException("Already attached to lifecycleOwner".toString());
        }
        this.f6918c = true;
        abstractC0426x.a(this);
        eVar.c(this.f6916a, this.f6917b.f6950e);
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        if (enumC0424v == EnumC0424v.ON_DESTROY) {
            this.f6918c = false;
            d.h().b(this);
        }
    }
}
