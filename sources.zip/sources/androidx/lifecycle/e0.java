package androidx.lifecycle;

import C8.D0;
import F8.InterfaceC0112b;
import android.app.Activity;
import android.app.FragmentManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import com.tajir.tajir.R;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicReference;
import m.C1189b;
import m0.AbstractC1194c;
import m0.C1195d;
import m0.C1197f;
import n.C1242f;
import s8.AbstractC1420h;
import s8.AbstractC1432t;

/* loaded from: classes.dex */
public abstract class e0 {

    /* renamed from: a */
    public static final l0 f6957a = new l0();

    /* renamed from: b */
    public static final l0 f6958b = new l0();

    /* renamed from: c */
    public static final l0 f6959c = new l0();

    public static C0415l a(InterfaceC0112b interfaceC0112b) {
        i8.j jVar = i8.j.f11298a;
        AbstractC1420h.f(interfaceC0112b, "<this>");
        C0419p c0419p = new C0419p(interfaceC0112b, null);
        C0415l c0415l = new C0415l();
        c0415l.f6990l = new C1242f();
        D0 d02 = new D0(null);
        J8.d dVar = C8.Q.f295a;
        D8.e eVar = H8.m.f1642a.f604f;
        eVar.getClass();
        c0415l.f6991m = new C0409f(c0415l, c0419p, 5000L, C8.I.b(C3.f.t(eVar, jVar).plus(d02)), new E0.g(c0415l, 4));
        if (interfaceC0112b instanceof F8.B) {
            if (C1189b.A().B()) {
                c0415l.k(((F8.B) interfaceC0112b).getValue());
            } else {
                c0415l.i(((F8.B) interfaceC0112b).getValue());
            }
        }
        return c0415l;
    }

    public static final void b(j0 j0Var, C0.e eVar, AbstractC0426x abstractC0426x) throws NoSuchMethodException, SecurityException {
        AbstractC1420h.f(j0Var, "viewModel");
        AbstractC1420h.f(eVar, "registry");
        AbstractC1420h.f(abstractC0426x, "lifecycle");
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) j0Var.getTag(AbstractC0405b.TAG_SAVED_STATE_HANDLE_CONTROLLER);
        if (savedStateHandleController == null || savedStateHandleController.f6918c) {
            return;
        }
        savedStateHandleController.b(eVar, abstractC0426x);
        m(eVar, abstractC0426x);
    }

    public static final SavedStateHandleController c(C0.e eVar, AbstractC0426x abstractC0426x, String str, Bundle bundle) throws NoSuchMethodException, SecurityException {
        AbstractC1420h.f(eVar, "registry");
        AbstractC1420h.f(abstractC0426x, "lifecycle");
        Bundle bundleA = eVar.a(str);
        Class[] clsArr = c0.f6946f;
        SavedStateHandleController savedStateHandleController = new SavedStateHandleController(str, d(bundleA, bundle));
        savedStateHandleController.b(eVar, abstractC0426x);
        m(eVar, abstractC0426x);
        return savedStateHandleController;
    }

    public static c0 d(Bundle bundle, Bundle bundle2) {
        if (bundle == null) {
            if (bundle2 == null) {
                return new c0();
            }
            HashMap map = new HashMap();
            for (String str : bundle2.keySet()) {
                AbstractC1420h.e(str, "key");
                map.put(str, bundle2.get(str));
            }
            return new c0(map);
        }
        ArrayList parcelableArrayList = bundle.getParcelableArrayList("keys");
        ArrayList parcelableArrayList2 = bundle.getParcelableArrayList("values");
        if (parcelableArrayList == null || parcelableArrayList2 == null || parcelableArrayList.size() != parcelableArrayList2.size()) {
            throw new IllegalStateException("Invalid bundle passed as restored state".toString());
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        int size = parcelableArrayList.size();
        for (int i10 = 0; i10 < size; i10++) {
            Object obj = parcelableArrayList.get(i10);
            AbstractC1420h.d(obj, "null cannot be cast to non-null type kotlin.String");
            linkedHashMap.put((String) obj, parcelableArrayList2.get(i10));
        }
        return new c0(linkedHashMap);
    }

    public static final c0 e(AbstractC1194c abstractC1194c) {
        AbstractC1420h.f(abstractC1194c, "<this>");
        C0.f fVar = (C0.f) abstractC1194c.a(f6957a);
        if (fVar == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `SAVED_STATE_REGISTRY_OWNER_KEY`");
        }
        r0 r0Var = (r0) abstractC1194c.a(f6958b);
        if (r0Var == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_STORE_OWNER_KEY`");
        }
        Bundle bundle = (Bundle) abstractC1194c.a(f6959c);
        String str = (String) abstractC1194c.a(l0.f6993b);
        if (str == null) {
            throw new IllegalArgumentException("CreationExtras must have a value by `VIEW_MODEL_KEY`");
        }
        C0.d dVarB = fVar.b().b();
        f0 f0Var = dVarB instanceof f0 ? (f0) dVarB : null;
        if (f0Var == null) {
            throw new IllegalStateException("enableSavedStateHandles() wasn't called prior to createSavedStateHandle() call");
        }
        LinkedHashMap linkedHashMap = i(r0Var).f6970a;
        c0 c0Var = (c0) linkedHashMap.get(str);
        if (c0Var != null) {
            return c0Var;
        }
        Class[] clsArr = c0.f6946f;
        if (!f0Var.f6966b) {
            f0Var.f6967c = f0Var.f6965a.a("androidx.lifecycle.internal.SavedStateHandlesProvider");
            f0Var.f6966b = true;
        }
        Bundle bundle2 = f0Var.f6967c;
        Bundle bundle3 = bundle2 != null ? bundle2.getBundle(str) : null;
        Bundle bundle4 = f0Var.f6967c;
        if (bundle4 != null) {
            bundle4.remove(str);
        }
        Bundle bundle5 = f0Var.f6967c;
        if (bundle5 != null && bundle5.isEmpty()) {
            f0Var.f6967c = null;
        }
        c0 c0VarD = d(bundle3, bundle);
        linkedHashMap.put(str, c0VarD);
        return c0VarD;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void f(Activity activity, EnumC0424v enumC0424v) {
        AbstractC1420h.f(activity, "activity");
        AbstractC1420h.f(enumC0424v, "event");
        if (activity instanceof D) {
            F fH = ((D) activity).h();
            if (fH instanceof F) {
                fH.e(enumC0424v);
            }
        }
    }

    public static final void g(C0.f fVar) {
        AbstractC1420h.f(fVar, "<this>");
        EnumC0425w enumC0425w = fVar.h().d;
        if (enumC0425w != EnumC0425w.f7004b && enumC0425w != EnumC0425w.f7005c) {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
        if (fVar.b().b() == null) {
            f0 f0Var = new f0(fVar.b(), (r0) fVar);
            fVar.b().c("androidx.lifecycle.internal.SavedStateHandlesProvider", f0Var);
            fVar.h().a(new SavedStateHandleAttacher(f0Var));
        }
    }

    public static final LifecycleCoroutineScopeImpl h(D d) {
        LifecycleCoroutineScopeImpl lifecycleCoroutineScopeImpl;
        AbstractC1420h.f(d, "<this>");
        F fH = d.h();
        AbstractC1420h.f(fH, "<this>");
        loop0: while (true) {
            AtomicReference atomicReference = fH.f7008a;
            lifecycleCoroutineScopeImpl = (LifecycleCoroutineScopeImpl) atomicReference.get();
            if (lifecycleCoroutineScopeImpl == null) {
                D0 d0D = C8.I.d();
                J8.d dVar = C8.Q.f295a;
                lifecycleCoroutineScopeImpl = new LifecycleCoroutineScopeImpl(fH, C3.f.t(d0D, H8.m.f1642a.f604f));
                while (!atomicReference.compareAndSet(null, lifecycleCoroutineScopeImpl)) {
                    if (atomicReference.get() != null) {
                        break;
                    }
                }
                J8.d dVar2 = C8.Q.f295a;
                C8.I.v(lifecycleCoroutineScopeImpl, H8.m.f1642a.f604f, new C0427y(lifecycleCoroutineScopeImpl, null), 2);
                break loop0;
            }
            break;
        }
        return lifecycleCoroutineScopeImpl;
    }

    public static final g0 i(r0 r0Var) {
        AbstractC1420h.f(r0Var, "<this>");
        ArrayList arrayList = new ArrayList();
        arrayList.add(new C1197f(D4.b.v(AbstractC1432t.a(g0.class)), d0.f6953a));
        C1197f[] c1197fArr = (C1197f[]) arrayList.toArray(new C1197f[0]);
        return (g0) new X0.m(r0Var, new C1195d((C1197f[]) Arrays.copyOf(c1197fArr, c1197fArr.length))).w(g0.class, "androidx.lifecycle.internal.SavedStateHandlesVM");
    }

    public static final C8.G j(j0 j0Var) throws IOException {
        AbstractC1420h.f(j0Var, "<this>");
        C8.G g = (C8.G) j0Var.getTag("androidx.lifecycle.ViewModelCoroutineScope.JOB_KEY");
        if (g != null) {
            return g;
        }
        D0 d0D = C8.I.d();
        J8.d dVar = C8.Q.f295a;
        Object tagIfAbsent = j0Var.setTagIfAbsent("androidx.lifecycle.ViewModelCoroutineScope.JOB_KEY", new C0413j(C3.f.t(d0D, H8.m.f1642a.f604f)));
        AbstractC1420h.e(tagIfAbsent, "setTagIfAbsent(\n        …Main.immediate)\n        )");
        return (C8.G) tagIfAbsent;
    }

    public static void k(Activity activity) {
        AbstractC1420h.f(activity, "activity");
        if (Build.VERSION.SDK_INT >= 29) {
            a0.Companion.getClass();
            activity.registerActivityLifecycleCallbacks(new a0());
        }
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new b0(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    public static final void l(View view, D d) {
        AbstractC1420h.f(view, "<this>");
        view.setTag(R.id.view_tree_lifecycle_owner, d);
    }

    public static void m(final C0.e eVar, final AbstractC0426x abstractC0426x) throws NoSuchMethodException, SecurityException {
        EnumC0425w enumC0425w = ((F) abstractC0426x).d;
        if (enumC0425w == EnumC0425w.f7004b || enumC0425w.compareTo(EnumC0425w.d) >= 0) {
            eVar.d();
        } else {
            abstractC0426x.a(new B() { // from class: androidx.lifecycle.LegacySavedStateHandleController$tryToAddRecreator$1
                @Override // androidx.lifecycle.B
                public final void d(D d, EnumC0424v enumC0424v) throws NoSuchMethodException, SecurityException {
                    if (enumC0424v == EnumC0424v.ON_START) {
                        abstractC0426x.b(this);
                        eVar.d();
                    }
                }
            });
        }
    }
}
