package androidx.lifecycle;

import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* loaded from: classes.dex */
public final class V extends AbstractC1113j implements r8.p {

    /* renamed from: a, reason: collision with root package name */
    public int f6927a;

    /* renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f6928b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ r8.p f6929c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public V(r8.p pVar, i8.d dVar) {
        super(2, dVar);
        this.f6929c = pVar;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        V v9 = new V(this.f6929c, dVar);
        v9.f6928b = obj;
        return v9;
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((V) create((C8.G) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        int i10 = this.f6927a;
        if (i10 == 0) {
            f9.d.x(obj);
            C8.G g = (C8.G) this.f6928b;
            this.f6927a = 1;
            if (this.f6929c.invoke(g, this) == enumC1073a) {
                return enumC1073a;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            f9.d.x(obj);
        }
        return C0803o.f10326a;
    }
}
