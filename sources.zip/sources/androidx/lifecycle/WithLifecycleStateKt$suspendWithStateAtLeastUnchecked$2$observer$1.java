package androidx.lifecycle;

/* loaded from: classes.dex */
public final class WithLifecycleStateKt$suspendWithStateAtLeastUnchecked$2$observer$1 implements B {
    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        EnumC0424v.Companion.getClass();
        C0422t.c(null);
        throw null;
    }
}
