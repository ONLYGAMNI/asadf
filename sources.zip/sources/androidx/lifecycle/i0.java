package androidx.lifecycle;

import android.app.Application;
import f8.AbstractC0841i;
import f8.AbstractC0843k;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class i0 {

    /* renamed from: a, reason: collision with root package name */
    public static final List f6980a = AbstractC0843k.O(Application.class, c0.class);

    /* renamed from: b, reason: collision with root package name */
    public static final List f6981b = E4.b.v(c0.class);

    public static final Constructor a(List list, Class cls) throws SecurityException {
        AbstractC1420h.f(list, "signature");
        Constructor<?>[] constructors = cls.getConstructors();
        AbstractC1420h.e(constructors, "modelClass.constructors");
        for (Constructor<?> constructor : constructors) {
            Class<?>[] parameterTypes = constructor.getParameterTypes();
            AbstractC1420h.e(parameterTypes, "constructor.parameterTypes");
            List listF0 = AbstractC0841i.f0(parameterTypes);
            if (list.equals(listF0)) {
                return constructor;
            }
            if (list.size() == listF0.size() && listF0.containsAll(list)) {
                throw new UnsupportedOperationException("Class " + cls.getSimpleName() + " must have parameters in the proper order: " + list);
            }
        }
        return null;
    }

    public static final j0 b(Class cls, Constructor constructor, Object... objArr) {
        try {
            return (j0) constructor.newInstance(Arrays.copyOf(objArr, objArr.length));
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("Failed to access " + cls, e4);
        } catch (InstantiationException e5) {
            throw new RuntimeException("A " + cls + " cannot be instantiated.", e5);
        } catch (InvocationTargetException e10) {
            throw new RuntimeException("An exception happened in constructor of " + cls, e10.getCause());
        }
    }
}
