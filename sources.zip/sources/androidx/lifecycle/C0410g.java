package androidx.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* renamed from: androidx.lifecycle.g, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0410g {

    /* renamed from: a, reason: collision with root package name */
    public final HashMap f6968a = new HashMap();

    /* renamed from: b, reason: collision with root package name */
    public final Map f6969b;

    public C0410g(HashMap map) {
        this.f6969b = map;
        for (Map.Entry entry : map.entrySet()) {
            EnumC0424v enumC0424v = (EnumC0424v) entry.getValue();
            List arrayList = (List) this.f6968a.get(enumC0424v);
            if (arrayList == null) {
                arrayList = new ArrayList();
                this.f6968a.put(enumC0424v, arrayList);
            }
            arrayList.add((C0411h) entry.getKey());
        }
    }

    public static void a(List list, D d, EnumC0424v enumC0424v, Object obj) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                C0411h c0411h = (C0411h) list.get(size);
                c0411h.getClass();
                try {
                    int i10 = c0411h.f6971a;
                    Method method = c0411h.f6972b;
                    if (i10 == 0) {
                        method.invoke(obj, null);
                    } else if (i10 == 1) {
                        method.invoke(obj, d);
                    } else if (i10 == 2) {
                        method.invoke(obj, d, enumC0424v);
                    }
                } catch (IllegalAccessException e4) {
                    throw new RuntimeException(e4);
                } catch (InvocationTargetException e5) {
                    throw new RuntimeException("Failed to call observer method", e5.getCause());
                }
            }
        }
    }
}
