package androidx.lifecycle;

import C8.C0;
import java.util.Map;
import n.C1238b;
import n.C1242f;

/* renamed from: androidx.lifecycle.l, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0415l extends N {

    /* renamed from: l, reason: collision with root package name */
    public C1242f f6990l;

    /* renamed from: m, reason: collision with root package name */
    public C0409f f6991m;

    @Override // androidx.lifecycle.K
    public final void g() {
        C1238b c1238b = (C1238b) this.f6990l.iterator();
        if (c1238b.hasNext()) {
            android.support.v4.media.session.a.u(((Map.Entry) c1238b.next()).getValue());
            throw null;
        }
        C0409f c0409f = this.f6991m;
        if (c0409f != null) {
            C0 c0 = c0409f.g;
            if (c0 != null) {
                c0.cancel(null);
            }
            c0409f.g = null;
            if (c0409f.f6964f != null) {
                return;
            }
            c0409f.f6964f = C8.I.v(c0409f.d, null, new C0408e(c0409f, null), 3);
        }
    }

    @Override // androidx.lifecycle.K
    public final void h() {
        C1238b c1238b = (C1238b) this.f6990l.iterator();
        if (c1238b.hasNext()) {
            android.support.v4.media.session.a.u(((Map.Entry) c1238b.next()).getValue());
            throw null;
        }
        C0409f c0409f = this.f6991m;
        if (c0409f != null) {
            if (c0409f.g != null) {
                throw new IllegalStateException("Cancel call cannot happen without a maybeRun".toString());
            }
            J8.d dVar = C8.Q.f295a;
            c0409f.g = C8.I.v(c0409f.d, H8.m.f1642a.f604f, new C0407d(c0409f, null), 2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x0013  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void l(i8.d r5) {
        /*
            r4 = this;
            boolean r0 = r5 instanceof androidx.lifecycle.C0414k
            if (r0 == 0) goto L13
            r0 = r5
            androidx.lifecycle.k r0 = (androidx.lifecycle.C0414k) r0
            int r1 = r0.f6985c
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = r1 & r2
            if (r3 == 0) goto L13
            int r1 = r1 - r2
            r0.f6985c = r1
            goto L18
        L13:
            androidx.lifecycle.k r0 = new androidx.lifecycle.k
            r0.<init>(r4, r5)
        L18:
            java.lang.Object r5 = r0.f6983a
            j8.a r1 = j8.EnumC1073a.f11857a
            int r0 = r0.f6985c
            if (r0 == 0) goto L30
            r1 = 1
            if (r0 != r1) goto L28
            f9.d.x(r5)
            r5 = 0
            goto L34
        L28:
            java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r5.<init>(r0)
            throw r5
        L30:
            f9.d.x(r5)
            r5 = r4
        L34:
            r5.getClass()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.lifecycle.C0415l.l(i8.d):void");
    }
}
