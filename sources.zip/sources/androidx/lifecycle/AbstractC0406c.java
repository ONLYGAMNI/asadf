package androidx.lifecycle;

import android.app.Application;
import s8.AbstractC1420h;

/* renamed from: androidx.lifecycle.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0406c extends j0 {
    private final Application application;

    public AbstractC0406c(Application application) {
        AbstractC1420h.f(application, "application");
        this.application = application;
    }

    public <T extends Application> T getApplication() {
        T t9 = (T) this.application;
        AbstractC1420h.d(t9, "null cannot be cast to non-null type T of androidx.lifecycle.AndroidViewModel.getApplication");
        return t9;
    }
}
