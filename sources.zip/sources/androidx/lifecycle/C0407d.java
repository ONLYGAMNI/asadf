package androidx.lifecycle;

import C8.InterfaceC0033j0;
import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* renamed from: androidx.lifecycle.d */
/* loaded from: classes.dex */
public final class C0407d extends AbstractC1113j implements r8.p {

    /* renamed from: a */
    public int f6951a;

    /* renamed from: b */
    public final /* synthetic */ C0409f f6952b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0407d(C0409f c0409f, i8.d dVar) {
        super(2, dVar);
        this.f6952b = c0409f;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        return new C0407d(this.f6952b, dVar);
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C0407d) create((C8.G) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        int i10 = this.f6951a;
        C0409f c0409f = this.f6952b;
        if (i10 == 0) {
            f9.d.x(obj);
            long j10 = c0409f.f6962c;
            this.f6951a = 1;
            if (C8.I.i(j10, this) == enumC1073a) {
                return enumC1073a;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            f9.d.x(obj);
        }
        if (c0409f.f6960a.f6890c <= 0) {
            InterfaceC0033j0 interfaceC0033j0 = c0409f.f6964f;
            if (interfaceC0033j0 != null) {
                interfaceC0033j0.cancel(null);
            }
            c0409f.f6964f = null;
        }
        return C0803o.f10326a;
    }
}
