package androidx.lifecycle;

import m0.AbstractC1194c;
import s8.AbstractC1420h;
import s8.AbstractC1421i;

/* loaded from: classes.dex */
public final class d0 extends AbstractC1421i implements r8.l {

    /* renamed from: a, reason: collision with root package name */
    public static final d0 f6953a = new d0(1);

    @Override // r8.l
    public final Object invoke(Object obj) {
        AbstractC1420h.f((AbstractC1194c) obj, "$this$initializer");
        return new g0();
    }
}
