package androidx.lifecycle;

import java.util.Iterator;
import java.util.LinkedHashMap;

/* loaded from: classes.dex */
public final class q0 {

    /* renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f7001a = new LinkedHashMap();

    public final void a() {
        LinkedHashMap linkedHashMap = this.f7001a;
        Iterator it = linkedHashMap.values().iterator();
        while (it.hasNext()) {
            ((j0) it.next()).clear();
        }
        linkedHashMap.clear();
    }
}
