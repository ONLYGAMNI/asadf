package androidx.lifecycle;

import android.app.Activity;
import android.os.Bundle;
import s8.AbstractC1420h;

/* renamed from: androidx.lifecycle.z, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0428z extends AbstractC0418o {
    @Override // androidx.lifecycle.AbstractC0418o, android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        AbstractC1420h.f(activity, "activity");
        int i10 = b0.f6944b;
        e0.k(activity);
    }
}
