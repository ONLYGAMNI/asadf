package androidx.lifecycle;

/* loaded from: classes.dex */
class LiveData$LifecycleBoundObserver extends J implements B {

    /* renamed from: e, reason: collision with root package name */
    public final D f6903e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ K f6904f;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public LiveData$LifecycleBoundObserver(K k10, D d, O o9) {
        super(k10, o9);
        this.f6904f = k10;
        this.f6903e = d;
    }

    @Override // androidx.lifecycle.B
    public final void d(D d, EnumC0424v enumC0424v) {
        D d10 = this.f6903e;
        EnumC0425w enumC0425w = d10.h().d;
        if (enumC0425w == EnumC0425w.f7003a) {
            this.f6904f.j(this.f6884a);
            return;
        }
        EnumC0425w enumC0425w2 = null;
        while (enumC0425w2 != enumC0425w) {
            b(h());
            enumC0425w2 = enumC0425w;
            enumC0425w = d10.h().d;
        }
    }

    @Override // androidx.lifecycle.J
    public final void f() {
        this.f6903e.h().b(this);
    }

    @Override // androidx.lifecycle.J
    public final boolean g(D d) {
        return this.f6903e == d;
    }

    @Override // androidx.lifecycle.J
    public final boolean h() {
        return this.f6903e.h().d.compareTo(EnumC0425w.d) >= 0;
    }
}
