package androidx.lifecycle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public abstract class G extends Service implements D {

    /* renamed from: a */
    public final X0.m f6881a = new X0.m(this);

    @Override // androidx.lifecycle.D
    public final F h() {
        return (F) this.f6881a.f5323b;
    }

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        AbstractC1420h.f(intent, "intent");
        this.f6881a.D(EnumC0424v.ON_START);
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        this.f6881a.D(EnumC0424v.ON_CREATE);
        super.onCreate();
    }

    @Override // android.app.Service
    public void onDestroy() {
        EnumC0424v enumC0424v = EnumC0424v.ON_STOP;
        X0.m mVar = this.f6881a;
        mVar.D(enumC0424v);
        mVar.D(EnumC0424v.ON_DESTROY);
        super.onDestroy();
    }

    @Override // android.app.Service
    public final void onStart(Intent intent, int i10) {
        this.f6881a.D(EnumC0424v.ON_START);
        super.onStart(intent, i10);
    }
}
