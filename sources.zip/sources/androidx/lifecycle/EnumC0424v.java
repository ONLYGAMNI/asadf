package androidx.lifecycle;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* renamed from: androidx.lifecycle.v, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0424v {
    private static final /* synthetic */ EnumC0424v[] $VALUES;
    public static final C0422t Companion;
    public static final EnumC0424v ON_ANY;
    public static final EnumC0424v ON_CREATE;
    public static final EnumC0424v ON_DESTROY;
    public static final EnumC0424v ON_PAUSE;
    public static final EnumC0424v ON_RESUME;
    public static final EnumC0424v ON_START;
    public static final EnumC0424v ON_STOP;

    static {
        EnumC0424v enumC0424v = new EnumC0424v("ON_CREATE", 0);
        ON_CREATE = enumC0424v;
        EnumC0424v enumC0424v2 = new EnumC0424v("ON_START", 1);
        ON_START = enumC0424v2;
        EnumC0424v enumC0424v3 = new EnumC0424v("ON_RESUME", 2);
        ON_RESUME = enumC0424v3;
        EnumC0424v enumC0424v4 = new EnumC0424v("ON_PAUSE", 3);
        ON_PAUSE = enumC0424v4;
        EnumC0424v enumC0424v5 = new EnumC0424v("ON_STOP", 4);
        ON_STOP = enumC0424v5;
        EnumC0424v enumC0424v6 = new EnumC0424v("ON_DESTROY", 5);
        ON_DESTROY = enumC0424v6;
        EnumC0424v enumC0424v7 = new EnumC0424v("ON_ANY", 6);
        ON_ANY = enumC0424v7;
        $VALUES = new EnumC0424v[]{enumC0424v, enumC0424v2, enumC0424v3, enumC0424v4, enumC0424v5, enumC0424v6, enumC0424v7};
        Companion = new C0422t();
    }

    public static EnumC0424v valueOf(String str) {
        return (EnumC0424v) Enum.valueOf(EnumC0424v.class, str);
    }

    public static EnumC0424v[] values() {
        return (EnumC0424v[]) $VALUES.clone();
    }

    public final EnumC0425w a() {
        switch (AbstractC0423u.f7002a[ordinal()]) {
            case 1:
            case 2:
                return EnumC0425w.f7005c;
            case 3:
            case 4:
                return EnumC0425w.d;
            case 5:
                return EnumC0425w.f7006e;
            case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                return EnumC0425w.f7003a;
            default:
                throw new IllegalArgumentException(this + " has no target state");
        }
    }
}
