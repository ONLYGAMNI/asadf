package androidx.lifecycle;

import android.app.Application;
import android.content.Context;
import android.os.Handler;
import f8.C0851s;
import java.util.List;
import s8.AbstractC1420h;

/* loaded from: classes.dex */
public final class ProcessLifecycleInitializer implements G0.b {
    @Override // G0.b
    public final List a() {
        return C0851s.f10627a;
    }

    @Override // G0.b
    public final Object b(Context context) {
        AbstractC1420h.f(context, "context");
        G0.a aVarC = G0.a.c(context);
        AbstractC1420h.e(aVarC, "getInstance(context)");
        if (!aVarC.f1383b.contains(ProcessLifecycleInitializer.class)) {
            throw new IllegalStateException("ProcessLifecycleInitializer cannot be initialized lazily.\n               Please ensure that you have:\n               <meta-data\n                   android:name='androidx.lifecycle.ProcessLifecycleInitializer'\n                   android:value='androidx.startup' />\n               under InitializationProvider in your AndroidManifest.xml".toString());
        }
        if (!A.f6869a.getAndSet(true)) {
            Context applicationContext = context.getApplicationContext();
            AbstractC1420h.d(applicationContext, "null cannot be cast to non-null type android.app.Application");
            ((Application) applicationContext).registerActivityLifecycleCallbacks(new C0428z());
        }
        U u7 = U.f6919p;
        u7.getClass();
        u7.f6923e = new Handler();
        u7.f6924f.e(EnumC0424v.ON_CREATE);
        Context applicationContext2 = context.getApplicationContext();
        AbstractC1420h.d(applicationContext2, "null cannot be cast to non-null type android.app.Application");
        ((Application) applicationContext2).registerActivityLifecycleCallbacks(new T(u7));
        return u7;
    }
}
