package androidx.lifecycle;

import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public abstract class A {

    /* renamed from: a, reason: collision with root package name */
    public static final AtomicBoolean f6869a = new AtomicBoolean(false);
}
