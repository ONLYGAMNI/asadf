package androidx.lifecycle;

import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* loaded from: classes.dex */
public final class L extends AbstractC1113j implements r8.p {

    /* renamed from: a, reason: collision with root package name */
    public int f6896a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ M f6897b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f6898c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public L(M m9, Object obj, i8.d dVar) {
        super(2, dVar);
        this.f6897b = m9;
        this.f6898c = obj;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        return new L(this.f6897b, this.f6898c, dVar);
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((L) create((C8.G) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        int i10 = this.f6896a;
        C0803o c0803o = C0803o.f10326a;
        M m9 = this.f6897b;
        if (i10 == 0) {
            f9.d.x(obj);
            C0415l c0415l = m9.f6905a;
            this.f6896a = 1;
            c0415l.l(this);
            if (c0803o == enumC1073a) {
                return enumC1073a;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            f9.d.x(obj);
        }
        m9.f6905a.k(this.f6898c);
        return c0803o;
    }
}
