package androidx.lifecycle;

import F8.InterfaceC0112b;
import e8.C0803o;
import j8.EnumC1073a;
import k8.AbstractC1113j;

/* renamed from: androidx.lifecycle.p, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0419p extends AbstractC1113j implements r8.p {

    /* renamed from: a, reason: collision with root package name */
    public int f6998a;

    /* renamed from: b, reason: collision with root package name */
    public /* synthetic */ Object f6999b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ InterfaceC0112b f7000c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0419p(InterfaceC0112b interfaceC0112b, i8.d dVar) {
        super(2, dVar);
        this.f7000c = interfaceC0112b;
    }

    @Override // k8.AbstractC1104a
    public final i8.d create(Object obj, i8.d dVar) {
        C0419p c0419p = new C0419p(this.f7000c, dVar);
        c0419p.f6999b = obj;
        return c0419p;
    }

    @Override // r8.p
    public final Object invoke(Object obj, Object obj2) {
        return ((C0419p) create((M) obj, (i8.d) obj2)).invokeSuspend(C0803o.f10326a);
    }

    @Override // k8.AbstractC1104a
    public final Object invokeSuspend(Object obj) {
        EnumC1073a enumC1073a = EnumC1073a.f11857a;
        int i10 = this.f6998a;
        if (i10 == 0) {
            f9.d.x(obj);
            E6.s sVar = new E6.s((M) this.f6999b, 5);
            this.f6998a = 1;
            if (this.f7000c.k(sVar, this) == enumC1073a) {
                return enumC1073a;
            }
        } else {
            if (i10 != 1) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            f9.d.x(obj);
        }
        return C0803o.f10326a;
    }
}
