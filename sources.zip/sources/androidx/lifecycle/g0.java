package androidx.lifecycle;

import java.util.LinkedHashMap;

/* loaded from: classes.dex */
public final class g0 extends j0 {

    /* renamed from: a, reason: collision with root package name */
    public final LinkedHashMap f6970a = new LinkedHashMap();
}
