package androidx.datastore.core;

import java.io.IOException;

/* loaded from: classes.dex */
public final class CorruptionException extends IOException {
}
