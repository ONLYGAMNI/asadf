package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public abstract class L {

    /* renamed from: a, reason: collision with root package name */
    public static final K f6432a;

    /* renamed from: b, reason: collision with root package name */
    public static final K f6433b;

    static {
        K k10 = null;
        try {
            k10 = (K) Class.forName("androidx.datastore.preferences.protobuf.MapFieldSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f6432a = k10;
        f6433b = new K();
    }
}
