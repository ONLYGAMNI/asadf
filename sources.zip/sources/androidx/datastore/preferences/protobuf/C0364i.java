package androidx.datastore.preferences.protobuf;

import androidx.datastore.preferences.protobuf.InvalidProtocolBufferException;
import com.google.android.gms.dynamite.descriptors.com.google.firebase.auth.ModuleDescriptor;
import java.nio.charset.Charset;
import java.util.List;

/* renamed from: androidx.datastore.preferences.protobuf.i, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0364i implements Y {

    /* renamed from: a, reason: collision with root package name */
    public final R.C f6501a;

    /* renamed from: b, reason: collision with root package name */
    public int f6502b;

    /* renamed from: c, reason: collision with root package name */
    public int f6503c;
    public int d = 0;

    public C0364i(R.C c4) {
        Charset charset = AbstractC0379y.f6539a;
        this.f6501a = c4;
        c4.d = this;
    }

    public static void U(int i10) throws InvalidProtocolBufferException {
        if ((i10 & 3) != 0) {
            throw InvalidProtocolBufferException.e();
        }
    }

    public static void V(int i10) throws InvalidProtocolBufferException {
        if ((i10 & 7) != 0) {
            throw InvalidProtocolBufferException.e();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x005d, code lost:
    
        r10.put(r3, r5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x0060, code lost:
    
        r1.k(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0063, code lost:
    
        return;
     */
    @Override // androidx.datastore.preferences.protobuf.Y
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void A(androidx.datastore.preferences.protobuf.J r10, X0.i r11, androidx.datastore.preferences.protobuf.C0368m r12) throws androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException {
        /*
            r9 = this;
            r0 = 2
            r9.S(r0)
            R.C r1 = r9.f6501a
            int r2 = r1.C()
            int r2 = r1.l(r2)
            java.lang.Object r3 = r11.f5316c
            java.lang.Object r4 = r11.f5317e
            r5 = r4
        L13:
            int r6 = r9.q()     // Catch: java.lang.Throwable -> L37
            r7 = 2147483647(0x7fffffff, float:NaN)
            if (r6 == r7) goto L5d
            boolean r7 = r1.j()     // Catch: java.lang.Throwable -> L37
            if (r7 == 0) goto L23
            goto L5d
        L23:
            r7 = 1
            java.lang.String r8 = "Unable to parse map entry."
            if (r6 == r7) goto L46
            if (r6 == r0) goto L39
            boolean r6 = r9.T()     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            if (r6 == 0) goto L31
            goto L13
        L31:
            androidx.datastore.preferences.protobuf.InvalidProtocolBufferException r6 = new androidx.datastore.preferences.protobuf.InvalidProtocolBufferException     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            r6.<init>(r8)     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            throw r6     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
        L37:
            r10 = move-exception
            goto L64
        L39:
            java.lang.Object r6 = r11.d     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            androidx.datastore.preferences.protobuf.y0 r6 = (androidx.datastore.preferences.protobuf.y0) r6     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            java.lang.Class r7 = r4.getClass()     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            java.lang.Object r5 = r9.N(r6, r7, r12)     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            goto L13
        L46:
            java.lang.Object r6 = r11.f5315b     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            androidx.datastore.preferences.protobuf.y0 r6 = (androidx.datastore.preferences.protobuf.y0) r6     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            r7 = 0
            java.lang.Object r3 = r9.N(r6, r7, r7)     // Catch: java.lang.Throwable -> L37 androidx.datastore.preferences.protobuf.InvalidProtocolBufferException.InvalidWireTypeException -> L50
            goto L13
        L50:
            boolean r6 = r9.T()     // Catch: java.lang.Throwable -> L37
            if (r6 == 0) goto L57
            goto L13
        L57:
            androidx.datastore.preferences.protobuf.InvalidProtocolBufferException r10 = new androidx.datastore.preferences.protobuf.InvalidProtocolBufferException     // Catch: java.lang.Throwable -> L37
            r10.<init>(r8)     // Catch: java.lang.Throwable -> L37
            throw r10     // Catch: java.lang.Throwable -> L37
        L5d:
            r10.put(r3, r5)     // Catch: java.lang.Throwable -> L37
            r1.k(r2)
            return
        L64:
            r1.k(r2)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.C0364i.A(androidx.datastore.preferences.protobuf.J, X0.i, androidx.datastore.preferences.protobuf.m):void");
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int B() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(5);
        return this.f6501a.v();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void C(List list) throws InvalidProtocolBufferException.InvalidWireTypeException {
        int iB;
        if ((this.f6502b & 7) != 2) {
            throw InvalidProtocolBufferException.b();
        }
        do {
            list.add(v());
            R.C c4 = this.f6501a;
            if (c4.j()) {
                return;
            } else {
                iB = c4.B();
            }
        } while (iB == this.f6502b);
        this.d = iB;
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void D(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0366k;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 1) {
                c4.o();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            V(c4.C());
            c4.o();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 1) {
            do {
                list.add(Double.valueOf(c4.o()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iC = c4.C();
        V(iC);
        int iH = c4.h() + iC;
        do {
            list.add(Double.valueOf(c4.o()));
        } while (c4.h() < iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void E(List list, Z z3, C0368m c0368m) throws InvalidProtocolBufferException.InvalidWireTypeException {
        int iB;
        int i10 = this.f6502b;
        if ((i10 & 7) != 2) {
            throw InvalidProtocolBufferException.b();
        }
        do {
            list.add(P(z3, c0368m));
            R.C c4 = this.f6501a;
            if (c4.j() || this.d != 0) {
                return;
            } else {
                iB = c4.B();
            }
        } while (iB == i10);
        this.d = iB;
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void F(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof F;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.u();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.u();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Long.valueOf(c4.u()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Long.valueOf(c4.u()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void G(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof F;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 1) {
                c4.w();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            V(c4.C());
            c4.w();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 1) {
            do {
                list.add(Long.valueOf(c4.w()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iC = c4.C();
        V(iC);
        int iH = c4.h() + iC;
        do {
            list.add(Long.valueOf(c4.w()));
        } while (c4.h() < iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final long H() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.u();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final String I() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(2);
        return this.f6501a.A();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void J(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof F;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 1) {
                c4.r();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            V(c4.C());
            c4.r();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 1) {
            do {
                list.add(Long.valueOf(c4.r()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iC = c4.C();
        V(iC);
        int iH = c4.h() + iC;
        do {
            list.add(Long.valueOf(c4.r()));
        } while (c4.h() < iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void K(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0377w;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.t();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.t();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Integer.valueOf(c4.t()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Integer.valueOf(c4.t()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void L(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0377w;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.p();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.p();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Integer.valueOf(c4.p()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Integer.valueOf(c4.p()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final Object M(Z z3, C0368m c0368m) throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(3);
        return O(z3, c0368m);
    }

    public final Object N(y0 y0Var, Class cls, C0368m c0368m) throws InvalidProtocolBufferException.InvalidWireTypeException {
        switch (y0Var.ordinal()) {
            case 0:
                return Double.valueOf(readDouble());
            case 1:
                return Float.valueOf(readFloat());
            case 2:
                return Long.valueOf(H());
            case 3:
                return Long.valueOf(e());
            case 4:
                return Integer.valueOf(y());
            case 5:
                return Long.valueOf(g());
            case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                return Integer.valueOf(o());
            case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                return Boolean.valueOf(p());
            case 8:
                return I();
            case 9:
            default:
                throw new RuntimeException("unsupported field type.");
            case 10:
                S(2);
                return P(V.f6455c.a(cls), c0368m);
            case ModuleDescriptor.MODULE_VERSION /* 11 */:
                return v();
            case 12:
                return Integer.valueOf(x());
            case 13:
                return Integer.valueOf(c());
            case 14:
                return Integer.valueOf(B());
            case 15:
                return Long.valueOf(s());
            case 16:
                return Integer.valueOf(i());
            case 17:
                return Long.valueOf(k());
        }
    }

    public final Object O(Z z3, C0368m c0368m) {
        int i10 = this.f6503c;
        this.f6503c = ((this.f6502b >>> 3) << 3) | 4;
        try {
            Object objH = z3.h();
            z3.a(objH, this, c0368m);
            z3.d(objH);
            if (this.f6502b == this.f6503c) {
                return objH;
            }
            throw InvalidProtocolBufferException.e();
        } finally {
            this.f6503c = i10;
        }
    }

    public final Object P(Z z3, C0368m c0368m) throws InvalidProtocolBufferException {
        R.C c4 = this.f6501a;
        int iC = c4.C();
        if (c4.f3952a >= c4.f3953b) {
            throw new InvalidProtocolBufferException("Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit.");
        }
        int iL = c4.l(iC);
        Object objH = z3.h();
        c4.f3952a++;
        z3.a(objH, this, c0368m);
        z3.d(objH);
        c4.d(0);
        c4.f3952a--;
        c4.k(iL);
        return objH;
    }

    public final void Q(List list, boolean z3) throws InvalidProtocolBufferException.InvalidWireTypeException {
        int iB;
        int iB2;
        if ((this.f6502b & 7) != 2) {
            throw InvalidProtocolBufferException.b();
        }
        boolean z9 = list instanceof B;
        R.C c4 = this.f6501a;
        if (!z9 || z3) {
            do {
                list.add(z3 ? I() : n());
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        B b7 = (B) list;
        do {
            b7.d(v());
            if (c4.j()) {
                return;
            } else {
                iB2 = c4.B();
            }
        } while (iB2 == this.f6502b);
        this.d = iB2;
    }

    public final void R(int i10) throws InvalidProtocolBufferException {
        if (this.f6501a.h() != i10) {
            throw InvalidProtocolBufferException.f();
        }
    }

    public final void S(int i10) throws InvalidProtocolBufferException.InvalidWireTypeException {
        if ((this.f6502b & 7) != i10) {
            throw InvalidProtocolBufferException.b();
        }
    }

    public final boolean T() {
        int i10;
        R.C c4 = this.f6501a;
        if (c4.j() || (i10 = this.f6502b) == this.f6503c) {
            return false;
        }
        return c4.G(i10);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final Object a(Z z3, C0368m c0368m) throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(2);
        return P(z3, c0368m);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void b(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0377w;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.x();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.x();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Integer.valueOf(c4.x()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Integer.valueOf(c4.x()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int c() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.p();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int d() {
        return this.f6502b;
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final long e() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.D();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void f(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0377w;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 2) {
                U(c4.C());
                c4.q();
                throw null;
            }
            if (i10 != 5) {
                throw InvalidProtocolBufferException.b();
            }
            c4.q();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 2) {
            int iC = c4.C();
            U(iC);
            int iH = c4.h() + iC;
            do {
                list.add(Integer.valueOf(c4.q()));
            } while (c4.h() < iH);
            return;
        }
        if (i11 != 5) {
            throw InvalidProtocolBufferException.b();
        }
        do {
            list.add(Integer.valueOf(c4.q()));
            if (c4.j()) {
                return;
            } else {
                iB = c4.B();
            }
        } while (iB == this.f6502b);
        this.d = iB;
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final long g() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(1);
        return this.f6501a.r();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void h(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0377w;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 2) {
                U(c4.C());
                c4.v();
                throw null;
            }
            if (i10 != 5) {
                throw InvalidProtocolBufferException.b();
            }
            c4.v();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 2) {
            int iC = c4.C();
            U(iC);
            int iH = c4.h() + iC;
            do {
                list.add(Integer.valueOf(c4.v()));
            } while (c4.h() < iH);
            return;
        }
        if (i11 != 5) {
            throw InvalidProtocolBufferException.b();
        }
        do {
            list.add(Integer.valueOf(c4.v()));
            if (c4.j()) {
                return;
            } else {
                iB = c4.B();
            }
        } while (iB == this.f6502b);
        this.d = iB;
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int i() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.x();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void j(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof F;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.y();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.y();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Long.valueOf(c4.y()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Long.valueOf(c4.y()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final long k() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.y();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void l(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0377w;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.C();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.C();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Integer.valueOf(c4.C()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Integer.valueOf(c4.C()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void m(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof AbstractC0359d;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.m();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.m();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Boolean.valueOf(c4.m()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Boolean.valueOf(c4.m()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final String n() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(2);
        return this.f6501a.z();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int o() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(5);
        return this.f6501a.q();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final boolean p() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.m();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int q() {
        int i10 = this.d;
        if (i10 != 0) {
            this.f6502b = i10;
            this.d = 0;
        } else {
            this.f6502b = this.f6501a.B();
        }
        int i11 = this.f6502b;
        return (i11 == 0 || i11 == this.f6503c) ? com.google.android.gms.common.api.f.API_PRIORITY_OTHER : i11 >>> 3;
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void r(List list) throws InvalidProtocolBufferException.InvalidWireTypeException {
        Q(list, false);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final double readDouble() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(1);
        return this.f6501a.o();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final float readFloat() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(5);
        return this.f6501a.s();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final long s() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(1);
        return this.f6501a.w();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void t(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof F;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 0) {
                c4.D();
                throw null;
            }
            if (i10 != 2) {
                throw InvalidProtocolBufferException.b();
            }
            c4.C();
            c4.D();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 0) {
            do {
                list.add(Long.valueOf(c4.D()));
                if (c4.j()) {
                    return;
                } else {
                    iB = c4.B();
                }
            } while (iB == this.f6502b);
            this.d = iB;
            return;
        }
        if (i11 != 2) {
            throw InvalidProtocolBufferException.b();
        }
        int iH = c4.h() + c4.C();
        do {
            list.add(Long.valueOf(c4.D()));
        } while (c4.h() < iH);
        R(iH);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void u(List list) throws InvalidProtocolBufferException.InvalidWireTypeException {
        Q(list, true);
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final C0362g v() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(2);
        return this.f6501a.n();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void w(List list) throws InvalidProtocolBufferException {
        int iB;
        boolean z3 = list instanceof r;
        R.C c4 = this.f6501a;
        if (z3) {
            android.support.v4.media.session.a.u(list);
            int i10 = this.f6502b & 7;
            if (i10 == 2) {
                U(c4.C());
                c4.s();
                throw null;
            }
            if (i10 != 5) {
                throw InvalidProtocolBufferException.b();
            }
            c4.s();
            throw null;
        }
        int i11 = this.f6502b & 7;
        if (i11 == 2) {
            int iC = c4.C();
            U(iC);
            int iH = c4.h() + iC;
            do {
                list.add(Float.valueOf(c4.s()));
            } while (c4.h() < iH);
            return;
        }
        if (i11 != 5) {
            throw InvalidProtocolBufferException.b();
        }
        do {
            list.add(Float.valueOf(c4.s()));
            if (c4.j()) {
                return;
            } else {
                iB = c4.B();
            }
        } while (iB == this.f6502b);
        this.d = iB;
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int x() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.C();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final int y() throws InvalidProtocolBufferException.InvalidWireTypeException {
        S(0);
        return this.f6501a.t();
    }

    @Override // androidx.datastore.preferences.protobuf.Y
    public final void z(List list, Z z3, C0368m c0368m) throws InvalidProtocolBufferException.InvalidWireTypeException {
        int iB;
        int i10 = this.f6502b;
        if ((i10 & 7) != 3) {
            throw InvalidProtocolBufferException.b();
        }
        do {
            list.add(O(z3, c0368m));
            R.C c4 = this.f6501a;
            if (c4.j() || this.d != 0) {
                return;
            } else {
                iB = c4.B();
            }
        } while (iB == i10);
        this.d = iB;
    }
}
