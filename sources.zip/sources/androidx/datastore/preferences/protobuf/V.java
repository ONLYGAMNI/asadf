package androidx.datastore.preferences.protobuf;

import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public final class V {

    /* renamed from: c */
    public static final V f6455c = new V();

    /* renamed from: b */
    public final ConcurrentHashMap f6457b = new ConcurrentHashMap();

    /* renamed from: a */
    public final H f6456a = new H();

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v5, types: [androidx.datastore.preferences.protobuf.P] */
    /* JADX WARN: Type inference failed for: r4v7, types: [androidx.datastore.preferences.protobuf.P] */
    public final Z a(Class cls) {
        O oX;
        O p9;
        Class cls2;
        AbstractC0379y.a(cls, "messageType");
        ConcurrentHashMap concurrentHashMap = this.f6457b;
        Z z3 = (Z) concurrentHashMap.get(cls);
        if (z3 != null) {
            return z3;
        }
        H h10 = this.f6456a;
        h10.getClass();
        Class cls3 = a0.f6463a;
        if (!AbstractC0376v.class.isAssignableFrom(cls) && (cls2 = a0.f6463a) != null && !cls2.isAssignableFrom(cls)) {
            throw new IllegalArgumentException("Message classes must extend GeneratedMessage or GeneratedMessageLite");
        }
        X xA = ((M) h10.f6426a).a(cls);
        if ((xA.d & 2) == 2) {
            boolean zIsAssignableFrom = AbstractC0376v.class.isAssignableFrom(cls);
            AbstractC0356a abstractC0356a = xA.f6460a;
            if (zIsAssignableFrom) {
                p9 = new P(a0.d, AbstractC0370o.f6516a, abstractC0356a);
            } else {
                g0 g0Var = a0.f6464b;
                C0369n c0369n = AbstractC0370o.f6517b;
                if (c0369n == null) {
                    throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
                }
                p9 = new P(g0Var, c0369n, abstractC0356a);
            }
            oX = p9;
        } else if (AbstractC0376v.class.isAssignableFrom(cls)) {
            oX = xA.d() == 1 ? O.x(xA, S.f6454b, E.f6423b, a0.d, AbstractC0370o.f6516a, L.f6433b) : O.x(xA, S.f6454b, E.f6423b, a0.d, null, L.f6433b);
        } else if (xA.d() == 1) {
            Q q6 = S.f6453a;
            C c4 = E.f6422a;
            g0 g0Var2 = a0.f6464b;
            C0369n c0369n2 = AbstractC0370o.f6517b;
            if (c0369n2 == null) {
                throw new IllegalStateException("Protobuf runtime is not correctly loaded.");
            }
            oX = O.x(xA, q6, c4, g0Var2, c0369n2, L.f6432a);
        } else {
            oX = O.x(xA, S.f6453a, E.f6422a, a0.f6465c, null, L.f6432a);
        }
        Z z9 = (Z) concurrentHashMap.putIfAbsent(cls, oX);
        return z9 != null ? z9 : oX;
    }
}
