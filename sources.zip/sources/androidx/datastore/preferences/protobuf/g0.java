package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public abstract class g0 {
    public final boolean a(Object obj, Y y9) throws InvalidProtocolBufferException {
        int iD = y9.d();
        int i10 = iD >>> 3;
        int i11 = iD & 7;
        if (i11 == 0) {
            ((h0) obj).c(i10 << 3, Long.valueOf(y9.H()));
            return true;
        }
        if (i11 == 1) {
            ((h0) obj).c((i10 << 3) | 1, Long.valueOf(y9.g()));
            return true;
        }
        if (i11 == 2) {
            ((h0) obj).c((i10 << 3) | 2, y9.v());
            return true;
        }
        if (i11 != 3) {
            if (i11 == 4) {
                return false;
            }
            if (i11 != 5) {
                throw InvalidProtocolBufferException.b();
            }
            ((h0) obj).c((i10 << 3) | 5, Integer.valueOf(y9.o()));
            return true;
        }
        h0 h0VarB = h0.b();
        int i12 = i10 << 3;
        int i13 = i12 | 4;
        while (y9.q() != Integer.MAX_VALUE && a(h0VarB, y9)) {
        }
        if (i13 != y9.d()) {
            throw new InvalidProtocolBufferException("Protocol message end-group tag did not match expected tag.");
        }
        h0VarB.f6500e = false;
        ((h0) obj).c(i12 | 3, h0VarB);
        return true;
    }
}
