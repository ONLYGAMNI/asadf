package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.a */
/* loaded from: classes.dex */
public abstract class AbstractC0356a {
    protected int memoizedHashCode;

    public abstract int a();

    public final int b(Z z3) {
        AbstractC0376v abstractC0376v = (AbstractC0376v) this;
        int i10 = abstractC0376v.memoizedSerializedSize;
        if (i10 != -1) {
            return i10;
        }
        int iG = z3.g(this);
        abstractC0376v.memoizedSerializedSize = iG;
        return iG;
    }

    public abstract void c(C0365j c0365j);
}
