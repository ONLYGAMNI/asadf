package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public abstract class S {

    /* renamed from: a, reason: collision with root package name */
    public static final Q f6453a;

    /* renamed from: b, reason: collision with root package name */
    public static final Q f6454b;

    static {
        Q q6 = null;
        try {
            q6 = (Q) Class.forName("androidx.datastore.preferences.protobuf.NewInstanceSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f6453a = q6;
        f6454b = new Q();
    }
}
