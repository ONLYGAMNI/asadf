package androidx.datastore.preferences.protobuf;

import java.nio.charset.Charset;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

/* loaded from: classes.dex */
public final class A extends AbstractC0357b implements B, RandomAccess {

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f6420b;

    static {
        new A(10).f6466a = false;
    }

    public A(int i10) {
        this(new ArrayList(i10));
    }

    @Override // androidx.datastore.preferences.protobuf.InterfaceC0378x
    public final InterfaceC0378x a(int i10) {
        ArrayList arrayList = this.f6420b;
        if (i10 < arrayList.size()) {
            throw new IllegalArgumentException();
        }
        ArrayList arrayList2 = new ArrayList(i10);
        arrayList2.addAll(arrayList);
        return new A(arrayList2);
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i10, Object obj) {
        b();
        this.f6420b.add(i10, (String) obj);
        ((AbstractList) this).modCount++;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0357b, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean addAll(Collection collection) {
        return addAll(this.f6420b.size(), collection);
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0357b, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final void clear() {
        b();
        this.f6420b.clear();
        ((AbstractList) this).modCount++;
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final void d(C0362g c0362g) {
        b();
        this.f6420b.add(c0362g);
        ((AbstractList) this).modCount++;
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final B f() {
        return this.f6466a ? new l0(this) : this;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i10) {
        String str;
        ArrayList arrayList = this.f6420b;
        Object obj = arrayList.get(i10);
        if (obj instanceof String) {
            return (String) obj;
        }
        if (obj instanceof C0362g) {
            C0362g c0362g = (C0362g) obj;
            c0362g.getClass();
            Charset charset = AbstractC0379y.f6539a;
            if (c0362g.size() == 0) {
                str = "";
            } else {
                str = new String(c0362g.f6487b, c0362g.e(), c0362g.size(), charset);
            }
            int iE = c0362g.e();
            if (t0.f6538a.j(c0362g.f6487b, iE, c0362g.size() + iE) == 0) {
                arrayList.set(i10, str);
            }
        } else {
            byte[] bArr = (byte[]) obj;
            str = new String(bArr, AbstractC0379y.f6539a);
            N n9 = t0.f6538a;
            if (t0.f6538a.j(bArr, 0, bArr.length) == 0) {
                arrayList.set(i10, str);
            }
        }
        return str;
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final Object h(int i10) {
        return this.f6420b.get(i10);
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final List i() {
        return Collections.unmodifiableList(this.f6420b);
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object remove(int i10) {
        b();
        Object objRemove = this.f6420b.remove(i10);
        ((AbstractList) this).modCount++;
        if (objRemove instanceof String) {
            return (String) objRemove;
        }
        if (!(objRemove instanceof C0362g)) {
            return new String((byte[]) objRemove, AbstractC0379y.f6539a);
        }
        C0362g c0362g = (C0362g) objRemove;
        c0362g.getClass();
        Charset charset = AbstractC0379y.f6539a;
        if (c0362g.size() == 0) {
            return "";
        }
        return new String(c0362g.f6487b, c0362g.e(), c0362g.size(), charset);
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i10, Object obj) {
        b();
        Object obj2 = this.f6420b.set(i10, (String) obj);
        if (obj2 instanceof String) {
            return (String) obj2;
        }
        if (!(obj2 instanceof C0362g)) {
            return new String((byte[]) obj2, AbstractC0379y.f6539a);
        }
        C0362g c0362g = (C0362g) obj2;
        c0362g.getClass();
        Charset charset = AbstractC0379y.f6539a;
        if (c0362g.size() == 0) {
            return "";
        }
        return new String(c0362g.f6487b, c0362g.e(), c0362g.size(), charset);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f6420b.size();
    }

    public A(ArrayList arrayList) {
        this.f6420b = arrayList;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0357b, java.util.AbstractList, java.util.List
    public final boolean addAll(int i10, Collection collection) {
        b();
        if (collection instanceof B) {
            collection = ((B) collection).i();
        }
        boolean zAddAll = this.f6420b.addAll(i10, collection);
        ((AbstractList) this).modCount++;
        return zAddAll;
    }
}
