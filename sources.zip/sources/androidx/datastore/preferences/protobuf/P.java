package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class P implements Z {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0356a f6450a;

    /* renamed from: b, reason: collision with root package name */
    public final g0 f6451b;

    /* renamed from: c, reason: collision with root package name */
    public final C0369n f6452c;

    public P(g0 g0Var, C0369n c0369n, AbstractC0356a abstractC0356a) {
        this.f6451b = g0Var;
        c0369n.getClass();
        this.f6452c = c0369n;
        this.f6450a = abstractC0356a;
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void a(Object obj, Y y9, C0368m c0368m) {
        ((i0) this.f6451b).getClass();
        AbstractC0376v abstractC0376v = (AbstractC0376v) obj;
        if (abstractC0376v.unknownFields == h0.f6496f) {
            abstractC0376v.unknownFields = h0.b();
        }
        this.f6452c.getClass();
        android.support.v4.media.session.a.u(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void b(Object obj, Object obj2) {
        a0.B(this.f6451b, obj, obj2);
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void c(Object obj, H h10) {
        this.f6452c.getClass();
        android.support.v4.media.session.a.u(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void d(Object obj) {
        ((i0) this.f6451b).getClass();
        ((AbstractC0376v) obj).unknownFields.f6500e = false;
        this.f6452c.getClass();
        android.support.v4.media.session.a.u(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final boolean e(Object obj) {
        this.f6452c.getClass();
        android.support.v4.media.session.a.u(obj);
        throw null;
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final boolean f(Object obj, Object obj2) {
        g0 g0Var = this.f6451b;
        ((i0) g0Var).getClass();
        h0 h0Var = ((AbstractC0376v) obj).unknownFields;
        ((i0) g0Var).getClass();
        return h0Var.equals(((AbstractC0376v) obj2).unknownFields);
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final int g(Object obj) {
        ((i0) this.f6451b).getClass();
        h0 h0Var = ((AbstractC0376v) obj).unknownFields;
        int i10 = h0Var.d;
        if (i10 != -1) {
            return i10;
        }
        int iT = 0;
        for (int i11 = 0; i11 < h0Var.f6497a; i11++) {
            int i12 = h0Var.f6498b[i11] >>> 3;
            iT += C0365j.t(3, (C0362g) h0Var.f6499c[i11]) + C0365j.L(2, i12) + (C0365j.K(1) * 2);
        }
        h0Var.d = iT;
        return iT;
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final Object h() {
        return ((AbstractC0374t) ((AbstractC0376v) this.f6450a).d(5)).c();
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final int i(Object obj) {
        ((i0) this.f6451b).getClass();
        return ((AbstractC0376v) obj).unknownFields.hashCode();
    }
}
