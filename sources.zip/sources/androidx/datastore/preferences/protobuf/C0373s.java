package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.s, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0373s implements M {

    /* renamed from: b, reason: collision with root package name */
    public static final C0373s f6533b = new C0373s(0);

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6534a;

    public /* synthetic */ C0373s(int i10) {
        this.f6534a = i10;
    }

    @Override // androidx.datastore.preferences.protobuf.M
    public final X a(Class cls) {
        switch (this.f6534a) {
            case 0:
                if (!AbstractC0376v.class.isAssignableFrom(cls)) {
                    throw new IllegalArgumentException("Unsupported message type: ".concat(cls.getName()));
                }
                try {
                    return (X) AbstractC0376v.e(cls.asSubclass(AbstractC0376v.class)).d(3);
                } catch (Exception e4) {
                    throw new RuntimeException("Unable to get message info for ".concat(cls.getName()), e4);
                }
            default:
                throw new IllegalStateException("This should never be called.");
        }
    }

    @Override // androidx.datastore.preferences.protobuf.M
    public final boolean b(Class cls) {
        switch (this.f6534a) {
            case 0:
                return AbstractC0376v.class.isAssignableFrom(cls);
            default:
                return false;
        }
    }
}
