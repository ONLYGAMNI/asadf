package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.c, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0358c {

    /* renamed from: a, reason: collision with root package name */
    public static final Class f6473a;

    /* renamed from: b, reason: collision with root package name */
    public static final boolean f6474b;

    static {
        Class<?> cls;
        Class<?> cls2 = null;
        try {
            cls = Class.forName("libcore.io.Memory");
        } catch (Throwable unused) {
            cls = null;
        }
        f6473a = cls;
        try {
            cls2 = Class.forName("org.robolectric.Robolectric");
        } catch (Throwable unused2) {
        }
        f6474b = cls2 != null;
    }

    public static boolean a() {
        return (f6473a == null || f6474b) ? false : true;
    }
}
