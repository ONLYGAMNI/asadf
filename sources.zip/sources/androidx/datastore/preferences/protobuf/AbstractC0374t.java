package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.t */
/* loaded from: classes.dex */
public abstract class AbstractC0374t implements Cloneable {

    /* renamed from: a */
    public final AbstractC0376v f6535a;

    /* renamed from: b */
    public AbstractC0376v f6536b;

    /* renamed from: c */
    public boolean f6537c = false;

    public AbstractC0374t(AbstractC0376v abstractC0376v) {
        this.f6535a = abstractC0376v;
        this.f6536b = (AbstractC0376v) abstractC0376v.d(4);
    }

    public static void f(AbstractC0376v abstractC0376v, AbstractC0376v abstractC0376v2) {
        V v9 = V.f6455c;
        v9.getClass();
        v9.a(abstractC0376v.getClass()).b(abstractC0376v, abstractC0376v2);
    }

    public final AbstractC0376v a() {
        AbstractC0376v abstractC0376vC = c();
        if (abstractC0376vC.g()) {
            return abstractC0376vC;
        }
        throw new UninitializedMessageException();
    }

    public final AbstractC0376v c() {
        if (this.f6537c) {
            return this.f6536b;
        }
        AbstractC0376v abstractC0376v = this.f6536b;
        abstractC0376v.getClass();
        V v9 = V.f6455c;
        v9.getClass();
        v9.a(abstractC0376v.getClass()).d(abstractC0376v);
        this.f6537c = true;
        return this.f6536b;
    }

    public final Object clone() {
        AbstractC0374t abstractC0374t = (AbstractC0374t) this.f6535a.d(5);
        AbstractC0376v abstractC0376vC = c();
        abstractC0374t.d();
        f(abstractC0374t.f6536b, abstractC0376vC);
        return abstractC0374t;
    }

    public final void d() {
        if (this.f6537c) {
            AbstractC0376v abstractC0376v = (AbstractC0376v) this.f6536b.d(4);
            f(abstractC0376v, this.f6536b);
            this.f6536b = abstractC0376v;
            this.f6537c = false;
        }
    }
}
