package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class G implements M {

    /* renamed from: a, reason: collision with root package name */
    public M[] f6424a;

    @Override // androidx.datastore.preferences.protobuf.M
    public final X a(Class cls) {
        for (M m9 : this.f6424a) {
            if (m9.b(cls)) {
                return m9.a(cls);
            }
        }
        throw new UnsupportedOperationException("No factory is available for message type: ".concat(cls.getName()));
    }

    @Override // androidx.datastore.preferences.protobuf.M
    public final boolean b(Class cls) {
        for (M m9 : this.f6424a) {
            if (m9.b(cls)) {
                return true;
            }
        }
        return false;
    }
}
