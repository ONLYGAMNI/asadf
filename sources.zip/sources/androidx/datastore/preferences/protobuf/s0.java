package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class s0 extends IllegalArgumentException {
    public s0(int i10, int i11) {
        super(android.support.v4.media.session.a.j("Unpaired surrogate at index ", i10, i11, " of "));
    }
}
