package androidx.datastore.preferences.protobuf;

import java.util.Map;

/* loaded from: classes.dex */
public final class e0 implements Map.Entry, Comparable {

    /* renamed from: a, reason: collision with root package name */
    public final Comparable f6478a;

    /* renamed from: b, reason: collision with root package name */
    public Object f6479b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ b0 f6480c;

    public e0(b0 b0Var, Comparable comparable, Object obj) {
        this.f6480c = b0Var;
        this.f6478a = comparable;
        this.f6479b = obj;
    }

    @Override // java.lang.Comparable
    public final int compareTo(Object obj) {
        return this.f6478a.compareTo(((e0) obj).f6478a);
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        Object key = entry.getKey();
        Comparable comparable = this.f6478a;
        if (comparable == null ? key == null : comparable.equals(key)) {
            Object obj2 = this.f6479b;
            Object value = entry.getValue();
            if (obj2 == null ? value == null : obj2.equals(value)) {
                return true;
            }
        }
        return false;
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        return this.f6478a;
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        return this.f6479b;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        Comparable comparable = this.f6478a;
        int iHashCode = comparable == null ? 0 : comparable.hashCode();
        Object obj = this.f6479b;
        return (obj != null ? obj.hashCode() : 0) ^ iHashCode;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        this.f6480c.b();
        Object obj2 = this.f6479b;
        this.f6479b = obj;
        return obj2;
    }

    public final String toString() {
        return this.f6478a + "=" + this.f6479b;
    }
}
