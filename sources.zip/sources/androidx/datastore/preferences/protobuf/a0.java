package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

/* loaded from: classes.dex */
public abstract class a0 {

    /* renamed from: a, reason: collision with root package name */
    public static final Class f6463a;

    /* renamed from: b, reason: collision with root package name */
    public static final g0 f6464b;

    /* renamed from: c, reason: collision with root package name */
    public static final g0 f6465c;
    public static final i0 d;

    static {
        Class<?> cls;
        try {
            cls = Class.forName("androidx.datastore.preferences.protobuf.GeneratedMessageV3");
        } catch (Throwable unused) {
            cls = null;
        }
        f6463a = cls;
        f6464b = A(false);
        f6465c = A(true);
        d = new i0();
    }

    public static g0 A(boolean z3) {
        Class<?> cls;
        try {
            cls = Class.forName("androidx.datastore.preferences.protobuf.UnknownFieldSetSchema");
        } catch (Throwable unused) {
            cls = null;
        }
        if (cls == null) {
            return null;
        }
        try {
            return (g0) cls.getConstructor(Boolean.TYPE).newInstance(Boolean.valueOf(z3));
        } catch (Throwable unused2) {
            return null;
        }
    }

    public static void B(g0 g0Var, Object obj, Object obj2) {
        ((i0) g0Var).getClass();
        AbstractC0376v abstractC0376v = (AbstractC0376v) obj;
        h0 h0Var = abstractC0376v.unknownFields;
        h0 h0Var2 = ((AbstractC0376v) obj2).unknownFields;
        if (!h0Var2.equals(h0.f6496f)) {
            int i10 = h0Var.f6497a + h0Var2.f6497a;
            int[] iArrCopyOf = Arrays.copyOf(h0Var.f6498b, i10);
            System.arraycopy(h0Var2.f6498b, 0, iArrCopyOf, h0Var.f6497a, h0Var2.f6497a);
            Object[] objArrCopyOf = Arrays.copyOf(h0Var.f6499c, i10);
            System.arraycopy(h0Var2.f6499c, 0, objArrCopyOf, h0Var.f6497a, h0Var2.f6497a);
            h0Var = new h0(i10, iArrCopyOf, objArrCopyOf, true);
        }
        abstractC0376v.unknownFields = h0Var;
    }

    public static boolean C(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    public static void D(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.U(i10, ((Boolean) list.get(i11)).booleanValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int i12 = 0;
        for (int i13 = 0; i13 < list.size(); i13++) {
            ((Boolean) list.get(i13)).getClass();
            Logger logger = C0365j.f6504h;
            i12++;
        }
        c0365j.k0(i12);
        while (i11 < list.size()) {
            c0365j.S(((Boolean) list.get(i11)).booleanValue() ? (byte) 1 : (byte) 0);
            i11++;
        }
    }

    public static void E(int i10, List list, H h10) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        h10.getClass();
        for (int i11 = 0; i11 < list.size(); i11++) {
            ((C0365j) h10.f6426a).W(i10, (C0362g) list.get(i11));
        }
    }

    public static void F(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                double dDoubleValue = ((Double) list.get(i11)).doubleValue();
                c0365j.getClass();
                c0365j.a0(i10, Double.doubleToRawLongBits(dDoubleValue));
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int i12 = 0;
        for (int i13 = 0; i13 < list.size(); i13++) {
            ((Double) list.get(i13)).getClass();
            Logger logger = C0365j.f6504h;
            i12 += 8;
        }
        c0365j.k0(i12);
        while (i11 < list.size()) {
            c0365j.b0(Double.doubleToRawLongBits(((Double) list.get(i11)).doubleValue()));
            i11++;
        }
    }

    public static void G(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.c0(i10, ((Integer) list.get(i11)).intValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int iC = 0;
        for (int i12 = 0; i12 < list.size(); i12++) {
            iC += C0365j.C(((Integer) list.get(i12)).intValue());
        }
        c0365j.k0(iC);
        while (i11 < list.size()) {
            c0365j.d0(((Integer) list.get(i11)).intValue());
            i11++;
        }
    }

    public static void H(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.Y(i10, ((Integer) list.get(i11)).intValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int i12 = 0;
        for (int i13 = 0; i13 < list.size(); i13++) {
            ((Integer) list.get(i13)).getClass();
            Logger logger = C0365j.f6504h;
            i12 += 4;
        }
        c0365j.k0(i12);
        while (i11 < list.size()) {
            c0365j.Z(((Integer) list.get(i11)).intValue());
            i11++;
        }
    }

    public static void I(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.a0(i10, ((Long) list.get(i11)).longValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int i12 = 0;
        for (int i13 = 0; i13 < list.size(); i13++) {
            ((Long) list.get(i13)).getClass();
            Logger logger = C0365j.f6504h;
            i12 += 8;
        }
        c0365j.k0(i12);
        while (i11 < list.size()) {
            c0365j.b0(((Long) list.get(i11)).longValue());
            i11++;
        }
    }

    public static void J(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                float fFloatValue = ((Float) list.get(i11)).floatValue();
                c0365j.getClass();
                c0365j.Y(i10, Float.floatToRawIntBits(fFloatValue));
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int i12 = 0;
        for (int i13 = 0; i13 < list.size(); i13++) {
            ((Float) list.get(i13)).getClass();
            Logger logger = C0365j.f6504h;
            i12 += 4;
        }
        c0365j.k0(i12);
        while (i11 < list.size()) {
            c0365j.Z(Float.floatToRawIntBits(((Float) list.get(i11)).floatValue()));
            i11++;
        }
    }

    public static void K(int i10, List list, H h10, Z z3) {
        if (list == null || list.isEmpty()) {
            return;
        }
        h10.getClass();
        for (int i11 = 0; i11 < list.size(); i11++) {
            h10.h(i10, list.get(i11), z3);
        }
    }

    public static void L(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.c0(i10, ((Integer) list.get(i11)).intValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int iC = 0;
        for (int i12 = 0; i12 < list.size(); i12++) {
            iC += C0365j.C(((Integer) list.get(i12)).intValue());
        }
        c0365j.k0(iC);
        while (i11 < list.size()) {
            c0365j.d0(((Integer) list.get(i11)).intValue());
            i11++;
        }
    }

    public static void M(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.l0(i10, ((Long) list.get(i11)).longValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int iO = 0;
        for (int i12 = 0; i12 < list.size(); i12++) {
            iO += C0365j.O(((Long) list.get(i12)).longValue());
        }
        c0365j.k0(iO);
        while (i11 < list.size()) {
            c0365j.m0(((Long) list.get(i11)).longValue());
            i11++;
        }
    }

    public static void N(int i10, List list, H h10, Z z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        h10.getClass();
        for (int i11 = 0; i11 < list.size(); i11++) {
            h10.k(i10, list.get(i11), z3);
        }
    }

    public static void O(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.Y(i10, ((Integer) list.get(i11)).intValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int i12 = 0;
        for (int i13 = 0; i13 < list.size(); i13++) {
            ((Integer) list.get(i13)).getClass();
            Logger logger = C0365j.f6504h;
            i12 += 4;
        }
        c0365j.k0(i12);
        while (i11 < list.size()) {
            c0365j.Z(((Integer) list.get(i11)).intValue());
            i11++;
        }
    }

    public static void P(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.a0(i10, ((Long) list.get(i11)).longValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int i12 = 0;
        for (int i13 = 0; i13 < list.size(); i13++) {
            ((Long) list.get(i13)).getClass();
            Logger logger = C0365j.f6504h;
            i12 += 8;
        }
        c0365j.k0(i12);
        while (i11 < list.size()) {
            c0365j.b0(((Long) list.get(i11)).longValue());
            i11++;
        }
    }

    public static void Q(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                int iIntValue = ((Integer) list.get(i11)).intValue();
                c0365j.j0(i10, (iIntValue >> 31) ^ (iIntValue << 1));
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int iM = 0;
        for (int i12 = 0; i12 < list.size(); i12++) {
            int iIntValue2 = ((Integer) list.get(i12)).intValue();
            iM += C0365j.M((iIntValue2 >> 31) ^ (iIntValue2 << 1));
        }
        c0365j.k0(iM);
        while (i11 < list.size()) {
            int iIntValue3 = ((Integer) list.get(i11)).intValue();
            c0365j.k0((iIntValue3 >> 31) ^ (iIntValue3 << 1));
            i11++;
        }
    }

    public static void R(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                long jLongValue = ((Long) list.get(i11)).longValue();
                c0365j.l0(i10, (jLongValue >> 63) ^ (jLongValue << 1));
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int iO = 0;
        for (int i12 = 0; i12 < list.size(); i12++) {
            long jLongValue2 = ((Long) list.get(i12)).longValue();
            iO += C0365j.O((jLongValue2 >> 63) ^ (jLongValue2 << 1));
        }
        c0365j.k0(iO);
        while (i11 < list.size()) {
            long jLongValue3 = ((Long) list.get(i11)).longValue();
            c0365j.m0((jLongValue3 >> 63) ^ (jLongValue3 << 1));
            i11++;
        }
    }

    public static void S(int i10, List list, H h10) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        h10.getClass();
        boolean z3 = list instanceof B;
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.g0(i10, (String) list.get(i11));
                i11++;
            }
            return;
        }
        B b7 = (B) list;
        while (i11 < list.size()) {
            Object objH = b7.h(i11);
            if (objH instanceof String) {
                c0365j.g0(i10, (String) objH);
            } else {
                c0365j.W(i10, (C0362g) objH);
            }
            i11++;
        }
    }

    public static void T(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.j0(i10, ((Integer) list.get(i11)).intValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int iM = 0;
        for (int i12 = 0; i12 < list.size(); i12++) {
            iM += C0365j.M(((Integer) list.get(i12)).intValue());
        }
        c0365j.k0(iM);
        while (i11 < list.size()) {
            c0365j.k0(((Integer) list.get(i11)).intValue());
            i11++;
        }
    }

    public static void U(int i10, List list, H h10, boolean z3) throws IOException {
        if (list == null || list.isEmpty()) {
            return;
        }
        C0365j c0365j = (C0365j) h10.f6426a;
        int i11 = 0;
        if (!z3) {
            while (i11 < list.size()) {
                c0365j.l0(i10, ((Long) list.get(i11)).longValue());
                i11++;
            }
            return;
        }
        c0365j.i0(i10, 2);
        int iO = 0;
        for (int i12 = 0; i12 < list.size(); i12++) {
            iO += C0365j.O(((Long) list.get(i12)).longValue());
        }
        c0365j.k0(iO);
        while (i11 < list.size()) {
            c0365j.m0(((Long) list.get(i11)).longValue());
            i11++;
        }
    }

    public static int a(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return C0365j.s(i10) * size;
    }

    public static int b(List list) {
        return list.size();
    }

    public static int c(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iK = C0365j.K(i10) * size;
        for (int i11 = 0; i11 < list.size(); i11++) {
            iK += C0365j.u((C0362g) list.get(i11));
        }
        return iK;
    }

    public static int d(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0365j.K(i10) * size) + e(list);
    }

    public static int e(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (list instanceof AbstractC0377w) {
            if (size <= 0) {
                return 0;
            }
            throw null;
        }
        int iC = 0;
        for (int i10 = 0; i10 < size; i10++) {
            iC += C0365j.C(((Integer) list.get(i10)).intValue());
        }
        return iC;
    }

    public static int f(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return C0365j.x(i10) * size;
    }

    public static int g(List list) {
        return list.size() * 4;
    }

    public static int h(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return C0365j.y(i10) * size;
    }

    public static int i(List list) {
        return list.size() * 8;
    }

    public static int j(int i10, List list, Z z3) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iA = 0;
        for (int i11 = 0; i11 < size; i11++) {
            iA += C0365j.A(i10, (AbstractC0356a) list.get(i11), z3);
        }
        return iA;
    }

    public static int k(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0365j.K(i10) * size) + l(list);
    }

    public static int l(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (list instanceof AbstractC0377w) {
            if (size <= 0) {
                return 0;
            }
            throw null;
        }
        int iC = 0;
        for (int i10 = 0; i10 < size; i10++) {
            iC += C0365j.C(((Integer) list.get(i10)).intValue());
        }
        return iC;
    }

    public static int m(int i10, List list) {
        if (list.size() == 0) {
            return 0;
        }
        return (C0365j.K(i10) * list.size()) + n(list);
    }

    public static int n(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (list instanceof F) {
            if (size <= 0) {
                return 0;
            }
            throw null;
        }
        int iO = 0;
        for (int i10 = 0; i10 < size; i10++) {
            iO += C0365j.O(((Long) list.get(i10)).longValue());
        }
        return iO;
    }

    public static int o(int i10, Object obj, Z z3) {
        int iK = C0365j.K(i10);
        int iB = ((AbstractC0356a) obj).b(z3);
        return C0365j.M(iB) + iB + iK;
    }

    public static int p(int i10, List list, Z z3) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        int iK = C0365j.K(i10) * size;
        for (int i11 = 0; i11 < size; i11++) {
            int iB = ((AbstractC0356a) list.get(i11)).b(z3);
            iK += C0365j.M(iB) + iB;
        }
        return iK;
    }

    public static int q(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0365j.K(i10) * size) + r(list);
    }

    public static int r(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (list instanceof AbstractC0377w) {
            if (size <= 0) {
                return 0;
            }
            throw null;
        }
        int iM = 0;
        for (int i10 = 0; i10 < size; i10++) {
            int iIntValue = ((Integer) list.get(i10)).intValue();
            iM += C0365j.M((iIntValue >> 31) ^ (iIntValue << 1));
        }
        return iM;
    }

    public static int s(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0365j.K(i10) * size) + t(list);
    }

    public static int t(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (list instanceof F) {
            if (size <= 0) {
                return 0;
            }
            throw null;
        }
        int iO = 0;
        for (int i10 = 0; i10 < size; i10++) {
            long jLongValue = ((Long) list.get(i10)).longValue();
            iO += C0365j.O((jLongValue >> 63) ^ (jLongValue << 1));
        }
        return iO;
    }

    public static int u(int i10, List list) {
        int size = list.size();
        int i11 = 0;
        if (size == 0) {
            return 0;
        }
        int iK = C0365j.K(i10) * size;
        if (list instanceof B) {
            B b7 = (B) list;
            while (i11 < size) {
                Object objH = b7.h(i11);
                iK = (objH instanceof C0362g ? C0365j.u((C0362g) objH) : C0365j.J((String) objH)) + iK;
                i11++;
            }
        } else {
            while (i11 < size) {
                Object obj = list.get(i11);
                iK = (obj instanceof C0362g ? C0365j.u((C0362g) obj) : C0365j.J((String) obj)) + iK;
                i11++;
            }
        }
        return iK;
    }

    public static int v(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0365j.K(i10) * size) + w(list);
    }

    public static int w(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (list instanceof AbstractC0377w) {
            if (size <= 0) {
                return 0;
            }
            throw null;
        }
        int iM = 0;
        for (int i10 = 0; i10 < size; i10++) {
            iM += C0365j.M(((Integer) list.get(i10)).intValue());
        }
        return iM;
    }

    public static int x(int i10, List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        return (C0365j.K(i10) * size) + y(list);
    }

    public static int y(List list) {
        int size = list.size();
        if (size == 0) {
            return 0;
        }
        if (list instanceof F) {
            if (size <= 0) {
                return 0;
            }
            throw null;
        }
        int iO = 0;
        for (int i10 = 0; i10 < size; i10++) {
            iO += C0365j.O(((Long) list.get(i10)).longValue());
        }
        return iO;
    }

    public static Object z(int i10, List list, Object obj, g0 g0Var) {
        return obj;
    }
}
