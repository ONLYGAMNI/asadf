package androidx.datastore.preferences.protobuf;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'EF6' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:451)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:395)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:324)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:262)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:151)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:100)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* renamed from: androidx.datastore.preferences.protobuf.q, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class EnumC0372q {

    /* renamed from: b, reason: collision with root package name */
    public static final EnumC0372q f6522b;

    /* renamed from: c, reason: collision with root package name */
    public static final EnumC0372q f6523c;
    public static final EnumC0372q[] d;

    /* renamed from: e, reason: collision with root package name */
    public static final /* synthetic */ EnumC0372q[] f6524e;

    /* renamed from: a, reason: collision with root package name */
    public final int f6525a;

    /* JADX INFO: Fake field, exist only in values array */
    EnumC0372q EF6;

    static {
        EnumC0380z enumC0380z = EnumC0380z.DOUBLE;
        EnumC0372q enumC0372q = new EnumC0372q("DOUBLE", 0, 0, 1, enumC0380z);
        EnumC0380z enumC0380z2 = EnumC0380z.FLOAT;
        EnumC0372q enumC0372q2 = new EnumC0372q("FLOAT", 1, 1, 1, enumC0380z2);
        EnumC0380z enumC0380z3 = EnumC0380z.LONG;
        EnumC0372q enumC0372q3 = new EnumC0372q("INT64", 2, 2, 1, enumC0380z3);
        EnumC0372q enumC0372q4 = new EnumC0372q("UINT64", 3, 3, 1, enumC0380z3);
        EnumC0380z enumC0380z4 = EnumC0380z.INT;
        EnumC0372q enumC0372q5 = new EnumC0372q("INT32", 4, 4, 1, enumC0380z4);
        EnumC0372q enumC0372q6 = new EnumC0372q("FIXED64", 5, 5, 1, enumC0380z3);
        EnumC0372q enumC0372q7 = new EnumC0372q("FIXED32", 6, 6, 1, enumC0380z4);
        EnumC0380z enumC0380z5 = EnumC0380z.BOOLEAN;
        EnumC0372q enumC0372q8 = new EnumC0372q("BOOL", 7, 7, 1, enumC0380z5);
        EnumC0380z enumC0380z6 = EnumC0380z.STRING;
        EnumC0372q enumC0372q9 = new EnumC0372q("STRING", 8, 8, 1, enumC0380z6);
        EnumC0380z enumC0380z7 = EnumC0380z.MESSAGE;
        EnumC0372q enumC0372q10 = new EnumC0372q("MESSAGE", 9, 9, 1, enumC0380z7);
        EnumC0380z enumC0380z8 = EnumC0380z.BYTE_STRING;
        EnumC0372q enumC0372q11 = new EnumC0372q("BYTES", 10, 10, 1, enumC0380z8);
        EnumC0372q enumC0372q12 = new EnumC0372q("UINT32", 11, 11, 1, enumC0380z4);
        EnumC0380z enumC0380z9 = EnumC0380z.ENUM;
        EnumC0372q enumC0372q13 = new EnumC0372q("ENUM", 12, 12, 1, enumC0380z9);
        EnumC0372q enumC0372q14 = new EnumC0372q("SFIXED32", 13, 13, 1, enumC0380z4);
        EnumC0372q enumC0372q15 = new EnumC0372q("SFIXED64", 14, 14, 1, enumC0380z3);
        EnumC0372q enumC0372q16 = new EnumC0372q("SINT32", 15, 15, 1, enumC0380z4);
        EnumC0372q enumC0372q17 = new EnumC0372q("SINT64", 16, 16, 1, enumC0380z3);
        EnumC0372q enumC0372q18 = new EnumC0372q("GROUP", 17, 17, 1, enumC0380z7);
        EnumC0372q enumC0372q19 = new EnumC0372q("DOUBLE_LIST", 18, 18, 2, enumC0380z);
        EnumC0372q enumC0372q20 = new EnumC0372q("FLOAT_LIST", 19, 19, 2, enumC0380z2);
        EnumC0372q enumC0372q21 = new EnumC0372q("INT64_LIST", 20, 20, 2, enumC0380z3);
        EnumC0372q enumC0372q22 = new EnumC0372q("UINT64_LIST", 21, 21, 2, enumC0380z3);
        EnumC0372q enumC0372q23 = new EnumC0372q("INT32_LIST", 22, 22, 2, enumC0380z4);
        EnumC0372q enumC0372q24 = new EnumC0372q("FIXED64_LIST", 23, 23, 2, enumC0380z3);
        EnumC0372q enumC0372q25 = new EnumC0372q("FIXED32_LIST", 24, 24, 2, enumC0380z4);
        EnumC0372q enumC0372q26 = new EnumC0372q("BOOL_LIST", 25, 25, 2, enumC0380z5);
        EnumC0372q enumC0372q27 = new EnumC0372q("STRING_LIST", 26, 26, 2, enumC0380z6);
        EnumC0372q enumC0372q28 = new EnumC0372q("MESSAGE_LIST", 27, 27, 2, enumC0380z7);
        EnumC0372q enumC0372q29 = new EnumC0372q("BYTES_LIST", 28, 28, 2, enumC0380z8);
        EnumC0372q enumC0372q30 = new EnumC0372q("UINT32_LIST", 29, 29, 2, enumC0380z4);
        EnumC0372q enumC0372q31 = new EnumC0372q("ENUM_LIST", 30, 30, 2, enumC0380z9);
        EnumC0372q enumC0372q32 = new EnumC0372q("SFIXED32_LIST", 31, 31, 2, enumC0380z4);
        EnumC0372q enumC0372q33 = new EnumC0372q("SFIXED64_LIST", 32, 32, 2, enumC0380z3);
        EnumC0372q enumC0372q34 = new EnumC0372q("SINT32_LIST", 33, 33, 2, enumC0380z4);
        EnumC0372q enumC0372q35 = new EnumC0372q("SINT64_LIST", 34, 34, 2, enumC0380z3);
        EnumC0372q enumC0372q36 = new EnumC0372q("DOUBLE_LIST_PACKED", 35, 35, 3, enumC0380z);
        f6522b = enumC0372q36;
        EnumC0372q enumC0372q37 = new EnumC0372q("FLOAT_LIST_PACKED", 36, 36, 3, enumC0380z2);
        EnumC0372q enumC0372q38 = new EnumC0372q("INT64_LIST_PACKED", 37, 37, 3, enumC0380z3);
        EnumC0372q enumC0372q39 = new EnumC0372q("UINT64_LIST_PACKED", 38, 38, 3, enumC0380z3);
        EnumC0372q enumC0372q40 = new EnumC0372q("INT32_LIST_PACKED", 39, 39, 3, enumC0380z4);
        EnumC0372q enumC0372q41 = new EnumC0372q("FIXED64_LIST_PACKED", 40, 40, 3, enumC0380z3);
        EnumC0372q enumC0372q42 = new EnumC0372q("FIXED32_LIST_PACKED", 41, 41, 3, enumC0380z4);
        EnumC0372q enumC0372q43 = new EnumC0372q("BOOL_LIST_PACKED", 42, 42, 3, enumC0380z5);
        EnumC0372q enumC0372q44 = new EnumC0372q("UINT32_LIST_PACKED", 43, 43, 3, enumC0380z4);
        EnumC0372q enumC0372q45 = new EnumC0372q("ENUM_LIST_PACKED", 44, 44, 3, enumC0380z9);
        EnumC0372q enumC0372q46 = new EnumC0372q("SFIXED32_LIST_PACKED", 45, 45, 3, enumC0380z4);
        EnumC0372q enumC0372q47 = new EnumC0372q("SFIXED64_LIST_PACKED", 46, 46, 3, enumC0380z3);
        EnumC0372q enumC0372q48 = new EnumC0372q("SINT32_LIST_PACKED", 47, 47, 3, enumC0380z4);
        EnumC0372q enumC0372q49 = new EnumC0372q("SINT64_LIST_PACKED", 48, 48, 3, enumC0380z3);
        f6523c = enumC0372q49;
        f6524e = new EnumC0372q[]{enumC0372q, enumC0372q2, enumC0372q3, enumC0372q4, enumC0372q5, enumC0372q6, enumC0372q7, enumC0372q8, enumC0372q9, enumC0372q10, enumC0372q11, enumC0372q12, enumC0372q13, enumC0372q14, enumC0372q15, enumC0372q16, enumC0372q17, enumC0372q18, enumC0372q19, enumC0372q20, enumC0372q21, enumC0372q22, enumC0372q23, enumC0372q24, enumC0372q25, enumC0372q26, enumC0372q27, enumC0372q28, enumC0372q29, enumC0372q30, enumC0372q31, enumC0372q32, enumC0372q33, enumC0372q34, enumC0372q35, enumC0372q36, enumC0372q37, enumC0372q38, enumC0372q39, enumC0372q40, enumC0372q41, enumC0372q42, enumC0372q43, enumC0372q44, enumC0372q45, enumC0372q46, enumC0372q47, enumC0372q48, enumC0372q49, new EnumC0372q("GROUP_LIST", 49, 49, 2, enumC0380z7), new EnumC0372q("MAP", 50, 50, 4, EnumC0380z.VOID)};
        EnumC0372q[] enumC0372qArrValues = values();
        d = new EnumC0372q[enumC0372qArrValues.length];
        for (EnumC0372q enumC0372q50 : enumC0372qArrValues) {
            d[enumC0372q50.f6525a] = enumC0372q50;
        }
    }

    public EnumC0372q(String str, int i10, int i11, int i12, EnumC0380z enumC0380z) {
        this.f6525a = i11;
        int iD = t.e.d(i12);
        if (iD == 1 || iD == 3) {
            enumC0380z.getClass();
        }
        if (i12 == 1) {
            enumC0380z.ordinal();
        }
    }

    public static EnumC0372q valueOf(String str) {
        return (EnumC0372q) Enum.valueOf(EnumC0372q.class, str);
    }

    public static EnumC0372q[] values() {
        return (EnumC0372q[]) f6524e.clone();
    }

    public final int a() {
        return this.f6525a;
    }
}
