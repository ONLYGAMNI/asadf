package androidx.datastore.preferences.protobuf;

import java.util.List;

/* loaded from: classes.dex */
public abstract class E {

    /* renamed from: a, reason: collision with root package name */
    public static final C f6422a = new C();

    /* renamed from: b, reason: collision with root package name */
    public static final D f6423b = new D();

    public abstract void a(Object obj, long j10);

    public abstract void b(Object obj, long j10, Object obj2);

    public abstract List c(Object obj, long j10);
}
