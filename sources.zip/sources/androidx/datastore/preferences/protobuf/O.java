package androidx.datastore.preferences.protobuf;

import com.google.android.gms.dynamite.descriptors.com.google.firebase.auth.ModuleDescriptor;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;
import sun.misc.Unsafe;

/* loaded from: classes.dex */
public final class O implements Z {

    /* renamed from: o, reason: collision with root package name */
    public static final int[] f6436o = new int[0];

    /* renamed from: p, reason: collision with root package name */
    public static final Unsafe f6437p = q0.l();

    /* renamed from: a, reason: collision with root package name */
    public final int[] f6438a;

    /* renamed from: b, reason: collision with root package name */
    public final Object[] f6439b;

    /* renamed from: c, reason: collision with root package name */
    public final int f6440c;
    public final int d;

    /* renamed from: e, reason: collision with root package name */
    public final AbstractC0356a f6441e;

    /* renamed from: f, reason: collision with root package name */
    public final boolean f6442f;
    public final boolean g;

    /* renamed from: h, reason: collision with root package name */
    public final int[] f6443h;

    /* renamed from: i, reason: collision with root package name */
    public final int f6444i;

    /* renamed from: j, reason: collision with root package name */
    public final int f6445j;

    /* renamed from: k, reason: collision with root package name */
    public final Q f6446k;

    /* renamed from: l, reason: collision with root package name */
    public final E f6447l;

    /* renamed from: m, reason: collision with root package name */
    public final g0 f6448m;

    /* renamed from: n, reason: collision with root package name */
    public final K f6449n;

    public O(int[] iArr, Object[] objArr, int i10, int i11, AbstractC0356a abstractC0356a, boolean z3, int[] iArr2, int i12, int i13, Q q6, E e4, g0 g0Var, C0369n c0369n, K k10) {
        this.f6438a = iArr;
        this.f6439b = objArr;
        this.f6440c = i10;
        this.d = i11;
        this.f6442f = abstractC0356a instanceof AbstractC0376v;
        this.g = z3;
        this.f6443h = iArr2;
        this.f6444i = i12;
        this.f6445j = i13;
        this.f6446k = q6;
        this.f6447l = e4;
        this.f6448m = g0Var;
        this.f6441e = abstractC0356a;
        this.f6449n = k10;
    }

    public static int A(Object obj, long j10) {
        return ((Integer) q0.d.i(obj, j10)).intValue();
    }

    public static long B(Object obj, long j10) {
        return ((Long) q0.d.i(obj, j10)).longValue();
    }

    public static Field H(Class cls, String str) {
        try {
            return cls.getDeclaredField(str);
        } catch (NoSuchFieldException unused) {
            Field[] declaredFields = cls.getDeclaredFields();
            for (Field field : declaredFields) {
                if (str.equals(field.getName())) {
                    return field;
                }
            }
            StringBuilder sbQ = android.support.v4.media.session.a.q("Field ", str, " for ");
            sbQ.append(cls.getName());
            sbQ.append(" not found. Known fields are ");
            sbQ.append(Arrays.toString(declaredFields));
            throw new RuntimeException(sbQ.toString());
        }
    }

    public static int K(int i10) {
        return (i10 & 267386880) >>> 20;
    }

    public static void O(int i10, Object obj, H h10) throws IOException {
        if (!(obj instanceof String)) {
            h10.b(i10, (C0362g) obj);
        } else {
            ((C0365j) h10.f6426a).g0(i10, (String) obj);
        }
    }

    public static List s(Object obj, long j10) {
        return (List) q0.d.i(obj, j10);
    }

    public static O x(X x9, Q q6, E e4, g0 g0Var, C0369n c0369n, K k10) {
        if (x9 instanceof X) {
            return y(x9, q6, e4, g0Var, c0369n, k10);
        }
        android.support.v4.media.session.a.u(x9);
        throw null;
    }

    public static O y(X x9, Q q6, E e4, g0 g0Var, C0369n c0369n, K k10) {
        int i10;
        int iCharAt;
        int iCharAt2;
        int i11;
        int i12;
        int i13;
        int i14;
        int[] iArr;
        int i15;
        int i16;
        char cCharAt;
        int i17;
        char cCharAt2;
        int i18;
        char cCharAt3;
        int i19;
        char cCharAt4;
        int i20;
        char cCharAt5;
        int i21;
        char cCharAt6;
        int i22;
        char cCharAt7;
        int i23;
        char cCharAt8;
        int i24;
        int i25;
        int i26;
        int i27;
        int i28;
        int i29;
        int i30;
        int i31;
        String str;
        char c4;
        int i32;
        int iObjectFieldOffset;
        int i33;
        int i34;
        int i35;
        Field fieldH;
        int i36;
        char cCharAt9;
        int i37;
        int i38;
        int i39;
        Field fieldH2;
        Field fieldH3;
        int i40;
        char cCharAt10;
        int i41;
        char cCharAt11;
        int i42;
        char cCharAt12;
        int i43;
        char cCharAt13;
        char cCharAt14;
        int i44 = 0;
        boolean z3 = x9.d() == 2;
        String strC = x9.c();
        int length = strC.length();
        int iCharAt3 = strC.charAt(0);
        if (iCharAt3 >= 55296) {
            int i45 = iCharAt3 & 8191;
            int i46 = 1;
            int i47 = 13;
            while (true) {
                i10 = i46 + 1;
                cCharAt14 = strC.charAt(i46);
                if (cCharAt14 < 55296) {
                    break;
                }
                i45 |= (cCharAt14 & 8191) << i47;
                i47 += 13;
                i46 = i10;
            }
            iCharAt3 = i45 | (cCharAt14 << i47);
        } else {
            i10 = 1;
        }
        int i48 = i10 + 1;
        int iCharAt4 = strC.charAt(i10);
        if (iCharAt4 >= 55296) {
            int i49 = iCharAt4 & 8191;
            int i50 = 13;
            while (true) {
                i43 = i48 + 1;
                cCharAt13 = strC.charAt(i48);
                if (cCharAt13 < 55296) {
                    break;
                }
                i49 |= (cCharAt13 & 8191) << i50;
                i50 += 13;
                i48 = i43;
            }
            iCharAt4 = i49 | (cCharAt13 << i50);
            i48 = i43;
        }
        if (iCharAt4 == 0) {
            i15 = 0;
            iCharAt = 0;
            iCharAt2 = 0;
            i14 = 0;
            i12 = 0;
            iArr = f6436o;
            i13 = 0;
        } else {
            int i51 = i48 + 1;
            int iCharAt5 = strC.charAt(i48);
            if (iCharAt5 >= 55296) {
                int i52 = iCharAt5 & 8191;
                int i53 = 13;
                while (true) {
                    i23 = i51 + 1;
                    cCharAt8 = strC.charAt(i51);
                    if (cCharAt8 < 55296) {
                        break;
                    }
                    i52 |= (cCharAt8 & 8191) << i53;
                    i53 += 13;
                    i51 = i23;
                }
                iCharAt5 = i52 | (cCharAt8 << i53);
                i51 = i23;
            }
            int i54 = i51 + 1;
            int iCharAt6 = strC.charAt(i51);
            if (iCharAt6 >= 55296) {
                int i55 = iCharAt6 & 8191;
                int i56 = 13;
                while (true) {
                    i22 = i54 + 1;
                    cCharAt7 = strC.charAt(i54);
                    if (cCharAt7 < 55296) {
                        break;
                    }
                    i55 |= (cCharAt7 & 8191) << i56;
                    i56 += 13;
                    i54 = i22;
                }
                iCharAt6 = i55 | (cCharAt7 << i56);
                i54 = i22;
            }
            int i57 = i54 + 1;
            iCharAt = strC.charAt(i54);
            if (iCharAt >= 55296) {
                int i58 = iCharAt & 8191;
                int i59 = 13;
                while (true) {
                    i21 = i57 + 1;
                    cCharAt6 = strC.charAt(i57);
                    if (cCharAt6 < 55296) {
                        break;
                    }
                    i58 |= (cCharAt6 & 8191) << i59;
                    i59 += 13;
                    i57 = i21;
                }
                iCharAt = i58 | (cCharAt6 << i59);
                i57 = i21;
            }
            int i60 = i57 + 1;
            iCharAt2 = strC.charAt(i57);
            if (iCharAt2 >= 55296) {
                int i61 = iCharAt2 & 8191;
                int i62 = 13;
                while (true) {
                    i20 = i60 + 1;
                    cCharAt5 = strC.charAt(i60);
                    if (cCharAt5 < 55296) {
                        break;
                    }
                    i61 |= (cCharAt5 & 8191) << i62;
                    i62 += 13;
                    i60 = i20;
                }
                iCharAt2 = i61 | (cCharAt5 << i62);
                i60 = i20;
            }
            int i63 = i60 + 1;
            int iCharAt7 = strC.charAt(i60);
            if (iCharAt7 >= 55296) {
                int i64 = iCharAt7 & 8191;
                int i65 = 13;
                while (true) {
                    i19 = i63 + 1;
                    cCharAt4 = strC.charAt(i63);
                    if (cCharAt4 < 55296) {
                        break;
                    }
                    i64 |= (cCharAt4 & 8191) << i65;
                    i65 += 13;
                    i63 = i19;
                }
                iCharAt7 = i64 | (cCharAt4 << i65);
                i63 = i19;
            }
            int i66 = i63 + 1;
            int iCharAt8 = strC.charAt(i63);
            if (iCharAt8 >= 55296) {
                int i67 = iCharAt8 & 8191;
                int i68 = 13;
                while (true) {
                    i18 = i66 + 1;
                    cCharAt3 = strC.charAt(i66);
                    if (cCharAt3 < 55296) {
                        break;
                    }
                    i67 |= (cCharAt3 & 8191) << i68;
                    i68 += 13;
                    i66 = i18;
                }
                iCharAt8 = i67 | (cCharAt3 << i68);
                i66 = i18;
            }
            int i69 = i66 + 1;
            int iCharAt9 = strC.charAt(i66);
            if (iCharAt9 >= 55296) {
                int i70 = iCharAt9 & 8191;
                int i71 = i69;
                int i72 = 13;
                while (true) {
                    i17 = i71 + 1;
                    cCharAt2 = strC.charAt(i71);
                    if (cCharAt2 < 55296) {
                        break;
                    }
                    i70 |= (cCharAt2 & 8191) << i72;
                    i72 += 13;
                    i71 = i17;
                }
                iCharAt9 = i70 | (cCharAt2 << i72);
                i11 = i17;
            } else {
                i11 = i69;
            }
            int i73 = i11 + 1;
            int iCharAt10 = strC.charAt(i11);
            if (iCharAt10 >= 55296) {
                int i74 = iCharAt10 & 8191;
                int i75 = i73;
                int i76 = 13;
                while (true) {
                    i16 = i75 + 1;
                    cCharAt = strC.charAt(i75);
                    if (cCharAt < 55296) {
                        break;
                    }
                    i74 |= (cCharAt & 8191) << i76;
                    i76 += 13;
                    i75 = i16;
                }
                iCharAt10 = i74 | (cCharAt << i76);
                i73 = i16;
            }
            int[] iArr2 = new int[iCharAt10 + iCharAt8 + iCharAt9];
            i12 = (iCharAt5 * 2) + iCharAt6;
            i13 = iCharAt8;
            i14 = iCharAt10;
            i44 = iCharAt5;
            i48 = i73;
            int i77 = iCharAt7;
            iArr = iArr2;
            i15 = i77;
        }
        Unsafe unsafe = f6437p;
        Object[] objArrB = x9.b();
        Class<?> cls = x9.a().getClass();
        int i78 = i48;
        int[] iArr3 = new int[i15 * 3];
        Object[] objArr = new Object[i15 * 2];
        int i79 = i14 + i13;
        int i80 = i14;
        int i81 = i78;
        int i82 = i79;
        int i83 = 0;
        int i84 = 0;
        while (i81 < length) {
            int i85 = i81 + 1;
            int iCharAt11 = strC.charAt(i81);
            if (iCharAt11 >= 55296) {
                int i86 = iCharAt11 & 8191;
                int i87 = i85;
                int i88 = 13;
                while (true) {
                    i42 = i87 + 1;
                    cCharAt12 = strC.charAt(i87);
                    i24 = length;
                    if (cCharAt12 < 55296) {
                        break;
                    }
                    i86 |= (cCharAt12 & 8191) << i88;
                    i88 += 13;
                    i87 = i42;
                    length = i24;
                }
                iCharAt11 = i86 | (cCharAt12 << i88);
                i25 = i42;
            } else {
                i24 = length;
                i25 = i85;
            }
            int i89 = i25 + 1;
            int iCharAt12 = strC.charAt(i25);
            if (iCharAt12 >= 55296) {
                int i90 = iCharAt12 & 8191;
                int i91 = i89;
                int i92 = 13;
                while (true) {
                    i41 = i91 + 1;
                    cCharAt11 = strC.charAt(i91);
                    i26 = i14;
                    if (cCharAt11 < 55296) {
                        break;
                    }
                    i90 |= (cCharAt11 & 8191) << i92;
                    i92 += 13;
                    i91 = i41;
                    i14 = i26;
                }
                iCharAt12 = i90 | (cCharAt11 << i92);
                i27 = i41;
            } else {
                i26 = i14;
                i27 = i89;
            }
            int i93 = iCharAt12 & 255;
            boolean z9 = z3;
            if ((iCharAt12 & 1024) != 0) {
                iArr[i83] = i84;
                i83++;
            }
            if (i93 >= 51) {
                int i94 = i27 + 1;
                int iCharAt13 = strC.charAt(i27);
                if (iCharAt13 >= 55296) {
                    int i95 = iCharAt13 & 8191;
                    int i96 = i94;
                    int i97 = 13;
                    while (true) {
                        i40 = i96 + 1;
                        cCharAt10 = strC.charAt(i96);
                        i28 = iCharAt2;
                        if (cCharAt10 < 55296) {
                            break;
                        }
                        i95 |= (cCharAt10 & 8191) << i97;
                        i97 += 13;
                        i96 = i40;
                        iCharAt2 = i28;
                    }
                    iCharAt13 = i95 | (cCharAt10 << i97);
                    i38 = i40;
                } else {
                    i28 = iCharAt2;
                    i38 = i94;
                }
                int i98 = i93 - 51;
                int i99 = i38;
                if (i98 == 9 || i98 == 17) {
                    i39 = 2;
                    objArr[((i84 / 3) * 2) + 1] = objArrB[i12];
                    i12++;
                } else {
                    if (i98 == 12 && (iCharAt3 & 1) == 1) {
                        objArr[((i84 / 3) * 2) + 1] = objArrB[i12];
                        i12++;
                    }
                    i39 = 2;
                }
                int i100 = iCharAt13 * i39;
                Object obj = objArrB[i100];
                if (obj instanceof Field) {
                    fieldH2 = (Field) obj;
                } else {
                    fieldH2 = H(cls, (String) obj);
                    objArrB[i100] = fieldH2;
                }
                int i101 = iCharAt;
                int iObjectFieldOffset2 = (int) unsafe.objectFieldOffset(fieldH2);
                int i102 = i100 + 1;
                Object obj2 = objArrB[i102];
                if (obj2 instanceof Field) {
                    fieldH3 = (Field) obj2;
                } else {
                    fieldH3 = H(cls, (String) obj2);
                    objArrB[i102] = fieldH3;
                }
                i35 = iObjectFieldOffset2;
                c4 = 2;
                i30 = iCharAt12;
                i34 = i12;
                str = strC;
                iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldH3);
                i33 = 0;
                i29 = i101;
                i32 = i99;
            } else {
                i28 = iCharAt2;
                int i103 = iCharAt;
                int i104 = i12 + 1;
                Field fieldH4 = H(cls, (String) objArrB[i12]);
                i29 = i103;
                if (i93 == 9 || i93 == 17) {
                    i30 = iCharAt12;
                    i31 = 1;
                    objArr[((i84 / 3) * 2) + 1] = fieldH4.getType();
                } else {
                    if (i93 == 27 || i93 == 49) {
                        i30 = iCharAt12;
                        i31 = 1;
                        i37 = i12 + 2;
                        objArr[((i84 / 3) * 2) + 1] = objArrB[i104];
                    } else if (i93 == 12 || i93 == 30 || i93 == 44) {
                        i30 = iCharAt12;
                        i31 = 1;
                        if ((iCharAt3 & 1) == 1) {
                            i37 = i12 + 2;
                            objArr[((i84 / 3) * 2) + 1] = objArrB[i104];
                        }
                    } else if (i93 == 50) {
                        int i105 = i80 + 1;
                        iArr[i80] = i84;
                        int i106 = (i84 / 3) * 2;
                        int i107 = i12 + 2;
                        objArr[i106] = objArrB[i104];
                        if ((iCharAt12 & 2048) != 0) {
                            i104 = i12 + 3;
                            objArr[i106 + 1] = objArrB[i107];
                            i30 = iCharAt12;
                            i80 = i105;
                            i31 = 1;
                        } else {
                            i80 = i105;
                            i104 = i107;
                            i30 = iCharAt12;
                            i31 = 1;
                        }
                    } else {
                        i30 = iCharAt12;
                        i31 = 1;
                    }
                    i104 = i37;
                }
                int iObjectFieldOffset3 = (int) unsafe.objectFieldOffset(fieldH4);
                if ((iCharAt3 & 1) != i31 || i93 > 17) {
                    str = strC;
                    c4 = 2;
                    i32 = i27;
                    iObjectFieldOffset = 0;
                    i33 = 0;
                } else {
                    i32 = i27 + 1;
                    int iCharAt14 = strC.charAt(i27);
                    if (iCharAt14 >= 55296) {
                        int i108 = iCharAt14 & 8191;
                        int i109 = 13;
                        while (true) {
                            i36 = i32 + 1;
                            cCharAt9 = strC.charAt(i32);
                            if (cCharAt9 < 55296) {
                                break;
                            }
                            i108 |= (cCharAt9 & 8191) << i109;
                            i109 += 13;
                            i32 = i36;
                        }
                        iCharAt14 = i108 | (cCharAt9 << i109);
                        i32 = i36;
                    }
                    c4 = 2;
                    int i110 = (iCharAt14 / 32) + (i44 * 2);
                    Object obj3 = objArrB[i110];
                    if (obj3 instanceof Field) {
                        fieldH = (Field) obj3;
                    } else {
                        fieldH = H(cls, (String) obj3);
                        objArrB[i110] = fieldH;
                    }
                    str = strC;
                    iObjectFieldOffset = (int) unsafe.objectFieldOffset(fieldH);
                    i33 = iCharAt14 % 32;
                }
                if (i93 >= 18 && i93 <= 49) {
                    iArr[i82] = iObjectFieldOffset3;
                    i82++;
                }
                i34 = i104;
                i35 = iObjectFieldOffset3;
            }
            int i111 = i84 + 1;
            iArr3[i84] = iCharAt11;
            int i112 = i84 + 2;
            int i113 = i34;
            int i114 = i30;
            int i115 = i44;
            iArr3[i111] = ((i114 & 256) != 0 ? 268435456 : 0) | ((i114 & 512) != 0 ? 536870912 : 0) | (i93 << 20) | i35;
            i84 += 3;
            iArr3[i112] = iObjectFieldOffset | (i33 << 20);
            i81 = i32;
            strC = str;
            z3 = z9;
            i12 = i113;
            iCharAt = i29;
            length = i24;
            i14 = i26;
            i44 = i115;
            iCharAt2 = i28;
        }
        return new O(iArr3, objArr, iCharAt, iCharAt2, x9.a(), z3, iArr, i14, i79, q6, e4, g0Var, c0369n, k10);
    }

    public static long z(int i10) {
        return i10 & 1048575;
    }

    public final int C(int i10) {
        if (i10 < this.f6440c || i10 > this.d) {
            return -1;
        }
        int[] iArr = this.f6438a;
        int length = (iArr.length / 3) - 1;
        int i11 = 0;
        while (i11 <= length) {
            int i12 = (length + i11) >>> 1;
            int i13 = i12 * 3;
            int i14 = iArr[i13];
            if (i10 == i14) {
                return i13;
            }
            if (i10 < i14) {
                length = i12 - 1;
            } else {
                i11 = i12 + 1;
            }
        }
        return -1;
    }

    public final void D(Object obj, long j10, Y y9, Z z3, C0368m c0368m) {
        y9.z(this.f6447l.c(obj, j10), z3, c0368m);
    }

    public final void E(Object obj, int i10, Y y9, Z z3, C0368m c0368m) {
        y9.E(this.f6447l.c(obj, i10 & 1048575), z3, c0368m);
    }

    public final void F(Object obj, int i10, Y y9) {
        if ((536870912 & i10) != 0) {
            q0.r(obj, i10 & 1048575, y9.I());
        } else if (this.f6442f) {
            q0.r(obj, i10 & 1048575, y9.n());
        } else {
            q0.r(obj, i10 & 1048575, y9.v());
        }
    }

    public final void G(Object obj, int i10, Y y9) {
        boolean z3 = (536870912 & i10) != 0;
        E e4 = this.f6447l;
        if (z3) {
            y9.u(e4.c(obj, i10 & 1048575));
        } else {
            y9.r(e4.c(obj, i10 & 1048575));
        }
    }

    public final void I(int i10, Object obj) {
        if (this.g) {
            return;
        }
        int i11 = this.f6438a[i10 + 2];
        long j10 = i11 & 1048575;
        q0.p(obj, j10, q0.d.g(obj, j10) | (1 << (i11 >>> 20)));
    }

    public final void J(int i10, int i11, Object obj) {
        q0.p(obj, this.f6438a[i11 + 2] & 1048575, i10);
    }

    public final int L(int i10) {
        return this.f6438a[i10 + 1];
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public final void M(Object obj, H h10) throws IOException {
        int i10;
        boolean z3;
        int[] iArr = this.f6438a;
        int length = iArr.length;
        Unsafe unsafe = f6437p;
        int i11 = -1;
        int i12 = 0;
        for (int i13 = 0; i13 < length; i13 += 3) {
            int iL = L(i13);
            int i14 = iArr[i13];
            int iK = K(iL);
            if (this.g || iK > 17) {
                i10 = 0;
            } else {
                int i15 = iArr[i13 + 2];
                int i16 = i15 & 1048575;
                if (i16 != i11) {
                    i12 = unsafe.getInt(obj, i16);
                    i11 = i16;
                }
                i10 = 1 << (i15 >>> 20);
            }
            long j10 = iL & 1048575;
            switch (iK) {
                case 0:
                    if ((i10 & i12) != 0) {
                        h10.c(i14, q0.d.e(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 1:
                    if ((i10 & i12) != 0) {
                        h10.g(i14, q0.d.f(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 2:
                    if ((i10 & i12) != 0) {
                        h10.j(i14, unsafe.getLong(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 3:
                    if ((i10 & i12) != 0) {
                        h10.q(i14, unsafe.getLong(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 4:
                    if ((i10 & i12) != 0) {
                        h10.i(i14, unsafe.getInt(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 5:
                    if ((i10 & i12) != 0) {
                        h10.f(i14, unsafe.getLong(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                    if ((i10 & i12) != 0) {
                        h10.e(i14, unsafe.getInt(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                    if ((i10 & i12) != 0) {
                        h10.a(i14, q0.d.c(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 8:
                    if ((i10 & i12) != 0) {
                        O(i14, unsafe.getObject(obj, j10), h10);
                        break;
                    } else {
                        break;
                    }
                case 9:
                    if ((i10 & i12) != 0) {
                        h10.k(i14, unsafe.getObject(obj, j10), n(i13));
                        break;
                    } else {
                        break;
                    }
                case 10:
                    if ((i10 & i12) != 0) {
                        h10.b(i14, (C0362g) unsafe.getObject(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case ModuleDescriptor.MODULE_VERSION /* 11 */:
                    if ((i10 & i12) != 0) {
                        h10.p(i14, unsafe.getInt(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 12:
                    if ((i10 & i12) != 0) {
                        h10.d(i14, unsafe.getInt(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 13:
                    if ((i10 & i12) != 0) {
                        h10.l(i14, unsafe.getInt(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 14:
                    if ((i10 & i12) != 0) {
                        h10.m(i14, unsafe.getLong(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 15:
                    if ((i10 & i12) != 0) {
                        h10.n(i14, unsafe.getInt(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 16:
                    if ((i10 & i12) != 0) {
                        h10.o(i14, unsafe.getLong(obj, j10));
                        break;
                    } else {
                        break;
                    }
                case 17:
                    if ((i10 & i12) != 0) {
                        h10.h(i14, unsafe.getObject(obj, j10), n(i13));
                        break;
                    } else {
                        break;
                    }
                case 18:
                    a0.F(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 19:
                    a0.J(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 20:
                    a0.M(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 21:
                    a0.U(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 22:
                    a0.L(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 23:
                    a0.I(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 24:
                    a0.H(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 25:
                    a0.D(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 26:
                    a0.S(iArr[i13], (List) unsafe.getObject(obj, j10), h10);
                    break;
                case 27:
                    a0.N(iArr[i13], (List) unsafe.getObject(obj, j10), h10, n(i13));
                    break;
                case 28:
                    a0.E(iArr[i13], (List) unsafe.getObject(obj, j10), h10);
                    break;
                case 29:
                    z3 = false;
                    a0.T(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 30:
                    z3 = false;
                    a0.G(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 31:
                    z3 = false;
                    a0.O(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 32:
                    z3 = false;
                    a0.P(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 33:
                    z3 = false;
                    a0.Q(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 34:
                    z3 = false;
                    a0.R(iArr[i13], (List) unsafe.getObject(obj, j10), h10, false);
                    break;
                case 35:
                    a0.F(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 36:
                    a0.J(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 37:
                    a0.M(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 38:
                    a0.U(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 39:
                    a0.L(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 40:
                    a0.I(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 41:
                    a0.H(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 42:
                    a0.D(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 43:
                    a0.T(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 44:
                    a0.G(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 45:
                    a0.O(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 46:
                    a0.P(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 47:
                    a0.Q(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 48:
                    a0.R(iArr[i13], (List) unsafe.getObject(obj, j10), h10, true);
                    break;
                case 49:
                    a0.K(iArr[i13], (List) unsafe.getObject(obj, j10), h10, n(i13));
                    break;
                case 50:
                    N(h10, i14, unsafe.getObject(obj, j10), i13);
                    break;
                case 51:
                    if (r(i14, i13, obj)) {
                        h10.c(i14, ((Double) q0.d.i(obj, j10)).doubleValue());
                    }
                    break;
                case 52:
                    if (r(i14, i13, obj)) {
                        h10.g(i14, ((Float) q0.d.i(obj, j10)).floatValue());
                    }
                    break;
                case 53:
                    if (r(i14, i13, obj)) {
                        h10.j(i14, B(obj, j10));
                    }
                    break;
                case 54:
                    if (r(i14, i13, obj)) {
                        h10.q(i14, B(obj, j10));
                    }
                    break;
                case 55:
                    if (r(i14, i13, obj)) {
                        h10.i(i14, A(obj, j10));
                    }
                    break;
                case 56:
                    if (r(i14, i13, obj)) {
                        h10.f(i14, B(obj, j10));
                    }
                    break;
                case 57:
                    if (r(i14, i13, obj)) {
                        h10.e(i14, A(obj, j10));
                    }
                    break;
                case 58:
                    if (r(i14, i13, obj)) {
                        h10.a(i14, ((Boolean) q0.d.i(obj, j10)).booleanValue());
                    }
                    break;
                case 59:
                    if (r(i14, i13, obj)) {
                        O(i14, unsafe.getObject(obj, j10), h10);
                    }
                    break;
                case 60:
                    if (r(i14, i13, obj)) {
                        h10.k(i14, unsafe.getObject(obj, j10), n(i13));
                    }
                    break;
                case 61:
                    if (r(i14, i13, obj)) {
                        h10.b(i14, (C0362g) unsafe.getObject(obj, j10));
                    }
                    break;
                case 62:
                    if (r(i14, i13, obj)) {
                        h10.p(i14, A(obj, j10));
                    }
                    break;
                case 63:
                    if (r(i14, i13, obj)) {
                        h10.d(i14, A(obj, j10));
                    }
                    break;
                case 64:
                    if (r(i14, i13, obj)) {
                        h10.l(i14, A(obj, j10));
                    }
                    break;
                case 65:
                    if (r(i14, i13, obj)) {
                        h10.m(i14, B(obj, j10));
                    }
                    break;
                case 66:
                    if (r(i14, i13, obj)) {
                        h10.n(i14, A(obj, j10));
                    }
                    break;
                case 67:
                    if (r(i14, i13, obj)) {
                        h10.o(i14, B(obj, j10));
                    }
                    break;
                case 68:
                    if (r(i14, i13, obj)) {
                        h10.h(i14, unsafe.getObject(obj, j10), n(i13));
                    }
                    break;
            }
        }
        ((i0) this.f6448m).getClass();
        ((AbstractC0376v) obj).unknownFields.d(h10);
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x013a  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x0148  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x015a  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x016b  */
    /* JADX WARN: Removed duplicated region for block: B:51:0x0172  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x017b  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0187  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0193  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x01a9  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x01b4  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01bb  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x01cd  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x01d4  */
    /* JADX WARN: Removed duplicated region for block: B:68:0x01da  */
    /* JADX WARN: Removed duplicated region for block: B:69:0x01e0  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x01eb  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x01f6  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x0201  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0208  */
    /* JADX WARN: Removed duplicated region for block: B:78:0x0142 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void N(androidx.datastore.preferences.protobuf.H r22, int r23, java.lang.Object r24, int r25) throws java.io.IOException {
        /*
            Method dump skipped, instructions count: 632
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.O.N(androidx.datastore.preferences.protobuf.H, int, java.lang.Object, int):void");
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void a(Object obj, Y y9, C0368m c0368m) throws Throwable {
        c0368m.getClass();
        t(this.f6448m, obj, y9, c0368m);
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void b(Object obj, Object obj2) {
        obj2.getClass();
        int i10 = 0;
        while (true) {
            int[] iArr = this.f6438a;
            if (i10 >= iArr.length) {
                if (this.g) {
                    return;
                }
                a0.B(this.f6448m, obj, obj2);
                return;
            }
            int iL = L(i10);
            long j10 = 1048575 & iL;
            int i11 = iArr[i10];
            switch (K(iL)) {
                case 0:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        p0 p0Var = q0.d;
                        p0Var.m(obj, j10, p0Var.e(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 1:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        p0 p0Var2 = q0.d;
                        p0Var2.n(obj, j10, p0Var2.f(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 2:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.q(obj, j10, q0.d.h(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 3:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.q(obj, j10, q0.d.h(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 4:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.p(obj, j10, q0.d.g(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 5:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.q(obj, j10, q0.d.h(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.p(obj, j10, q0.d.g(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        p0 p0Var3 = q0.d;
                        p0Var3.k(obj, j10, p0Var3.c(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 8:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.r(obj, j10, q0.d.i(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 9:
                    v(i10, obj, obj2);
                    break;
                case 10:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.r(obj, j10, q0.d.i(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case ModuleDescriptor.MODULE_VERSION /* 11 */:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.p(obj, j10, q0.d.g(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 12:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.p(obj, j10, q0.d.g(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 13:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.p(obj, j10, q0.d.g(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 14:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.q(obj, j10, q0.d.h(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 15:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.p(obj, j10, q0.d.g(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 16:
                    if (!q(i10, obj2)) {
                        break;
                    } else {
                        q0.q(obj, j10, q0.d.h(obj2, j10));
                        I(i10, obj);
                        break;
                    }
                case 17:
                    v(i10, obj, obj2);
                    break;
                case 18:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                case 49:
                    this.f6447l.b(obj, j10, obj2);
                    break;
                case 50:
                    Class cls = a0.f6463a;
                    p0 p0Var4 = q0.d;
                    Object objI = p0Var4.i(obj, j10);
                    Object objI2 = p0Var4.i(obj2, j10);
                    this.f6449n.getClass();
                    q0.r(obj, j10, K.b(objI, objI2));
                    break;
                case 51:
                case 52:
                case 53:
                case 54:
                case 55:
                case 56:
                case 57:
                case 58:
                case 59:
                    if (!r(i11, i10, obj2)) {
                        break;
                    } else {
                        q0.r(obj, j10, q0.d.i(obj2, j10));
                        J(i11, i10, obj);
                        break;
                    }
                case 60:
                    w(i10, obj, obj2);
                    break;
                case 61:
                case 62:
                case 63:
                case 64:
                case 65:
                case 66:
                case 67:
                    if (!r(i11, i10, obj2)) {
                        break;
                    } else {
                        q0.r(obj, j10, q0.d.i(obj2, j10));
                        J(i11, i10, obj);
                        break;
                    }
                case 68:
                    w(i10, obj, obj2);
                    break;
            }
            i10 += 3;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void c(Object obj, H h10) throws IOException {
        h10.getClass();
        if (!this.g) {
            M(obj, h10);
            return;
        }
        int[] iArr = this.f6438a;
        int length = iArr.length;
        for (int i10 = 0; i10 < length; i10 += 3) {
            int iL = L(i10);
            int i11 = iArr[i10];
            switch (K(iL)) {
                case 0:
                    if (q(i10, obj)) {
                        h10.c(i11, q0.d.e(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 1:
                    if (q(i10, obj)) {
                        h10.g(i11, q0.d.f(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 2:
                    if (q(i10, obj)) {
                        h10.j(i11, q0.d.h(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 3:
                    if (q(i10, obj)) {
                        h10.q(i11, q0.d.h(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 4:
                    if (q(i10, obj)) {
                        h10.i(i11, q0.d.g(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 5:
                    if (q(i10, obj)) {
                        h10.f(i11, q0.d.h(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                    if (q(i10, obj)) {
                        h10.e(i11, q0.d.g(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                    if (q(i10, obj)) {
                        h10.a(i11, q0.d.c(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 8:
                    if (q(i10, obj)) {
                        O(i11, q0.d.i(obj, iL & 1048575), h10);
                        break;
                    } else {
                        break;
                    }
                case 9:
                    if (q(i10, obj)) {
                        h10.k(i11, q0.d.i(obj, iL & 1048575), n(i10));
                        break;
                    } else {
                        break;
                    }
                case 10:
                    if (q(i10, obj)) {
                        h10.b(i11, (C0362g) q0.d.i(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case ModuleDescriptor.MODULE_VERSION /* 11 */:
                    if (q(i10, obj)) {
                        h10.p(i11, q0.d.g(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 12:
                    if (q(i10, obj)) {
                        h10.d(i11, q0.d.g(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 13:
                    if (q(i10, obj)) {
                        h10.l(i11, q0.d.g(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 14:
                    if (q(i10, obj)) {
                        h10.m(i11, q0.d.h(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 15:
                    if (q(i10, obj)) {
                        h10.n(i11, q0.d.g(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 16:
                    if (q(i10, obj)) {
                        h10.o(i11, q0.d.h(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 17:
                    if (q(i10, obj)) {
                        h10.h(i11, q0.d.i(obj, iL & 1048575), n(i10));
                        break;
                    } else {
                        break;
                    }
                case 18:
                    a0.F(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 19:
                    a0.J(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 20:
                    a0.M(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 21:
                    a0.U(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 22:
                    a0.L(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 23:
                    a0.I(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 24:
                    a0.H(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 25:
                    a0.D(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 26:
                    a0.S(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10);
                    break;
                case 27:
                    a0.N(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, n(i10));
                    break;
                case 28:
                    a0.E(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10);
                    break;
                case 29:
                    a0.T(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 30:
                    a0.G(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 31:
                    a0.O(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 32:
                    a0.P(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 33:
                    a0.Q(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 34:
                    a0.R(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, false);
                    break;
                case 35:
                    a0.F(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 36:
                    a0.J(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 37:
                    a0.M(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 38:
                    a0.U(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 39:
                    a0.L(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 40:
                    a0.I(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 41:
                    a0.H(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 42:
                    a0.D(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 43:
                    a0.T(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 44:
                    a0.G(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 45:
                    a0.O(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 46:
                    a0.P(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 47:
                    a0.Q(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 48:
                    a0.R(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, true);
                    break;
                case 49:
                    a0.K(iArr[i10], (List) q0.d.i(obj, iL & 1048575), h10, n(i10));
                    break;
                case 50:
                    N(h10, i11, q0.d.i(obj, iL & 1048575), i10);
                    break;
                case 51:
                    if (r(i11, i10, obj)) {
                        h10.c(i11, ((Double) q0.d.i(obj, iL & 1048575)).doubleValue());
                        break;
                    } else {
                        break;
                    }
                case 52:
                    if (r(i11, i10, obj)) {
                        h10.g(i11, ((Float) q0.d.i(obj, iL & 1048575)).floatValue());
                        break;
                    } else {
                        break;
                    }
                case 53:
                    if (r(i11, i10, obj)) {
                        h10.j(i11, B(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 54:
                    if (r(i11, i10, obj)) {
                        h10.q(i11, B(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 55:
                    if (r(i11, i10, obj)) {
                        h10.i(i11, A(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 56:
                    if (r(i11, i10, obj)) {
                        h10.f(i11, B(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 57:
                    if (r(i11, i10, obj)) {
                        h10.e(i11, A(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 58:
                    if (r(i11, i10, obj)) {
                        h10.a(i11, ((Boolean) q0.d.i(obj, iL & 1048575)).booleanValue());
                        break;
                    } else {
                        break;
                    }
                case 59:
                    if (r(i11, i10, obj)) {
                        O(i11, q0.d.i(obj, iL & 1048575), h10);
                        break;
                    } else {
                        break;
                    }
                case 60:
                    if (r(i11, i10, obj)) {
                        h10.k(i11, q0.d.i(obj, iL & 1048575), n(i10));
                        break;
                    } else {
                        break;
                    }
                case 61:
                    if (r(i11, i10, obj)) {
                        h10.b(i11, (C0362g) q0.d.i(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 62:
                    if (r(i11, i10, obj)) {
                        h10.p(i11, A(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 63:
                    if (r(i11, i10, obj)) {
                        h10.d(i11, A(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 64:
                    if (r(i11, i10, obj)) {
                        h10.l(i11, A(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 65:
                    if (r(i11, i10, obj)) {
                        h10.m(i11, B(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 66:
                    if (r(i11, i10, obj)) {
                        h10.n(i11, A(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 67:
                    if (r(i11, i10, obj)) {
                        h10.o(i11, B(obj, iL & 1048575));
                        break;
                    } else {
                        break;
                    }
                case 68:
                    if (r(i11, i10, obj)) {
                        h10.h(i11, q0.d.i(obj, iL & 1048575), n(i10));
                        break;
                    } else {
                        break;
                    }
            }
        }
        ((i0) this.f6448m).getClass();
        ((AbstractC0376v) obj).unknownFields.d(h10);
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final void d(Object obj) {
        int[] iArr;
        int i10;
        int i11 = this.f6444i;
        while (true) {
            iArr = this.f6443h;
            i10 = this.f6445j;
            if (i11 >= i10) {
                break;
            }
            long jL = L(iArr[i11]) & 1048575;
            Object objI = q0.d.i(obj, jL);
            if (objI != null) {
                this.f6449n.getClass();
                ((J) objI).f6431a = false;
                q0.r(obj, jL, objI);
            }
            i11++;
        }
        int length = iArr.length;
        while (i10 < length) {
            this.f6447l.a(obj, iArr[i10]);
            i10++;
        }
        ((i0) this.f6448m).getClass();
        ((AbstractC0376v) obj).unknownFields.f6500e = false;
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x00d6  */
    @Override // androidx.datastore.preferences.protobuf.Z
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean e(java.lang.Object r15) {
        /*
            Method dump skipped, instructions count: 296
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.O.e(java.lang.Object):boolean");
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x003d  */
    @Override // androidx.datastore.preferences.protobuf.Z
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final boolean f(java.lang.Object r12, java.lang.Object r13) {
        /*
            Method dump skipped, instructions count: 670
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.O.f(java.lang.Object, java.lang.Object):boolean");
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final int g(Object obj) {
        return this.g ? p(obj) : o(obj);
    }

    @Override // androidx.datastore.preferences.protobuf.Z
    public final Object h() {
        this.f6446k.getClass();
        return ((AbstractC0376v) this.f6441e).d(4);
    }

    /* JADX WARN: Removed duplicated region for block: B:42:0x00e1 A[PHI: r3
  0x00e1: PHI (r3v32 int) = (r3v10 int), (r3v33 int) binds: [B:83:0x0216, B:41:0x00df] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // androidx.datastore.preferences.protobuf.Z
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int i(java.lang.Object r12) {
        /*
            Method dump skipped, instructions count: 798
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.O.i(java.lang.Object):int");
    }

    public final boolean j(int i10, Object obj, Object obj2) {
        return q(i10, obj) == q(i10, obj2);
    }

    public final void k(int i10, Object obj, Object obj2) {
        int i11 = this.f6438a[i10];
        if (q0.d.i(obj, L(i10) & 1048575) == null) {
            return;
        }
        l(i10);
    }

    public final void l(int i10) {
        android.support.v4.media.session.a.u(this.f6439b[((i10 / 3) * 2) + 1]);
    }

    public final Object m(int i10) {
        return this.f6439b[(i10 / 3) * 2];
    }

    public final Z n(int i10) {
        int i11 = (i10 / 3) * 2;
        Object[] objArr = this.f6439b;
        Z z3 = (Z) objArr[i11];
        if (z3 != null) {
            return z3;
        }
        Z zA = V.f6455c.a((Class) objArr[i11 + 1]);
        objArr[i11] = zA;
        return zA;
    }

    public final int o(Object obj) {
        int i10;
        int iV;
        int iT;
        Unsafe unsafe = f6437p;
        int i11 = -1;
        int i12 = 0;
        int iF = 0;
        int i13 = 0;
        while (true) {
            int[] iArr = this.f6438a;
            if (i12 >= iArr.length) {
                ((i0) this.f6448m).getClass();
                return ((AbstractC0376v) obj).unknownFields.a() + iF;
            }
            int iL = L(i12);
            int i14 = iArr[i12];
            int iK = K(iL);
            if (iK <= 17) {
                int i15 = iArr[i12 + 2];
                int i16 = i15 & 1048575;
                i10 = 1 << (i15 >>> 20);
                if (i16 != i11) {
                    i13 = unsafe.getInt(obj, i16);
                    i11 = i16;
                }
            } else {
                i10 = 0;
            }
            long j10 = iL & 1048575;
            switch (iK) {
                case 0:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.v(i14);
                        iF += iV;
                        break;
                    }
                case 1:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.z(i14);
                        iF += iV;
                        break;
                    }
                case 2:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.D(i14, unsafe.getLong(obj, j10));
                        iF += iV;
                        break;
                    }
                case 3:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.N(i14, unsafe.getLong(obj, j10));
                        iF += iV;
                        break;
                    }
                case 4:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.B(i14, unsafe.getInt(obj, j10));
                        iF += iV;
                        break;
                    }
                case 5:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.y(i14);
                        iF += iV;
                        break;
                    }
                case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.x(i14);
                        iF += iV;
                        break;
                    }
                case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.s(i14);
                        iF += iV;
                        break;
                    }
                case 8:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        Object object = unsafe.getObject(obj, j10);
                        iT = object instanceof C0362g ? C0365j.t(i14, (C0362g) object) : C0365j.I(i14, (String) object);
                        iF = iT + iF;
                        break;
                    }
                case 9:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = a0.o(i14, unsafe.getObject(obj, j10), n(i12));
                        iF += iV;
                        break;
                    }
                case 10:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.t(i14, (C0362g) unsafe.getObject(obj, j10));
                        iF += iV;
                        break;
                    }
                case ModuleDescriptor.MODULE_VERSION /* 11 */:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.L(i14, unsafe.getInt(obj, j10));
                        iF += iV;
                        break;
                    }
                case 12:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.w(i14, unsafe.getInt(obj, j10));
                        iF += iV;
                        break;
                    }
                case 13:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.E(i14);
                        iF += iV;
                        break;
                    }
                case 14:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.F(i14);
                        iF += iV;
                        break;
                    }
                case 15:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.G(i14, unsafe.getInt(obj, j10));
                        iF += iV;
                        break;
                    }
                case 16:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.H(i14, unsafe.getLong(obj, j10));
                        iF += iV;
                        break;
                    }
                case 17:
                    if ((i10 & i13) == 0) {
                        break;
                    } else {
                        iV = C0365j.A(i14, (AbstractC0356a) unsafe.getObject(obj, j10), n(i12));
                        iF += iV;
                        break;
                    }
                case 18:
                    iV = a0.h(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 19:
                    iV = a0.f(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 20:
                    iV = a0.m(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 21:
                    iV = a0.x(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 22:
                    iV = a0.k(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 23:
                    iV = a0.h(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 24:
                    iV = a0.f(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 25:
                    iV = a0.a(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 26:
                    iV = a0.u(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 27:
                    iV = a0.p(i14, (List) unsafe.getObject(obj, j10), n(i12));
                    iF += iV;
                    break;
                case 28:
                    iV = a0.c(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 29:
                    iV = a0.v(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 30:
                    iV = a0.d(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 31:
                    iV = a0.f(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 32:
                    iV = a0.h(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 33:
                    iV = a0.q(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 34:
                    iV = a0.s(i14, (List) unsafe.getObject(obj, j10));
                    iF += iV;
                    break;
                case 35:
                    int i17 = a0.i((List) unsafe.getObject(obj, j10));
                    if (i17 <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(i17, C0365j.K(i14), i17, iF);
                        break;
                    }
                case 36:
                    int iG = a0.g((List) unsafe.getObject(obj, j10));
                    if (iG <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iG, C0365j.K(i14), iG, iF);
                        break;
                    }
                case 37:
                    int iN = a0.n((List) unsafe.getObject(obj, j10));
                    if (iN <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iN, C0365j.K(i14), iN, iF);
                        break;
                    }
                case 38:
                    int iY = a0.y((List) unsafe.getObject(obj, j10));
                    if (iY <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iY, C0365j.K(i14), iY, iF);
                        break;
                    }
                case 39:
                    int iL2 = a0.l((List) unsafe.getObject(obj, j10));
                    if (iL2 <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iL2, C0365j.K(i14), iL2, iF);
                        break;
                    }
                case 40:
                    int i18 = a0.i((List) unsafe.getObject(obj, j10));
                    if (i18 <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(i18, C0365j.K(i14), i18, iF);
                        break;
                    }
                case 41:
                    int iG2 = a0.g((List) unsafe.getObject(obj, j10));
                    if (iG2 <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iG2, C0365j.K(i14), iG2, iF);
                        break;
                    }
                case 42:
                    int iB = a0.b((List) unsafe.getObject(obj, j10));
                    if (iB <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iB, C0365j.K(i14), iB, iF);
                        break;
                    }
                case 43:
                    int iW = a0.w((List) unsafe.getObject(obj, j10));
                    if (iW <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iW, C0365j.K(i14), iW, iF);
                        break;
                    }
                case 44:
                    int iE = a0.e((List) unsafe.getObject(obj, j10));
                    if (iE <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iE, C0365j.K(i14), iE, iF);
                        break;
                    }
                case 45:
                    int iG3 = a0.g((List) unsafe.getObject(obj, j10));
                    if (iG3 <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iG3, C0365j.K(i14), iG3, iF);
                        break;
                    }
                case 46:
                    int i19 = a0.i((List) unsafe.getObject(obj, j10));
                    if (i19 <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(i19, C0365j.K(i14), i19, iF);
                        break;
                    }
                case 47:
                    int iR = a0.r((List) unsafe.getObject(obj, j10));
                    if (iR <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iR, C0365j.K(i14), iR, iF);
                        break;
                    }
                case 48:
                    int iT2 = a0.t((List) unsafe.getObject(obj, j10));
                    if (iT2 <= 0) {
                        break;
                    } else {
                        iF = android.support.v4.media.session.a.f(iT2, C0365j.K(i14), iT2, iF);
                        break;
                    }
                case 49:
                    iV = a0.j(i14, (List) unsafe.getObject(obj, j10), n(i12));
                    iF += iV;
                    break;
                case 50:
                    Object object2 = unsafe.getObject(obj, j10);
                    Object objM = m(i12);
                    this.f6449n.getClass();
                    iV = K.a(i14, object2, objM);
                    iF += iV;
                    break;
                case 51:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.v(i14);
                        iF += iV;
                        break;
                    }
                case 52:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.z(i14);
                        iF += iV;
                        break;
                    }
                case 53:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.D(i14, B(obj, j10));
                        iF += iV;
                        break;
                    }
                case 54:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.N(i14, B(obj, j10));
                        iF += iV;
                        break;
                    }
                case 55:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.B(i14, A(obj, j10));
                        iF += iV;
                        break;
                    }
                case 56:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.y(i14);
                        iF += iV;
                        break;
                    }
                case 57:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.x(i14);
                        iF += iV;
                        break;
                    }
                case 58:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.s(i14);
                        iF += iV;
                        break;
                    }
                case 59:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        Object object3 = unsafe.getObject(obj, j10);
                        iT = object3 instanceof C0362g ? C0365j.t(i14, (C0362g) object3) : C0365j.I(i14, (String) object3);
                        iF = iT + iF;
                        break;
                    }
                case 60:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = a0.o(i14, unsafe.getObject(obj, j10), n(i12));
                        iF += iV;
                        break;
                    }
                case 61:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.t(i14, (C0362g) unsafe.getObject(obj, j10));
                        iF += iV;
                        break;
                    }
                case 62:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.L(i14, A(obj, j10));
                        iF += iV;
                        break;
                    }
                case 63:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.w(i14, A(obj, j10));
                        iF += iV;
                        break;
                    }
                case 64:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.E(i14);
                        iF += iV;
                        break;
                    }
                case 65:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.F(i14);
                        iF += iV;
                        break;
                    }
                case 66:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.G(i14, A(obj, j10));
                        iF += iV;
                        break;
                    }
                case 67:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.H(i14, B(obj, j10));
                        iF += iV;
                        break;
                    }
                case 68:
                    if (!r(i14, i12, obj)) {
                        break;
                    } else {
                        iV = C0365j.A(i14, (AbstractC0356a) unsafe.getObject(obj, j10), n(i12));
                        iF += iV;
                        break;
                    }
            }
            i12 += 3;
        }
    }

    public final int p(Object obj) {
        int iV;
        Unsafe unsafe = f6437p;
        int i10 = 0;
        int iF = 0;
        while (true) {
            int[] iArr = this.f6438a;
            if (i10 >= iArr.length) {
                ((i0) this.f6448m).getClass();
                return ((AbstractC0376v) obj).unknownFields.a() + iF;
            }
            int iL = L(i10);
            int iK = K(iL);
            int i11 = iArr[i10];
            long j10 = iL & 1048575;
            if (iK >= EnumC0372q.f6522b.a() && iK <= EnumC0372q.f6523c.a()) {
                int i12 = iArr[i10 + 2];
            }
            switch (iK) {
                case 0:
                    if (q(i10, obj)) {
                        iV = C0365j.v(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 1:
                    if (q(i10, obj)) {
                        iV = C0365j.z(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 2:
                    if (q(i10, obj)) {
                        iV = C0365j.D(i11, q0.j(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 3:
                    if (q(i10, obj)) {
                        iV = C0365j.N(i11, q0.j(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 4:
                    if (q(i10, obj)) {
                        iV = C0365j.B(i11, q0.i(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 5:
                    if (q(i10, obj)) {
                        iV = C0365j.y(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                    if (q(i10, obj)) {
                        iV = C0365j.x(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                    if (q(i10, obj)) {
                        iV = C0365j.s(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 8:
                    if (q(i10, obj)) {
                        Object objK = q0.k(obj, j10);
                        if (!(objK instanceof C0362g)) {
                            iV = C0365j.I(i11, (String) objK);
                            break;
                        } else {
                            iV = C0365j.t(i11, (C0362g) objK);
                            break;
                        }
                    } else {
                        i10 += 3;
                    }
                case 9:
                    if (q(i10, obj)) {
                        iV = a0.o(i11, q0.k(obj, j10), n(i10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 10:
                    if (q(i10, obj)) {
                        iV = C0365j.t(i11, (C0362g) q0.k(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case ModuleDescriptor.MODULE_VERSION /* 11 */:
                    if (q(i10, obj)) {
                        iV = C0365j.L(i11, q0.i(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 12:
                    if (q(i10, obj)) {
                        iV = C0365j.w(i11, q0.i(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 13:
                    if (q(i10, obj)) {
                        iV = C0365j.E(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 14:
                    if (q(i10, obj)) {
                        iV = C0365j.F(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 15:
                    if (q(i10, obj)) {
                        iV = C0365j.G(i11, q0.i(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 16:
                    if (q(i10, obj)) {
                        iV = C0365j.H(i11, q0.j(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 17:
                    if (q(i10, obj)) {
                        iV = C0365j.A(i11, (AbstractC0356a) q0.k(obj, j10), n(i10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 18:
                    iV = a0.h(i11, s(obj, j10));
                    break;
                case 19:
                    iV = a0.f(i11, s(obj, j10));
                    break;
                case 20:
                    iV = a0.m(i11, s(obj, j10));
                    break;
                case 21:
                    iV = a0.x(i11, s(obj, j10));
                    break;
                case 22:
                    iV = a0.k(i11, s(obj, j10));
                    break;
                case 23:
                    iV = a0.h(i11, s(obj, j10));
                    break;
                case 24:
                    iV = a0.f(i11, s(obj, j10));
                    break;
                case 25:
                    iV = a0.a(i11, s(obj, j10));
                    break;
                case 26:
                    iV = a0.u(i11, s(obj, j10));
                    break;
                case 27:
                    iV = a0.p(i11, s(obj, j10), n(i10));
                    break;
                case 28:
                    iV = a0.c(i11, s(obj, j10));
                    break;
                case 29:
                    iV = a0.v(i11, s(obj, j10));
                    break;
                case 30:
                    iV = a0.d(i11, s(obj, j10));
                    break;
                case 31:
                    iV = a0.f(i11, s(obj, j10));
                    break;
                case 32:
                    iV = a0.h(i11, s(obj, j10));
                    break;
                case 33:
                    iV = a0.q(i11, s(obj, j10));
                    break;
                case 34:
                    iV = a0.s(i11, s(obj, j10));
                    break;
                case 35:
                    int i13 = a0.i((List) unsafe.getObject(obj, j10));
                    if (i13 > 0) {
                        iF = android.support.v4.media.session.a.f(i13, C0365j.K(i11), i13, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 36:
                    int iG = a0.g((List) unsafe.getObject(obj, j10));
                    if (iG > 0) {
                        iF = android.support.v4.media.session.a.f(iG, C0365j.K(i11), iG, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 37:
                    int iN = a0.n((List) unsafe.getObject(obj, j10));
                    if (iN > 0) {
                        iF = android.support.v4.media.session.a.f(iN, C0365j.K(i11), iN, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 38:
                    int iY = a0.y((List) unsafe.getObject(obj, j10));
                    if (iY > 0) {
                        iF = android.support.v4.media.session.a.f(iY, C0365j.K(i11), iY, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 39:
                    int iL2 = a0.l((List) unsafe.getObject(obj, j10));
                    if (iL2 > 0) {
                        iF = android.support.v4.media.session.a.f(iL2, C0365j.K(i11), iL2, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 40:
                    int i14 = a0.i((List) unsafe.getObject(obj, j10));
                    if (i14 > 0) {
                        iF = android.support.v4.media.session.a.f(i14, C0365j.K(i11), i14, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 41:
                    int iG2 = a0.g((List) unsafe.getObject(obj, j10));
                    if (iG2 > 0) {
                        iF = android.support.v4.media.session.a.f(iG2, C0365j.K(i11), iG2, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 42:
                    int iB = a0.b((List) unsafe.getObject(obj, j10));
                    if (iB > 0) {
                        iF = android.support.v4.media.session.a.f(iB, C0365j.K(i11), iB, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 43:
                    int iW = a0.w((List) unsafe.getObject(obj, j10));
                    if (iW > 0) {
                        iF = android.support.v4.media.session.a.f(iW, C0365j.K(i11), iW, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 44:
                    int iE = a0.e((List) unsafe.getObject(obj, j10));
                    if (iE > 0) {
                        iF = android.support.v4.media.session.a.f(iE, C0365j.K(i11), iE, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 45:
                    int iG3 = a0.g((List) unsafe.getObject(obj, j10));
                    if (iG3 > 0) {
                        iF = android.support.v4.media.session.a.f(iG3, C0365j.K(i11), iG3, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 46:
                    int i15 = a0.i((List) unsafe.getObject(obj, j10));
                    if (i15 > 0) {
                        iF = android.support.v4.media.session.a.f(i15, C0365j.K(i11), i15, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 47:
                    int iR = a0.r((List) unsafe.getObject(obj, j10));
                    if (iR > 0) {
                        iF = android.support.v4.media.session.a.f(iR, C0365j.K(i11), iR, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 48:
                    int iT = a0.t((List) unsafe.getObject(obj, j10));
                    if (iT > 0) {
                        iF = android.support.v4.media.session.a.f(iT, C0365j.K(i11), iT, iF);
                    } else {
                        continue;
                    }
                    i10 += 3;
                case 49:
                    iV = a0.j(i11, s(obj, j10), n(i10));
                    break;
                case 50:
                    Object objK2 = q0.k(obj, j10);
                    Object objM = m(i10);
                    this.f6449n.getClass();
                    iV = K.a(i11, objK2, objM);
                    break;
                case 51:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.v(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 52:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.z(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 53:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.D(i11, B(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 54:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.N(i11, B(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 55:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.B(i11, A(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 56:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.y(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 57:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.x(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 58:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.s(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 59:
                    if (r(i11, i10, obj)) {
                        Object objK3 = q0.k(obj, j10);
                        if (!(objK3 instanceof C0362g)) {
                            iV = C0365j.I(i11, (String) objK3);
                            break;
                        } else {
                            iV = C0365j.t(i11, (C0362g) objK3);
                            break;
                        }
                    } else {
                        i10 += 3;
                    }
                case 60:
                    if (r(i11, i10, obj)) {
                        iV = a0.o(i11, q0.k(obj, j10), n(i10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 61:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.t(i11, (C0362g) q0.k(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 62:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.L(i11, A(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 63:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.w(i11, A(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 64:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.E(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 65:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.F(i11);
                        break;
                    } else {
                        i10 += 3;
                    }
                case 66:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.G(i11, A(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 67:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.H(i11, B(obj, j10));
                        break;
                    } else {
                        i10 += 3;
                    }
                case 68:
                    if (r(i11, i10, obj)) {
                        iV = C0365j.A(i11, (AbstractC0356a) q0.k(obj, j10), n(i10));
                        break;
                    } else {
                        i10 += 3;
                    }
                default:
                    i10 += 3;
            }
            iF = iV + iF;
            i10 += 3;
        }
    }

    public final boolean q(int i10, Object obj) {
        if (!this.g) {
            int i11 = this.f6438a[i10 + 2];
            return (q0.d.g(obj, (long) (i11 & 1048575)) & (1 << (i11 >>> 20))) != 0;
        }
        int iL = L(i10);
        long j10 = iL & 1048575;
        switch (K(iL)) {
            case 0:
                return q0.d.e(obj, j10) != 0.0d;
            case 1:
                return q0.d.f(obj, j10) != 0.0f;
            case 2:
                return q0.d.h(obj, j10) != 0;
            case 3:
                return q0.d.h(obj, j10) != 0;
            case 4:
                return q0.d.g(obj, j10) != 0;
            case 5:
                return q0.d.h(obj, j10) != 0;
            case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                return q0.d.g(obj, j10) != 0;
            case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                return q0.d.c(obj, j10);
            case 8:
                Object objI = q0.d.i(obj, j10);
                if (objI instanceof String) {
                    return !((String) objI).isEmpty();
                }
                if (objI instanceof C0362g) {
                    return !C0362g.f6485c.equals(objI);
                }
                throw new IllegalArgumentException();
            case 9:
                return q0.d.i(obj, j10) != null;
            case 10:
                return !C0362g.f6485c.equals(q0.d.i(obj, j10));
            case ModuleDescriptor.MODULE_VERSION /* 11 */:
                return q0.d.g(obj, j10) != 0;
            case 12:
                return q0.d.g(obj, j10) != 0;
            case 13:
                return q0.d.g(obj, j10) != 0;
            case 14:
                return q0.d.h(obj, j10) != 0;
            case 15:
                return q0.d.g(obj, j10) != 0;
            case 16:
                return q0.d.h(obj, j10) != 0;
            case 17:
                return q0.d.i(obj, j10) != null;
            default:
                throw new IllegalArgumentException();
        }
    }

    public final boolean r(int i10, int i11, Object obj) {
        return q0.d.g(obj, (long) (this.f6438a[i11 + 2] & 1048575)) == i10;
    }

    /* JADX WARN: Removed duplicated region for block: B:134:0x05f4 A[Catch: all -> 0x0250, TryCatch #0 {all -> 0x0250, blocks: (B:132:0x05ef, B:134:0x05f4, B:136:0x05fb, B:138:0x0602, B:73:0x024b, B:76:0x0253, B:77:0x0263, B:78:0x0273, B:79:0x0283, B:80:0x0293, B:81:0x02a9, B:82:0x02b9, B:83:0x02c9, B:84:0x02d9, B:85:0x02e9, B:86:0x02f9, B:87:0x0309, B:88:0x0319, B:89:0x0329, B:90:0x0339, B:91:0x0349, B:92:0x0359, B:93:0x0369, B:94:0x0379, B:95:0x038f, B:96:0x039f, B:97:0x03af, B:98:0x03c3, B:99:0x03cb, B:100:0x03db, B:101:0x03eb, B:102:0x03fb, B:103:0x040b, B:104:0x041b, B:105:0x042b, B:106:0x043b, B:107:0x044b, B:109:0x0454, B:110:0x0471, B:111:0x0485, B:112:0x0498, B:113:0x04ab, B:114:0x04be, B:115:0x04d1, B:116:0x04e7, B:117:0x04fa, B:118:0x050d, B:120:0x0516, B:121:0x0533, B:122:0x0547, B:123:0x0552, B:124:0x0567, B:125:0x057a, B:126:0x058d, B:127:0x05a0, B:128:0x05b3, B:129:0x05c5, B:130:0x05d9), top: B:154:0x05ef }] */
    /* JADX WARN: Removed duplicated region for block: B:169:0x0608 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final void t(androidx.datastore.preferences.protobuf.g0 r18, java.lang.Object r19, androidx.datastore.preferences.protobuf.Y r20, androidx.datastore.preferences.protobuf.C0368m r21) throws java.lang.Throwable {
        /*
            Method dump skipped, instructions count: 1736
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.O.t(androidx.datastore.preferences.protobuf.g0, java.lang.Object, androidx.datastore.preferences.protobuf.Y, androidx.datastore.preferences.protobuf.m):void");
    }

    public final void u(Object obj, int i10, Object obj2, C0368m c0368m, Y y9) {
        long jL = L(i10) & 1048575;
        Object objI = q0.d.i(obj, jL);
        K k10 = this.f6449n;
        if (objI == null) {
            k10.getClass();
            objI = J.f6430b.d();
            q0.r(obj, jL, objI);
        } else {
            k10.getClass();
            if (!((J) objI).f6431a) {
                J jD = J.f6430b.d();
                K.b(jD, objI);
                q0.r(obj, jL, jD);
                objI = jD;
            }
        }
        k10.getClass();
        y9.A((J) objI, ((I) obj2).f6427a, c0368m);
    }

    public final void v(int i10, Object obj, Object obj2) {
        long jL = L(i10) & 1048575;
        if (q(i10, obj2)) {
            p0 p0Var = q0.d;
            Object objI = p0Var.i(obj, jL);
            Object objI2 = p0Var.i(obj2, jL);
            if (objI != null && objI2 != null) {
                q0.r(obj, jL, AbstractC0379y.c(objI, objI2));
                I(i10, obj);
            } else if (objI2 != null) {
                q0.r(obj, jL, objI2);
                I(i10, obj);
            }
        }
    }

    public final void w(int i10, Object obj, Object obj2) {
        int iL = L(i10);
        int i11 = this.f6438a[i10];
        long j10 = iL & 1048575;
        if (r(i11, i10, obj2)) {
            p0 p0Var = q0.d;
            Object objI = p0Var.i(obj, j10);
            Object objI2 = p0Var.i(obj2, j10);
            if (objI != null && objI2 != null) {
                q0.r(obj, j10, AbstractC0379y.c(objI, objI2));
                J(i11, i10, obj);
            } else if (objI2 != null) {
                q0.r(obj, j10, objI2);
                J(i11, i10, obj);
            }
        }
    }
}
