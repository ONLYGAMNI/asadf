package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class r0 extends N {

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f6532c;

    public static int n(long j10, byte[] bArr, int i10, int i11) {
        if (i11 == 0) {
            N n9 = t0.f6538a;
            if (i10 > -12) {
                return -1;
            }
            return i10;
        }
        if (i11 == 1) {
            return t0.c(i10, q0.f(bArr, j10));
        }
        if (i11 == 2) {
            return t0.d(i10, q0.f(bArr, j10), q0.f(bArr, j10 + 1));
        }
        throw new AssertionError();
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x003e  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x0118  */
    @Override // androidx.datastore.preferences.protobuf.N
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final java.lang.String f(byte[] r20, int r21, int r22) throws androidx.datastore.preferences.protobuf.InvalidProtocolBufferException {
        /*
            Method dump skipped, instructions count: 458
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.r0.f(byte[], int, int):java.lang.String");
    }

    @Override // androidx.datastore.preferences.protobuf.N
    public final int g(CharSequence charSequence, byte[] bArr, int i10, int i11) {
        int i12;
        int i13;
        char cCharAt;
        long j10;
        String str;
        String str2;
        int i14;
        char cCharAt2;
        switch (this.f6532c) {
            case 0:
                int length = charSequence.length();
                int i15 = i11 + i10;
                int i16 = 0;
                while (i16 < length && (i13 = i16 + i10) < i15 && (cCharAt = charSequence.charAt(i16)) < 128) {
                    bArr[i13] = (byte) cCharAt;
                    i16++;
                }
                if (i16 == length) {
                    return i10 + length;
                }
                int i17 = i10 + i16;
                while (i16 < length) {
                    char cCharAt3 = charSequence.charAt(i16);
                    if (cCharAt3 < 128 && i17 < i15) {
                        bArr[i17] = (byte) cCharAt3;
                        i17++;
                    } else if (cCharAt3 < 2048 && i17 <= i15 - 2) {
                        int i18 = i17 + 1;
                        bArr[i17] = (byte) ((cCharAt3 >>> 6) | 960);
                        i17 += 2;
                        bArr[i18] = (byte) ((cCharAt3 & '?') | 128);
                    } else {
                        if ((cCharAt3 >= 55296 && 57343 >= cCharAt3) || i17 > i15 - 3) {
                            if (i17 > i15 - 4) {
                                if (55296 <= cCharAt3 && cCharAt3 <= 57343 && ((i12 = i16 + 1) == charSequence.length() || !Character.isSurrogatePair(cCharAt3, charSequence.charAt(i12)))) {
                                    throw new s0(i16, length);
                                }
                                throw new ArrayIndexOutOfBoundsException("Failed writing " + cCharAt3 + " at index " + i17);
                            }
                            int i19 = i16 + 1;
                            if (i19 != charSequence.length()) {
                                char cCharAt4 = charSequence.charAt(i19);
                                if (Character.isSurrogatePair(cCharAt3, cCharAt4)) {
                                    int codePoint = Character.toCodePoint(cCharAt3, cCharAt4);
                                    bArr[i17] = (byte) ((codePoint >>> 18) | 240);
                                    bArr[i17 + 1] = (byte) (((codePoint >>> 12) & 63) | 128);
                                    int i20 = i17 + 3;
                                    bArr[i17 + 2] = (byte) (((codePoint >>> 6) & 63) | 128);
                                    i17 += 4;
                                    bArr[i20] = (byte) ((codePoint & 63) | 128);
                                    i16 = i19;
                                } else {
                                    i16 = i19;
                                }
                            }
                            throw new s0(i16 - 1, length);
                        }
                        bArr[i17] = (byte) ((cCharAt3 >>> '\f') | 480);
                        int i21 = i17 + 2;
                        bArr[i17 + 1] = (byte) (((cCharAt3 >>> 6) & 63) | 128);
                        i17 += 3;
                        bArr[i21] = (byte) ((cCharAt3 & '?') | 128);
                    }
                    i16++;
                }
                return i17;
            default:
                long j11 = i10;
                long j12 = i11 + j11;
                int length2 = charSequence.length();
                String str3 = " at index ";
                String str4 = "Failed writing ";
                if (length2 > i11 || bArr.length - i11 < i10) {
                    throw new ArrayIndexOutOfBoundsException("Failed writing " + charSequence.charAt(length2 - 1) + " at index " + (i10 + i11));
                }
                int i22 = 0;
                while (true) {
                    j10 = 1;
                    if (i22 < length2 && (cCharAt2 = charSequence.charAt(i22)) < 128) {
                        q0.m(bArr, j11, (byte) cCharAt2);
                        i22++;
                        j11 = 1 + j11;
                    }
                }
                if (i22 != length2) {
                    while (i22 < length2) {
                        char cCharAt5 = charSequence.charAt(i22);
                        if (cCharAt5 < 128 && j11 < j12) {
                            q0.m(bArr, j11, (byte) cCharAt5);
                            str2 = str4;
                            j11 += j10;
                            str = str3;
                        } else if (cCharAt5 >= 2048 || j11 > j12 - 2) {
                            str = str3;
                            str2 = str4;
                            if ((cCharAt5 >= 55296 && 57343 >= cCharAt5) || j11 > j12 - 3) {
                                if (j11 > j12 - 4) {
                                    if (55296 <= cCharAt5 && cCharAt5 <= 57343 && ((i14 = i22 + 1) == length2 || !Character.isSurrogatePair(cCharAt5, charSequence.charAt(i14)))) {
                                        throw new s0(i22, length2);
                                    }
                                    throw new ArrayIndexOutOfBoundsException(str2 + cCharAt5 + str + j11);
                                }
                                int i23 = i22 + 1;
                                if (i23 != length2) {
                                    char cCharAt6 = charSequence.charAt(i23);
                                    if (Character.isSurrogatePair(cCharAt5, cCharAt6)) {
                                        int codePoint2 = Character.toCodePoint(cCharAt5, cCharAt6);
                                        q0.m(bArr, j11, (byte) ((codePoint2 >>> 18) | 240));
                                        q0.m(bArr, j11 + 1, (byte) (((codePoint2 >>> 12) & 63) | 128));
                                        long j13 = 3 + j11;
                                        q0.m(bArr, j11 + 2, (byte) (((codePoint2 >>> 6) & 63) | 128));
                                        j11 += 4;
                                        q0.m(bArr, j13, (byte) ((codePoint2 & 63) | 128));
                                        i22 = i23;
                                    } else {
                                        i22 = i23;
                                    }
                                }
                                throw new s0(i22 - 1, length2);
                            }
                            q0.m(bArr, j11, (byte) ((cCharAt5 >>> '\f') | 480));
                            long j14 = j11 + 2;
                            q0.m(bArr, j11 + 1, (byte) (((cCharAt5 >>> 6) & 63) | 128));
                            j11 += 3;
                            q0.m(bArr, j14, (byte) ((cCharAt5 & '?') | 128));
                        } else {
                            str = str3;
                            str2 = str4;
                            long j15 = j11 + j10;
                            q0.m(bArr, j11, (byte) ((cCharAt5 >>> 6) | 960));
                            j11 += 2;
                            q0.m(bArr, j15, (byte) ((cCharAt5 & '?') | 128));
                        }
                        i22++;
                        str3 = str;
                        str4 = str2;
                        j10 = 1;
                    }
                }
                return (int) j11;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:171:?, code lost:
    
        return r11;
     */
    @Override // androidx.datastore.preferences.protobuf.N
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int j(byte[] r21, int r22, int r23) {
        /*
            Method dump skipped, instructions count: 392
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.r0.j(byte[], int, int):int");
    }
}
