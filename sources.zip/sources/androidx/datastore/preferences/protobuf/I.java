package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class I {

    /* renamed from: a */
    public final X0.i f6427a;

    /* renamed from: b */
    public final Object f6428b;

    /* renamed from: c */
    public final Object f6429c;

    public I(u0 u0Var, w0 w0Var, d0.i iVar) {
        this.f6427a = new X0.i(u0Var, w0Var, iVar);
    }
}
