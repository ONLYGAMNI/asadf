package androidx.datastore.preferences.protobuf;

import java.util.Collections;

/* renamed from: androidx.datastore.preferences.protobuf.m, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0368m {

    /* renamed from: a, reason: collision with root package name */
    public static volatile C0368m f6513a;

    /* renamed from: b, reason: collision with root package name */
    public static final C0368m f6514b;

    static {
        try {
            Class.forName("androidx.datastore.preferences.protobuf.Extension");
        } catch (ClassNotFoundException unused) {
        }
        C0368m c0368m = new C0368m();
        Collections.emptyMap();
        f6514b = c0368m;
    }

    public static C0368m a() {
        C0368m c0368m = f6513a;
        if (c0368m == null) {
            synchronized (C0368m.class) {
                try {
                    c0368m = f6513a;
                    if (c0368m == null) {
                        Class cls = AbstractC0367l.f6511a;
                        if (cls != null) {
                            try {
                                c0368m = (C0368m) cls.getDeclaredMethod("getEmptyRegistry", null).invoke(null, null);
                            } catch (Exception unused) {
                            }
                            f6513a = c0368m;
                        } else {
                            c0368m = f6514b;
                            f6513a = c0368m;
                        }
                    }
                } finally {
                }
            }
        }
        return c0368m;
    }
}
