package androidx.datastore.preferences.protobuf;

import sun.misc.Unsafe;

/* loaded from: classes.dex */
public final class n0 extends p0 {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f6515b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ n0(Unsafe unsafe, int i10) {
        super(unsafe);
        this.f6515b = i10;
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final boolean c(Object obj, long j10) {
        switch (this.f6515b) {
            case 0:
                if (q0.f6531h) {
                    if (q0.g(obj, j10) == 0) {
                    }
                } else if (q0.h(obj, j10) == 0) {
                }
                break;
            default:
                if (q0.f6531h) {
                    if (q0.g(obj, j10) == 0) {
                    }
                } else if (q0.h(obj, j10) == 0) {
                }
                break;
        }
        return false;
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final byte d(Object obj, long j10) {
        switch (this.f6515b) {
            case 0:
                if (!q0.f6531h) {
                    break;
                } else {
                    break;
                }
            default:
                if (!q0.f6531h) {
                    break;
                } else {
                    break;
                }
        }
        return q0.h(obj, j10);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final double e(Object obj, long j10) {
        switch (this.f6515b) {
        }
        return Double.longBitsToDouble(h(obj, j10));
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final float f(Object obj, long j10) {
        switch (this.f6515b) {
        }
        return Float.intBitsToFloat(g(obj, j10));
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void k(Object obj, long j10, boolean z3) {
        switch (this.f6515b) {
            case 0:
                if (!q0.f6531h) {
                    q0.o(obj, j10, z3 ? (byte) 1 : (byte) 0);
                    break;
                } else {
                    q0.n(obj, j10, z3 ? (byte) 1 : (byte) 0);
                    break;
                }
            default:
                if (!q0.f6531h) {
                    q0.o(obj, j10, z3 ? (byte) 1 : (byte) 0);
                    break;
                } else {
                    q0.n(obj, j10, z3 ? (byte) 1 : (byte) 0);
                    break;
                }
        }
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void l(Object obj, long j10, byte b7) {
        switch (this.f6515b) {
            case 0:
                if (!q0.f6531h) {
                    q0.o(obj, j10, b7);
                    break;
                } else {
                    q0.n(obj, j10, b7);
                    break;
                }
            default:
                if (!q0.f6531h) {
                    q0.o(obj, j10, b7);
                    break;
                } else {
                    q0.n(obj, j10, b7);
                    break;
                }
        }
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void m(Object obj, long j10, double d) {
        switch (this.f6515b) {
            case 0:
                p(obj, j10, Double.doubleToLongBits(d));
                break;
            default:
                p(obj, j10, Double.doubleToLongBits(d));
                break;
        }
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void n(Object obj, long j10, float f10) {
        switch (this.f6515b) {
            case 0:
                o(obj, j10, Float.floatToIntBits(f10));
                break;
            default:
                o(obj, j10, Float.floatToIntBits(f10));
                break;
        }
    }
}
