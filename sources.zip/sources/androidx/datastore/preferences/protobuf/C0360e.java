package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* renamed from: androidx.datastore.preferences.protobuf.e, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0360e implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public int f6475a = 0;

    /* renamed from: b, reason: collision with root package name */
    public final int f6476b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ C0362g f6477c;

    public C0360e(C0362g c0362g) {
        this.f6477c = c0362g;
        this.f6476b = c0362g.size();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f6475a < this.f6476b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i10 = this.f6475a;
        if (i10 >= this.f6476b) {
            throw new NoSuchElementException();
        }
        this.f6475a = i10 + 1;
        return Byte.valueOf(this.f6477c.g(i10));
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
