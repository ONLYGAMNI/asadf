package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class o0 extends p0 {
    @Override // androidx.datastore.preferences.protobuf.p0
    public final boolean c(Object obj, long j10) {
        return this.f6521a.getBoolean(obj, j10);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final byte d(Object obj, long j10) {
        return this.f6521a.getByte(obj, j10);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final double e(Object obj, long j10) {
        return this.f6521a.getDouble(obj, j10);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final float f(Object obj, long j10) {
        return this.f6521a.getFloat(obj, j10);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void k(Object obj, long j10, boolean z3) {
        this.f6521a.putBoolean(obj, j10, z3);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void l(Object obj, long j10, byte b7) {
        this.f6521a.putByte(obj, j10, b7);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void m(Object obj, long j10, double d) {
        this.f6521a.putDouble(obj, j10, d);
    }

    @Override // androidx.datastore.preferences.protobuf.p0
    public final void n(Object obj, long j10, float f10) {
        this.f6521a.putFloat(obj, j10, f10);
    }
}
