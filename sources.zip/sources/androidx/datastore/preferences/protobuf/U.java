package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public interface U {
}
