package androidx.datastore.preferences.protobuf;

import java.util.Iterator;

/* loaded from: classes.dex */
public final class k0 implements Iterator {

    /* renamed from: a */
    public final Iterator f6510a;

    public k0(l0 l0Var) {
        this.f6510a = l0Var.f6512a.iterator();
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f6510a.hasNext();
    }

    @Override // java.util.Iterator
    public final Object next() {
        return (String) this.f6510a.next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException();
    }
}
