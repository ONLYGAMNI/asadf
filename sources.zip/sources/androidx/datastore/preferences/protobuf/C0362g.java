package androidx.datastore.preferences.protobuf;

import java.io.Serializable;
import java.util.Iterator;
import u0.AbstractC1480a;

/* renamed from: androidx.datastore.preferences.protobuf.g */
/* loaded from: classes.dex */
public class C0362g implements Iterable, Serializable {

    /* renamed from: c */
    public static final C0362g f6485c = new C0362g(AbstractC0379y.f6540b);
    public static final C0361f d;

    /* renamed from: a */
    public int f6486a = 0;

    /* renamed from: b */
    public final byte[] f6487b;

    static {
        d = AbstractC0358c.a() ? new C0361f(1) : new C0361f(0);
    }

    public C0362g(byte[] bArr) {
        bArr.getClass();
        this.f6487b = bArr;
    }

    public static C0362g c(byte[] bArr, int i10, int i11) {
        int i12 = i10 + i11;
        int length = bArr.length;
        if (((i12 - i10) | i10 | i12 | (length - i12)) >= 0) {
            return new C0362g(d.a(bArr, i10, i11));
        }
        if (i10 < 0) {
            throw new IndexOutOfBoundsException(AbstractC1480a.j("Beginning index: ", i10, " < 0"));
        }
        if (i12 < i10) {
            throw new IndexOutOfBoundsException(android.support.v4.media.session.a.j("Beginning index larger than ending index: ", i10, i12, ", "));
        }
        throw new IndexOutOfBoundsException(android.support.v4.media.session.a.j("End index: ", i12, length, " >= "));
    }

    public byte b(int i10) {
        return this.f6487b[i10];
    }

    public int e() {
        return 0;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0362g) || size() != ((C0362g) obj).size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        if (!(obj instanceof C0362g)) {
            return obj.equals(this);
        }
        C0362g c0362g = (C0362g) obj;
        int i10 = this.f6486a;
        int i11 = c0362g.f6486a;
        if (i10 != 0 && i11 != 0 && i10 != i11) {
            return false;
        }
        int size = size();
        if (size > c0362g.size()) {
            throw new IllegalArgumentException("Length too large: " + size + size());
        }
        if (size > c0362g.size()) {
            StringBuilder sbP = android.support.v4.media.session.a.p("Ran off end of other: 0, ", size, ", ");
            sbP.append(c0362g.size());
            throw new IllegalArgumentException(sbP.toString());
        }
        int iE = e() + size;
        int iE2 = e();
        int iE3 = c0362g.e();
        while (iE2 < iE) {
            if (this.f6487b[iE2] != c0362g.f6487b[iE3]) {
                return false;
            }
            iE2++;
            iE3++;
        }
        return true;
    }

    public byte g(int i10) {
        return this.f6487b[i10];
    }

    public final int hashCode() {
        int i10 = this.f6486a;
        if (i10 == 0) {
            int size = size();
            int iE = e();
            int i11 = size;
            for (int i12 = iE; i12 < iE + size; i12++) {
                i11 = (i11 * 31) + this.f6487b[i12];
            }
            i10 = i11 == 0 ? 1 : i11;
            this.f6486a = i10;
        }
        return i10;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return new C0360e(this);
    }

    public int size() {
        return this.f6487b.length;
    }

    public final String toString() {
        return String.format("<ByteString@%s size=%d>", Integer.toHexString(System.identityHashCode(this)), Integer.valueOf(size()));
    }
}
