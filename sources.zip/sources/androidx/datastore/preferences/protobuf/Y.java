package androidx.datastore.preferences.protobuf;

import java.util.List;

/* loaded from: classes.dex */
public interface Y {
    void A(J j10, X0.i iVar, C0368m c0368m);

    int B();

    void C(List list);

    void D(List list);

    void E(List list, Z z3, C0368m c0368m);

    void F(List list);

    void G(List list);

    long H();

    String I();

    void J(List list);

    void K(List list);

    void L(List list);

    Object M(Z z3, C0368m c0368m);

    Object a(Z z3, C0368m c0368m);

    void b(List list);

    int c();

    int d();

    long e();

    void f(List list);

    long g();

    void h(List list);

    int i();

    void j(List list);

    long k();

    void l(List list);

    void m(List list);

    String n();

    int o();

    boolean p();

    int q();

    void r(List list);

    double readDouble();

    float readFloat();

    long s();

    void t(List list);

    void u(List list);

    C0362g v();

    void w(List list);

    int x();

    int y();

    void z(List list, Z z3, C0368m c0368m);
}
