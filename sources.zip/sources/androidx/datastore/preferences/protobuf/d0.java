package androidx.datastore.preferences.protobuf;

import java.util.Iterator;

/* loaded from: classes.dex */
public final class d0 implements Iterable {
    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return N.f6434a;
    }
}
