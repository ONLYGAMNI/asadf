package androidx.datastore.preferences.protobuf;

import java.util.List;

/* loaded from: classes.dex */
public interface B extends List {
    void d(C0362g c0362g);

    B f();

    Object h(int i10);

    List i();
}
