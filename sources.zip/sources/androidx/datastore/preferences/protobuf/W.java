package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Arrays;
import java.util.RandomAccess;

/* loaded from: classes.dex */
public final class W extends AbstractC0357b implements RandomAccess {
    public static final W d;

    /* renamed from: b, reason: collision with root package name */
    public Object[] f6458b;

    /* renamed from: c, reason: collision with root package name */
    public int f6459c;

    static {
        W w9 = new W(new Object[0], 0);
        d = w9;
        w9.f6466a = false;
    }

    public W(Object[] objArr, int i10) {
        this.f6458b = objArr;
        this.f6459c = i10;
    }

    @Override // androidx.datastore.preferences.protobuf.InterfaceC0378x
    public final InterfaceC0378x a(int i10) {
        if (i10 >= this.f6459c) {
            return new W(Arrays.copyOf(this.f6458b, i10), this.f6459c);
        }
        throw new IllegalArgumentException();
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0357b, java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.util.List
    public final boolean add(Object obj) {
        b();
        int i10 = this.f6459c;
        Object[] objArr = this.f6458b;
        if (i10 == objArr.length) {
            this.f6458b = Arrays.copyOf(objArr, ((i10 * 3) / 2) + 1);
        }
        Object[] objArr2 = this.f6458b;
        int i11 = this.f6459c;
        this.f6459c = i11 + 1;
        objArr2[i11] = obj;
        ((AbstractList) this).modCount++;
        return true;
    }

    public final void c(int i10) {
        if (i10 < 0 || i10 >= this.f6459c) {
            StringBuilder sbP = android.support.v4.media.session.a.p("Index:", i10, ", Size:");
            sbP.append(this.f6459c);
            throw new IndexOutOfBoundsException(sbP.toString());
        }
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i10) {
        c(i10);
        return this.f6458b[i10];
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object remove(int i10) {
        b();
        c(i10);
        Object[] objArr = this.f6458b;
        Object obj = objArr[i10];
        if (i10 < this.f6459c - 1) {
            System.arraycopy(objArr, i10 + 1, objArr, i10, (r2 - i10) - 1);
        }
        this.f6459c--;
        ((AbstractList) this).modCount++;
        return obj;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object set(int i10, Object obj) {
        b();
        c(i10);
        Object[] objArr = this.f6458b;
        Object obj2 = objArr[i10];
        objArr[i10] = obj;
        ((AbstractList) this).modCount++;
        return obj2;
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f6459c;
    }

    @Override // java.util.AbstractList, java.util.List
    public final void add(int i10, Object obj) {
        int i11;
        b();
        if (i10 >= 0 && i10 <= (i11 = this.f6459c)) {
            Object[] objArr = this.f6458b;
            if (i11 < objArr.length) {
                System.arraycopy(objArr, i10, objArr, i10 + 1, i11 - i10);
            } else {
                Object[] objArr2 = new Object[android.support.v4.media.session.a.w(i11, 3, 2, 1)];
                System.arraycopy(objArr, 0, objArr2, 0, i10);
                System.arraycopy(this.f6458b, i10, objArr2, i10 + 1, this.f6459c - i10);
                this.f6458b = objArr2;
            }
            this.f6458b[i10] = obj;
            this.f6459c++;
            ((AbstractList) this).modCount++;
            return;
        }
        StringBuilder sbP = android.support.v4.media.session.a.p("Index:", i10, ", Size:");
        sbP.append(this.f6459c);
        throw new IndexOutOfBoundsException(sbP.toString());
    }
}
