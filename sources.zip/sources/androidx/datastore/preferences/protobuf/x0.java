package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public enum x0 extends y0 {
}
