package androidx.datastore.preferences.protobuf;

import java.io.IOException;
import java.nio.charset.Charset;

/* loaded from: classes.dex */
public final class H {

    /* renamed from: b, reason: collision with root package name */
    public static final C0373s f6425b = new C0373s(1);

    /* renamed from: a, reason: collision with root package name */
    public final Object f6426a;

    public H(C0365j c0365j) {
        AbstractC0379y.a(c0365j, "output");
        this.f6426a = c0365j;
        c0365j.f6506c = this;
    }

    public void a(int i10, boolean z3) throws IOException {
        ((C0365j) this.f6426a).U(i10, z3);
    }

    public void b(int i10, C0362g c0362g) {
        ((C0365j) this.f6426a).W(i10, c0362g);
    }

    public void c(int i10, double d) throws IOException {
        C0365j c0365j = (C0365j) this.f6426a;
        c0365j.getClass();
        c0365j.a0(i10, Double.doubleToRawLongBits(d));
    }

    public void d(int i10, int i11) throws IOException {
        ((C0365j) this.f6426a).c0(i10, i11);
    }

    public void e(int i10, int i11) {
        ((C0365j) this.f6426a).Y(i10, i11);
    }

    public void f(int i10, long j10) {
        ((C0365j) this.f6426a).a0(i10, j10);
    }

    public void g(int i10, float f10) throws IOException {
        C0365j c0365j = (C0365j) this.f6426a;
        c0365j.getClass();
        c0365j.Y(i10, Float.floatToRawIntBits(f10));
    }

    public void h(int i10, Object obj, Z z3) {
        C0365j c0365j = (C0365j) this.f6426a;
        c0365j.i0(i10, 3);
        z3.c((AbstractC0356a) obj, c0365j.f6506c);
        c0365j.i0(i10, 4);
    }

    public void i(int i10, int i11) throws IOException {
        ((C0365j) this.f6426a).c0(i10, i11);
    }

    public void j(int i10, long j10) {
        ((C0365j) this.f6426a).l0(i10, j10);
    }

    public void k(int i10, Object obj, Z z3) throws IOException {
        ((C0365j) this.f6426a).e0(i10, (AbstractC0356a) obj, z3);
    }

    public void l(int i10, int i11) throws IOException {
        ((C0365j) this.f6426a).Y(i10, i11);
    }

    public void m(int i10, long j10) throws IOException {
        ((C0365j) this.f6426a).a0(i10, j10);
    }

    public void n(int i10, int i11) throws IOException {
        ((C0365j) this.f6426a).j0(i10, (i11 >> 31) ^ (i11 << 1));
    }

    public void o(int i10, long j10) throws IOException {
        ((C0365j) this.f6426a).l0(i10, (j10 >> 63) ^ (j10 << 1));
    }

    public void p(int i10, int i11) throws IOException {
        ((C0365j) this.f6426a).j0(i10, i11);
    }

    public void q(int i10, long j10) throws IOException {
        ((C0365j) this.f6426a).l0(i10, j10);
    }

    public H() {
        M m9;
        try {
            m9 = (M) Class.forName("androidx.datastore.preferences.protobuf.DescriptorMessageInfoFactory").getDeclaredMethod("getInstance", null).invoke(null, null);
        } catch (Exception unused) {
            m9 = f6425b;
        }
        M[] mArr = {C0373s.f6533b, m9};
        G g = new G();
        g.f6424a = mArr;
        Charset charset = AbstractC0379y.f6539a;
        this.f6426a = g;
    }
}
