package androidx.datastore.preferences.protobuf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public final class C extends E {

    /* renamed from: c */
    public static final Class f6421c = Collections.unmodifiableList(Collections.emptyList()).getClass();

    /* JADX WARN: Multi-variable type inference failed */
    public static List d(Object obj, long j10, int i10) {
        A a6;
        List list = (List) q0.d.i(obj, j10);
        if (list.isEmpty()) {
            List a9 = list instanceof B ? new A(i10) : ((list instanceof U) && (list instanceof InterfaceC0378x)) ? ((InterfaceC0378x) list).a(i10) : new ArrayList(i10);
            q0.r(obj, j10, a9);
            return a9;
        }
        if (f6421c.isAssignableFrom(list.getClass())) {
            ArrayList arrayList = new ArrayList(list.size() + i10);
            arrayList.addAll(list);
            q0.r(obj, j10, arrayList);
            a6 = arrayList;
        } else {
            if (!(list instanceof l0)) {
                if (!(list instanceof U) || !(list instanceof InterfaceC0378x)) {
                    return list;
                }
                InterfaceC0378x interfaceC0378x = (InterfaceC0378x) list;
                if (((AbstractC0357b) interfaceC0378x).f6466a) {
                    return list;
                }
                InterfaceC0378x interfaceC0378xA = interfaceC0378x.a(list.size() + i10);
                q0.r(obj, j10, interfaceC0378xA);
                return interfaceC0378xA;
            }
            A a10 = new A(list.size() + i10);
            a10.addAll((l0) list);
            q0.r(obj, j10, a10);
            a6 = a10;
        }
        return a6;
    }

    @Override // androidx.datastore.preferences.protobuf.E
    public final void a(Object obj, long j10) {
        Object objUnmodifiableList;
        List list = (List) q0.d.i(obj, j10);
        if (list instanceof B) {
            objUnmodifiableList = ((B) list).f();
        } else {
            if (f6421c.isAssignableFrom(list.getClass())) {
                return;
            }
            if ((list instanceof U) && (list instanceof InterfaceC0378x)) {
                AbstractC0357b abstractC0357b = (AbstractC0357b) ((InterfaceC0378x) list);
                if (abstractC0357b.f6466a) {
                    abstractC0357b.f6466a = false;
                    return;
                }
                return;
            }
            objUnmodifiableList = Collections.unmodifiableList(list);
        }
        q0.r(obj, j10, objUnmodifiableList);
    }

    @Override // androidx.datastore.preferences.protobuf.E
    public final void b(Object obj, long j10, Object obj2) {
        List list = (List) q0.d.i(obj2, j10);
        List listD = d(obj, j10, list.size());
        int size = listD.size();
        int size2 = list.size();
        if (size > 0 && size2 > 0) {
            listD.addAll(list);
        }
        if (size > 0) {
            list = listD;
        }
        q0.r(obj, j10, list);
    }

    @Override // androidx.datastore.preferences.protobuf.E
    public final List c(Object obj, long j10) {
        return d(obj, j10, 10);
    }
}
