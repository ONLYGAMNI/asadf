package androidx.datastore.preferences.protobuf;

import java.util.RandomAccess;

/* renamed from: androidx.datastore.preferences.protobuf.w, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0377w extends AbstractC0357b implements RandomAccess, U {
}
