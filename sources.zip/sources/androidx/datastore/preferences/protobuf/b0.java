package androidx.datastore.preferences.protobuf;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

/* loaded from: classes.dex */
public final class b0 extends AbstractMap {

    /* renamed from: n */
    public static final /* synthetic */ int f6467n = 0;

    /* renamed from: a */
    public final int f6468a;
    public boolean d;

    /* renamed from: e */
    public volatile S5.l f6471e;

    /* renamed from: b */
    public List f6469b = Collections.emptyList();

    /* renamed from: c */
    public Map f6470c = Collections.emptyMap();

    /* renamed from: f */
    public Map f6472f = Collections.emptyMap();

    public b0(int i10) {
        this.f6468a = i10;
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x0024  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final int a(java.lang.Comparable r5) {
        /*
            r4 = this;
            java.util.List r0 = r4.f6469b
            int r0 = r0.size()
            int r1 = r0 + (-1)
            if (r1 < 0) goto L21
            java.util.List r2 = r4.f6469b
            java.lang.Object r2 = r2.get(r1)
            androidx.datastore.preferences.protobuf.e0 r2 = (androidx.datastore.preferences.protobuf.e0) r2
            java.lang.Comparable r2 = r2.f6478a
            int r2 = r5.compareTo(r2)
            if (r2 <= 0) goto L1e
            int r0 = r0 + 1
        L1c:
            int r5 = -r0
            return r5
        L1e:
            if (r2 != 0) goto L21
            return r1
        L21:
            r0 = 0
        L22:
            if (r0 > r1) goto L43
            int r2 = r0 + r1
            int r2 = r2 / 2
            java.util.List r3 = r4.f6469b
            java.lang.Object r3 = r3.get(r2)
            androidx.datastore.preferences.protobuf.e0 r3 = (androidx.datastore.preferences.protobuf.e0) r3
            java.lang.Comparable r3 = r3.f6478a
            int r3 = r5.compareTo(r3)
            if (r3 >= 0) goto L3c
            int r2 = r2 + (-1)
            r1 = r2
            goto L22
        L3c:
            if (r3 <= 0) goto L42
            int r2 = r2 + 1
            r0 = r2
            goto L22
        L42:
            return r2
        L43:
            int r0 = r0 + 1
            goto L1c
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.b0.a(java.lang.Comparable):int");
    }

    public final void b() {
        if (this.d) {
            throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final void clear() {
        b();
        if (!this.f6469b.isEmpty()) {
            this.f6469b.clear();
        }
        if (this.f6470c.isEmpty()) {
            return;
        }
        this.f6470c.clear();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean containsKey(Object obj) {
        Comparable comparable = (Comparable) obj;
        return a(comparable) >= 0 || this.f6470c.containsKey(comparable);
    }

    public final Map.Entry d(int i10) {
        return (Map.Entry) this.f6469b.get(i10);
    }

    public final Iterable e() {
        return this.f6470c.isEmpty() ? N.f6435b : this.f6470c.entrySet();
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Set entrySet() {
        if (this.f6471e == null) {
            this.f6471e = new S5.l(this, 2);
        }
        return this.f6471e;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b0)) {
            return super.equals(obj);
        }
        b0 b0Var = (b0) obj;
        int size = size();
        if (size != b0Var.size()) {
            return false;
        }
        int size2 = this.f6469b.size();
        if (size2 != b0Var.f6469b.size()) {
            return entrySet().equals(b0Var.entrySet());
        }
        for (int i10 = 0; i10 < size2; i10++) {
            if (!d(i10).equals(b0Var.d(i10))) {
                return false;
            }
        }
        if (size2 != size) {
            return this.f6470c.equals(b0Var.f6470c);
        }
        return true;
    }

    public final SortedMap f() {
        b();
        if (this.f6470c.isEmpty() && !(this.f6470c instanceof TreeMap)) {
            TreeMap treeMap = new TreeMap();
            this.f6470c = treeMap;
            this.f6472f = treeMap.descendingMap();
        }
        return (SortedMap) this.f6470c;
    }

    public final Object g(Comparable comparable, Object obj) {
        b();
        int iA = a(comparable);
        if (iA >= 0) {
            return ((e0) this.f6469b.get(iA)).setValue(obj);
        }
        b();
        boolean zIsEmpty = this.f6469b.isEmpty();
        int i10 = this.f6468a;
        if (zIsEmpty && !(this.f6469b instanceof ArrayList)) {
            this.f6469b = new ArrayList(i10);
        }
        int i11 = -(iA + 1);
        if (i11 >= i10) {
            return f().put(comparable, obj);
        }
        if (this.f6469b.size() == i10) {
            e0 e0Var = (e0) this.f6469b.remove(i10 - 1);
            f().put(e0Var.f6478a, e0Var.f6479b);
        }
        this.f6469b.add(i11, new e0(this, comparable, obj));
        return null;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object get(Object obj) {
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        return iA >= 0 ? ((e0) this.f6469b.get(iA)).f6479b : this.f6470c.get(comparable);
    }

    public final Object h(int i10) {
        b();
        Object obj = ((e0) this.f6469b.remove(i10)).f6479b;
        if (!this.f6470c.isEmpty()) {
            Iterator it = f().entrySet().iterator();
            List list = this.f6469b;
            Map.Entry entry = (Map.Entry) it.next();
            list.add(new e0(this, (Comparable) entry.getKey(), entry.getValue()));
            it.remove();
        }
        return obj;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int hashCode() {
        int size = this.f6469b.size();
        int iHashCode = 0;
        for (int i10 = 0; i10 < size; i10++) {
            iHashCode += ((e0) this.f6469b.get(i10)).hashCode();
        }
        return this.f6470c.size() > 0 ? iHashCode + this.f6470c.hashCode() : iHashCode;
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final /* bridge */ /* synthetic */ Object put(Object obj, Object obj2) {
        android.support.v4.media.session.a.u(obj);
        return g(null, obj2);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final Object remove(Object obj) {
        b();
        Comparable comparable = (Comparable) obj;
        int iA = a(comparable);
        if (iA >= 0) {
            return h(iA);
        }
        if (this.f6470c.isEmpty()) {
            return null;
        }
        return this.f6470c.remove(comparable);
    }

    @Override // java.util.AbstractMap, java.util.Map
    public final int size() {
        return this.f6470c.size() + this.f6469b.size();
    }
}
