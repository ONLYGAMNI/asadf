package androidx.datastore.preferences.protobuf;

import java.util.RandomAccess;

/* renamed from: androidx.datastore.preferences.protobuf.k, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0366k extends AbstractC0357b implements RandomAccess, U {
}
