package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

/* loaded from: classes.dex */
public abstract class p0 {

    /* renamed from: a, reason: collision with root package name */
    public final Unsafe f6521a;

    public p0(Unsafe unsafe) {
        this.f6521a = unsafe;
    }

    public final int a(Class cls) {
        return this.f6521a.arrayBaseOffset(cls);
    }

    public final int b(Class cls) {
        return this.f6521a.arrayIndexScale(cls);
    }

    public abstract boolean c(Object obj, long j10);

    public abstract byte d(Object obj, long j10);

    public abstract double e(Object obj, long j10);

    public abstract float f(Object obj, long j10);

    public final int g(Object obj, long j10) {
        return this.f6521a.getInt(obj, j10);
    }

    public final long h(Object obj, long j10) {
        return this.f6521a.getLong(obj, j10);
    }

    public final Object i(Object obj, long j10) {
        return this.f6521a.getObject(obj, j10);
    }

    public final long j(Field field) {
        return this.f6521a.objectFieldOffset(field);
    }

    public abstract void k(Object obj, long j10, boolean z3);

    public abstract void l(Object obj, long j10, byte b7);

    public abstract void m(Object obj, long j10, double d);

    public abstract void n(Object obj, long j10, float f10);

    public final void o(Object obj, long j10, int i10) {
        this.f6521a.putInt(obj, j10, i10);
    }

    public final void p(Object obj, long j10, long j11) {
        this.f6521a.putLong(obj, j10, j11);
    }

    public final void q(Object obj, long j10, Object obj2) {
        this.f6521a.putObject(obj, j10, obj2);
    }
}
