package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public enum u0 extends y0 {
}
