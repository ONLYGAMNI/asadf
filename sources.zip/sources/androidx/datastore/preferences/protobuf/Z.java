package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public interface Z {
    void a(Object obj, Y y9, C0368m c0368m);

    void b(Object obj, Object obj2);

    void c(Object obj, H h10);

    void d(Object obj);

    boolean e(Object obj);

    boolean f(Object obj, Object obj2);

    int g(Object obj);

    Object h();

    int i(Object obj);
}
