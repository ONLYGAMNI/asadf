package androidx.datastore.preferences.protobuf;

import java.util.List;

/* loaded from: classes.dex */
public final class D extends E {
    @Override // androidx.datastore.preferences.protobuf.E
    public final void a(Object obj, long j10) {
        ((AbstractC0357b) ((InterfaceC0378x) q0.d.i(obj, j10))).f6466a = false;
    }

    @Override // androidx.datastore.preferences.protobuf.E
    public final void b(Object obj, long j10, Object obj2) {
        p0 p0Var = q0.d;
        InterfaceC0378x interfaceC0378xA = (InterfaceC0378x) p0Var.i(obj, j10);
        InterfaceC0378x interfaceC0378x = (InterfaceC0378x) p0Var.i(obj2, j10);
        int size = interfaceC0378xA.size();
        int size2 = interfaceC0378x.size();
        if (size > 0 && size2 > 0) {
            if (!((AbstractC0357b) interfaceC0378xA).f6466a) {
                interfaceC0378xA = interfaceC0378xA.a(size2 + size);
            }
            interfaceC0378xA.addAll(interfaceC0378x);
        }
        if (size > 0) {
            interfaceC0378x = interfaceC0378xA;
        }
        q0.r(obj, j10, interfaceC0378x);
    }

    @Override // androidx.datastore.preferences.protobuf.E
    public final List c(Object obj, long j10) {
        InterfaceC0378x interfaceC0378x = (InterfaceC0378x) q0.d.i(obj, j10);
        if (((AbstractC0357b) interfaceC0378x).f6466a) {
            return interfaceC0378x;
        }
        int size = interfaceC0378x.size();
        InterfaceC0378x interfaceC0378xA = interfaceC0378x.a(size == 0 ? 10 : size * 2);
        q0.r(obj, j10, interfaceC0378xA);
        return interfaceC0378xA;
    }
}
