package androidx.datastore.preferences.protobuf;

import java.io.Serializable;

/* loaded from: classes.dex */
public enum z0 {
    INT(0),
    LONG(0L),
    FLOAT(Float.valueOf(0.0f)),
    DOUBLE(Double.valueOf(0.0d)),
    BOOLEAN(Boolean.FALSE),
    STRING(""),
    BYTE_STRING(C0362g.f6485c),
    ENUM(null),
    MESSAGE(null);


    /* renamed from: a */
    public final Object f6566a;

    z0(Serializable serializable) {
    }
}
