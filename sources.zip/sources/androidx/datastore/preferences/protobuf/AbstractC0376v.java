package androidx.datastore.preferences.protobuf;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/* renamed from: androidx.datastore.preferences.protobuf.v */
/* loaded from: classes.dex */
public abstract class AbstractC0376v extends AbstractC0356a {
    private static Map<Object, AbstractC0376v> defaultInstanceMap = new ConcurrentHashMap();
    protected int memoizedSerializedSize;
    protected h0 unknownFields;

    public AbstractC0376v() {
        this.memoizedHashCode = 0;
        this.unknownFields = h0.f6496f;
        this.memoizedSerializedSize = -1;
    }

    public static AbstractC0376v e(Class cls) throws ClassNotFoundException {
        AbstractC0376v abstractC0376v = defaultInstanceMap.get(cls);
        if (abstractC0376v == null) {
            try {
                Class.forName(cls.getName(), true, cls.getClassLoader());
                abstractC0376v = defaultInstanceMap.get(cls);
            } catch (ClassNotFoundException e4) {
                throw new IllegalStateException("Class initialization cannot fail.", e4);
            }
        }
        if (abstractC0376v == null) {
            abstractC0376v = (AbstractC0376v) ((AbstractC0376v) q0.a(cls)).d(6);
            if (abstractC0376v == null) {
                throw new IllegalStateException();
            }
            defaultInstanceMap.put(cls, abstractC0376v);
        }
        return abstractC0376v;
    }

    public static Object f(Method method, Object obj, Object... objArr) {
        try {
            return method.invoke(obj, objArr);
        } catch (IllegalAccessException e4) {
            throw new RuntimeException("Couldn't use Java reflection to implement protocol message reflection.", e4);
        } catch (InvocationTargetException e5) {
            Throwable cause = e5.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            if (cause instanceof Error) {
                throw ((Error) cause);
            }
            throw new RuntimeException("Unexpected exception thrown by generated accessor method.", cause);
        }
    }

    public static void h(Class cls, AbstractC0376v abstractC0376v) {
        defaultInstanceMap.put(cls, abstractC0376v);
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0356a
    public final int a() {
        if (this.memoizedSerializedSize == -1) {
            V v9 = V.f6455c;
            v9.getClass();
            this.memoizedSerializedSize = v9.a(getClass()).g(this);
        }
        return this.memoizedSerializedSize;
    }

    @Override // androidx.datastore.preferences.protobuf.AbstractC0356a
    public final void c(C0365j c0365j) {
        V v9 = V.f6455c;
        v9.getClass();
        Z zA = v9.a(getClass());
        H h10 = c0365j.f6506c;
        if (h10 == null) {
            h10 = new H(c0365j);
        }
        zA.c(this, h10);
    }

    public abstract Object d(int i10);

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!((AbstractC0376v) d(6)).getClass().isInstance(obj)) {
            return false;
        }
        V v9 = V.f6455c;
        v9.getClass();
        return v9.a(getClass()).f(this, (AbstractC0376v) obj);
    }

    public final boolean g() {
        byte bByteValue = ((Byte) d(1)).byteValue();
        if (bByteValue == 1) {
            return true;
        }
        if (bByteValue == 0) {
            return false;
        }
        V v9 = V.f6455c;
        v9.getClass();
        boolean zE = v9.a(getClass()).e(this);
        d(2);
        return zE;
    }

    public final int hashCode() {
        int i10 = this.memoizedHashCode;
        if (i10 != 0) {
            return i10;
        }
        V v9 = V.f6455c;
        v9.getClass();
        int i11 = v9.a(getClass()).i(this);
        this.memoizedHashCode = i11;
        return i11;
    }

    public final String toString() {
        String string = super.toString();
        StringBuilder sb = new StringBuilder();
        sb.append("# ");
        sb.append(string);
        N.l(this, sb, 0);
        return sb.toString();
    }
}
