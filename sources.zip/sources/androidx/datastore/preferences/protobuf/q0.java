package androidx.datastore.preferences.protobuf;

import java.lang.reflect.Field;
import java.nio.Buffer;
import java.security.AccessController;
import java.util.logging.Logger;
import sun.misc.Unsafe;

/* loaded from: classes.dex */
public abstract class q0 {

    /* renamed from: a, reason: collision with root package name */
    public static final Logger f6526a = Logger.getLogger(q0.class.getName());

    /* renamed from: b, reason: collision with root package name */
    public static final Unsafe f6527b;

    /* renamed from: c, reason: collision with root package name */
    public static final Class f6528c;
    public static final p0 d;

    /* renamed from: e, reason: collision with root package name */
    public static final boolean f6529e;

    /* renamed from: f, reason: collision with root package name */
    public static final boolean f6530f;
    public static final long g;

    /* renamed from: h, reason: collision with root package name */
    public static final boolean f6531h;

    /* JADX WARN: Removed duplicated region for block: B:110:0x0268  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0278  */
    /* JADX WARN: Removed duplicated region for block: B:117:0x027a  */
    static {
        /*
            Method dump skipped, instructions count: 638
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.q0.<clinit>():void");
    }

    public static Object a(Class cls) {
        try {
            return f6527b.allocateInstance(cls);
        } catch (InstantiationException e4) {
            throw new IllegalStateException(e4);
        }
    }

    public static int b(Class cls) {
        if (f6530f) {
            return d.a(cls);
        }
        return -1;
    }

    public static void c(Class cls) {
        if (f6530f) {
            d.b(cls);
        }
    }

    public static Field d() {
        Field declaredField;
        Field declaredField2;
        if (AbstractC0358c.a()) {
            try {
                declaredField2 = Buffer.class.getDeclaredField("effectiveDirectAddress");
            } catch (Throwable unused) {
                declaredField2 = null;
            }
            if (declaredField2 != null) {
                return declaredField2;
            }
        }
        try {
            declaredField = Buffer.class.getDeclaredField("address");
        } catch (Throwable unused2) {
            declaredField = null;
        }
        if (declaredField == null || declaredField.getType() != Long.TYPE) {
            return null;
        }
        return declaredField;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static boolean e(Class cls) {
        if (!AbstractC0358c.a()) {
            return false;
        }
        try {
            Class cls2 = f6528c;
            Class cls3 = Boolean.TYPE;
            cls2.getMethod("peekLong", cls, cls3);
            cls2.getMethod("pokeLong", cls, Long.TYPE, cls3);
            Class cls4 = Integer.TYPE;
            cls2.getMethod("pokeInt", cls, cls4, cls3);
            cls2.getMethod("peekInt", cls, cls3);
            cls2.getMethod("pokeByte", cls, Byte.TYPE);
            cls2.getMethod("peekByte", cls);
            cls2.getMethod("pokeByteArray", cls, byte[].class, cls4, cls4);
            cls2.getMethod("peekByteArray", cls, byte[].class, cls4, cls4);
            return true;
        } catch (Throwable unused) {
            return false;
        }
    }

    public static byte f(byte[] bArr, long j10) {
        return d.d(bArr, g + j10);
    }

    public static byte g(Object obj, long j10) {
        return (byte) ((d.g(obj, (-4) & j10) >>> ((int) (((~j10) & 3) << 3))) & 255);
    }

    public static byte h(Object obj, long j10) {
        return (byte) ((d.g(obj, (-4) & j10) >>> ((int) ((j10 & 3) << 3))) & 255);
    }

    public static int i(Object obj, long j10) {
        return d.g(obj, j10);
    }

    public static long j(Object obj, long j10) {
        return d.h(obj, j10);
    }

    public static Object k(Object obj, long j10) {
        return d.i(obj, j10);
    }

    public static Unsafe l() {
        try {
            return (Unsafe) AccessController.doPrivileged(new m0());
        } catch (Throwable unused) {
            return null;
        }
    }

    public static void m(byte[] bArr, long j10, byte b7) {
        d.l(bArr, g + j10, b7);
    }

    public static void n(Object obj, long j10, byte b7) {
        long j11 = (-4) & j10;
        int iG = d.g(obj, j11);
        int i10 = ((~((int) j10)) & 3) << 3;
        p(obj, j11, ((255 & b7) << i10) | (iG & (~(255 << i10))));
    }

    public static void o(Object obj, long j10, byte b7) {
        long j11 = (-4) & j10;
        int i10 = (((int) j10) & 3) << 3;
        p(obj, j11, ((255 & b7) << i10) | (d.g(obj, j11) & (~(255 << i10))));
    }

    public static void p(Object obj, long j10, int i10) {
        d.o(obj, j10, i10);
    }

    public static void q(Object obj, long j10, long j11) {
        d.p(obj, j10, j11);
    }

    public static void r(Object obj, long j10, Object obj2) {
        d.q(obj, j10, obj2);
    }
}
