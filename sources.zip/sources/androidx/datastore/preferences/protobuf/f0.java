package androidx.datastore.preferences.protobuf;

import java.util.Iterator;
import java.util.Map;

/* loaded from: classes.dex */
public final class f0 implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public int f6482a = -1;

    /* renamed from: b, reason: collision with root package name */
    public boolean f6483b;

    /* renamed from: c, reason: collision with root package name */
    public Iterator f6484c;
    public final /* synthetic */ b0 d;

    public f0(b0 b0Var) {
        this.d = b0Var;
    }

    public final Iterator a() {
        if (this.f6484c == null) {
            this.f6484c = this.d.f6470c.entrySet().iterator();
        }
        return this.f6484c;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i10 = this.f6482a + 1;
        b0 b0Var = this.d;
        if (i10 >= b0Var.f6469b.size()) {
            return !b0Var.f6470c.isEmpty() && a().hasNext();
        }
        return true;
    }

    @Override // java.util.Iterator
    public final Object next() {
        this.f6483b = true;
        int i10 = this.f6482a + 1;
        this.f6482a = i10;
        b0 b0Var = this.d;
        return i10 < b0Var.f6469b.size() ? (Map.Entry) b0Var.f6469b.get(this.f6482a) : (Map.Entry) a().next();
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f6483b) {
            throw new IllegalStateException("remove() was called before next()");
        }
        this.f6483b = false;
        int i10 = b0.f6467n;
        b0 b0Var = this.d;
        b0Var.b();
        if (this.f6482a >= b0Var.f6469b.size()) {
            a().remove();
            return;
        }
        int i11 = this.f6482a;
        this.f6482a = i11 - 1;
        b0Var.h(i11);
    }
}
