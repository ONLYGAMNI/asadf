package androidx.datastore.preferences.protobuf;

/* renamed from: androidx.datastore.preferences.protobuf.o, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0370o {

    /* renamed from: a, reason: collision with root package name */
    public static final C0369n f6516a = new C0369n();

    /* renamed from: b, reason: collision with root package name */
    public static final C0369n f6517b;

    static {
        C0369n c0369n = null;
        try {
            c0369n = (C0369n) Class.forName("androidx.datastore.preferences.protobuf.ExtensionSchemaFull").getDeclaredConstructor(null).newInstance(null);
        } catch (Exception unused) {
        }
        f6517b = c0369n;
    }
}
