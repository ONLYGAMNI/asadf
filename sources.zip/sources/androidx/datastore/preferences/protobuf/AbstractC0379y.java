package androidx.datastore.preferences.protobuf;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;

/* renamed from: androidx.datastore.preferences.protobuf.y, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public abstract class AbstractC0379y {

    /* renamed from: a, reason: collision with root package name */
    public static final Charset f6539a = Charset.forName("UTF-8");

    /* renamed from: b, reason: collision with root package name */
    public static final byte[] f6540b;

    static {
        Charset.forName("ISO-8859-1");
        byte[] bArr = new byte[0];
        f6540b = bArr;
        ByteBuffer.wrap(bArr);
        if ((0 - 0) + 0 <= Integer.MAX_VALUE) {
            return;
        }
        try {
            throw InvalidProtocolBufferException.f();
        } catch (InvalidProtocolBufferException e4) {
            throw new IllegalArgumentException(e4);
        }
    }

    public static void a(Object obj, String str) {
        if (obj == null) {
            throw new NullPointerException(str);
        }
    }

    public static int b(long j10) {
        return (int) (j10 ^ (j10 >>> 32));
    }

    public static AbstractC0376v c(Object obj, Object obj2) {
        AbstractC0376v abstractC0376v = (AbstractC0376v) ((AbstractC0356a) obj);
        AbstractC0374t abstractC0374t = (AbstractC0374t) abstractC0376v.d(5);
        abstractC0374t.d();
        AbstractC0374t.f(abstractC0374t.f6536b, abstractC0376v);
        AbstractC0356a abstractC0356a = (AbstractC0356a) obj2;
        if (!abstractC0374t.f6535a.getClass().isInstance(abstractC0356a)) {
            throw new IllegalArgumentException("mergeFrom(MessageLite) can only merge messages of the same type.");
        }
        abstractC0374t.d();
        AbstractC0374t.f(abstractC0374t.f6536b, (AbstractC0376v) abstractC0356a);
        return abstractC0374t.c();
    }
}
