package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

/* renamed from: androidx.datastore.preferences.protobuf.f, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0361f {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f6481a;

    public final byte[] a(byte[] bArr, int i10, int i11) {
        switch (this.f6481a) {
            case 0:
                return Arrays.copyOfRange(bArr, i10, i11 + i10);
            default:
                byte[] bArr2 = new byte[i11];
                System.arraycopy(bArr, i10, bArr2, 0, i11);
                return bArr2;
        }
    }
}
