package androidx.datastore.preferences.protobuf;

/* loaded from: classes.dex */
public final class X {

    /* renamed from: a, reason: collision with root package name */
    public final AbstractC0356a f6460a;

    /* renamed from: b, reason: collision with root package name */
    public final String f6461b;

    /* renamed from: c, reason: collision with root package name */
    public final Object[] f6462c;
    public final int d;

    public X(AbstractC0356a abstractC0356a, String str, Object[] objArr) {
        this.f6460a = abstractC0356a;
        this.f6461b = str;
        this.f6462c = objArr;
        char cCharAt = str.charAt(0);
        if (cCharAt < 55296) {
            this.d = cCharAt;
            return;
        }
        int i10 = cCharAt & 8191;
        int i11 = 1;
        int i12 = 13;
        while (true) {
            int i13 = i11 + 1;
            char cCharAt2 = str.charAt(i11);
            if (cCharAt2 < 55296) {
                this.d = i10 | (cCharAt2 << i12);
                return;
            } else {
                i10 |= (cCharAt2 & 8191) << i12;
                i12 += 13;
                i11 = i13;
            }
        }
    }

    public final AbstractC0356a a() {
        return this.f6460a;
    }

    public final Object[] b() {
        return this.f6462c;
    }

    public final String c() {
        return this.f6461b;
    }

    public final int d() {
        return (this.d & 1) == 1 ? 1 : 2;
    }
}
