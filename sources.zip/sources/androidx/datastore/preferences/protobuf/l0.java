package androidx.datastore.preferences.protobuf;

import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

/* loaded from: classes.dex */
public final class l0 extends AbstractList implements B, RandomAccess {

    /* renamed from: a, reason: collision with root package name */
    public final B f6512a;

    public l0(B b7) {
        this.f6512a = b7;
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final void d(C0362g c0362g) {
        throw new UnsupportedOperationException();
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final B f() {
        return this;
    }

    @Override // java.util.AbstractList, java.util.List
    public final Object get(int i10) {
        return (String) this.f6512a.get(i10);
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final Object h(int i10) {
        return this.f6512a.h(i10);
    }

    @Override // androidx.datastore.preferences.protobuf.B
    public final List i() {
        return this.f6512a.i();
    }

    @Override // java.util.AbstractList, java.util.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
    public final Iterator iterator() {
        return new k0(this);
    }

    @Override // java.util.AbstractList, java.util.List
    public final ListIterator listIterator(int i10) {
        return new j0(this, i10);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public final int size() {
        return this.f6512a.size();
    }
}
