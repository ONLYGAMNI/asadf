package androidx.datastore.preferences.protobuf;

/* JADX WARN: Enum visitor error
jadx.core.utils.exceptions.JadxRuntimeException: Init of enum field 'EF12' uses external variables
	at jadx.core.dex.visitors.EnumVisitor.createEnumFieldByConstructor(EnumVisitor.java:451)
	at jadx.core.dex.visitors.EnumVisitor.processEnumFieldByRegister(EnumVisitor.java:395)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromFilledArray(EnumVisitor.java:324)
	at jadx.core.dex.visitors.EnumVisitor.extractEnumFieldsFromInsn(EnumVisitor.java:262)
	at jadx.core.dex.visitors.EnumVisitor.convertToEnum(EnumVisitor.java:151)
	at jadx.core.dex.visitors.EnumVisitor.visit(EnumVisitor.java:100)
 */
/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* loaded from: classes.dex */
public class y0 {

    /* renamed from: c, reason: collision with root package name */
    public static final u0 f6541c;
    public static final v0 d;

    /* renamed from: e, reason: collision with root package name */
    public static final w0 f6542e;

    /* renamed from: f, reason: collision with root package name */
    public static final /* synthetic */ y0[] f6543f;

    /* renamed from: a, reason: collision with root package name */
    public final z0 f6544a;

    /* renamed from: b, reason: collision with root package name */
    public final int f6545b;

    /* JADX INFO: Fake field, exist only in values array */
    y0 EF10;

    /* JADX INFO: Fake field, exist only in values array */
    y0 EF11;

    /* JADX INFO: Fake field, exist only in values array */
    y0 EF12;

    static {
        y0 y0Var = new y0("DOUBLE", 0, z0.DOUBLE, 1);
        y0 y0Var2 = new y0("FLOAT", 1, z0.FLOAT, 5);
        z0 z0Var = z0.LONG;
        y0 y0Var3 = new y0("INT64", 2, z0Var, 0);
        y0 y0Var4 = new y0("UINT64", 3, z0Var, 0);
        z0 z0Var2 = z0.INT;
        y0 y0Var5 = new y0("INT32", 4, z0Var2, 0);
        y0 y0Var6 = new y0("FIXED64", 5, z0Var, 1);
        y0 y0Var7 = new y0("FIXED32", 6, z0Var2, 5);
        y0 y0Var8 = new y0("BOOL", 7, z0.BOOLEAN, 0);
        u0 u0Var = new u0("STRING", 8, z0.STRING, 2);
        f6541c = u0Var;
        z0 z0Var3 = z0.MESSAGE;
        v0 v0Var = new v0("GROUP", 9, z0Var3, 3);
        d = v0Var;
        w0 w0Var = new w0("MESSAGE", 10, z0Var3, 2);
        f6542e = w0Var;
        f6543f = new y0[]{y0Var, y0Var2, y0Var3, y0Var4, y0Var5, y0Var6, y0Var7, y0Var8, u0Var, v0Var, w0Var, new x0("BYTES", 11, z0.BYTE_STRING, 2), new y0("UINT32", 12, z0Var2, 0), new y0("ENUM", 13, z0.ENUM, 0), new y0("SFIXED32", 14, z0Var2, 5), new y0("SFIXED64", 15, z0Var, 1), new y0("SINT32", 16, z0Var2, 0), new y0("SINT64", 17, z0Var, 0)};
    }

    public y0(String str, int i10, z0 z0Var, int i11) {
        this.f6544a = z0Var;
        this.f6545b = i11;
    }

    public static y0 valueOf(String str) {
        return (y0) Enum.valueOf(y0.class, str);
    }

    public static y0[] values() {
        return (y0[]) f6543f.clone();
    }
}
