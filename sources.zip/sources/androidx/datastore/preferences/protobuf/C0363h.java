package androidx.datastore.preferences.protobuf;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import u0.AbstractC1480a;

/* renamed from: androidx.datastore.preferences.protobuf.h, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public final class C0363h extends R.C {

    /* renamed from: e, reason: collision with root package name */
    public final InputStream f6488e;

    /* renamed from: f, reason: collision with root package name */
    public final byte[] f6489f;

    /* renamed from: n, reason: collision with root package name */
    public int f6490n;

    /* renamed from: o, reason: collision with root package name */
    public int f6491o;

    /* renamed from: p, reason: collision with root package name */
    public int f6492p;

    /* renamed from: q, reason: collision with root package name */
    public int f6493q;

    /* renamed from: r, reason: collision with root package name */
    public int f6494r;

    /* renamed from: s, reason: collision with root package name */
    public int f6495s;

    public C0363h(FileInputStream fileInputStream) {
        super(1);
        this.f6495s = com.google.android.gms.common.api.f.API_PRIORITY_OTHER;
        Charset charset = AbstractC0379y.f6539a;
        this.f6488e = fileInputStream;
        this.f6489f = new byte[4096];
        this.f6490n = 0;
        this.f6492p = 0;
        this.f6494r = 0;
    }

    @Override // R.C
    public final String A() throws IOException {
        int iM = M();
        int i10 = this.f6492p;
        int i11 = this.f6490n;
        int i12 = i11 - i10;
        byte[] bArrH = this.f6489f;
        if (iM <= i12 && iM > 0) {
            this.f6492p = i10 + iM;
        } else {
            if (iM == 0) {
                return "";
            }
            i10 = 0;
            if (iM <= i11) {
                Q(iM);
                this.f6492p = iM;
            } else {
                bArrH = H(iM);
            }
        }
        return t0.f6538a.f(bArrH, i10, iM);
    }

    @Override // R.C
    public final int B() throws InvalidProtocolBufferException {
        if (j()) {
            this.f6493q = 0;
            return 0;
        }
        int iM = M();
        this.f6493q = iM;
        if ((iM >>> 3) != 0) {
            return iM;
        }
        throw new InvalidProtocolBufferException("Protocol message contained an invalid tag (zero).");
    }

    @Override // R.C
    public final int C() {
        return M();
    }

    @Override // R.C
    public final long D() {
        return N();
    }

    @Override // R.C
    public final boolean G(int i10) throws InvalidProtocolBufferException {
        int iB;
        int i11 = i10 & 7;
        int i12 = 0;
        if (i11 == 0) {
            int i13 = this.f6490n - this.f6492p;
            byte[] bArr = this.f6489f;
            if (i13 >= 10) {
                while (i12 < 10) {
                    int i14 = this.f6492p;
                    this.f6492p = i14 + 1;
                    if (bArr[i14] < 0) {
                        i12++;
                    }
                }
                throw InvalidProtocolBufferException.c();
            }
            while (i12 < 10) {
                if (this.f6492p == this.f6490n) {
                    Q(1);
                }
                int i15 = this.f6492p;
                this.f6492p = i15 + 1;
                if (bArr[i15] < 0) {
                    i12++;
                }
            }
            throw InvalidProtocolBufferException.c();
            return true;
        }
        if (i11 == 1) {
            R(8);
            return true;
        }
        if (i11 == 2) {
            R(M());
            return true;
        }
        if (i11 != 3) {
            if (i11 == 4) {
                return false;
            }
            if (i11 != 5) {
                throw InvalidProtocolBufferException.b();
            }
            R(4);
            return true;
        }
        do {
            iB = B();
            if (iB == 0) {
                break;
            }
        } while (G(iB));
        d(((i10 >>> 3) << 3) | 4);
        return true;
    }

    public final byte[] H(int i10) throws IOException {
        byte[] bArrI = I(i10);
        if (bArrI != null) {
            return bArrI;
        }
        int i11 = this.f6492p;
        int i12 = this.f6490n;
        int length = i12 - i11;
        this.f6494r += i12;
        this.f6492p = 0;
        this.f6490n = 0;
        ArrayList arrayListJ = J(i10 - length);
        byte[] bArr = new byte[i10];
        System.arraycopy(this.f6489f, i11, bArr, 0, length);
        Iterator it = arrayListJ.iterator();
        while (it.hasNext()) {
            byte[] bArr2 = (byte[]) it.next();
            System.arraycopy(bArr2, 0, bArr, length, bArr2.length);
            length += bArr2.length;
        }
        return bArr;
    }

    public final byte[] I(int i10) throws IOException {
        if (i10 == 0) {
            return AbstractC0379y.f6540b;
        }
        if (i10 < 0) {
            throw InvalidProtocolBufferException.d();
        }
        int i11 = this.f6494r;
        int i12 = this.f6492p;
        int i13 = i11 + i12 + i10;
        if (i13 - this.f3954c > 0) {
            throw new InvalidProtocolBufferException("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
        }
        int i14 = this.f6495s;
        if (i13 > i14) {
            R((i14 - i11) - i12);
            throw InvalidProtocolBufferException.f();
        }
        int i15 = this.f6490n - i12;
        int i16 = i10 - i15;
        InputStream inputStream = this.f6488e;
        if (i16 >= 4096 && i16 > inputStream.available()) {
            return null;
        }
        byte[] bArr = new byte[i10];
        System.arraycopy(this.f6489f, this.f6492p, bArr, 0, i15);
        this.f6494r += this.f6490n;
        this.f6492p = 0;
        this.f6490n = 0;
        while (i15 < i10) {
            int i17 = inputStream.read(bArr, i15, i10 - i15);
            if (i17 == -1) {
                throw InvalidProtocolBufferException.f();
            }
            this.f6494r += i17;
            i15 += i17;
        }
        return bArr;
    }

    public final ArrayList J(int i10) throws IOException {
        ArrayList arrayList = new ArrayList();
        while (i10 > 0) {
            int iMin = Math.min(i10, 4096);
            byte[] bArr = new byte[iMin];
            int i11 = 0;
            while (i11 < iMin) {
                int i12 = this.f6488e.read(bArr, i11, iMin - i11);
                if (i12 == -1) {
                    throw InvalidProtocolBufferException.f();
                }
                this.f6494r += i12;
                i11 += i12;
            }
            i10 -= iMin;
            arrayList.add(bArr);
        }
        return arrayList;
    }

    public final int K() throws InvalidProtocolBufferException {
        int i10 = this.f6492p;
        if (this.f6490n - i10 < 4) {
            Q(4);
            i10 = this.f6492p;
        }
        this.f6492p = i10 + 4;
        byte[] bArr = this.f6489f;
        return ((bArr[i10 + 3] & 255) << 24) | (bArr[i10] & 255) | ((bArr[i10 + 1] & 255) << 8) | ((bArr[i10 + 2] & 255) << 16);
    }

    public final long L() throws InvalidProtocolBufferException {
        int i10 = this.f6492p;
        if (this.f6490n - i10 < 8) {
            Q(8);
            i10 = this.f6492p;
        }
        this.f6492p = i10 + 8;
        byte[] bArr = this.f6489f;
        return ((bArr[i10 + 7] & 255) << 56) | (bArr[i10] & 255) | ((bArr[i10 + 1] & 255) << 8) | ((bArr[i10 + 2] & 255) << 16) | ((bArr[i10 + 3] & 255) << 24) | ((bArr[i10 + 4] & 255) << 32) | ((bArr[i10 + 5] & 255) << 40) | ((bArr[i10 + 6] & 255) << 48);
    }

    public final int M() {
        int i10;
        int i11 = this.f6492p;
        int i12 = this.f6490n;
        if (i12 != i11) {
            int i13 = i11 + 1;
            byte[] bArr = this.f6489f;
            byte b7 = bArr[i11];
            if (b7 >= 0) {
                this.f6492p = i13;
                return b7;
            }
            if (i12 - i13 >= 9) {
                int i14 = i11 + 2;
                int i15 = (bArr[i13] << 7) ^ b7;
                if (i15 < 0) {
                    i10 = i15 ^ (-128);
                } else {
                    int i16 = i11 + 3;
                    int i17 = (bArr[i14] << 14) ^ i15;
                    if (i17 >= 0) {
                        i10 = i17 ^ 16256;
                    } else {
                        int i18 = i11 + 4;
                        int i19 = i17 ^ (bArr[i16] << 21);
                        if (i19 < 0) {
                            i10 = (-2080896) ^ i19;
                        } else {
                            i16 = i11 + 5;
                            byte b8 = bArr[i18];
                            int i20 = (i19 ^ (b8 << 28)) ^ 266354560;
                            if (b8 < 0) {
                                i18 = i11 + 6;
                                if (bArr[i16] < 0) {
                                    i16 = i11 + 7;
                                    if (bArr[i18] < 0) {
                                        i18 = i11 + 8;
                                        if (bArr[i16] < 0) {
                                            i16 = i11 + 9;
                                            if (bArr[i18] < 0) {
                                                int i21 = i11 + 10;
                                                if (bArr[i16] >= 0) {
                                                    i14 = i21;
                                                    i10 = i20;
                                                }
                                            }
                                        }
                                    }
                                }
                                i10 = i20;
                            }
                            i10 = i20;
                        }
                        i14 = i18;
                    }
                    i14 = i16;
                }
                this.f6492p = i14;
                return i10;
            }
        }
        return (int) O();
    }

    public final long N() {
        long j10;
        long j11;
        long j12;
        long j13;
        int i10 = this.f6492p;
        int i11 = this.f6490n;
        if (i11 != i10) {
            int i12 = i10 + 1;
            byte[] bArr = this.f6489f;
            byte b7 = bArr[i10];
            if (b7 >= 0) {
                this.f6492p = i12;
                return b7;
            }
            if (i11 - i12 >= 9) {
                int i13 = i10 + 2;
                int i14 = (bArr[i12] << 7) ^ b7;
                if (i14 < 0) {
                    j10 = i14 ^ (-128);
                } else {
                    int i15 = i10 + 3;
                    int i16 = (bArr[i13] << 14) ^ i14;
                    if (i16 >= 0) {
                        j10 = i16 ^ 16256;
                        i13 = i15;
                    } else {
                        int i17 = i10 + 4;
                        int i18 = i16 ^ (bArr[i15] << 21);
                        if (i18 < 0) {
                            j13 = (-2080896) ^ i18;
                        } else {
                            long j14 = i18;
                            i13 = i10 + 5;
                            long j15 = j14 ^ (bArr[i17] << 28);
                            if (j15 >= 0) {
                                j12 = 266354560;
                            } else {
                                i17 = i10 + 6;
                                long j16 = j15 ^ (bArr[i13] << 35);
                                if (j16 < 0) {
                                    j11 = -34093383808L;
                                } else {
                                    i13 = i10 + 7;
                                    j15 = j16 ^ (bArr[i17] << 42);
                                    if (j15 >= 0) {
                                        j12 = 4363953127296L;
                                    } else {
                                        i17 = i10 + 8;
                                        j16 = j15 ^ (bArr[i13] << 49);
                                        if (j16 < 0) {
                                            j11 = -558586000294016L;
                                        } else {
                                            i13 = i10 + 9;
                                            long j17 = (j16 ^ (bArr[i17] << 56)) ^ 71499008037633920L;
                                            if (j17 < 0) {
                                                int i19 = i10 + 10;
                                                if (bArr[i13] >= 0) {
                                                    i13 = i19;
                                                }
                                            }
                                            j10 = j17;
                                        }
                                    }
                                }
                                j13 = j11 ^ j16;
                            }
                            j10 = j12 ^ j15;
                        }
                        i13 = i17;
                        j10 = j13;
                    }
                }
                this.f6492p = i13;
                return j10;
            }
        }
        return O();
    }

    public final long O() throws InvalidProtocolBufferException {
        long j10 = 0;
        for (int i10 = 0; i10 < 64; i10 += 7) {
            if (this.f6492p == this.f6490n) {
                Q(1);
            }
            int i11 = this.f6492p;
            this.f6492p = i11 + 1;
            j10 |= (r3 & Byte.MAX_VALUE) << i10;
            if ((this.f6489f[i11] & 128) == 0) {
                return j10;
            }
        }
        throw InvalidProtocolBufferException.c();
    }

    public final void P() {
        int i10 = this.f6490n + this.f6491o;
        this.f6490n = i10;
        int i11 = this.f6494r + i10;
        int i12 = this.f6495s;
        if (i11 <= i12) {
            this.f6491o = 0;
            return;
        }
        int i13 = i11 - i12;
        this.f6491o = i13;
        this.f6490n = i10 - i13;
    }

    public final void Q(int i10) throws InvalidProtocolBufferException {
        if (S(i10)) {
            return;
        }
        if (i10 <= (this.f3954c - this.f6494r) - this.f6492p) {
            throw InvalidProtocolBufferException.f();
        }
        throw new InvalidProtocolBufferException("Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit.");
    }

    public final void R(int i10) throws InvalidProtocolBufferException {
        int i11 = this.f6490n;
        int i12 = this.f6492p;
        if (i10 <= i11 - i12 && i10 >= 0) {
            this.f6492p = i12 + i10;
            return;
        }
        InputStream inputStream = this.f6488e;
        if (i10 < 0) {
            throw InvalidProtocolBufferException.d();
        }
        int i13 = this.f6494r;
        int i14 = i13 + i12;
        int i15 = i14 + i10;
        int i16 = this.f6495s;
        if (i15 > i16) {
            R((i16 - i13) - i12);
            throw InvalidProtocolBufferException.f();
        }
        this.f6494r = i14;
        int i17 = i11 - i12;
        this.f6490n = 0;
        this.f6492p = 0;
        while (i17 < i10) {
            long j10 = i10 - i17;
            try {
                long jSkip = inputStream.skip(j10);
                if (jSkip < 0 || jSkip > j10) {
                    throw new IllegalStateException(inputStream.getClass() + "#skip returned invalid result: " + jSkip + "\nThe InputStream implementation is buggy.");
                }
                if (jSkip == 0) {
                    break;
                } else {
                    i17 += (int) jSkip;
                }
            } finally {
                this.f6494r += i17;
                P();
            }
        }
        if (i17 >= i10) {
            return;
        }
        int i18 = this.f6490n;
        int i19 = i18 - this.f6492p;
        this.f6492p = i18;
        Q(1);
        while (true) {
            int i20 = i10 - i19;
            int i21 = this.f6490n;
            if (i20 <= i21) {
                this.f6492p = i20;
                return;
            } else {
                i19 += i21;
                this.f6492p = i21;
                Q(1);
            }
        }
    }

    public final boolean S(int i10) throws IOException {
        int i11 = this.f6492p;
        int i12 = i11 + i10;
        int i13 = this.f6490n;
        if (i12 <= i13) {
            throw new IllegalStateException(AbstractC1480a.j("refillBuffer() called when ", i10, " bytes were already available in buffer"));
        }
        int i14 = this.f6494r;
        int i15 = this.f3954c;
        if (i10 > (i15 - i14) - i11 || i14 + i11 + i10 > this.f6495s) {
            return false;
        }
        byte[] bArr = this.f6489f;
        if (i11 > 0) {
            if (i13 > i11) {
                System.arraycopy(bArr, i11, bArr, 0, i13 - i11);
            }
            this.f6494r += i11;
            this.f6490n -= i11;
            this.f6492p = 0;
        }
        int i16 = this.f6490n;
        int iMin = Math.min(bArr.length - i16, (i15 - this.f6494r) - i16);
        InputStream inputStream = this.f6488e;
        int i17 = inputStream.read(bArr, i16, iMin);
        if (i17 == 0 || i17 < -1 || i17 > bArr.length) {
            throw new IllegalStateException(inputStream.getClass() + "#read(byte[]) returned invalid result: " + i17 + "\nThe InputStream implementation is buggy.");
        }
        if (i17 <= 0) {
            return false;
        }
        this.f6490n += i17;
        P();
        if (this.f6490n >= i10) {
            return true;
        }
        return S(i10);
    }

    @Override // R.C
    public final void d(int i10) throws InvalidProtocolBufferException {
        if (this.f6493q != i10) {
            throw new InvalidProtocolBufferException("Protocol message end-group tag did not match expected tag.");
        }
    }

    @Override // R.C
    public final int h() {
        return this.f6494r + this.f6492p;
    }

    @Override // R.C
    public final boolean j() {
        return this.f6492p == this.f6490n && !S(1);
    }

    @Override // R.C
    public final void k(int i10) {
        this.f6495s = i10;
        P();
    }

    @Override // R.C
    public final int l(int i10) throws InvalidProtocolBufferException {
        if (i10 < 0) {
            throw InvalidProtocolBufferException.d();
        }
        int i11 = this.f6494r + this.f6492p + i10;
        int i12 = this.f6495s;
        if (i11 > i12) {
            throw InvalidProtocolBufferException.f();
        }
        this.f6495s = i11;
        P();
        return i12;
    }

    @Override // R.C
    public final boolean m() {
        return N() != 0;
    }

    @Override // R.C
    public final C0362g n() throws IOException {
        int iM = M();
        int i10 = this.f6490n;
        int i11 = this.f6492p;
        int i12 = i10 - i11;
        byte[] bArr = this.f6489f;
        if (iM <= i12 && iM > 0) {
            C0362g c0362gC = C0362g.c(bArr, i11, iM);
            this.f6492p += iM;
            return c0362gC;
        }
        if (iM == 0) {
            return C0362g.f6485c;
        }
        byte[] bArrI = I(iM);
        if (bArrI != null) {
            return C0362g.c(bArrI, 0, bArrI.length);
        }
        int i13 = this.f6492p;
        int i14 = this.f6490n;
        int length = i14 - i13;
        this.f6494r += i14;
        this.f6492p = 0;
        this.f6490n = 0;
        ArrayList arrayListJ = J(iM - length);
        byte[] bArr2 = new byte[iM];
        System.arraycopy(bArr, i13, bArr2, 0, length);
        Iterator it = arrayListJ.iterator();
        while (it.hasNext()) {
            byte[] bArr3 = (byte[]) it.next();
            System.arraycopy(bArr3, 0, bArr2, length, bArr3.length);
            length += bArr3.length;
        }
        C0362g c0362g = C0362g.f6485c;
        return new C0362g(bArr2);
    }

    @Override // R.C
    public final double o() {
        return Double.longBitsToDouble(L());
    }

    @Override // R.C
    public final int p() {
        return M();
    }

    @Override // R.C
    public final int q() {
        return K();
    }

    @Override // R.C
    public final long r() {
        return L();
    }

    @Override // R.C
    public final float s() {
        return Float.intBitsToFloat(K());
    }

    @Override // R.C
    public final int t() {
        return M();
    }

    @Override // R.C
    public final long u() {
        return N();
    }

    @Override // R.C
    public final int v() {
        return K();
    }

    @Override // R.C
    public final long w() {
        return L();
    }

    @Override // R.C
    public final int x() {
        int iM = M();
        return (-(iM & 1)) ^ (iM >>> 1);
    }

    @Override // R.C
    public final long y() {
        long jN = N();
        return (-(jN & 1)) ^ (jN >>> 1);
    }

    @Override // R.C
    public final String z() throws InvalidProtocolBufferException {
        int iM = M();
        byte[] bArr = this.f6489f;
        if (iM > 0) {
            int i10 = this.f6490n;
            int i11 = this.f6492p;
            if (iM <= i10 - i11) {
                String str = new String(bArr, i11, iM, AbstractC0379y.f6539a);
                this.f6492p += iM;
                return str;
            }
        }
        if (iM == 0) {
            return "";
        }
        if (iM > this.f6490n) {
            return new String(H(iM), AbstractC0379y.f6539a);
        }
        Q(iM);
        String str2 = new String(bArr, this.f6492p, iM, AbstractC0379y.f6539a);
        this.f6492p += iM;
        return str2;
    }
}
