package androidx.datastore.preferences.protobuf;

import com.google.android.gms.dynamite.descriptors.com.google.android.gms.measurement.dynamite.ModuleDescriptor;
import java.io.IOException;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/* renamed from: androidx.datastore.preferences.protobuf.j */
/* loaded from: classes.dex */
public final class C0365j extends N {

    /* renamed from: h */
    public static final Logger f6504h = Logger.getLogger(C0365j.class.getName());

    /* renamed from: i */
    public static final boolean f6505i = q0.f6530f;

    /* renamed from: c */
    public H f6506c;
    public final byte[] d;

    /* renamed from: e */
    public final int f6507e;

    /* renamed from: f */
    public int f6508f;
    public final OutputStream g;

    public C0365j(b0.p pVar, int i10) {
        if (i10 < 0) {
            throw new IllegalArgumentException("bufferSize must be >= 0");
        }
        int iMax = Math.max(i10, 20);
        this.d = new byte[iMax];
        this.f6507e = iMax;
        this.g = pVar;
    }

    public static int A(int i10, AbstractC0356a abstractC0356a, Z z3) {
        return abstractC0356a.b(z3) + (K(i10) * 2);
    }

    public static int B(int i10, int i11) {
        return C(i11) + K(i10);
    }

    public static int C(int i10) {
        if (i10 >= 0) {
            return M(i10);
        }
        return 10;
    }

    public static int D(int i10, long j10) {
        return O(j10) + K(i10);
    }

    public static int E(int i10) {
        return K(i10) + 4;
    }

    public static int F(int i10) {
        return K(i10) + 8;
    }

    public static int G(int i10, int i11) {
        return M((i11 >> 31) ^ (i11 << 1)) + K(i10);
    }

    public static int H(int i10, long j10) {
        return O((j10 >> 63) ^ (j10 << 1)) + K(i10);
    }

    public static int I(int i10, String str) {
        return J(str) + K(i10);
    }

    public static int J(String str) {
        int length;
        try {
            length = t0.b(str);
        } catch (s0 unused) {
            length = str.getBytes(AbstractC0379y.f6539a).length;
        }
        return M(length) + length;
    }

    public static int K(int i10) {
        return M(i10 << 3);
    }

    public static int L(int i10, int i11) {
        return M(i11) + K(i10);
    }

    public static int M(int i10) {
        if ((i10 & (-128)) == 0) {
            return 1;
        }
        if ((i10 & (-16384)) == 0) {
            return 2;
        }
        if (((-2097152) & i10) == 0) {
            return 3;
        }
        return (i10 & (-268435456)) == 0 ? 4 : 5;
    }

    public static int N(int i10, long j10) {
        return O(j10) + K(i10);
    }

    public static int O(long j10) {
        int i10;
        if (((-128) & j10) == 0) {
            return 1;
        }
        if (j10 < 0) {
            return 10;
        }
        if (((-34359738368L) & j10) != 0) {
            j10 >>>= 28;
            i10 = 6;
        } else {
            i10 = 2;
        }
        if (((-2097152) & j10) != 0) {
            i10 += 2;
            j10 >>>= 14;
        }
        return (j10 & (-16384)) != 0 ? i10 + 1 : i10;
    }

    public static int s(int i10) {
        return K(i10) + 1;
    }

    public static int t(int i10, C0362g c0362g) {
        return u(c0362g) + K(i10);
    }

    public static int u(C0362g c0362g) {
        int size = c0362g.size();
        return M(size) + size;
    }

    public static int v(int i10) {
        return K(i10) + 8;
    }

    public static int w(int i10, int i11) {
        return C(i11) + K(i10);
    }

    public static int x(int i10) {
        return K(i10) + 4;
    }

    public static int y(int i10) {
        return K(i10) + 8;
    }

    public static int z(int i10) {
        return K(i10) + 4;
    }

    public final void P() throws IOException {
        this.g.write(this.d, 0, this.f6508f);
        this.f6508f = 0;
    }

    public final void Q(int i10) throws IOException {
        if (this.f6507e - this.f6508f < i10) {
            P();
        }
    }

    public final void R(String str, s0 s0Var) throws IOException {
        f6504h.log(Level.WARNING, "Converting ill-formed UTF-16. Your Protocol Buffer will not round trip correctly!", (Throwable) s0Var);
        byte[] bytes = str.getBytes(AbstractC0379y.f6539a);
        try {
            k0(bytes.length);
            m(bytes, 0, bytes.length);
        } catch (CodedOutputStream$OutOfSpaceException e4) {
            throw e4;
        } catch (IndexOutOfBoundsException e5) {
            throw new CodedOutputStream$OutOfSpaceException(e5);
        }
    }

    public final void S(byte b7) throws IOException {
        if (this.f6508f == this.f6507e) {
            P();
        }
        int i10 = this.f6508f;
        this.f6508f = i10 + 1;
        this.d[i10] = b7;
    }

    public final void T(byte[] bArr, int i10, int i11) throws IOException {
        int i12 = this.f6508f;
        int i13 = this.f6507e;
        int i14 = i13 - i12;
        byte[] bArr2 = this.d;
        if (i14 >= i11) {
            System.arraycopy(bArr, i10, bArr2, i12, i11);
            this.f6508f += i11;
            return;
        }
        System.arraycopy(bArr, i10, bArr2, i12, i14);
        int i15 = i10 + i14;
        int i16 = i11 - i14;
        this.f6508f = i13;
        P();
        if (i16 > i13) {
            this.g.write(bArr, i15, i16);
        } else {
            System.arraycopy(bArr, i15, bArr2, 0, i16);
            this.f6508f = i16;
        }
    }

    public final void U(int i10, boolean z3) throws IOException {
        Q(11);
        p(i10, 0);
        byte b7 = z3 ? (byte) 1 : (byte) 0;
        int i11 = this.f6508f;
        this.f6508f = i11 + 1;
        this.d[i11] = b7;
    }

    public final void V(byte[] bArr, int i10) throws IOException {
        k0(i10);
        T(bArr, 0, i10);
    }

    public final void W(int i10, C0362g c0362g) throws IOException {
        i0(i10, 2);
        X(c0362g);
    }

    public final void X(C0362g c0362g) throws IOException {
        k0(c0362g.size());
        m(c0362g.f6487b, c0362g.e(), c0362g.size());
    }

    public final void Y(int i10, int i11) throws IOException {
        Q(14);
        p(i10, 5);
        n(i11);
    }

    public final void Z(int i10) throws IOException {
        Q(4);
        n(i10);
    }

    public final void a0(int i10, long j10) throws IOException {
        Q(18);
        p(i10, 1);
        o(j10);
    }

    public final void b0(long j10) throws IOException {
        Q(8);
        o(j10);
    }

    public final void c0(int i10, int i11) throws IOException {
        Q(20);
        p(i10, 0);
        if (i11 >= 0) {
            q(i11);
        } else {
            r(i11);
        }
    }

    public final void d0(int i10) throws IOException {
        if (i10 >= 0) {
            k0(i10);
        } else {
            m0(i10);
        }
    }

    public final void e0(int i10, AbstractC0356a abstractC0356a, Z z3) throws IOException {
        i0(i10, 2);
        k0(abstractC0356a.b(z3));
        z3.c(abstractC0356a, this.f6506c);
    }

    public final void f0(AbstractC0356a abstractC0356a) throws IOException {
        k0(abstractC0356a.a());
        abstractC0356a.c(this);
    }

    public final void g0(int i10, String str) throws IOException {
        i0(i10, 2);
        h0(str);
    }

    public final void h0(String str) throws IOException {
        try {
            int length = str.length() * 3;
            int iM = M(length);
            int i10 = iM + length;
            int i11 = this.f6507e;
            if (i10 > i11) {
                byte[] bArr = new byte[length];
                int iG = t0.f6538a.g(str, bArr, 0, length);
                k0(iG);
                T(bArr, 0, iG);
                return;
            }
            if (i10 > i11 - this.f6508f) {
                P();
            }
            int iM2 = M(str.length());
            int i12 = this.f6508f;
            byte[] bArr2 = this.d;
            try {
                if (iM2 == iM) {
                    int i13 = i12 + iM2;
                    this.f6508f = i13;
                    int iG2 = t0.f6538a.g(str, bArr2, i13, i11 - i13);
                    this.f6508f = i12;
                    q((iG2 - i12) - iM2);
                    this.f6508f = iG2;
                } else {
                    int iB = t0.b(str);
                    q(iB);
                    this.f6508f = t0.f6538a.g(str, bArr2, this.f6508f, iB);
                }
            } catch (s0 e4) {
                this.f6508f = i12;
                throw e4;
            } catch (ArrayIndexOutOfBoundsException e5) {
                throw new CodedOutputStream$OutOfSpaceException(e5);
            }
        } catch (s0 e10) {
            R(str, e10);
        }
    }

    public final void i0(int i10, int i11) {
        k0((i10 << 3) | i11);
    }

    public final void j0(int i10, int i11) throws IOException {
        Q(20);
        p(i10, 0);
        q(i11);
    }

    public final void k0(int i10) throws IOException {
        Q(5);
        q(i10);
    }

    public final void l0(int i10, long j10) throws IOException {
        Q(20);
        p(i10, 0);
        r(j10);
    }

    @Override // androidx.datastore.preferences.protobuf.N
    public final void m(byte[] bArr, int i10, int i11) throws IOException {
        T(bArr, i10, i11);
    }

    public final void m0(long j10) throws IOException {
        Q(10);
        r(j10);
    }

    public final void n(int i10) {
        int i11 = this.f6508f;
        int i12 = i11 + 1;
        this.f6508f = i12;
        byte[] bArr = this.d;
        bArr[i11] = (byte) (i10 & 255);
        int i13 = i11 + 2;
        this.f6508f = i13;
        bArr[i12] = (byte) ((i10 >> 8) & 255);
        int i14 = i11 + 3;
        this.f6508f = i14;
        bArr[i13] = (byte) ((i10 >> 16) & 255);
        this.f6508f = i11 + 4;
        bArr[i14] = (byte) ((i10 >> 24) & 255);
    }

    public final void o(long j10) {
        int i10 = this.f6508f;
        int i11 = i10 + 1;
        this.f6508f = i11;
        byte[] bArr = this.d;
        bArr[i10] = (byte) (j10 & 255);
        int i12 = i10 + 2;
        this.f6508f = i12;
        bArr[i11] = (byte) ((j10 >> 8) & 255);
        int i13 = i10 + 3;
        this.f6508f = i13;
        bArr[i12] = (byte) ((j10 >> 16) & 255);
        int i14 = i10 + 4;
        this.f6508f = i14;
        bArr[i13] = (byte) (255 & (j10 >> 24));
        int i15 = i10 + 5;
        this.f6508f = i15;
        bArr[i14] = (byte) (((int) (j10 >> 32)) & 255);
        int i16 = i10 + 6;
        this.f6508f = i16;
        bArr[i15] = (byte) (((int) (j10 >> 40)) & 255);
        int i17 = i10 + 7;
        this.f6508f = i17;
        bArr[i16] = (byte) (((int) (j10 >> 48)) & 255);
        this.f6508f = i10 + 8;
        bArr[i17] = (byte) (((int) (j10 >> 56)) & 255);
    }

    public final void p(int i10, int i11) {
        q((i10 << 3) | i11);
    }

    public final void q(int i10) {
        boolean z3 = f6505i;
        byte[] bArr = this.d;
        if (z3) {
            while ((i10 & (-128)) != 0) {
                int i11 = this.f6508f;
                this.f6508f = i11 + 1;
                q0.m(bArr, i11, (byte) ((i10 & ModuleDescriptor.MODULE_VERSION) | 128));
                i10 >>>= 7;
            }
            int i12 = this.f6508f;
            this.f6508f = i12 + 1;
            q0.m(bArr, i12, (byte) i10);
            return;
        }
        while ((i10 & (-128)) != 0) {
            int i13 = this.f6508f;
            this.f6508f = i13 + 1;
            bArr[i13] = (byte) ((i10 & ModuleDescriptor.MODULE_VERSION) | 128);
            i10 >>>= 7;
        }
        int i14 = this.f6508f;
        this.f6508f = i14 + 1;
        bArr[i14] = (byte) i10;
    }

    public final void r(long j10) {
        boolean z3 = f6505i;
        byte[] bArr = this.d;
        if (z3) {
            while ((j10 & (-128)) != 0) {
                int i10 = this.f6508f;
                this.f6508f = i10 + 1;
                q0.m(bArr, i10, (byte) ((((int) j10) & ModuleDescriptor.MODULE_VERSION) | 128));
                j10 >>>= 7;
            }
            int i11 = this.f6508f;
            this.f6508f = i11 + 1;
            q0.m(bArr, i11, (byte) j10);
            return;
        }
        while ((j10 & (-128)) != 0) {
            int i12 = this.f6508f;
            this.f6508f = i12 + 1;
            bArr[i12] = (byte) ((((int) j10) & ModuleDescriptor.MODULE_VERSION) | 128);
            j10 >>>= 7;
        }
        int i13 = this.f6508f;
        this.f6508f = i13 + 1;
        bArr[i13] = (byte) j10;
    }
}
