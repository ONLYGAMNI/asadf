package androidx.datastore.preferences.protobuf;

import com.google.android.gms.dynamite.descriptors.com.google.firebase.auth.ModuleDescriptor;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/* renamed from: androidx.datastore.preferences.protobuf.p */
/* loaded from: classes.dex */
public final class C0371p {

    /* renamed from: c */
    public static final /* synthetic */ int f6518c = 0;

    /* renamed from: a */
    public final b0 f6519a = new b0(16);

    /* renamed from: b */
    public boolean f6520b;

    static {
        new C0371p(0);
    }

    public C0371p() {
    }

    public static void b(C0365j c0365j, y0 y0Var, int i10, Object obj) throws IOException {
        if (y0Var == y0.d) {
            c0365j.i0(i10, 3);
            ((AbstractC0356a) obj).c(c0365j);
            c0365j.i0(i10, 4);
            return;
        }
        c0365j.i0(i10, y0Var.f6545b);
        switch (y0Var.ordinal()) {
            case 0:
                c0365j.b0(Double.doubleToRawLongBits(((Double) obj).doubleValue()));
                break;
            case 1:
                c0365j.Z(Float.floatToRawIntBits(((Float) obj).floatValue()));
                break;
            case 2:
                c0365j.m0(((Long) obj).longValue());
                break;
            case 3:
                c0365j.m0(((Long) obj).longValue());
                break;
            case 4:
                c0365j.d0(((Integer) obj).intValue());
                break;
            case 5:
                c0365j.b0(((Long) obj).longValue());
                break;
            case d0.i.STRING_SET_FIELD_NUMBER /* 6 */:
                c0365j.Z(((Integer) obj).intValue());
                break;
            case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                c0365j.S(((Boolean) obj).booleanValue() ? (byte) 1 : (byte) 0);
                break;
            case 8:
                if (!(obj instanceof C0362g)) {
                    c0365j.h0((String) obj);
                    break;
                } else {
                    c0365j.X((C0362g) obj);
                    break;
                }
            case 9:
                ((AbstractC0356a) obj).c(c0365j);
                break;
            case 10:
                c0365j.f0((AbstractC0356a) obj);
                break;
            case ModuleDescriptor.MODULE_VERSION /* 11 */:
                if (!(obj instanceof C0362g)) {
                    byte[] bArr = (byte[]) obj;
                    c0365j.V(bArr, bArr.length);
                    break;
                } else {
                    c0365j.X((C0362g) obj);
                    break;
                }
            case 12:
                c0365j.k0(((Integer) obj).intValue());
                break;
            case 13:
                c0365j.d0(((Integer) obj).intValue());
                break;
            case 14:
                c0365j.Z(((Integer) obj).intValue());
                break;
            case 15:
                c0365j.b0(((Long) obj).longValue());
                break;
            case 16:
                int iIntValue = ((Integer) obj).intValue();
                c0365j.k0((iIntValue >> 31) ^ (iIntValue << 1));
                break;
            case 17:
                long jLongValue = ((Long) obj).longValue();
                c0365j.m0((jLongValue >> 63) ^ (jLongValue << 1));
                break;
        }
    }

    public final void a() {
        if (this.f6520b) {
            return;
        }
        b0 b0Var = this.f6519a;
        if (!b0Var.d) {
            if (b0Var.f6469b.size() > 0) {
                android.support.v4.media.session.a.u(b0Var.d(0).getKey());
                throw null;
            }
            Iterator it = b0Var.e().iterator();
            if (it.hasNext()) {
                android.support.v4.media.session.a.u(((Map.Entry) it.next()).getKey());
                throw null;
            }
        }
        if (!b0Var.d) {
            b0Var.f6470c = b0Var.f6470c.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(b0Var.f6470c);
            b0Var.f6472f = b0Var.f6472f.isEmpty() ? Collections.emptyMap() : Collections.unmodifiableMap(b0Var.f6472f);
            b0Var.d = true;
        }
        this.f6520b = true;
    }

    public final Object clone() {
        C0371p c0371p = new C0371p();
        b0 b0Var = this.f6519a;
        if (b0Var.f6469b.size() > 0) {
            Map.Entry entryD = b0Var.d(0);
            android.support.v4.media.session.a.u(entryD.getKey());
            entryD.getValue();
            throw null;
        }
        Iterator it = b0Var.e().iterator();
        if (!it.hasNext()) {
            return c0371p;
        }
        Map.Entry entry = (Map.Entry) it.next();
        android.support.v4.media.session.a.u(entry.getKey());
        entry.getValue();
        throw null;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0371p) {
            return this.f6519a.equals(((C0371p) obj).f6519a);
        }
        return false;
    }

    public final int hashCode() {
        return this.f6519a.hashCode();
    }

    public C0371p(int i10) {
        a();
        a();
    }
}
