package androidx.datastore.preferences.protobuf;

import com.google.android.gms.dynamite.descriptors.com.google.firebase.auth.ModuleDescriptor;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public abstract class N {

    /* renamed from: a, reason: collision with root package name */
    public static final c0 f6434a = new c0();

    /* renamed from: b, reason: collision with root package name */
    public static final d0 f6435b = new d0();

    public static void a(byte b7, byte b8, byte b10, byte b11, char[] cArr, int i10) throws InvalidProtocolBufferException {
        if (!i(b8)) {
            if ((((b8 + 112) + (b7 << 28)) >> 30) == 0 && !i(b10) && !i(b11)) {
                int i11 = ((b7 & 7) << 18) | ((b8 & 63) << 12) | ((b10 & 63) << 6) | (b11 & 63);
                cArr[i10] = (char) ((i11 >>> 10) + 55232);
                cArr[i10 + 1] = (char) ((i11 & 1023) + 56320);
                return;
            }
        }
        throw InvalidProtocolBufferException.a();
    }

    public static boolean b(byte b7) {
        return b7 >= 0;
    }

    public static void c(byte b7, byte b8, char[] cArr, int i10) throws InvalidProtocolBufferException {
        if (b7 < -62 || i(b8)) {
            throw InvalidProtocolBufferException.a();
        }
        cArr[i10] = (char) (((b7 & 31) << 6) | (b8 & 63));
    }

    public static void d(byte b7, byte b8, byte b10, char[] cArr, int i10) throws InvalidProtocolBufferException {
        if (i(b8) || ((b7 == -32 && b8 < -96) || ((b7 == -19 && b8 >= -96) || i(b10)))) {
            throw InvalidProtocolBufferException.a();
        }
        cArr[i10] = (char) (((b7 & 15) << 12) | ((b8 & 63) << 6) | (b10 & 63));
    }

    public static final String e(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i10 = 0; i10 < str.length(); i10++) {
            char cCharAt = str.charAt(i10);
            if (Character.isUpperCase(cCharAt)) {
                sb.append("_");
            }
            sb.append(Character.toLowerCase(cCharAt));
        }
        return sb.toString();
    }

    public static String h(C0362g c0362g) {
        StringBuilder sb = new StringBuilder(c0362g.size());
        for (int i10 = 0; i10 < c0362g.size(); i10++) {
            byte b7 = c0362g.b(i10);
            if (b7 == 34) {
                sb.append("\\\"");
            } else if (b7 == 39) {
                sb.append("\\'");
            } else if (b7 != 92) {
                switch (b7) {
                    case d0.i.DOUBLE_FIELD_NUMBER /* 7 */:
                        sb.append("\\a");
                        break;
                    case 8:
                        sb.append("\\b");
                        break;
                    case 9:
                        sb.append("\\t");
                        break;
                    case 10:
                        sb.append("\\n");
                        break;
                    case ModuleDescriptor.MODULE_VERSION /* 11 */:
                        sb.append("\\v");
                        break;
                    case 12:
                        sb.append("\\f");
                        break;
                    case 13:
                        sb.append("\\r");
                        break;
                    default:
                        if (b7 < 32 || b7 > 126) {
                            sb.append('\\');
                            sb.append((char) (((b7 >>> 6) & 3) + 48));
                            sb.append((char) (((b7 >>> 3) & 7) + 48));
                            sb.append((char) ((b7 & 7) + 48));
                            break;
                        } else {
                            sb.append((char) b7);
                            break;
                        }
                }
            } else {
                sb.append("\\\\");
            }
        }
        return sb.toString();
    }

    public static boolean i(byte b7) {
        return b7 > -65;
    }

    public static final void k(StringBuilder sb, int i10, String str, Object obj) {
        if (obj instanceof List) {
            Iterator it = ((List) obj).iterator();
            while (it.hasNext()) {
                k(sb, i10, str, it.next());
            }
            return;
        }
        if (obj instanceof Map) {
            Iterator it2 = ((Map) obj).entrySet().iterator();
            while (it2.hasNext()) {
                k(sb, i10, str, (Map.Entry) it2.next());
            }
            return;
        }
        sb.append('\n');
        int i11 = 0;
        for (int i12 = 0; i12 < i10; i12++) {
            sb.append(' ');
        }
        sb.append(str);
        if (obj instanceof String) {
            sb.append(": \"");
            C0362g c0362g = C0362g.f6485c;
            sb.append(h(new C0362g(((String) obj).getBytes(AbstractC0379y.f6539a))));
            sb.append('\"');
            return;
        }
        if (obj instanceof C0362g) {
            sb.append(": \"");
            sb.append(h((C0362g) obj));
            sb.append('\"');
            return;
        }
        if (obj instanceof AbstractC0376v) {
            sb.append(" {");
            l((AbstractC0376v) obj, sb, i10 + 2);
            sb.append("\n");
            while (i11 < i10) {
                sb.append(' ');
                i11++;
            }
            sb.append("}");
            return;
        }
        if (!(obj instanceof Map.Entry)) {
            sb.append(": ");
            sb.append(obj.toString());
            return;
        }
        sb.append(" {");
        Map.Entry entry = (Map.Entry) obj;
        int i13 = i10 + 2;
        k(sb, i13, "key", entry.getKey());
        k(sb, i13, "value", entry.getValue());
        sb.append("\n");
        while (i11 < i10) {
            sb.append(' ');
            i11++;
        }
        sb.append("}");
    }

    /* JADX WARN: Removed duplicated region for block: B:57:0x01af  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x0209  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public static void l(androidx.datastore.preferences.protobuf.AbstractC0356a r18, java.lang.StringBuilder r19, int r20) {
        /*
            Method dump skipped, instructions count: 581
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.datastore.preferences.protobuf.N.l(androidx.datastore.preferences.protobuf.a, java.lang.StringBuilder, int):void");
    }

    public abstract String f(byte[] bArr, int i10, int i11);

    public abstract int g(CharSequence charSequence, byte[] bArr, int i10, int i11);

    public abstract int j(byte[] bArr, int i10, int i11);

    public abstract void m(byte[] bArr, int i10, int i11);
}
