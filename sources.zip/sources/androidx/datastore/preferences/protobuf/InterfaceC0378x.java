package androidx.datastore.preferences.protobuf;

import java.util.List;
import java.util.RandomAccess;

/* renamed from: androidx.datastore.preferences.protobuf.x, reason: case insensitive filesystem */
/* loaded from: classes.dex */
public interface InterfaceC0378x extends List, RandomAccess {
    InterfaceC0378x a(int i10);
}
