package androidx.datastore.preferences.protobuf;

import java.util.RandomAccess;

/* loaded from: classes.dex */
public abstract class r extends AbstractC0357b implements RandomAccess, U {
}
