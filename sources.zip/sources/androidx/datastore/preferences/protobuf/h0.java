package androidx.datastore.preferences.protobuf;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class h0 {

    /* renamed from: f */
    public static final h0 f6496f = new h0(0, new int[0], new Object[0], false);

    /* renamed from: a */
    public int f6497a;

    /* renamed from: b */
    public int[] f6498b;

    /* renamed from: c */
    public Object[] f6499c;
    public int d = -1;

    /* renamed from: e */
    public boolean f6500e;

    public h0(int i10, int[] iArr, Object[] objArr, boolean z3) {
        this.f6497a = i10;
        this.f6498b = iArr;
        this.f6499c = objArr;
        this.f6500e = z3;
    }

    public static h0 b() {
        return new h0(0, new int[8], new Object[8], true);
    }

    public final int a() {
        int iN;
        int i10 = this.d;
        if (i10 != -1) {
            return i10;
        }
        int iA = 0;
        for (int i11 = 0; i11 < this.f6497a; i11++) {
            int i12 = this.f6498b[i11];
            int i13 = i12 >>> 3;
            int i14 = i12 & 7;
            if (i14 == 0) {
                iN = C0365j.N(i13, ((Long) this.f6499c[i11]).longValue());
            } else if (i14 == 1) {
                ((Long) this.f6499c[i11]).getClass();
                iN = C0365j.y(i13);
            } else if (i14 == 2) {
                iN = C0365j.t(i13, (C0362g) this.f6499c[i11]);
            } else if (i14 == 3) {
                iA = ((h0) this.f6499c[i11]).a() + (C0365j.K(i13) * 2) + iA;
            } else {
                if (i14 != 5) {
                    throw new IllegalStateException(InvalidProtocolBufferException.b());
                }
                ((Integer) this.f6499c[i11]).getClass();
                iN = C0365j.x(i13);
            }
            iA = iN + iA;
        }
        this.d = iA;
        return iA;
    }

    public final void c(int i10, Object obj) {
        if (!this.f6500e) {
            throw new UnsupportedOperationException();
        }
        int i11 = this.f6497a;
        int[] iArr = this.f6498b;
        if (i11 == iArr.length) {
            int i12 = i11 + (i11 < 4 ? 8 : i11 >> 1);
            this.f6498b = Arrays.copyOf(iArr, i12);
            this.f6499c = Arrays.copyOf(this.f6499c, i12);
        }
        int[] iArr2 = this.f6498b;
        int i13 = this.f6497a;
        iArr2[i13] = i10;
        this.f6499c[i13] = obj;
        this.f6497a = i13 + 1;
    }

    public final void d(H h10) {
        if (this.f6497a == 0) {
            return;
        }
        h10.getClass();
        for (int i10 = 0; i10 < this.f6497a; i10++) {
            int i11 = this.f6498b[i10];
            Object obj = this.f6499c[i10];
            int i12 = i11 >>> 3;
            int i13 = i11 & 7;
            if (i13 == 0) {
                h10.j(i12, ((Long) obj).longValue());
            } else if (i13 == 1) {
                h10.f(i12, ((Long) obj).longValue());
            } else if (i13 == 2) {
                h10.b(i12, (C0362g) obj);
            } else if (i13 == 3) {
                C0365j c0365j = (C0365j) h10.f6426a;
                c0365j.i0(i12, 3);
                ((h0) obj).d(h10);
                c0365j.i0(i12, 4);
            } else {
                if (i13 != 5) {
                    throw new RuntimeException(InvalidProtocolBufferException.b());
                }
                h10.e(i12, ((Integer) obj).intValue());
            }
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof h0)) {
            return false;
        }
        h0 h0Var = (h0) obj;
        int i10 = this.f6497a;
        if (i10 == h0Var.f6497a) {
            int[] iArr = this.f6498b;
            int[] iArr2 = h0Var.f6498b;
            int i11 = 0;
            while (true) {
                if (i11 >= i10) {
                    Object[] objArr = this.f6499c;
                    Object[] objArr2 = h0Var.f6499c;
                    int i12 = this.f6497a;
                    for (int i13 = 0; i13 < i12; i13++) {
                        if (objArr[i13].equals(objArr2[i13])) {
                        }
                    }
                    return true;
                }
                if (iArr[i11] != iArr2[i11]) {
                    break;
                }
                i11++;
            }
        }
        return false;
    }

    public final int hashCode() {
        int i10 = this.f6497a;
        int i11 = (527 + i10) * 31;
        int[] iArr = this.f6498b;
        int iHashCode = 17;
        int i12 = 17;
        for (int i13 = 0; i13 < i10; i13++) {
            i12 = (i12 * 31) + iArr[i13];
        }
        int i14 = (i11 + i12) * 31;
        Object[] objArr = this.f6499c;
        int i15 = this.f6497a;
        for (int i16 = 0; i16 < i15; i16++) {
            iHashCode = (iHashCode * 31) + objArr[i16].hashCode();
        }
        return i14 + iHashCode;
    }
}
